--ID of the package
local package_id = "com.louise.Cutman"
-- prefix of the character id
local character_id = "com.louise.enemy."

function package_requires_scripts()
  --Define characters here.
  Engine.define_character(character_id .. "Cutman", _modpath .. "Cutman")
  Engine.define_character(character_id .. "Rock", _modpath .. "Rock")
end

--package init.
function package_init(package)
  package:declare_package_id(package_id)
  package:set_name("Cutman")
  package:set_description("Cutman")
  package:set_speed(1)
  package:set_attack(15)
  package:set_health(40)
  package:set_preview_texture_path(_modpath .. "preview.png")
end

-- setup the test package
function package_build(mob)

  mob:spawn_player(1, 1, 2)
  local texPath = _modpath .. "BG.png"
  local animPath = _modpath .. "BG.animation"
  mob:set_background(texPath, animPath, 0.2, 0.2)
  local spawner = mob:create_spawner(character_id .. "Cutman", Rank.V1)
  spawner:spawn_at(6, 2)
  local rock1 = create_rock()
  local rock2 = create_rock()
  mob:get_field():spawn(rock1, 2, 2)
  mob:get_field():spawn(rock2, 5, 2)
end

function create_rock()
  local rock_texture = Engine.load_texture(_modpath .. "Rock/battle.png")
  local rock_anim = _modpath .. "Rock/battle.animation"
  local cube = Battle.Obstacle.new(Team.Other)
  cube:set_texture(rock_texture, true)
  cube:get_animation():load(rock_anim)
  cube:get_animation():set_state("IDLE")
  cube:get_animation():set_playback(Playback.Loop)
  cube:set_health(200)
  cube:share_tile(false)
  return cube
end
