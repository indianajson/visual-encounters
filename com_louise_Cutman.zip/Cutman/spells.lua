local BOOMERANG_SOUND = Engine.load_audio(_folderpath .. "boomer.ogg")
local BOOMERANG_SPRITE = Engine.load_texture(_folderpath .. "blade.png")
local BOOMERANG_ANIM = _folderpath .. "blade.animation"

local scissors = Engine.load_texture(_folderpath .. "scissors.png")
local scissors_anim = _folderpath .. "scissors.animation"
local effects_texture = Engine.load_texture(_modpath .. "effect.png")
local effects_anim = _modpath .. "effect.animation"
local battle_helpers = include("battle_helpers.lua")

local kunai_sound = Engine.load_audio(_folderpath .. "kunai.ogg")

---@class Blade
local helper = {}

helper.throw = function(user, damage)

    local anim = user:get_animation()
    anim:set_state("PLAYER_SPECIAL")
    local hit_props = HitProps.new(
        damage,
        Hit.Impact | Hit.Flinch,
        Element.Sword,
        user:get_context(),
        Drag.None
    )

    anim:on_frame(3, function()
        Engine.play_audio(BOOMERANG_SOUND, AudioPriority.High)
        boomerang(user, hit_props)
    end)

    anim:on_complete(function()
        user.set_state(1)
    end)

end


local startmap = { { Direction.Right, Direction.Right, Direction.Down, Direction.Right, Direction.Right,
    Direction.Down },
    { Direction.Up, Direction.Right, Direction.Down, Direction.Up, Direction.Right, Direction.Down },
    { Direction.Up, Direction.Left, Direction.Left, Direction.Up, Direction.Left, Direction.Left } }



helper.summon_scissor = function(user, damage, tile)
    Engine.play_audio(kunai_sound, AudioPriority.Highest)
    local hit_props = HitProps.new(
        damage,
        Hit.Impact | Hit.Flinch,
        Element.Sword,
        user:get_context(),
        Drag.None
    )

    local field = user:get_field()
    ---@class Spell
    local spell = Battle.Obstacle.new(user:get_team())
    local spell_animation = spell:get_animation()


    -- Spell Hit Properties
    spell:set_health(200)
    spell:set_hit_props(hit_props)
    spell:set_facing(user:get_facing())
    spell:set_shadow(Shadow.Small)
    spell:show_shadow(true)
    spell:set_elevation(50)
    spell.speed = 30
    if (user:get_rank() == Rank.NM) then
        spell.speed = 15
    end
    spell_animation:load(scissors_anim)

    spell:set_texture(scissors)
    spell_animation:refresh(spell:sprite())
    spell:sprite():set_layer(-5)
    -- Starting direction is user's facing
    spell.direction = startmap[tile:y()][tile:x()]

    setAnimStateForDir(spell.direction, spell:get_animation())
    spell.next_tile = tile:get_tile(spell.direction, 1)
    spell.frames = 0
    spell.update_func = function(self, dt)
        if (spell.frames > 30) then
            if (not spell:is_sliding()) then
                spell.direction = startmap[spell:get_current_tile():y()][spell:get_current_tile():x()]
                spell.next_tile = spell:get_current_tile():get_tile(spell.direction, 1)
                setAnimStateForDir(spell.direction, spell:get_animation())
                spell:slide(spell.next_tile, frames(spell.speed), frames(spell.speed), ActionOrder.Voluntary, nil)
                spell.frames = 0
            end
        else
            spell.frames = spell.frames + 1
        end
        spell:get_current_tile():attack_entities(spell)
    end
    spell.collision_func = function(self, other)
        user.scissors = user.scissors - 1
        self:erase()
    end
    spell.attack_func = function(self, other)
        battle_helpers.spawn_visual_artifact(self:get_field(), self:get_tile(), effects_texture, effects_anim, "8"
            , 0, 0)

    end
    spell.delete_func = function(self)
        user.scissors = user.scissors - 1
        self:erase()
    end
    spell.can_move_to_func = function(tile)
        return true
    end
    field:spawn(spell, tile)

end

function setAnimStateForDir(dir, anim)
    local animState = "RIGHT"
    if (dir == Direction.Left) then
        animState = "LEFT"
    elseif (dir == Direction.Up) then
        animState = "UP"
    elseif (dir == Direction.Down) then
        animState = "DOWN"
    end
    anim:set_state(animState)
    anim:set_playback(Playback.Loop)

end

function Tiletostring(tile)
    return "Tile: [" .. tostring(tile:x()) .. "," .. tostring(tile:y()) .. "]"
end

---Boomerang!
---@param user Entity
function boomerang(user, hit_props)
    local field = user:get_field()
    ---@class Spell
    local spell = Battle.Spell.new(user:get_team())
    local spell_animation = spell:get_animation()
    local start_tile = user:get_tile(user:get_facing(), 1)
    -- Spell Hit Properties
    spell:set_hit_props(hit_props)
    spell:set_facing(user:get_facing())
    spell:set_shadow(Shadow.Small)
    spell:show_shadow(true)
    spell_animation:load(BOOMERANG_ANIM)
    spell_animation:set_state("DEFAULT")
    spell_animation:set_playback(Playback.Loop)
    spell:set_texture(BOOMERANG_SPRITE)
    spell_animation:refresh(spell:sprite())
    spell:sprite():set_layer(-5)
    -- Starting direction is user's facing
    spell.direction = user:get_facing()
    spell.userfacing = user:get_facing()
    spell.returning = false
    spell.boomer_speed = 9
    spell.next_tile = start_tile:get_tile(spell.direction, 1)
    spell.update_func = function(self, dt)
        if (spell.returning and spell:get_tile() == start_tile) then
            spell:erase()
        end
        if (spell.next_tile:is_edge()) then
            if (spell:get_tile():get_team() == user:get_team()) then
                spell:erase()
            else
                spell.direction = Direction.reverse(spell.direction)
                spell.returning = true
            end
        end
        spell:slide(spell.next_tile, frames(spell.boomer_speed), frames(0), ActionOrder.Voluntary, nil)
        spell.next_tile = spell:get_current_tile():get_tile(spell.direction, 1)
        spell:get_current_tile():attack_entities(self)
    end
    spell.collision_func = function(self, other)
        self:erase()
    end
    spell.attack_func = function(self, other)
        battle_helpers.spawn_visual_artifact(self:get_field(), self:get_tile(), effects_texture, effects_anim, "8"
            , 0, 0)
    end
    spell.delete_func = function(self)
        self:erase()
    end
    spell.can_move_to_func = function(tile)
        return true
    end
    field:spawn(spell, start_tile)
end

return helper
