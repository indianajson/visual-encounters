local print_debug = false

local CHARACTER_TEXTURE = Engine.load_texture(_folderpath.."gfx/battle.grayscaled.png")
local CHARACTER_ANIMPATH = _folderpath.."gfx/battle.animation"

local TARGET_TEXTURE = Engine.load_texture(_folderpath.."gfx/target.grayscaled.png")
local TARGET_PALETTE = Engine.load_texture(_folderpath.."gfx/palette/target.png")
local TARGET_ANIMPATH = _folderpath.."gfx/target.animation"
local TILE_HIT_TEXTURE = Engine.load_texture(_folderpath.."gfx/tile_hit.grayscaled.png")
local TILE_HIT_PALETTE = Engine.load_texture(_folderpath.."gfx/palette/tile_hit.png")
local TILE_HIT_ANIMPATH = _folderpath.."gfx/tile_hit.animation"
local MUZZLEFLASH_TEXTURE = Engine.load_texture(_folderpath.."gfx/muzzleflash.grayscaled.png")
local MUZZLEFLASH_PALETTE = Engine.load_texture(_folderpath.."gfx/palette/muzzleflash.png")
local MUZZLEFLASH_ANIMPATH = _folderpath.."gfx/muzzleflash.animation"

local EFFECT0_TEXTURE = Engine.load_texture(_folderpath.."gfx/effect0.grayscaled.png")
local EFFECT0_PALETTE = Engine.load_texture(_folderpath.."gfx/palette/effect0.png")
local EFFECT0_ANIMPATH = _folderpath.."gfx/effect0.animation"

local CURSOR_AUDIO = Engine.load_audio(_folderpath.."sfx/EXE6_211.ogg", true)
local LOCKON_AUDIO = Engine.load_audio(_folderpath.."sfx/EXE6_103.ogg", true)
local GUN_AUDIO = Engine.load_audio(_folderpath.."sfx/EXE6_301.ogg", true)

local battle_helpers = include("battle_helpers.lua")

-- Battle Chips
local Chip157 = include("chips/com_OFC_card_EXE6_157_Recovery30/recovery/recovery.lua") -- used by RareGunner1.
Chip157.recover_hp = 30
local Chip160 = include("chips/com_OFC_card_EXE6_160_Recovery120/recovery/recovery.lua") -- used by RareGunner2.
Chip160.recover_hp = 120

local function debug_print(text)
    if print_debug then
        print("[Gunner] "..text)
    end
end

--(Function by Alrysc, edited by K1rbYat1Na)
local function graphic_init(type, x, y, texture, palette, animation, layer, state, anim_playback, user, facing, delete_on_complete, relative_to_user, flip)
    texture = texture or nil
    animation = animation or nil
    layer = layer or nil
    state = state or nil
    anim_playback = anim_playback or nil
    facing = facing or nil
    delete_on_complete = delete_on_complete or false
    flip = flip or false
    
    local graphic = nil
    if type == "artifact" then 
        graphic = Battle.Artifact.new()
    elseif type == "spell" then 
        graphic = Battle.Spell.new(user:get_team())
    elseif type == "obstacle" then 
        graphic = Battle.Obstacle.new(user:get_team())
    end
    if palette then
        graphic:store_base_palette(palette)
        graphic:set_palette(graphic:get_base_palette())
    end
    if layer then
        graphic:sprite():set_layer(layer)
    end
    graphic:never_flip(flip)
    if texture then
        graphic:set_texture(texture, false)
    end
    if facing then 
        graphic:set_facing(facing)
    end
    
    if relative_to_user and user:get_facing() == Direction.Left then 
        x = x * -1
    end
    graphic:set_offset(x, y)
    local anim = graphic:get_animation()
    if animation then
        graphic:get_animation():load(animation)
    end
    if state then
        graphic:get_animation():set_state(state)
    end
    if anim_playback then
        graphic:get_animation():set_playback(anim_playback)
    end
    anim:refresh(graphic:sprite())

    if delete_on_complete then 
        anim:on_complete(function()
            graphic:delete()
        end)
    end

    return graphic
end

local function sweep_should_switch_direction(next_tile, team)
    return (next_tile:is_edge() or next_tile:get_team() == team)
end

local function spawn_attack(user, tile, damage, crack_tiles)
    local spell = graphic_init("spell", 0, 0, TILE_HIT_TEXTURE, TILE_HIT_PALETTE, TILE_HIT_ANIMPATH, -3, "0", Playback.Once, user, user:get_facing())
    spell.anim = spell:get_animation()
    spell:hide()
    spell:set_hit_props(
        HitProps.new()
        :dmg(damage)
        :impact()
        :flinch()
        :flash()
        :pierce_ground()
        :retangible()
        :from(user:get_context())
    )
    spell.frames = 1
    spell.on_spawn_func = function()
        debug_print("attack spawned on tile ("..tile:x()..";"..tile:y()..")")
    end
    spell.update_func = function(self)
        for i=1,11 do
            if self.frames == i then
                tile:highlight(Highlight.Flash)
            end
        end
        if self.frames == 12 then
            tile:highlight(Highlight.Solid)
            if crack_tiles then
                if not tile:is_cracked() and not tile:is_hole() then
                    Engine.play_audio(AudioType.PanelCrack, AudioPriority.Immediate)
                    tile:set_state(TileState.Cracked)
                end
            end
            Engine.play_audio(GUN_AUDIO, AudioPriority.Immediate)
            if not tile:is_hole() then
                self:reveal()
                self.anim:set_state("0")
                self.anim:refresh(self:sprite())
            end
            tile:attack_entities(self)
        end
        if self.frames == 13 then
            tile:highlight(Highlight.None)
        end
        if self.frames == 25 then
            self:delete()
        end
        self.frames = self.frames + 1
    end
    spell.attack_func = function(self, other, judge)
        debug_print("attacked tile ("..other:get_tile():x()..";"..other:get_tile():y()..")")
        if not judge:hint_spawn_gfx() then return end
        local offset_x = math.random(2,6)
        if self:get_facing() == Direction.Left then offset_x = math.random(-7,-3) end
        local hit_effect = graphic_init("artifact", (offset_x*2), (math.random(-8,3)*2), EFFECT0_TEXTURE, EFFECT0_PALETTE, EFFECT0_ANIMPATH, -999, "0", Playback.Once, self, self:get_facing(), true, false, true)
        hit_effect:get_animation():on_complete(function() hit_effect:erase() end)
        self:get_field():spawn(hit_effect, other:get_tile())
    end
    user:get_field():spawn(spell, tile)
end

function create_scope(user, scan_finished_callback, reticle_travel_frames, sweep)
    local facing = user:get_facing()
    local field = user:get_field()
    local team = user:get_team()
    local spell = graphic_init("spell", 0, -16*2, TARGET_TEXTURE, TARGET_PALETTE, TARGET_ANIMPATH, -3, "0", Playback.Loop, user, facing)
    spell.anim = spell:get_animation()
    local sprite = spell:sprite()
    spell.move_direction = facing
    spell.update_func = function(self)
        if user:is_deleted() then
            self:delete()
            return
        end
        local cur_anim_state = self.anim:get_state()
        if cur_anim_state == "0" then
            local current_tile = self:get_tile()
            local sweeper_misplaced = current_tile:get_team() == team
            if current_tile:is_edge() or (sweep and sweeper_misplaced) then
                scan_finished_callback(current_tile, false)
                self:delete()
                return
            end
            local next_tile = self:get_tile(self.move_direction, 1)
            if not self:is_sliding() then
                local targets = current_tile:find_characters(function(c)
                    return c:get_health() > 0 and not c:is_team(team)
                end)
                if #targets > 0 then
                    Engine.play_audio(LOCKON_AUDIO, AudioPriority.Immediate)
                    self.anim:set_state("1")              
                    self.anim:on_complete(function()
                        self:delete()
                        pcall(function()
                            scan_finished_callback(current_tile, true)
                        end)
                    end)
                else
                    if not sweep then
                        --just slide like normal
                        self:slide(next_tile, frames(reticle_travel_frames), frames(0), ActionOrder.Voluntary)
                        return
                    end
                    local reticle_should_switch_direction = sweep_should_switch_direction(next_tile, team)
                    if reticle_should_switch_direction then
                        self.move_direction = Direction.reverse(self.move_direction)
                    else
                        self:slide(next_tile, frames(reticle_travel_frames), frames(0), ActionOrder.Voluntary)
                    end
                end
            end
        end
    end
    spell.delete_func = function(self)
        user.reticle_spell = nil
    end
    spell.can_move_to_func = function(tile)
        return true
    end
    return spell
end

--[[
function spell_delayed_bullet(character,target_tile,damage,new_tile_state)
    local facing = character:get_facing()
    local team = character:get_team()
    local spell = Battle.Spell.new(team)
    local anim = spell:get_animation()
    local sprite = spell:sprite()
    spell:set_texture(ground_bullet_texture,true)
    anim:load(ground_bullet_animation_path)
    anim:set_state("DEFAULT")
    anim:refresh(sprite)
    anim:set_playback(Playback.Once)
    spell.frames_before_impact = 10
    spell.warning_frames = 3
    spell:set_hit_props(HitProps.new(
        damage,
        Hit.Flash|Hit.Impact|Hit.Flinch,
        Element.None,
        character:get_context(),
        Drag.None)
    )
    anim:on_complete(function()
        spell:delete()
    end)
    spell.update_func = function (self)
        local tile = spell:get_current_tile()
        if self.warning_frames > 0 then
            tile:highlight(Highlight.Solid)
            self.warning_frames = self.warning_frames - 1
        end
        if self.frames_before_impact > 0 then
            self.frames_before_impact = self.frames_before_impact -1
        else
            tile:attack_entities(self)
            if new_tile_state then
                tile:set_state(new_tile_state)
            end
        end
    end
    spell.can_move_to_func = function()
        return true
    end
    return spell
end
]]

--[[
function action_fire(character, target_tile, shots, shots_animated)
    local action = Battle.CardAction.new(character, "ATTACK")
    local field = character:get_field()
    local team = character:get_team()
    local sweeping = character.sweeping_reticle
	action:set_lockout(make_animation_lockout())

    --local f_idle = {1, 0.017}
    local f_left_flash = {1, 0.017}
    local f_left_fade_1 = {2, 0.017}
    local f_left_fade_2 = {3, 0.017}
    local f_left_fade_3 = {4, 0.033}
    local f_left_fade_4 = {5, 0.017}
    local f_right_flash = {6, 0.017}
    local f_right_fade_1 = {7, 0.017}
    local f_right_fade_2 = {8, 0.017}
    local f_right_fade_3 = {9, 0.033}
    local f_right_fade_4 = {10, 0.017}
    action.frames = {}
    local animate_left = true
    for i=1, shots_animated do
        if animate_left then
            table.insert(action.frames, f_left_flash)
            table.insert(action.frames, f_left_fade_1)
            table.insert(action.frames, f_left_fade_2)
            table.insert(action.frames, f_left_fade_3)
            table.insert(action.frames, f_left_fade_4)
            animate_left = false
        else
            table.insert(action.frames, f_right_flash)
            table.insert(action.frames, f_right_fade_1)
            table.insert(action.frames, f_right_fade_2)
            table.insert(action.frames, f_right_fade_3)
            table.insert(action.frames, f_right_fade_4)
            animate_left = true
        end
    end
    action.frames[1] = {1, 0.000} --(+)1
    action.frames[#action.frames] = {10, 0.033} --(-)1
    local FRAME_DATA = make_frame_data(action.frames)
    action:override_animation_frames(FRAME_DATA)
    local function gun_shooty_pew()
        local scanned_tile = target_tile
        local sweep_direction = character:get_facing()
        if sweeping then
            for i=0, action.bullets_fired do
                scanned_tile = scanned_tile:get_tile(sweep_direction, math.min(i,1))
                if sweep_should_switch_direction(scanned_tile,team) then
                    sweep_direction = Direction.reverse(sweep_direction)
                    scanned_tile = scanned_tile:get_tile(sweep_direction, 2)
                end
            end
        end
        --local spell_bullet = spell_delayed_bullet(character,scanned_tile,character.bullet_damage,character.set_tile_state)
        local spell_bullet = spawn_attack(character, scanned_tile, character.damage_machinegun, character.crack_tiles)
        field:spawn(spell_bullet, scanned_tile:x(), scanned_tile:y())
        action.bullets_fired = action.bullets_fired + 1
    end
    action.execute_func = function(self, user)
        action.bullets_fired = 0
        user:toggle_counter(true)
        self:add_anim_action(1, function()
            gun_shooty_pew()
        end)
        self:add_anim_action(10, function()
            user:toggle_counter(false)
        end)
        for i=2,#self.frames,10 do
            self:add_anim_action(i, function()
                local muzzle_fx = graphic_init("artifact", 31*2, 0)
                muzzle_fx:set_elevation(28*2)
                field:spawn(muzzle_fx, self:get_tile())
            end)
        end
        for i=7,#self.frames,10 do
            self:add_anim_action(i, function()
                gun_shooty_pew()
            end)
        end
        for i=1, shots do
            self:add_anim_action(1+(i*10), function()
                gun_shooty_pew()
            end)
        end
    end
    return action
end
]]

--[[
function action_scan(character)
    local facing = character:get_facing()
    local field = character:get_field()
    local team = character:get_team()
    local reticle_spawn_tile = character:get_tile()
    local action = Battle.CardAction.new(character, "SEARCH")
	action:set_lockout(make_animation_lockout())
    action.update_func = function (self)
    end
    action.execute_func = function(self, user)
        self:add_anim_action(4, function()
            if self.reticle_spell then
                return
            end
            local scan_finished_callback = function(tile,target_was_found)
                if target_was_found then
                    character.ai_state = "firing"
                    character.animation:set_state("PREATTACK")
                    character.attack_action = action_fire(character,tile,character.shots,character.shots*2)
                    character.attack_action.action_end_func = function ()
                        character.ai_state = "cooldown"
                        character.cooldown = 30
                    end
                    character:card_action_event(character.attack_action, ActionOrder.Immediate)
                else
                    character.ai_state = "cooldown"
                    character.cooldown = 30
                end
                if self then
                    self:end_action()
                end
            end
            self.reticle_spell = create_scope(character, scan_finished_callback, character.reticle_travel_frames, character.sweeping_reticle)
            Engine.play_audio(CURSOR_AUDIO, AudioPriority.Highest)
            self.reticle_spell.on_delete = function()
                self.reticle_spell = nil
            end
            if character.sweeping_reticle then
                --for reticles that sweep back and forth, find first tile of another team's to spawn the reticle on
                while reticle_spawn_tile:get_team() == team do
                    reticle_spawn_tile = reticle_spawn_tile:get_tile(facing,1)
                end
            end
            field:spawn(self.reticle_spell, reticle_spawn_tile:x(), reticle_spawn_tile:y())
        end)
	end
    return action
end
]]

local function package_init(self, character_info)
    debug_print("package_init called")
    --Required function, main package information

    --Load character resources
	self.texture = CHARACTER_TEXTURE
	self.animation = self:get_animation()
	self.animation:load(CHARACTER_ANIMPATH)

    --Set up character meta
    self:set_name(character_info.name)
    self:set_health(character_info.health)
    self:set_texture(self.texture, true)
    self:set_height(50)
    self:share_tile(false)
    self:set_explosion_behavior(2, 1, false)
    self:set_offset(0,0)
    self:set_palette(Engine.load_texture(_folderpath.."gfx/palette/battle-"..self:get_rank()..".png"))

    -- DefenseRules
    self.defense = Battle.DefenseVirusBody.new()
    self:add_defense_rule(self.defense)
    
    --Initial state
    self.animation:set_state("PLAYER_IDLE")
    self.animation:set_playback(Playback.Loop)
    self.damage = character_info.damage
    self.damage_machinegun = character_info.damage_machinegun
    self.reticle_travel_frames = character_info.reticle_travel_frames
    self.shots = character_info.shots
    self.sweeping_reticle = character_info.sweeping_reticle
    self.crack_tiles = character_info.crack_tiles
    self.counter_frames = 30
    self.ai_state = "idle"
    self.cooldown = 30
    self.reticle_spell = nil
    self.bullets_fired = 0
    self.target_tile = nil

    self.muzzle_fx1 = self:create_node()
    self.muzzle_fx1:set_texture(MUZZLEFLASH_TEXTURE)
    self.muzzle_fx1:set_layer(-1)
    self.muzzle_fx1:enable_parent_shader(true)
    self.muzzle_anim1 = Engine.Animation.new(MUZZLEFLASH_ANIMPATH)
    self.muzzle_anim1:set_state("1")
    self.muzzle_anim1:refresh(self.muzzle_fx1)
    self.muzzle_anim1:set_playback(Playback.Once)
    
    self.muzzle_fx2 = self:create_node()
    self.muzzle_fx2:set_texture(MUZZLEFLASH_TEXTURE)
    self.muzzle_fx2:set_layer(-1)
    self.muzzle_fx2:enable_parent_shader(true)
    self.muzzle_anim2 = Engine.Animation.new(MUZZLEFLASH_ANIMPATH)
    self.muzzle_anim2:set_state("1")
    self.muzzle_anim2:refresh(self.muzzle_fx2)
    self.muzzle_anim2:set_playback(Playback.Once)

    local ref = self
    --This is how we animate nodes.
    self.animate_component = Battle.Component.new(self, Lifetimes.Battlestep)
    self.animate_component.update_func = function(self, dt)
        ref.muzzle_anim1:update(dt, ref.muzzle_fx1)
        ref.muzzle_anim2:update(dt, ref.muzzle_fx2)
    end
    self:register_component(self.animate_component)
    
    --Battle Chips
    self.battle_chip_start = false
    self.battle_chip_timer = 300
    self.battle_chip_amount = 0
    self.battle_chip = nil
    self.battle_chip_id = 0

    local character = self
    local scanning_interrupt = function()
        if self.reticle_spell then
            self.reticle_spell:delete()
        end
        --[[
        if character.current_scan_action then
            character.current_scan_action:end_action()
        end]]
        --self.ai_state = "idle"
        --self.animation:set_state("PLAYER_IDLE")
        if self.ai_state == "scanning" then
            self.cooldown = 0
            self.frames = 1
            self.ai_state = "idle"
        end
    end
    self:register_status_callback(Hit.Stun, scanning_interrupt)
    --self:register_status_callback(Hit.Drag, scanning_interrupt)
    self.can_move_to_func = function(tile)
        --if self:is_rooted() then return false end
        if tile:is_edge() or not tile:is_walkable() then
            return false
        end
        if(tile:is_reserved({self:get_id()})) then
            return false
        end
        if tile == self:get_tile() then
            return true
        end
        if tile:get_team() ~= self:get_team() then
            return false
        end
        return not check_obstacles(tile) and not check_characters_true(tile)
    end
    self.frames = 1
    self.update_func = function(character, dt)
        if self.battle_chip_start then
            if self.battle_chip_timer > 0 then
                self.battle_chip_timer = self.battle_chip_timer - 1
            else
                if self.battle_chip_amount <= 0 then
                    self.battle_chip_start = false
                end
            end
        end
        if self.ai_state == "cooldown" then
            if self.frames == 1 then
                self.animation:set_state("PLAYER_IDLE")
                self.animation:refresh(self:sprite())
            end
            if self.frames == self.cooldown then
                self.cooldown = 0
                self.frames = 1
                self.ai_state = "idle"
            end
        end
        if self.ai_state == "idle" then
            if self.frames == 1 then
                self.animation:set_state("PLAYER_IDLE")
                self.animation:refresh(self:sprite())
            end
            if self.battle_chip_amount > 0 and self:get_health() <= self:get_max_health()/2 then
                debug_print("using Chip")
                self.battle_chip_amount = self.battle_chip_amount - 1
                local chip_action = self.battle_chip.card_create_action(self)
                local props = chip_action:copy_metadata()
                if self.battle_chip_id == 157 then
                    props.shortname = "Recovery30"
                    props.damage = 0
                    props.time_freeze = false
                    props.element = Element.None
                    props.can_boost = false
                elseif self.battle_chip_id == 160 then
                    props.shortname = "Recovery120"
                    props.damage = 0
                    props.time_freeze = false
                    props.element = Element.None
                    props.can_boost = false
                end
                chip_action = self.battle_chip.card_create_action(self, props)
	            chip_action:set_metadata(props)
                self:card_action_event(chip_action, ActionOrder.Voluntary)
                --chip_action.action_end_func = function()
                    --self.battle_chip_timer = 300
                --end
            else
                -- If Confused or Blind, can't see anything ahead.
                if self:can_attack() and not self:is_confused() and not self:is_blind() then
                    local targets = battle_helpers.find_targets_ahead(self)
                    local filtered_targets = {}
                    for index, entity in ipairs(targets) do
                        if entity:get_team() ~= Team.Other then
                            filtered_targets[#filtered_targets+1] = entity
                        end
                    end
                    if #filtered_targets > 0 or self.sweeping_reticle then
                        self.frames = 1
                        self.ai_state = "scanning"
                        --[[
                        local action = action_scan(self)
                        action.action_end_func = function()
                            if action.reticle_spell then
                                action.reticle_spell:delete()
                            end
                            self.current_scan_action = nil
                        end
                        self.current_scan_action = action
                        self:card_action_event(action, ActionOrder.Voluntary)]]
                    end
                end
            end
        end
        if self.ai_state == "scanning" then
            local scan_finished_callback = function(tile, target_was_found)
                if target_was_found then
                    self.frames = 1
                    self.ai_state = "firing"
                    self.target_tile = tile
                    --self.animation:set_state("PREATTACK")
                    --self.attack_action = action_fire(self, tile, self.shots, self.shots*2)
                    --self:card_action_event(self.attack_action, ActionOrder.Immediate)
                else
                    self.frames = 0
                    self.ai_state = "cooldown"
                    self.cooldown = 30
                end
            end
            if self.frames == 1 then
                self.animation:set_state("SEARCH")
                self.animation:refresh(self:sprite())
            end
            if self.frames == 26 then
                if self.reticle_spell then
                    return
                end
                self.reticle_spell = create_scope(self, scan_finished_callback, self.reticle_travel_frames, self.sweeping_reticle)
                Engine.play_audio(CURSOR_AUDIO, AudioPriority.Highest)
                local reticle_spawn_tile = self:get_tile()
                if self.sweeping_reticle then
                    --for reticles that sweep back and forth, find first tile of another team's to spawn the reticle on
                    for i=0,self:get_field():width() do
                        local new_tile = reticle_spawn_tile:get_tile(self:get_facing(),i)
                        if new_tile:get_team() ~= self:get_team() then
                            reticle_spawn_tile = new_tile
                            break
                        end
                    end
                end
                self:get_field():spawn(self.reticle_spell, reticle_spawn_tile)
            end
        end
        if self.ai_state == "firing" then
            local function gun_shooty_pew()
                local scanned_tile = self.target_tile
                local sweep_direction = self:get_facing()
                if self.sweeping_reticle then
                    for i=0, self.bullets_fired do
                        scanned_tile = scanned_tile:get_tile(sweep_direction, math.min(i,1))
                        if sweep_should_switch_direction(scanned_tile, self:get_team()) then
                            sweep_direction = Direction.reverse(sweep_direction)
                            scanned_tile = scanned_tile:get_tile(sweep_direction, 2)
                        end
                    end
                end
                --local spell_bullet = spell_delayed_bullet(self,scanned_tile,self.bullet_damage,self.set_tile_state)
                local spell_bullet = spawn_attack(self, scanned_tile, self.damage_machinegun, self.crack_tiles)
                --self:get_field():spawn(spell_bullet, scanned_tile:x(), scanned_tile:y())
                self.bullets_fired = self.bullets_fired + 1
            end
            --[[
            if self.frames == 2 then --9 16
            end]]
            if self.frames == 1 then --15
                --print("self.frames == 1")
                self.animation:set_state("ATTACK")
                self.animation:set_playback(Playback.Loop)
                self.animation:refresh(self:sprite())
                self.bullets_fired = 0
                self:toggle_counter(true)
            end
            if self.frames == self.counter_frames+1 then
                --print("self.frames == self.counter_frames+1")
                self:toggle_counter(false)
            end
            for i=1, 1+((self.shots-1)*10), 10 do
                if self.frames == i then
                    --print("self.frames == 1+((self.shots-1)*10)")
                    gun_shooty_pew()
                end
            end
            for i=1, (self.shots+1)*10, 15 do
                if self.frames == i then
                    --print("self.frames == i")
                    self.muzzle_anim1:set_state("0")
                    self.muzzle_anim1:refresh(self.muzzle_fx1)
                end
                if self.frames == i+7 then
                    --print("self.frames == i+7")
                    self.muzzle_anim2:set_state("0")
                    self.muzzle_anim2:refresh(self.muzzle_fx2)
                end
            end
            if self.frames == (self.shots*10)+1 then
                --print("self.frames == (self.shots*10)+1")
                self.muzzle_anim1:set_state("1")
                self.muzzle_anim1:refresh(self.muzzle_fx1)
                self.muzzle_anim2:set_state("1")
                self.muzzle_anim2:refresh(self.muzzle_fx2)
            end
            if self.frames == (self.shots*10)+2 then
                --print("self.frames == (self.shots*10)+2")
                self.frames = 0
                self.ai_state = "cooldown"
                self.cooldown = 30
            end
        end
        self.frames = self.frames + 1
    end
    self.battle_start_func = function(self)
        debug_print("battle_start_func called")
        self.muzzle_fx1:set_offset(31,-28)
        self.muzzle_fx2:set_offset(34,-33)
        --[[
        if self:get_facing() == Direction.Right then
            self.muzzle_fx1:set_offset( 31*2 , -28*2)
            self.muzzle_fx2:set_offset( 34*2 , -33*2)
        else
            self.muzzle_fx1:set_offset(-31*2 , -28*2)
            self.muzzle_fx2:set_offset(-34*2 , -33*2)
        end]]
    end
    self.battle_end_func = function(self)
        debug_print("battle_end_func called")
    end
    self.on_spawn_func = function(self, spawn_tile) 
        debug_print("on_spawn_func called")
        if character_info.name_on_spawn then
            self:set_name(character_info.name)
        end
        if self:get_rank() == Rank.Rare1 then
            local chance = math.random(1,2)
            if chance == 1 then
                self.battle_chip_amount = 1
                self.battle_chip = Chip157
                self.battle_chip_id = 157
                if self.battle_chip_amount == 1 then
                    print("RareGunner has a BattleChip: Recovery30")
                elseif self.battle_chip_amount > 1 then
                    print("RareGunner has "..self.battle_chip_amount.." BattleChips: Recovery30")
                end
            end
        elseif self:get_rank() == Rank.Rare2 then
            local chance = math.random(1,2)
            if chance == 1 then
                self.battle_chip_amount = 1
                self.battle_chip = Chip160
                self.battle_chip_id = 160
                if self.battle_chip_amount == 1 then
                    print("RareGunner2 has a BattleChip: Recovery120")
                elseif self.battle_chip_amount > 1 then
                    print("RareGunner2 has "..self.battle_chip_amount.." BattleChips: Recovery120")
                end
            end
        end
    end
    self.delete_func = function(self)
        scanning_interrupt()
    end
end

-- Checks for non-zero-health Obstacles.
function check_obstacles(tile)
    local ob = tile:find_obstacles(function(o)
        if o:get_animation():has_state("PASS_THROUGH") or o:get_name() == "CANTINTERACT" then
            return false
        else
            return true
        end
        return o:get_health() > 0
    end)
    return #ob > 0 
end

-- Checks for unfriendly Characters.
function check_characters(tile, self)
    local characters = tile:find_characters(function(c)
        return c:get_id() ~= self:get_id() and c:get_team() ~= self:get_team()
    end)
    return #characters > 0
end

-- Checks for any Characters.
function check_characters_true(tile)
    local characters = tile:find_characters(function(c)
        return c:get_health() > 0
    end)
    return #characters > 0
end

return package_init