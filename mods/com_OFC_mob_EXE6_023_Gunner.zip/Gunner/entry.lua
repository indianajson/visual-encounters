local shared_package_init = include("../Gunner/character.lua")

function package_init(character)
    local character_info = {
        name = "Gunner",
        name_on_spawn = true,
        health = 60,
        damage = 10,
        damage_machinegun = 10,
        sweeping_reticle = false,
        reticle_travel_frames = 13,
        shots = 3,
        search_type = 0,
        crack_tiles = false
    }
    if character:get_rank() == Rank.V1 then
        character_info.name_on_spawn = false
    end
    if character:get_rank() == Rank.V2 then
        character_info.name = "Shooter"
        character_info.health = 140
        character_info.damage = 30
        character_info.sweeping_reticle = true
        character_info.reticle_travel_frames = 30
        character_info.shots = 5
    end
    if character:get_rank() == Rank.V3 then
        character_info.name = "Sniper"
        character_info.health = 220
        character_info.damage = 50
        character_info.reticle_travel_frames = 10
    end
    if character:get_rank() == Rank.SP then
        character_info.name_on_spawn = false
        character_info.health = 250
        character_info.damage = 80
        character_info.sweeping_reticle = true
        character_info.reticle_travel_frames = 17
        character_info.shots = 7
        character_info.crack_tiles = true
    end
    if character:get_rank() == Rank.Rare1 then
        character_info.name = "RarGunner"
        character_info.health = 180
        character_info.damage = 40
        character_info.reticle_travel_frames = 9
        character_info.crack_tiles = true
    end
    if character:get_rank() == Rank.Rare2 then
        character_info.name = "RarGunnr2"
        character_info.health = 250
        character_info.damage = 100
        character_info.sweeping_reticle = true
        character_info.reticle_travel_frames = 13
        character_info.shots = 7
        character_info.crack_tiles = true
    end
    shared_package_init(character,character_info)
end