local teleport_animation_path = _modpath .. "teleport.animation"
local teleport_texture_path = _modpath .. "teleport.png"
local teleport_texture = Engine.load_texture(teleport_texture_path)

local debug = false
local function debug_print(text)
    if debug then
        print("[spikey] " .. text)
    end
end

local MobTracker = include("mob_tracker.lua")
local left_mob_tracker = MobTracker:new()
local right_mob_tracker = MobTracker:new()
function get_tracker_from_direction(facing)
    if facing == Direction.Left then
        return left_mob_tracker
    elseif facing == Direction.Right then
        return right_mob_tracker
    end
end

function advance_a_turn_by_facing(facing)
    local mob_tracker = get_tracker_from_direction(facing)
    return mob_tracker:advance_a_turn()
end

function get_active_mob_id_for_same_direction(facing)
    local mob_tracker = get_tracker_from_direction(facing)
    return mob_tracker:get_active_mob()
end

function add_enemy_to_tracking(enemy)
    local facing = enemy:get_facing()
    local id = enemy:get_id()
    local mob_tracker = get_tracker_from_direction(facing)
    mob_tracker:add_by_id(id)
end

function remove_enemy_from_tracking(enemy)
    local facing = enemy:get_facing()
    local id = enemy:get_id()
    local mob_tracker = get_tracker_from_direction(facing)
    mob_tracker:remove_by_id(id)
end

-- Required function, main package information
function package_init(self, ezencounters_data)
    -- EZENCOUNTERS MAX-HP SUPPORT v11 --
    do
        local payload = ezencounters_data
        if type(payload) == "table" then
            local ids = {"com.Dawn.char.Spikey"}
            local aliases = {["Spikey"]=true}
            local requested = nil
            local conflict = false
            local maxima = payload.__ezencounters_hp_max_by_package
            if type(maxima) == "table" then
                for _, id in ipairs(ids) do
                    local value = tonumber(maxima[id])
                    if value ~= nil and value > 0 and value == value and value ~= math.huge then
                        if requested ~= nil and requested ~= value then conflict = true end
                        requested = value
                    end
                end
            end
            -- Some engine builds pass an independent copy of encounter data
            -- to the Character package. Resolve from original enemy entries
            -- as well, rather than depending on a mutation in package_build.
            if requested == nil and type(payload.enemies) == "table" then
                for _, enemy in ipairs(payload.enemies) do
                    if type(enemy) == "table" and aliases[enemy.name] then
                        local value = tonumber(enemy.max_hp)
                        if value == nil and #payload.enemies == 1 then
                            value = tonumber(payload.max_hp)
                        end
                        if value ~= nil and value > 0 and value == value and value ~= math.huge then
                            if requested ~= nil and requested ~= value then conflict = true end
                            requested = value
                        end
                    end
                end
            end
            if not conflict and requested ~= nil and requested == math.floor(requested) then
                print("[ezencounters hp] INITIAL MAX HP", ids[1], requested)
                self:set_health(requested)
            end
        end
    end

    debug_print("package_init called")
    -- Load character resources
    self.texture = Engine.load_texture(_modpath .. "battle.greyscaled.png")
    self.animation = self:get_animation()
    self.animation:load(_modpath .. "battle.animation")
    -- Set up character meta
    self:set_texture(self.texture, true)
    self:set_height(54)
    self:share_tile(false)
    self:set_explosion_behavior(1, 1, false)
    self:set_offset(0, 0)
    self:set_name("Spikey")
    self:set_element(Element.Fire)
    local rank = self:get_rank()
    if rank == Rank.V2 then
        self.__ezhp_native_max_hp = (140)
        self:set_palette(Engine.load_texture(_modpath .. "battle_v2.palette.png"))
        self.move_before_attack = 6
        self.current_moves = 6
        self.cascade_frame_index = 10
    elseif rank == Rank.V3 then
        self.__ezhp_native_max_hp = (190)
        self:set_palette(Engine.load_texture(_modpath .. "battle_v3.palette.png"))
        self.move_before_attack = 5
        self.current_moves = 5
        self.cascade_frame_index = 5
    elseif rank == Rank.SP then
        self.__ezhp_native_max_hp = (260)
        self:set_palette(Engine.load_texture(_modpath .. "battle_v4.palette.png"))
        self.move_before_attack = 3
        self.current_moves = 3
        self.cascade_frame_index = 3
    else
        self.__ezhp_native_max_hp = (90)
        self:set_palette(Engine.load_texture(_modpath .. "battle_v1.palette.png"))
        self.move_before_attack = 7
        self.current_moves = 7
        self.cascade_frame_index = 16
    end

    --defense rules
    self.defense = Battle.DefenseVirusBody.new()
    self:add_defense_rule(self.defense)

    -- Initial state
    self.animation:set_state("IDLE")
    self.animation:set_playback(Playback.Loop)
    self.frames_between_actions = 40
    self.ai_wait = self.frames_between_actions
    self.ai_taken_turn = false

    self.update_func = function(self, dt)
        take_turn(self)
        if self.current_moves <= 0 then
            initiate_attack(self)
        end
    end

    self.battle_start_func = function(self)
        debug_print("battle_start_func called")
        local field = self:get_field()
        add_enemy_to_tracking(self)
        local mob_sort_func = function(a, b)
            local var_a = Battle.Character.from(field:get_entity(a)):get_rank()
            local var_b = Battle.Character.from(field:get_entity(b)):get_rank()
            return var_a < var_b
        end
        left_mob_tracker:sort_turn_order(mob_sort_func)
        right_mob_tracker:sort_turn_order(mob_sort_func)
    end
    self.battle_end_func = function(self)
        debug_print("battle_end_func called")
        left_mob_tracker:clear()
        right_mob_tracker:clear()
    end
    self.on_spawn_func = function(self, spawn_tile)
        debug_print("on_spawn_func called")
        left_mob_tracker:clear()
        right_mob_tracker:clear()
    end
    self.can_move_to_func = function(tile)
        debug_print("can_move_to_func called")
        return is_tile_free_for_movement(tile, self)
    end
    self.delete_func = function(self)
        debug_print("delete_func called")
        remove_enemy_from_tracking(self)
    end
end

function take_turn(self)
    local id = self:get_id()
    if self.ai_wait > 0 or self.ai_taken_turn then
        self.ai_wait = self.ai_wait - 1
        return
    end

    local moved_randomly = move_at_random(self)

    if moved_randomly then
        self.ai_wait = self.frames_between_actions
        self.ai_taken_turn = false
        self.current_moves = self.current_moves - 1
        return
    else
        self.ai_wait = self.frames_between_actions
        self.ai_taken_turn = false
        return
    end
end

local function find_best_target(virus)
    if not virus or virus and virus:is_deleted() then return end
    local target = virus:get_target() --Grab a basic target from the virus itself.
    local field = virus:get_field() --Grab the field so you can scan it.
    local query = function(c)
        return c:get_team() ~= virus:get_team() --Make sure you're not targeting the same team, since that won't work for an attack.
    end
    local potential_threats = field:find_characters(query) --Find CHARACTERS, not entities, to attack.
    local goal_hp = 999999 --Start with a ridiculous health.
    if #potential_threats > 0 then --If the list is bigger than 0, we go in to a loop.
        for i = 1, #potential_threats, 1 do --The pound sign, or hashtag if you're more familiar with that term, is used to denote length of a list or array in lua.
            local possible_target = potential_threats[i] --Index with square brackets.
            --Make sure it exists, is not deleted, and that its health is less than the goal HP. First one always will be.
            if possible_target and not possible_target:is_deleted() and possible_target:get_health() <= goal_hp then
                --Make it the new target. This way the lowest HP target is attacked.
                target = possible_target
            end
        end
    end
    --Return whoever the target is.
    return target
end

function initiate_attack(self)
    local id = self:get_id()
    if self.ai_wait > 0 or self.ai_taken_turn then
        self.ai_wait = self.ai_wait - 1
        return
    end

    local moved = move_towards_character(self)

    if not moved then
        return
    end

    self.current_moves = self.move_before_attack

    local fireball_action = action_fireball(self)
    local next_action = fireball_action
    next_action.action_end_func = function()
        local facing = self:get_facing()
        self.ai_wait = self.frames_between_actions
        self.ai_taken_turn = false
        advance_a_turn_by_facing(facing)
    end
    self:card_action_event(next_action, ActionOrder.Voluntary)
end

function move_at_random(self)
    local field = self:get_field()
    local target_tile = nil
    local tile_array = {}
    local moved = false
    for x = 1, 6, 1 do
        for y = 1, 3, 1 do
            local prospective_tile = field:tile_at(x, y)
            if self.can_move_to_func(prospective_tile) then
                table.insert(tile_array, prospective_tile)
            end
        end
    end
    if #tile_array == 0 then return false end
    target_tile = tile_array[math.random(1, #tile_array)]
    if target_tile then
        target_tile:reserve_entity_by_id(self:get_id())
        moved = self:teleport(target_tile, ActionOrder.Immediate)
        if moved then
            self:set_facing(target_tile:get_facing())
            spawn_visual_artifact(target_tile, self, teleport_texture, teleport_animation_path, "SMALL_TELEPORT_FROM", 0, 0)
        end
    end
    return moved
end

function move_towards_character(self)
    local target_character = find_best_target(self)
    if target_character == nil then return false end
    local tile = self:get_current_tile()
    local moved = false
    local target_movement_tile = nil
    for i = 1, 6, 1 do
        if target_movement_tile ~= nil then
            break
        else
            local check_tile = target_character:get_tile(target_character:get_facing(), i)
            if self.can_move_to_func(check_tile) then
                target_movement_tile = check_tile
            end
        end
    end
    if target_movement_tile then
        target_movement_tile:reserve_entity_by_id(self:get_id())
        moved = self:teleport(target_movement_tile, ActionOrder.Immediate)
        if moved then
            self:set_facing(target_movement_tile:get_facing())
            spawn_visual_artifact(tile, self, teleport_texture, teleport_animation_path, "SMALL_TELEPORT_FROM", 0, 0)
        end
    end
    return moved
end

function action_fireball(character)
    debug_print("started fireball action")
    local action_name = "fireball"
    local facing = character:get_facing()
    debug_print('action ' .. action_name)
    --Set the damage. Default is 30.
    local damage = 30
    local rank = character:get_rank()
    if rank == Rank.V2 then
        damage = 60
    elseif rank == Rank.V3 then
        damage = 90
    elseif rank == Rank.SP then
        damage = 150
    end
    local action = Battle.CardAction.new(character, "ATTACK")
    action:set_lockout(make_animation_lockout())
    action.execute_func = function(self, user)
        self:add_anim_action(2, function()
            character:toggle_counter(true)
        end)
        self:add_anim_action(4, function()
            local tile = character:get_tile(facing, 1)
            spawn_fireball(character, tile, facing, damage, character.cascade_frame_index)
        end)
        self:add_anim_action(6, function()
            character:toggle_counter(false)
        end)
    end
    character.ai_taken_turn = true
    return action
end

function is_tile_free_for_movement(tile, character)
    --Basic check to see if a tile is suitable for a chracter of a team to move to
    if not tile then return false end --If the tile isn't real, lol.
    if not character:is_team(tile:get_team()) then return false end --If it's red and we're blue / blue and we're red, lol.
    if not tile:is_walkable() then return false end --If it's not walkable and we're a Spikey, lol.
    local occupants = tile:find_entities(function(ent) --Setup filtering for obstacles & characters.
        if Battle.Character.from(ent) ~= nil or Battle.Obstacle.from(ent) ~= nil then
            return true
        end
    end)
    if #occupants > 0 then --If it's occupied by an obstacle or character, lol.
        return false
    end
    --Cool let's go there.
    return true
end

function spawn_visual_artifact(tile, character, texture, animation_path, animation_state, position_x, position_y)
    local field = character:get_field()
    local visual_artifact = Battle.Artifact.new()
    visual_artifact:set_texture(texture, true)
    local anim = visual_artifact:get_animation()
    anim:load(animation_path)
    anim:set_state(animation_state)
    anim:on_complete(function()
        visual_artifact:delete()
    end)
    visual_artifact:sprite():set_offset(position_x, position_y)
    field:spawn(visual_artifact, tile:x(), tile:y())
end

function spawn_fireball(owner, tile, direction, damage, cascade_frame_index)
    debug_print("in spawn fireball")
    local owner_id = owner:get_context()
    local team = owner:get_team()
    local field = owner:get_field()
    local fireball_texture = Engine.load_texture(_modpath .. "fireball.png", true)
    local fireball_sfx = Engine.load_audio(_modpath .. "sfx.ogg", true)
    local explosion_texture = Engine.load_texture(_modpath .. "spell_explosion.png")
    Engine.play_audio(fireball_sfx, AudioPriority.Low)
    local spell = Battle.Spell.new(team)
    spell:set_texture(fireball_texture)
    spell:set_facing(direction)

    spell:highlight_tile(Highlight.Solid)
    spell:set_hit_props(
        HitProps.new(
            damage,
            Hit.Impact | Hit.Flash,
            Element.Fire,
            owner_id,
            Drag.None
        )
    )
    local sprite = spell:sprite()
    sprite:set_layer(-1)
    local animation = spell:get_animation()
    animation:load(_modpath .. "fireball.animation")
    animation:set_state("DEFAULT")
    animation:set_playback(Playback.Loop)
    animation:refresh(sprite)

    spell.has_hit = false
    spell.update_func = function(self, dt)
        local own_tile = self:get_tile()
        own_tile:attack_entities(self)
        --Erase spell if we're on an edge and we've started sliding, but AREN'T currently sliding. Make it clean.
        if own_tile:is_edge() and not self:is_sliding() and self.slide_started then self:delete() end

        --Destination is one tile ahead.
        local dest = self:get_tile(spell:get_facing(), 1)
        local ref = self
        --If a hit has not landed...
        if not self.has_hit then
            --Slide for the fireball's slide time. 12f for V1, 9f for V2, 6f for V3. Signal the slide has started.
            self:slide(dest, frames(cascade_frame_index), frames(0), ActionOrder.Voluntary, function() ref.slide_started = true end)
        end
    end
    local function rank_relevant_boom(attack, explosion_table)
        for explosions = 1, #explosion_table, 1 do
            if explosion_table[explosions] and not explosion_table[explosions]:is_edge() then
                local hitbox = Battle.Hitbox.new(spell:get_team())
                hitbox:set_hit_props(attack:copy_hit_props())
                local fx = Battle.Spell.new(attack:get_team())
                fx:set_texture(explosion_texture, true)
                local fx_anim = fx:get_animation()
                fx_anim:load(_modpath .. "spell_explosion.animation")
                fx_anim:set_state("Default")
                fx_anim:refresh(fx:sprite())
                fx:sprite():set_layer(-2)
                fx_anim:on_complete(function() fx:erase() end)
                field:spawn(fx, explosion_table[explosions])
                field:spawn(hitbox, explosion_table[explosions])
            end
        end
        attack:erase()
    end

    spell.collision_func = function(self, other)
        self.has_hit = true
        local explosion_tiles = {}
        local rank = owner:get_rank()
        if rank == Rank.V1 or rank == Rank.SP then
            explosion_tiles = { self:get_tile(), self:get_tile(self:get_facing(), 1) }
        elseif rank == Rank.V2 then
            explosion_tiles = { self:get_tile(), self:get_tile(Direction.join(self:get_facing(), Direction.Up), 1),
                self:get_tile(Direction.join(self:get_facing(), Direction.Down), 1) }
        elseif rank == Rank.V3 then
            explosion_tiles = { self:get_tile(), self:get_tile(Direction.Up, 1), self:get_tile(Direction.Down, 1) }
        end
        rank_relevant_boom(self, explosion_tiles)
    end
    spell.can_move_to_func = function(move_tile)
        return true
    end
    field:spawn(spell, tile)
end

-- EZEncounters deferred native HP adapter.
-- The native fallback must not lock max HP in on_spawn_func: some client
-- spawners run on_spawn before their encounter mutate callback.
-- Battle start occurs after encounter mutations and before the first update.
local __ezhp_original_package_init = package_init
package_init = function(character, ...)
    __ezhp_original_package_init(character, ...)
    local __ezhp_original_battle_start = character.battle_start_func
    character.battle_start_func = function(self, ...)
        if self:get_max_health() == 0 then
            local native = tonumber(self.__ezhp_native_max_hp)
            if not native or native ~= native or native <= 0 or native == math.huge then native = 1 end
            native = math.max(1, math.floor(native))
            self:set_health(native)
            print('[EZHP][CLIENT][NATIVE_FALLBACK_BATTLE_START]', tostring(self:get_name()), native,
                'actual', self:get_max_health())
        end
        if __ezhp_original_battle_start then return __ezhp_original_battle_start(self, ...) end
    end
end
