local shared_package_init = include("../shared/entry.lua")

function package_init(character)
    local character_info = {
        name = "Yura",
        hp = 60,
        damage = 40,
        palette = _folderpath.."V1.png",
        height = 44,
        idle_time = 40,
        move_speed = 40,
        edge_time = 30,
    }
    if character:get_rank() == Rank.SP then
        character_info.hp = 230
        character_info.damage = 100
        character_info.palette = _folderpath.."SP.png"
        character_info.idle_time = 25
        character_info.move_speed = 20
    end
    shared_package_init(character, character_info)
end