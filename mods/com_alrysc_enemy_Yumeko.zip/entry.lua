local package_id = "com.alrysc.enemy.Yumeko"
local character_id = "com.alrysc.enemy.YumekoEnemy"

function package_requires_scripts()
    Engine.define_character(character_id, _modpath.."enemy")
end

function package_init(package) 
    package:declare_package_id(package_id)
    package:set_name("Yumeko")
    package:set_description("An unlikely opponent...!")
    package:set_speed(1)
    package:set_attack(80)
    package:set_health(2400)
    package:set_preview_texture_path(_modpath.."preview.png")
end

function package_build(mob) 

    local texPath = _modpath.."bg.png"
    local animPath = _modpath.."bg.animation"
    -- One pixel right every three frames
    -- Actually I don't know what unit this is in. 1 is 4 pixels per frame?
    mob:set_background(texPath, animPath, 1/12, 0)
    -- Samples / Hz, * 1000 to get ms
    --45727
    mob:stream_music(_modpath.."Tournament.ogg", 1598, 44197)
    mob:create_spawner(character_id, Rank.V1):spawn_at(5, 2)

    local field = mob:get_field()

end