local texture = nil
local alert = nli
local shadow_texture = nil
local anim = nil

local THROW_SFX = nil
local FIRE_PROJECTILE_SFX = nil
local FIRE_KICK = nil
local FLAME_PILLAR_SFX = nil
local SEARCH_SFX = nil
local LOCK_ON_SFX = nil
local APPEAR_SFX = nil
local BREAK_SFX = nil
local SPIN_SFX = nil
local SNAKE_SFX = nil
local EXPLOSION_SFX = nil

local HIT_SFX = nil
local FIRE_SFX = nil
local RAIN_SFX = nil
local LASER_SFX = nil
local SPAWN_SFX = nil
local GUARD_SFX = nil
local SHOOT_SFX = nil

local ObstacleInfo = include("ObstacleInfo/ObstacleInfo.lua")

function package_init(self)
    texture = Engine.load_texture(_modpath.."Hecatia.png")
    effect_texture = Engine.load_texture(_modpath.."HecatiaEffects.png")
    laser_effect_texture = Engine.load_texture(_modpath.."HecatiaLasers.png")

    alert = Engine.load_texture(_modpath.."overlay_fx07_animations.png")
    hit_effects_texture = Engine.load_texture(_modpath.."hit_effects.png")
    self:set_name("Hecatia")
	local rank = self:get_rank()
    self.damage = 120

	if rank == Rank.V1 then
    	self:set_health(3500)
	else
		self:set_health(5000)

	end
	self:set_element(Element.Fire)
    self:set_texture(texture, true)
    self:set_height(60)
    self:share_tile(false)
    self.max_health = self:get_health()
    self:set_explosion_behavior(8, 8, true)


    anim = self:get_animation()
    anim:load(_modpath.."Hecatia.animation")
    
    
--[[
    THROW_SFX = Engine.load_audio(_folderpath.."throw.ogg")
    FIRE_PROJECTILE_SFX = Engine.load_audio(_folderpath.."FireProjectile.ogg")
    FIRE_KICK = Engine.load_audio(_folderpath.."FireKick.ogg")
    FLAME_PILLAR_SFX = Engine.load_audio(_folderpath.."FlamePillar.ogg")
    SEARCH_SFX = Engine.load_audio(_folderpath.."Search.ogg")
    LOCK_ON_SFX = Engine.load_audio(_folderpath.."LockOn.ogg")
    BREAK_SFX = Engine.load_audio(_folderpath.."break.ogg")
    SPIN_SFX = Engine.load_audio(_folderpath.."Spin.ogg")
    APPEAR_SFX = Engine.load_audio(_folderpath.."appear.ogg")
    SNAKE_SFX = Engine.load_audio(_folderpath.."quake.ogg")
    EXPLOSION_SFX = Engine.load_audio(_folderpath.."explosion.ogg")

]]
    HIT_SFX = Engine.load_audio(_folderpath.."hit.ogg")
    FIRE_SFX = Engine.load_audio(_folderpath.."explosion.ogg")
    RAIN_SFX = Engine.load_audio(_folderpath.."rain.ogg")
    LASER_SFX = Engine.load_audio(_folderpath.."beam.ogg")
    SPAWN_SFX = Engine.load_audio(_folderpath.."spawn.ogg")
    GUARD_SFX = Engine.load_audio(_folderpath.."tink.ogg")
    SHOOT_SFX = Engine.load_audio(_folderpath.."shoot.ogg")
    BREAK_SFX = Engine.load_audio(_folderpath.."break.ogg")

    init_boss(self)

end

function init_boss(self)
    -- Setting names here is just convenience if I want to print the state I'm in later
    self.states = {
        idle = {name = "idle", func = idle},
        move = {name = "move", func = move},
        flinch = {name = "flinch", func = flinch},
        
        start_sub_pattern = {name = "start_sub_pattern"},
        finish_sub_pattern = {name = "finish_sub_pattern"},

        move_line_up = {name = "move_line_up", func = move_line_up},
        move_to_back = {name = "move_to_back", func = move_to_back},
        move_to_back_center = {name = "move_to_back_center", func = move_to_back_center},
        move_near_front = {name = "move_near_front", func = move_near_front},
        move_to_enemy = {name = "move_to_enemy", func = move_to_enemy},
        move_to_column_in_front_of_target = {name = "move_to_column_in_front_of_target", func = move_to_column_in_front_of_target},
        
        
        change_forms = {name = "change_forms", func = change_forms},
        start_planet_attacks = {name = "planet_attacks", func = start_planet_attacks},
        fire_attack = {name = "fire_attack", func = fire_attack},
        ice_attack = {name = "ice_attack", func = ice_attack},
        swipe_attack = {name = "swipe_attack", func = swipe_attack},
        raise_attack = {name = "raise_attack", func = raise_attack}
        
    }
    

    local elem_defense = Battle.DefenseRule.new(224,DefenseOrder.CollisionOnly)

    elem_defense.can_block_func = function(judge, attacker, defender)
        local attacker_hit_props = attacker:copy_hit_props()
        if attacker_hit_props.damage > 0 then
            if attacker:get_name() == "Element.Earth" then 
                attacker_hit_props = attacker:copy_hit_props()
                attacker_hit_props.damage = attacker_hit_props.damage + attacker_hit_props.damage
                attacker:set_hit_props(attacker_hit_props)

                local alert = graphic_init("artifact", 32, 0, alert, "overlay_fx07_animations.animation", -9, "0", defender, defender:get_facing(), true)
                local y = defender:get_height()+14
                if y < 20 then 
                    y = 40
                end
                alert:set_elevation(y)
                defender:get_field():spawn(alert, defender:get_current_tile())

            end

        end


    end

    self:add_defense_rule(elem_defense)

    local s = self.states
    
      
    self.pattern = {
        s.idle, s.idle, s.start_planet_attacks,
        s.idle, s.idle, s.idle, s.idle,s.idle, s.idle, s.idle, s.idle, s.idle,

        s.change_forms,
        s.idle, s.idle, s.idle, s.idle,s.idle, s.idle, s.idle, s.idle, s.idle,
        s.idle, s.idle, s.idle, s.idle,s.idle, s.idle, s.idle, s.idle, s.idle

        
    }


    self.pattern = {
        s.idle, s.idle, s.swipe_attack,
        s.idle, s.idle, s.idle, s.idle,s.idle, s.idle, s.idle, s.idle, s.idle,
        s.idle, s.idle, s.idle, s.idle,s.idle, s.idle, s.idle, s.idle, s.idle,
        s.idle, s.idle, s.idle, s.idle,s.idle, s.idle, s.idle, s.idle, s.idle,
        s.idle, s.idle, s.idle, s.idle,s.idle, s.idle, s.idle, s.idle, s.idle,
        s.change_forms, 
        s.idle, s.idle, s.idle, s.idle,s.idle, s.idle, s.idle, s.idle, s.idle,
        s.idle, s.idle, s.idle, s.idle,s.idle, s.idle, s.idle, s.idle, s.idle,
        s.swipe_attack, 
        s.idle, s.idle, s.idle, s.idle,s.idle, s.idle, s.idle, s.idle, s.idle,
        s.idle, s.idle, s.idle, s.idle,s.idle, s.idle, s.idle, s.idle, s.idle,
        s.idle, s.idle, s.idle, s.idle,s.idle, s.idle, s.idle, s.idle, s.idle,
        s.idle, s.idle, s.idle, s.idle,s.idle, s.idle, s.idle, s.idle, s.idle,
        s.idle, s.idle, s.idle, s.idle,s.idle, s.idle, s.idle, s.idle, s.idle,
        s.idle, s.idle, s.idle, s.idle,s.idle, s.idle, s.idle, s.idle, s.idle


        
    }


    self.pattern = {
        s.idle, s.idle, s.idle, s.idle,s.idle, s.idle, s.idle, s.idle, s.idle,

        s.raise_attack,
        s.idle, s.idle, s.idle, s.idle,s.idle, s.idle, s.idle, s.idle, s.idle,
        s.idle, s.idle, s.idle, s.idle,s.idle, s.idle, s.idle, s.idle, s.idle,
        s.idle, s.idle, s.idle, s.idle,s.idle, s.idle, s.idle, s.idle, s.idle,
        s.idle, s.idle, s.idle, s.idle,s.idle, s.idle, s.idle, s.idle, s.idle,
        s.idle, s.idle, s.idle, s.idle,s.idle, s.idle, s.idle, s.idle, s.idle,
        
        s.move, s.idle, s.idle, s.idle,
        s.raise_attack,
        s.idle, s.idle, s.idle, s.idle,s.idle, s.idle, s.idle, s.idle, s.idle,
        s.idle, s.idle, s.idle, s.idle,s.idle, s.idle, s.idle, s.idle, s.idle,
        s.idle, s.idle, s.idle, s.idle,s.idle, s.idle, s.idle, s.idle, s.idle,
        s.idle, s.idle, s.idle, s.idle,s.idle, s.idle, s.idle, s.idle, s.idle,
        s.idle, s.idle, s.idle, s.idle,s.idle, s.idle, s.idle, s.idle, s.idle,

        
        s.move, s.idle, s.idle, s.idle,
        s.raise_attack,
        s.idle, s.idle, s.idle, s.idle,s.idle, s.idle, s.idle, s.idle, s.idle,
        s.idle, s.idle, s.idle, s.idle,s.idle, s.idle, s.idle, s.idle, s.idle,
        s.idle, s.idle, s.idle, s.idle,s.idle, s.idle, s.idle, s.idle, s.idle,
        s.idle, s.idle, s.idle, s.idle,s.idle, s.idle, s.idle, s.idle, s.idle,
        s.idle, s.idle, s.idle, s.idle,s.idle, s.idle, s.idle, s.idle, s.idle,

        
        s.move, s.idle, s.idle, s.idle,
        s.raise_attack


    }

    self.pattern = {
        s.idle, s.idle, s.idle, s.idle,s.idle, s.idle, s.idle, s.idle, s.idle,
        s.idle, s.idle, s.idle, s.idle,s.idle, s.idle, s.idle, s.idle, s.idle,
        s.swipe_attack,
        s.idle, s.idle, s.idle, s.idle,s.idle, s.idle, s.idle, s.idle, s.idle,
        s.idle, s.idle, s.idle, s.idle,s.idle, s.idle, s.idle, s.idle, s.idle,
        s.idle, s.idle, s.idle, s.idle,s.idle, s.idle, s.idle, s.idle, s.idle,
        s.idle, s.idle, s.idle, s.idle,s.idle, s.idle, s.idle, s.idle, s.idle,

        s.raise_attack,
        s.idle, s.idle, s.idle, s.idle,s.idle, s.idle, s.idle, s.idle, s.idle,
        s.idle, s.idle, s.idle, s.idle,s.idle, s.idle, s.idle, s.idle, s.idle,

        s.change_forms
    }

    self.pattern = {
        s.idle, s.move, s.idle,
        s.swipe_attack,

        s.idle, s.move, s.idle,

        s.raise_attack,
        s.idle, s.move, s.idle,

        s.change_forms
    }

    self.pattern = {
        s.idle, s.idle,
        s.swipe_attack,

        s.idle, s.idle,

        s.raise_attack,
        s.idle,

        s.change_forms
    }


    --[[
    self.pattern = {
        s.idle, s.idle, s.move, s.idle, s.idle,

        s.start_sub_pattern,
            s.move_line_up, s.fire_shot, s.move_line_up, s.fire_shot, s.move_to_enemy, s.combo, s.move_to_enemy, s.combo,
        s.finish_sub_pattern, s.move
        
    }
]]



    self.pattern_index = 1
    self.in_sub_pattern = false
    self.nloop = 1
    self.mloop = 3
    self.move_count = 0
    
    self.idle_frames = 60
    self.idle_count = self.idle_frames -- Will count down to 0, loop back to s.idle_frames



    self.acting = false
    self.first_act = true

    self.state_done = false

    self.state = self.pattern[1]

    self.first_flinch = true

    self.tiles_to_highlight = {}
    self.should_clear_highlight = true


    self.forms = {
        Fire = 1,
        Aqua = 2,
        Elec = 3,
    }

    self.form = self.forms.Fire

    anim:set_state("IDLE_"..self.form)
    anim:set_playback(Playback.Loop)    

    local dirs = {
        Direction.Up,
        Direction.UpRight,
        Direction.Right,
        Direction.DownRight,
        Direction.Down,
        Direction.DownLeft,
        Direction.Left,
        Direction.UpLeft
    }

    self.panel_component = Battle.Component.new(self, Lifetimes.Scene)
    self.start_tile = nil
    self.panel_component.update_func = function()
        if not self.start_tile then 
            self.start_tile = self:get_tile()
            return
        end
    
        for i=1, #dirs 
        do
            local t = self.start_tile:get_tile(dirs[i], 1)
            t:set_state(TileState.Empty)
            t:set_team(self:get_team(), false)
        end

    end
    
    self:register_component(self.panel_component)

    self.hit_func = function()
   --     print("Hit")
        self.flinching = false
        self.first_act = false
        self.state_done = false
        self.moving_to_enemy_tile = false
        if self.first_flinch then 
         --   self.state.cleanup
            self.last_state = self.state
            if self.state ~= self.states.idle and self.state ~= self.states.move then 
               -- increment_pattern(self)
            end

            self.first_flinch = false
        end
        self.state = self.states.flinch
        if self.slide_component ~= nil then 
          --  print("Hit while moving.")
            self.slide_component:eject()
            self.slide_component = nil
            self:set_offset(0, 0)

            if self.slide_dest and self:get_current_tile() ~= self.slide_dest then 
            --    print("Hit before reaching destination.")
                self:get_current_tile():remove_entity_by_id(self:get_id())
                self.slide_dest:add_entity(self)
                self.slide_dest = nil
            end

        end
        flinch(self)

    end

    self.delete_func = function(self)
        self.planet1.move_component:eject()
        self.planet2.move_component:eject()

        self.planet1:delete()
        self.planet2:delete()
        self.planet_update_component:eject()
        self.update_func = function(self)
            anim:set_state("FLINCH_"..self.form)
            self.state = self.states.flinch
        end

    end


    self.end_attack = false
    self.moving_to_enemy_tile = false
    self.spinning = false
    self.slide_component = nil
    self.slide_dest = nil
    self.counter = 0
    self.kick_count = 3
    self.collision_available = true


    self:register_status_callback(Hit.Stun, self.hit_func)
    self:register_status_callback(Hit.Flinch, self.hit_func)
    self:register_status_callback(Hit.Drag, self.hit_func)
    self:register_status_callback(Hit.Root, function() self.rooted = 120 end)

    -- Bring it back next build. For now, relying on the stun callback
    --[[
    self.on_countered = function(self)
        print("Countered")
        self:toggle_counter(false)
        self.hit_func(self)

    end
    --]]

    self.can_move_to_func = function(tile)
        if self.rooted > 0 then return false end
        if tile:is_edge() or not tile:is_walkable() then
            return false
        end
        if(tile:is_reserved({})) then
            return false
        end

        if not self.moving_to_enemy_tile and (tile:get_team() ~= self:get_team()) then
            return false
        end

        return not check_obstacles(tile, self) --and not check_characters(tile, self)
    end

    local create_planet = nil
    local shift_planet_action = nil

    self.shift_check = Battle.Component.new(self, Lifetimes.Battlestep)

    self.shift_check_frame = 0
    self.shift_attempted = false
    self.can_attempt_shift = false
    self.shift_check.update_func = function()
        if not self.can_attempt_shift and self.ring1_anim == nil and self:get_health() > 0 and self:get_health() <= self.max_health/2 then 
            self.can_attempt_shift = true
  
        end

        if self.can_attempt_shift and not self:is_sliding() and self.shift_check_frame % 2 == 1 then 
            self:card_action_event(shift_planet_action(self), ActionOrder.Immediate)
            self.shift_attempted = true
        end

        if self.can_attempt_shift and not self:is_sliding() then  
            self.shift_check_frame = self.shift_check_frame + 1
        end
        
    end

    self:register_component(self.shift_check)
    -- Do movement by attaching a component
        -- Use a function so I can come back to a move pattern if I want

        local function attach_move_circle(ob, t)
            ob.move_component = Battle.Component.new(ob.owner, Lifetimes.Battlestep)
            local dirs = {
                Direction.Down,
                self:get_facing_away(),
                Direction.Up,
                self:get_facing()
            }
    
            ob.move_count = 0
            ob.current_dir = 1
            ob.speed = 60
    
            if t:get_tile(Direction.Down, 1):is_edge() then 
                ob.current_dir = 2
                if t:get_tile(self:get_facing_away(), 1):is_edge() then
                    ob.current_dir = 3
                end
            end
    
            if t:get_tile(Direction.Up, 1):is_edge() then 
                ob.current_dir = 1
                if t:get_tile(self:get_facing_away(), 1):is_edge() then 
                    ob.current_dir = 4
                end
            end
    
            ob.move_component.update_func = function()
                ob.can_act = true
                if ob:is_sliding() == false then
                    ob.move_count = ob.move_count + 1
                    if ob.move_count > 2 then 
                        ob.move_count = 1
                        ob.current_dir = ob.current_dir + 1
                        if ob.current_dir > #dirs then 
                            ob.current_dir = 1
                        end
                    end
                    
                    local dest = ob:get_tile(dirs[ob.current_dir], 1)
                    ob:slide(dest, frames(ob.speed), frames(0), ActionOrder.Voluntary, nil)
                end
    
            end
    
            self:register_component(ob.move_component)
        end

    self.start_component = Battle.Component.new(self, Lifetimes.Scene)

    self.start_component.update_func = function()
        self.planet1 = create_planet(self, self.forms.Aqua)
        self.planet2 = create_planet(self, self.forms.Elec)
    
        self:get_field():spawn(self.planet1, self:get_tile(Direction.join(self:get_facing(), Direction.Up), 1))
        self:get_field():spawn(self.planet2, self:get_tile(Direction.join(self:get_facing_away(), Direction.Down), 1))

        self.start_component:eject()
        self.start_component = nil
    end

    self:register_component(self.start_component)

    self.battle_start_func = function(self)
        attach_move_circle(self.planet1, self.planet1:get_current_tile())
        attach_move_circle(self.planet2, self.planet2:get_current_tile())

    end

    self.rooted = 0
    self.update_func = function(self)
      --  print("     ", self.state.name, self.moving_to_enemy_tile)
        if self.rooted > 0  then self.rooted = self.rooted - 1 end
        self.state.func(self)
     --   check_collision(self)
    end
    
    local function enemy_query(c)
        return c:get_team() ~= self:get_team()

    end

    local function planet_idle(ob)
        if ob.first_act then 
            if ob.anim:get_state() ~= "PLANET_"..ob.form then 
                ob.anim:set_state("PLANET_"..ob.form)
            end
            ob.anim:set_playback(Playback.Loop)
    
           
            ob.first_act = false
        end


        if ob.attack_cooldown == 0 and not ob.defending then 
            local f = ob:get_facing()
            local t = ob:get_tile(f, 1)
            while not t:is_edge()
            do
                local list = t:find_characters(enemy_query)
                if #list > 0 then 
                    ob.state = self.planet_states.attack
                    ob.first_act = true

                    break
                end
                t = t:get_tile(f, 1)
            end
        else
            ob.attack_cooldown = ob.attack_cooldown - 1
        end

    end


    local function planet_attack(ob)
        if ob.first_act then 
            if ob.anim:get_state() ~= "PLANET_ATTACK_"..ob.form then 
                ob.anim:set_state("PLANET_ATTACK_"..ob.form)
            end
    
            ob.anim:on_frame(2, function()
                create_planet_attack(ob, self)
                ob.attack_cooldown = ob.max_cooldown
            end)

            ob.anim:on_complete(function()
                ob.first_act = true
                ob.state = self.planet_states.idle
            
            end)


            ob.first_act = false

        end

    end

    local function planet_change(ob)
        if ob.first_act then 
            ob.anim:set_state("PLANET_CHANGE")
            next_form(ob)
    
            ob.anim:on_complete(function()
                ob.first_act = true
                ob.state = self.planet_states.idle
            
            end)
    
    
            ob.first_act = false
    
        end
    
    end

    self.planet_states = {
        idle = {name = "idle", func = planet_idle},
        attack = {name = "attack", func = planet_attack},
        change = {name = "change", func = planet_change}

    }


    local function collide_attack_func(self)
        Engine.play_audio(HIT_SFX, AudioPriority.Low)
    end

    local function collide_update_func(self)
        self:get_current_tile():attack_entities(self)
        self:delete()
    end
    
    local function collision_attack(ob)
        local spell = Battle.Spell.new(ob:get_team())
        spell.attack_func = collide_attack_func
        spell.update_func = collide_update_func
        spell:set_hit_props(ob.hit_props)

        ob:get_field():spawn(spell, ob:get_current_tile())
    end

    create_planet = function(self, num)
        local ob = graphic_init("obstacle", 0, 0, effect_texture, "HecatiaEffects.animation", 0, "PLANET_"..num, self, self:get_facing())
        ObstacleInfo.set_cannot_be_manipulated(ob, true)
        ob:set_texture(Engine.load_texture(_modpath.."planet"..num..".png"))
        ob.owner = self
        ob.state = self.planet_states.idle
        ob.form = num
        ob.anim = ob:get_animation()
        ob.anim:refresh(ob:sprite())

        ob.can_act = true -- I'm using this to stop the update during time freeze. When spawned in TF, update_func runs

        ob.anim:set_playback(Playback.Loop)
        ob:share_tile(true)

        ob.first_act = true
    
        ob.attack_cooldown = 0
        ob.max_cooldown = 120

        ob.double = ob:create_node()
        ob.double:set_texture(effect_texture, false)
        ob.double_anim = Engine.Animation.new(_modpath.."HecatiaEffects.animation")
        ob.double_anim:set_state("HIDDEN")
        ob.double_anim:refresh(ob.double)

        ob:set_float_shoe(true)
        ob.double:set_layer(-1)

        ob:set_name("PLANET")
        ob:set_health(self.max_health)
        ob:toggle_hitbox(true)
        add_defense(ob)
        ob.on_spawn_func = function()
            if not self.planet_update_component then 
                self.planet_update_component =  Battle.Component.new(self, Lifetimes.Local)
                self.planet_update_component.update_func = function(dontknow, dt)
                    self.planet1.double_anim:update(dt, self.planet1.double)
                    self.planet2.double_anim:update(dt, self.planet2.double)


                end

                self:register_component(self.planet_update_component)
            end

        end


        ob.hit_props = HitProps.new(
            self.damage,
            Hit.Impact | Hit.Breaking | Hit.Flinch | Hit.Flash,
            Element.None, 
            self:get_id(), 
            Drag.None
        )

        

    
        ob.update_func = function(ob, dt)
            if not ob.can_act then return end
            ob.state.func(ob)
            collision_attack(ob)

        end
    
        ob.can_move_to_func = function()
            return true
        end
    

        return ob
    end

    local function set_move_block(self, ob)
        ob.check_component = Battle.Component.new(ob.owner, Lifetimes.Battlestep)
        ob.check_component.update_func = function()
            ob.can_act = true
            ob.check_component:eject()
            ob.check_component = nil
        end

        ob:register_component(ob.check_component)

        ob.defending = true
        local idle = self.planet_states.idle

        local function query(c)
            return c:get_team() ~= ob:get_team()
        end

        local function search_target(ob)
            local l = ob:get_field():find_characters(query)

            ob.target = l[1]
        end

        ob.target = nil
        ob.speed = 60
        ob.update_func = function(ob)
            if not ob.can_act then return end
            ob.state.func(ob)
            collision_attack(ob)            
            if not ob.target then 
                search_target(ob)
            elseif ob.state == idle and ob.attack_cooldown <= 0 then 
                if not ob:is_sliding() then 
                    local y = ob.target:get_current_tile():y() - ob:get_current_tile():y()
                    local dest = nil

                    if y > 0 then 
                        dest = ob:get_tile(Direction.Down, 1)
                    elseif y < 0 then 
                        dest = ob:get_tile(Direction.Up, 1)
                    else
                        ob.state = self.planet_states.attack
                        ob.first_act = true
                    end

                    if dest then
                        ob:slide(dest, frames(ob.speed), frames(0), ActionOrder.Voluntary, nil)
                    end
                end
            end

        end

    end

    shift_planet_action = function(self)
        local action = Battle.CardAction.new(self, "SHIFT_PLANET_"..self.form)
    
        local meta = action:copy_metadata()
        meta.time_freeze = true
        meta.skip_time_freeze_intro = false
        meta.shortname = "Planetary Shift"
        action:set_metadata(meta)
    
        local new_tile1 = nil
        local new_tile2 = nil
    
        local form1 = nil
        local form2 = nil
    
        action.execute_func = function()
            self.shift_check:eject()
            local t = self:get_field():tile_at(1, 1)
            if self:get_facing() == Direction.Right then 
                t = t:get_tile(Direction.Right, 3)
            end

            new_tile1 = t
            new_tile2 = self:get_tile(self:get_facing(), 1)
    
            form1 = self.planet1.form
            form2 = self.planet2.form
        end
    
        action:add_anim_action(1, function()
            self.planet1.move_component:eject()
            self.planet2.move_component:eject()
            self.planet1:delete()
            self.planet2:delete()
    
            Engine.play_audio(SPAWN_SFX, AudioPriority.Low)
        end)
    
        action:add_anim_action(2, function()
            self.planet1 = create_planet(self, form1)
            self.planet2 = create_planet(self, form2)
            self.planet1.can_act = false
            self.planet2.can_act = false

         --   self.planet1:set_facing(self.planet1:get_facing_away())
            
            attach_move_circle(self.planet1, new_tile1)
            self.planet1.speed = 90
            self.planet1.defending = true

            set_move_block(self, self.planet2)

            local field = self:get_field()

            field:spawn(self.planet1, new_tile1)
            field:spawn(self.planet2, new_tile2)

            Engine.play_audio(SPAWN_SFX, AudioPriority.Low)
        end)
    
    
        return action
    end

end

function idle(self, time)
    if self.first_act then
      --  print("Got ", self, time) 
        if anim:get_state() ~= "IDLE_"..self.form then 
            anim:set_state("IDLE_"..self.form)
        end
        anim:set_playback(Playback.Loop)

        --[[
        anim:on_complete(function()
            if not self.looped then 
                --self.looped = true
                self.idle_count = self.idle_count+1
               -- print("Complete"..self.idle_count)

                if self.idle_count >= self.nloop then 
                    self.state_done = true
                    
                end
            end

            self.looped = not self.looped
        
        end)
        ]]

        self.first_act = false
    end

   -- print("Idle "..self.idle_count)
    self.idle_count = self.idle_count - 1
    --self.looped = false
    if self.idle_count == 0 then 
       -- print("State done")
        self.idle_count = self.idle_frames
        self.state_done = false
        increment_pattern(self)
    end
end

function hit()
    

end

function end_sub_pattern(self)
    while(self.in_sub_pattern)
    do
        increment_pattern(self)
    end

end

function flinch(self)
   -- print("Flinch played")
    self.looped = false

    if not self.flinching then 
        anim:set_state("FLINCH_"..self.form)        
        anim:on_complete(function()
           -- print("Anim done")
            self.flinching = false
            self.state_done = true
            self.first_flinch = false

            self.looped = true

        --    print("Done")
            self.state_done = false
            if self.last_state ~= self.states.idle and self.last_state ~= self.states.move then 
           --     print("Last state was not idle or move")

                if not self.in_sub_pattern then 
                    increment_pattern(self)
                else
                    end_sub_pattern(self)
                end

               
            else
             --   print("Last state was idle or move")

                if self.in_sub_pattern then 
                    end_sub_pattern(self)
                else
                    self.state = self.last_state
                    self.first_act = true
                end
            end

        end)

    end

    self.flinching = true
   
end


function highlight_tiles(self, list, time)
    local spell = Battle.Spell.new(self:get_team())


    local ref = self
    spell.update_func = function(self)
        for i=1, #list
        do 
            local t = list[i]
            if t and not t:is_edge() then 
                t:highlight(Highlight.Solid)
            end

        end


        time = time - 1
        if time == 0 then 
            self:delete()
        end

        if self.flinching then 
            if spell and not spell:is_deleted() then 
                spell:delete()
    
            end
        end
    end


    self:get_field():spawn(spell, self:get_current_tile())

    return spell
end



function move(self)
    if self.first_act then 
        anim:set_state("MOVE")

        local tile = choose_move(self, self:get_field())
      --  print("###STARTING NEW MOVE")
        anim:on_frame(2, function()
            if self.can_move_to_func(tile) then 
        --        print("Can reach")
            else
            --    print("Can't do it now")
                tile = self:get_current_tile()
            end
            self:teleport(tile, ActionOrder.Voluntary, function()
          --      print("Move")
            end)
        end)

        anim:on_complete(function()
            increment_pattern(self)
        
        end)

        self.first_act = false
    end
end


function fire_shot(self)
    if self.first_act then 
        anim:set_state("PUNCH1")

        anim:on_frame(1, function()
            self:toggle_counter(true)
            Engine.play_audio(FIRE_PROJECTILE_SFX, AudioPriority.Low)
            create_fire_shot(self)
        end)
        anim:on_frame(4, function()
            self:toggle_counter(false)
        end)

        anim:on_complete(function()
            increment_pattern(self)
        
        end)

        self.first_act = false
    end

end


function start_planet_attacks(self)
    self.planet1.first_act = true
    self.planet2.first_act = true
    self.planet1.state = self.planet_states.attack
    self.planet2.state = self.planet_states.attack

end

function create_planet_attack(ob, self)
    local field = self:get_field()
    local form = ob.form
    local spell = graphic_init("spell", 0, 0, effect_texture, "HecatiaEffects.animation", -4, "SHOT_START_"..form, ob, ob:get_facing())
    local facing = ob:get_facing()
    local element = nil
    local flags = Hit.Impact | Hit.Flinch | Hit.Flash
    local speed = nil

    if form == self.forms.Fire then 
        element = Element.Fire
        speed = 10
    elseif form == self.forms.Aqua then 
        element = Element.Aqua
        speed = 25
    elseif form == self.forms.Elec then 
        element = Element.Elec
        speed = 7
    end

    local update = function(self)
      --  if not self.start_moving then 
        --    return 
        --end
        self:get_tile():attack_entities(self)
       -- self:get_current_tile():highlight(Highlight.Solid)

        if self:is_sliding() == false then
            if self:get_current_tile():is_edge() and self.slide_started then 
                self:delete()

            end 
            
            local dest = self:get_tile(facing, 1)
            local ref = self
            self:slide(dest, frames(speed), frames(0), ActionOrder.Voluntary,
                function()
                    ref.slide_started = true 
                end
            )
        end

    end

    local move = function()
        return true
    end

    local att = function(s, other)
        Engine.play_audio(HIT_SFX, AudioPriority.Low)
        local hit_effect = graphic_init("artifact", 0, 0, hit_effects_texture, "HecatiaEffects.animation", -4, "HIT_"..form, s, s:get_facing(), true)
        field:spawn(hit_effect, s:get_current_tile())
        
    end

    local collision = function(s, other)
        s:delete()
    end

    local on_spawn = function()
        Engine.play_audio(SHOOT_SFX, AudioPriority.Low)
    end


    local hit_props = HitProps.new(
        self.damage,
        flags,
        element, 
        ob:get_id(), 
        Drag.None
    )

    if form == self.forms.Elec then 
        spell:get_animation():on_frame(3, function()
            local spell2 = graphic_init("spell", 0, 0, effect_texture, "HecatiaEffects.animation", -4, "SHOT_LOOP_"..form, ob, ob:get_facing())
            spell2:get_animation():set_playback(Playback.Loop)
            spell2.start_moving = true

            spell2.update_func = update
            spell2.attack_func = att
            spell2.collision_func = collision
            spell2.can_move_to_func = move
            spell2.on_spawn_func = on_spawn
            spell2:set_hit_props(hit_props)

            field:spawn(spell2, spell:get_current_tile())

        
        end)
        spell:get_animation():on_complete(function()
            spell:delete()        

        end)
        

    else
        spell.update_func = update
        spell.attack_func = att
        spell.collision_func = collision
        spell.can_move_to_func = move
        spell.on_spawn_func = on_spawn

        spell:set_hit_props(hit_props)

        spell:get_animation():on_complete(function()
            spell:get_animation():set_state("SHOT_LOOP_"..form)
            spell:get_animation():refresh(spell:sprite())
            spell:get_animation():set_playback(Playback.Loop)
            spell.start_moving = true

            
        end)
    end

    
    local facing = ob:get_facing()

    local damage = self.damage
  
    

    spell:set_hit_props(hit_props)

    

   -- Engine.play_audio(SHOOT_SFX, AudioPriority.Low)
    local tile = ob:get_tile()

    if tile then 
        field:spawn(spell, tile)
    end


end


function change_forms(self)
    if self.first_act then 
        anim:set_state("CHANGE")
        start_planet_change(self)
        next_form(self)
        if self.form == self.forms.Fire then 
            self:set_element(Element.Fire)
        elseif self.form == self.forms.Aqua then 
            self:set_element(Element.Aqua)
        elseif self.form == self.forms.Elec then 
            self:set_element(Element.Elec)
        end

        anim:on_frame(1, function()
            
          --  Engine.play_audio(FIRE_PROJECTILE_SFX, AudioPriority.Low)
        end)

        anim:on_complete(function()
            increment_pattern(self)
        
        end)

        self.first_act = false
    end


end

function start_planet_change(self)
    self.planet1.double_anim:set_state("PLANET_CHANGE")
    self.planet2.double_anim:set_state("PLANET_CHANGE")

    self.planet1.double_anim:on_frame(2, function()
        next_form(self.planet1)
        self.planet1:set_texture(Engine.load_texture(_modpath.."planet"..self.planet1.form..".png"))
        self.planet1.anim:refresh(self.planet1:sprite())

    end)

    self.planet2.double_anim:on_frame(2, function()
        next_form(self.planet2)
        self.planet2:set_texture(Engine.load_texture(_modpath.."planet"..self.planet2.form..".png"))
        self.planet2.anim:refresh(self.planet2:sprite())

    end)

    self.planet1.double_anim:refresh(self.planet1.double)
    self.planet2.double_anim:refresh(self.planet2.double)

end



function next_form(caller)
    local form = caller.form
    form = form + 1
    if form > 3 then form = 1 end

    caller.form = form

end


function fire_attack(self)
    if self.first_act then 
        anim:set_state("SWIPE_"..self.form)

        anim:on_frame(3, function()
            create_moving_fire(self, self:get_tile(self:get_facing(), 1), Direction.Down, self:get_id())
          --  Engine.play_audio(FIRE_PROJECTILE_SFX, AudioPriority.Low)
        end)

        anim:on_complete(function()
            increment_pattern(self)
        
        end)

        self.first_act = false
    end


end


function create_moving_fire(self, tile, vertical, id)
    local field = self:get_field()
    local spell = graphic_init("spell", 0, 0, effect_texture, "HecatiaEffects.animation", -4, "FIRE", self, self:get_facing(), true)
    spell.attacking = true
    spell.damage = self.damage
    -- The self in here is the current spell, not the create_moving_fire caller
    spell:get_animation():on_frame(3, function()
        local next_tile = spell:get_tile(vertical, 1)
        if next_tile:is_edge() then 
            next_tile = spell:get_tile(spell:get_facing(), 1)
            vertical = Direction.reverse(vertical)
        end

        if not next_tile then return end

        create_moving_fire(spell, next_tile, vertical, id)
    
    end)

    spell:get_animation():on_frame(6, function()
        spell.attacking = false
    
    end)

    spell.on_spawn_func = function()
        Engine.play_audio(FIRE_SFX, AudioPriority.Low)
    end

    local hit_props = HitProps.new(
        spell.damage,
        Hit.Impact | Hit.Flinch | Hit.Flash,
        Element.Fire, 
        id, 
        Drag.None
    )

    spell:set_hit_props(hit_props)
    spell.update_func = function(self)
        if self.attacking then 
            self:get_tile():attack_entities(self)
        end

    end


    spell.attack_func = function()
        Engine.play_audio(HIT_SFX, AudioPriority.Low)

    end


    field:spawn(spell, tile)
end

function create_fire(self, tile)
    if not (tile and not tile:is_edge()) then return end
    local field = self:get_field()
    local spell = graphic_init("spell", 0, 0, effect_texture, "HecatiaEffects.animation", -4, "FIRE", self, self:get_facing(), true)
    spell.attacking = true
    spell.damage = self.damage



    spell:get_animation():on_frame(6, function()
        spell.attacking = false
    
    end)

    local hit_props = HitProps.new(
        spell.damage,
        Hit.Impact | Hit.Flinch | Hit.Flash,
        Element.Fire, 
        self:get_id(), 
        Drag.None
    )

    spell:set_hit_props(hit_props)
    spell.update_func = function(self)
        if self.attacking then 
            self:get_tile():attack_entities(self)
        end

    end


    spell.attack_func = function()
        Engine.play_audio(HIT_SFX, AudioPriority.Low)

    end


    field:spawn(spell, tile)
end


function ice_attack(self)
    if self.first_act then 
        anim:set_state("SWIPE_"..self.form)

        anim:on_frame(3, function()
            create_ice(self)
        end)

        anim:on_complete(function()
            increment_pattern(self)
        
        end)

        self.first_act = false
    end


end

function choose_adjacent_enemy_tile(pivot, team, exclude)
    local tiles = {}
    local directions = {
        Direction.Up,
        Direction.Down,
        Direction.Left,
        Direction.Right
    }

    for i=1, #directions
    do
        local t = pivot:get_tile(directions[i], 1)
        local should_exclude = false
        for i=1, #exclude
        do
            if t == exclude[i] then 
                should_exclude = true
                break
            end
        end
        
        if not should_exclude and t and t:get_team() ~= team and not t:is_edge() then 
            table.insert(tiles, t)
        end
    end


    if #tiles == 0 then return end

    local choose_tile = tiles[math.random(1, #tiles)]

    return choose_tile
end

function swipe_attack(self)

    -- I probably want to put stuff in here for highlighting the tiles, I guess
    -- So I have to choose them ahead of time, which I guess isn't a problem.
    if self.first_act then 
        local form = self.form
        self:toggle_counter(true)

        if form == self.forms.Aqua then 
            self.should_clear_highlight = false

            local team = self:get_team()
            local exclude = {}
            local t = choose_random_enemy_tile(self)
            self.tiles_to_highlight[1] = t
            table.insert(exclude, t)

            local t2 = choose_adjacent_enemy_tile(t, team, exclude)
            self.tiles_to_highlight[2] = t2
            table.insert(exclude, t2)

            local t3 = choose_adjacent_enemy_tile(t2, team, exclude)
            self.tiles_to_highlight[3] = t3
            table.insert(exclude, t3)
        end

        anim:set_state("SWIPE_"..form)

        anim:on_frame(3, function()
            self:toggle_counter(false)

            if form == self.forms.Fire then 
                create_moving_fire(self, self:get_tile(self:get_facing(), 1), Direction.Down, self:get_id())

            elseif form == self.forms.Aqua then 
                self.should_clear_highlight = false
                create_ice(self, self.tiles_to_highlight[1], self:get_id(), 3, self.tiles_to_highlight)

            elseif form == self.forms.Elec then 
                create_zag_laser(self, self:get_tile(self:get_facing(), 1), self:get_id(), 1, 0, 0, true)

            end
        end)

        anim:on_complete(function()
            increment_pattern(self)
        
        end)

        self.first_act = false
    end


    for i=1, #self.tiles_to_highlight 
    do
        self.tiles_to_highlight[i]:highlight(Highlight.Flash)
    end

end

function create_ice(self, tile, id, num, tile_list)
    if not tile or num == 0 then return end

    local field = self:get_field()
    local spell = graphic_init("spell", 0, 0, effect_texture, "HecatiaEffects.animation", -4, "ICE", self, self:get_facing(), true)
    spell.attacking = false
    spell.attack_first = true
    spell.damage = self.damage
    local anim = spell:get_animation()
  
    table.remove(tile_list, 1)
    local next_tile = tile_list[1]

    anim:on_frame(2, function()
        spell.attacking = true

    end)

    anim:on_frame(6, function()
        spell.attacking = false
    end)

    anim:on_frame(4, function()
        create_ice(spell, next_tile, id, num-1, tile_list)
    end)

    local hit_props = HitProps.new(
        spell.damage,
        Hit.Impact | Hit.Flinch | Hit.Flash,
        Element.Aqua, 
        id, 
        Drag.None
    )

    spell:set_hit_props(hit_props)
    spell.update_func = function(self)
        if self.attacking then 
            if not self.attack_first then 
                self:get_tile():set_state(TileState.Ice)
            end
            self:get_tile():attack_entities(self)
            self.attack_first = false

        end

    end
    spell.on_spawn_func = function()
        Engine.play_audio(BREAK_SFX, AudioPriority.Low)
    end

    spell.attack_func = function()
        Engine.play_audio(HIT_SFX, AudioPriority.Low)

    end

    field:spawn(spell, tile)
end

function create_zag_laser(self, tile, id, flipy, x, y, first)
    if not tile then return end
    
    x = x or 0
    y = y or 0
    first = first or false

    local field = self:get_field()
    local distance = 1
    local next_tile = nil
    local state = nil

    local attack_list = {
        tile
    }

    local function create_hitbox(spell, tile)
        if not tile or tile:is_edge() then return end
        local box = Battle.Spell.new(spell:get_team())
        box.damage = spell.damage
        box.boosted = false
        local hit_props = HitProps.new(
            box.damage,
            Hit.Impact | Hit.Flinch | Hit.Flash,
            Element.Elec, 
            id, 
            Drag.None
        )
    
        box:set_hit_props(hit_props)

        box.attack_func = function()
            Engine.play_audio(HIT_SFX, AudioPriority.Low)
        end

        box.update_func = function(self)
            local t = self:get_current_tile()
            if box.boosted then 
                local p = box:copy_hit_props()
                p.damage = box.damage
                box:set_hit_props(p)
                box.boosted = false
            end

            if t:get_state() == TileState.Ice then 
                box.boosted = true
                t:set_state(TileState.Normal)
                local p = box:copy_hit_props()
                p.damage = p.damage * 2
                box:set_hit_props(p)


            end
        
            t:attack_entities(self)
        end

        field:spawn(box, tile)
        return box
    end

    
    local function check_path(self)
        local facing = self:get_facing()

        local function check_diagonal(dir)
            local t = tile
            local count = 0
            while(t and not t:is_edge())
            do
                t = tile:get_tile(Direction.join(facing, dir), count+1)
                if t and not t:is_edge() then 
                    count = count + 1
                    table.insert(attack_list, t)
                end

                -- I don't want to deal with stages being bigger than 6x3 and breaking everything
                if count == 2 then break end
            end

            if count > 0 then 
                distance = count
                
                return tile:get_tile(Direction.join(facing, dir), count)
            else return nil
            end
        end


        local new_tile = nil
        if flipy == 1 then 
            new_tile = check_diagonal(Direction.Down)
            if not new_tile then 
                new_tile = check_diagonal(Direction.Up)
                if new_tile then 
                    flipy = 0
                end
            end

        else
            new_tile = check_diagonal(Direction.Up)
            if not new_tile then 
                new_tile = check_diagonal(Direction.Down)
                if new_tile then 
                    flipy = 1
                end
            end

        end
     

        return new_tile
    end

    next_tile = check_path(self)

    if not next_tile then 
        if flipy == 0 then 
            flipy = 1
        else
            flipy = 0
        end
    end
            
    if distance == 1 and next_tile then 
        state = "SMALL_LASER_"..flipy
    else
        state = "MEDIUM_LASER_"..flipy
    end
    local spell = graphic_init("spell", x, y, laser_effect_texture, "HecatiaEffects.animation", -4, state, self, self:get_facing())
    local anim = spell:get_animation()
    spell.damage = self.damage
    spell.next_tile = next_tile
    spell.attack_one = create_hitbox(spell, tile)
    spell.attack_two = false
    spell.attack_three = false


    

    spell.on_spawn_func = function()
        Engine.play_audio(LASER_SFX, AudioPriority.Low)
    end
    

    anim:on_frame(2, function()
        spell.attack_two = create_hitbox(spell, attack_list[2])
    
    end)

    anim:on_frame(3, function()
        if distance == 2 then 
            spell.attack_three = create_hitbox(spell, attack_list[3])
        end

    end)

    anim:on_frame(5, function()
        if distance == 2 then 
            if not spell.attack_two then return end
            spell.attack_two:delete()
        end
    end)
    

    anim:on_frame(4, function()
        spell.attack_one:delete()
        local y = 2
        if flipy == 1 then 
            y = y * -1
        end

        create_zag_laser(spell, spell.next_tile, id, flipy, x, y)

    
        if first then 

            -- These checks are to make sure this laser does not overlap with the other one that spawned here
            local dir = Direction.Up
            local flip = 0
            if flipy == 0 then 
                dir = Direction.Down
                flip = 1
            end
            local t = tile:get_tile(Direction.join(spell:get_facing(), dir), 1)

            if t and not t:is_edge() then 
                create_zag_laser(spell, tile, id, flip, 0, 0)
            end

        end

    end)

    anim:on_complete(function()
        spell:delete()
        if distance == 2 then 
            if not spell.attack_three then return end
            spell.attack_three:delete()
        else
            if not spell.attack_two then return end
            spell.attack_two:delete()
        end

    end)

    
    spell.dedupdate_func = function(self)
        if spell.attack_one then 
            local t = attack_list[1]
            if t then 
                if t:get_state() == TileState.Ice then 
                    t:set_state(TileState.Normal)
                    local p = spell:copy_hit_props()
                    p.damage = p.damage * 2
                    
                   -- spell:set_hit_props(p)
                    t:attack_entities(self)
                   -- spell:set_hit_props(hit_props)
                else
                    t:attack_entities(self)
                end
            end
        end

        if spell.attack_two then 
            local t = attack_list[2]
            if t then 
                if t:get_state() == TileState.Ice then 
                    t:set_state(TileState.Normal)
                    local p = spell:copy_hit_props()
                    p.damage = p.damage * 2
                    
                    --spell:set_hit_props(p)
                    t:attack_entities(self)
                    --spell:set_hit_props(hit_props)
                else
                    t:attack_entities(self)
                end
            end
        end

        if spell.attack_three then 
            local t = attack_list[3]
            if t then 
                if t:get_state() == TileState.Ice then 
                    t:set_state(TileState.Normal)
                    local p = spell:copy_hit_props()
                    p.damage = p.damage * 2
                    
                   -- spell:set_hit_props(p)
                    t:attack_entities(self)
                    --spell:set_hit_props(hit_props)
                else
                    t:attack_entities(self)
                end
            end
        end

    end

    

    field:spawn(spell, tile)
end

function raise_attack(self)
    if self.first_act then 
        local form = self.form
        self:toggle_counter(true)

        if form == self.forms.Aqua then 
            self.should_clear_highlight = true
            self.tiles_to_highlight = choose_n_random_enemy_tiles(self, 5)

        elseif form == self.forms.Fire then 
            self.should_clear_highlight = true
            local t = choose_random_enemy_tile(self)
            self.tiles_to_highlight[1] = t

        elseif form == self.forms.Elec then
            self.should_clear_highlight = true
            self.tiles_to_highlight = gather_backward_line_of_sight(self)
        end

        anim:set_state("RAISE_"..form)

        anim:on_frame(3, function()
            if form == self.forms.Fire then 
                create_orb(self, self.tiles_to_highlight[1])
                self.tiles_to_highlight = {}

            elseif form == self.forms.Aqua then 
                self.should_clear_highlight = false

                local first = true
                for i=1, #self.tiles_to_highlight
                do
                    create_rain(self, self.tiles_to_highlight[i], first)
                    first = false
                end

            elseif form == self.forms.Elec then 
                local field = self:get_field()
                local y = self:get_current_tile():y()
                local x = 1
                if self:get_facing() == Direction.Right then 
                    x = field:width()
                end

                create_laser(self, field:tile_at(x, y), self:get_id())

            end

            self:toggle_counter(false)

        end)

        anim:on_complete(function()
            increment_pattern(self)
        
        end)

        self.first_act = false
    end


    for i=1, #self.tiles_to_highlight 
    do
        self.tiles_to_highlight[i]:highlight(Highlight.Flash)
    end

end


function create_rain(self, tile, first)
    local spell = graphic_init("spell", 0, 0, effect_texture, "HecatiaEffects.animation", -8, "RAIN", self, self:get_facing(), true)
    spell.attacking = false

    spell:get_animation():on_frame(4, function()
        spell.attacking = true
        self.tiles_to_highlight = {}
    
        if first then 
            Engine.play_audio(RAIN_SFX, AudioPriority.Low)
        end
    end)

    spell:get_animation():on_frame(16, function()
        spell.attacking = false
    
    end)


    local hit_props = HitProps.new(
        self.damage,
        Hit.Impact | Hit.Flinch | Hit.Flash,
        Element.Aqua, 
        self:get_id(), 
        Drag.None
    )

    spell:set_hit_props(hit_props)


    spell.update_func = function(self)
        if self.attacking then 
            self:get_tile():attack_entities(self)
        end

    end

    spell.attack_func = function()
        Engine.play_audio(HIT_SFX, AudioPriority.Low)
    end



    self:get_field():spawn(spell, tile)
end


function gather_backward_line_of_sight(self)
    local field = self:get_field()
    local y = self:get_current_tile():y()
    local x = 1
    local f = self:get_facing()
    local away = self:get_facing_away()
    if f == Direction.Right then 
        x = field:width()
    end

    local list = {}
    local tile = field:tile_at(x, y)
    table.insert(list, tile)
    while true
    do
        tile = tile:get_tile(away, 1)
        if tile and not tile:is_edge() and tile:get_team() ~= self:get_team() then 
            table.insert(list, tile)
        else
            break
        end
    end

    return list
end


function create_laser(self, tile, id)
    local spell = graphic_init("spell", 0, 0, laser_effect_texture, "HecatiaEffects.animation", -8, "LASER", self, self:get_facing(), true)
    spell.attacking = false
    spell.damage = self.damage

    spell:get_animation():on_frame(2, function()
        local t = tile:get_tile(spell:get_facing_away(), 1)
        if t and not t:is_edge() and t:get_team() ~= spell:get_team() then 
            create_laser(spell, t, id)
        end
    end)

    spell:get_animation():on_frame(4, function()
        spell.attacking = true
       
    end)

 
    spell.on_spawn_func = function()
        Engine.play_audio(LASER_SFX, AudioPriority.Low)
    end


    local hit_props = HitProps.new(
        self.damage,
        Hit.Impact | Hit.Flinch | Hit.Flash | Hit.Pierce | Hit.Breaking,
        Element.Elec, 
        id, 
        Drag.None
    )

    spell:set_hit_props(hit_props)


    spell.boosted = false
    spell.update_func = function(self)
        if self.boosted then 
            local p = spell:copy_hit_props()
            p.damage = self.damage
            
            spell:set_hit_props(p)

            self.boosted = false
        end

        if self.attacking then 
            local t = self:get_current_tile()
            if t:get_state() == TileState.Ice then 
                t:set_state(TileState.Normal)
                local p = spell:copy_hit_props()
                p.damage = p.damage * 2
                
                spell:set_hit_props(p)
                self.boosted = true
            end
            
            t:attack_entities(self)
        
        end

    end

    spell.attack_func = function()
        Engine.play_audio(HIT_SFX, AudioPriority.Low)
    end



    self:get_field():spawn(spell, tile)
end

function create_orb(self, tile)
    if not tile then return end

    local ob = graphic_init("obstacle", 0, 0, effect_texture, "HecatiaEffects.animation", -1, "ORB", self, self:get_facing(), true)
    
    ob.anim = ob:get_animation()
    ob.damage = self.damage
    ob.pre_attack = false
    ob.pre_second_attack = false
    ob:share_tile(true)

    
    ob:set_name("ORB")
    ob:set_height(50)
    ob:set_health(self.max_health)
    ob:toggle_hitbox(true)
    add_defense(ob)

    local hit_props = HitProps.new(
        self.damage,
        Hit.Impact | Hit.Flinch | Hit.Flash,
        Element.None, 
        self:get_id(), 
        Drag.None
    )

    local function attack(self)
        Engine.play_audio(HIT_SFX, AudioPriority.Low)
    end

    local function update(self)
        self:get_current_tile():attack_entities(self)
        self:delete()
    end

    local function collision_attack()
        local spell = Battle.Spell.new(ob:get_team())

        spell.attack_func = attack
        spell.update_func = update
        spell:set_hit_props(hit_props)

        ob:get_field():spawn(spell, ob:get_current_tile())
    end

    ob.on_spawn_func = function()
        Engine.play_audio(SPAWN_SFX, AudioPriority.Low)
    end

    ob.anim:on_frame(3, function()
        ob.pre_attack = true

    end)

    ob.anim:on_frame(7, function()
        ob.pre_attack = false
        ob.pre_second_attack = true
        local t = ob:get_current_tile()
        local tiles = {
            t:get_tile(Direction.UpRight, 1),
            t:get_tile(Direction.DownRight, 1),
            t:get_tile(Direction.DownLeft, 1),
            t:get_tile(Direction.UpLeft, 1)
        }

        for i=1, #tiles
        do
            create_fire(ob, tiles[i])
        end

        Engine.play_audio(FIRE_SFX, AudioPriority.Low)
    end)

    ob.anim:on_frame(13, function()
        ob.pre_attack = false
        local t = ob:get_current_tile()
        local tiles = {
            t:get_tile(Direction.Up, 1),
            t:get_tile(Direction.Right, 1),
            t:get_tile(Direction.Down, 1),
            t:get_tile(Direction.Left, 1)
        }

        for i=1, #tiles
        do
            create_fire(ob, tiles[i])
        end

        Engine.play_audio(FIRE_SFX, AudioPriority.Low)
    end)

    ob.can_move_to_func = function()
        return false
    end

    ob.update_func = function(ob)
        collision_attack()
        if ob.pre_attack then 
            local t = ob:get_current_tile()
            local tiles = {
                t:get_tile(Direction.UpRight, 1),
                t:get_tile(Direction.DownRight, 1),
                t:get_tile(Direction.DownLeft, 1),
                t:get_tile(Direction.UpLeft, 1)
            }

            for i=1, #tiles
            do
                tiles[i]:highlight(Highlight.Flash)
            end
        elseif ob.pre_second_attack then 
            local t = ob:get_current_tile()
            local tiles = {
                t:get_tile(Direction.Up, 1),
                t:get_tile(Direction.Right, 1),
                t:get_tile(Direction.Down, 1),
                t:get_tile(Direction.Left, 1)
            }

            for i=1, #tiles
            do
                tiles[i]:highlight(Highlight.Flash)
            end
        end

    end

    self:get_field():spawn(ob, tile)
end


function add_defense(ent)
    local defense = Battle.DefenseRule.new(0,DefenseOrder.CollisionOnly)

    defense.can_block_func = function(judge, attacker, defender)
        local attacker_hit_props = attacker:copy_hit_props()

        
        if attacker_hit_props.damage > 0 then
            local f = defender:get_facing()
            local flip = 1
            if f == Direction.Left then 
                flip = -1
            end
            defender:get_field():spawn(graphic_init("artifact", flip*defender:get_tile_offset().x, -20, hit_effects_texture, "HecatiaEffects.animation", -9, "GUARD", defender, f, true), defender:get_current_tile())
            Engine.play_audio(GUARD_SFX, AudioPriority.Low)

        end

        judge:block_impact()
        judge:block_damage()

    end

   -- defense.filter_statuses_func = function(statuses)
     --   statuses.flags = statuses.flags & ~Hit.Drag
       -- return statuses
    --end
    
    ent:add_defense_rule(defense)

end



function choose_random_enemy_tile(self)
    local field = self:get_field()
    local tiles = field:find_tiles(function(tile)
        local c = tile:find_characters(function() return true end)
        return not tile:is_edge() and tile:get_team() ~= self:get_team() and #c == 0
    
    end)

    if #tiles == 0 then 
        tiles = field:find_tiles(function(tile)
            return not tile:is_edge() and tile:get_team() ~= self:get_team()
        
        end)
    end

    

    return tiles[math.random(1, #tiles)]
end

function choose_n_random_enemy_tiles(self, n)
    local field = self:get_field()
    local tile_set = {}
    local tiles = field:find_tiles(function(tile)
        return not tile:is_edge() and tile:get_team() ~= self:get_team()
    
    end)

    for i=1, n
    do
        if #tiles == 0 then break end
        local r = math.random(1, #tiles)
        table.insert(tile_set, tiles[r])
        table.remove(tiles, r)
    end    

    return tile_set
end

function choose_move(self, field)
    local team = self:get_team()

    local tiles = field:find_tiles(function(tile)
        return tile ~= self:get_current_tile() and self.can_move_to_func(tile)
    
    end)


    --print("Found ", #tiles, " possible tiles")

    if #tiles == 0 then 
        return self:get_current_tile()
    end

    return tiles[math.random(1, #tiles)]
end

function move_to_column_in_front_of_target(self)
    if self.first_act then 
        anim:set_state("MOVE_"..self.behavior)
        local could_move = false
        self.moving_to_enemy_tile = true
        local tile = choose_column_in_front_of_enemy(self, self:get_field())

        anim:on_frame(2, function()
            if tile and self.can_move_to_func(tile) then 
               could_move = true
            else
                --print("Can't do it now")
                tile = self:get_current_tile()
            end
            self:teleport(tile, ActionOrder.Voluntary, function()
                --print("Move")
            end)
        end)

        anim:on_complete(function()
            increment_pattern(self)
            if not could_move then 
                while self.in_sub_pattern
                do
                    increment_pattern(self)
                end
            end
        end)

        self.first_act = false
    end
end

function choose_column_in_front_of_enemy(self, field)
    local team = self:get_team()
    local tile

    local target = field:find_characters(function(c)
        return c:get_team() ~= team
    end)

    if not target[1] then 
       -- print("No targets")
        return nil
    end

    local offset = 1
    if self:get_facing() == Direction.Right then 
        offset = -1
    end

    -- X of tile in front of target
    local x = target[1]:get_current_tile():x() + offset
    for i = 1, field:height()
    do
        local t = field:tile_at(x, i)
        local check = self.can_move_to_func(t)
        if check then 
            return t
        end
    end


    return nil
end

function choose_move_line_up(self, field)
    local team = self:get_team()

    local target = field:find_characters(function(c)
        return c:get_team() ~= team
    end)

    if not target[1] then 
       -- print("No targets")
        return choose_move(self, field)
    end

    t_x = target[1]:get_current_tile():x()
    t_y = target[1]:get_current_tile():y()

    local facing = -1
    if self:get_facing() == Direction.Right then 
        facing = 1
    end

    local tiles = field:find_tiles(function(tile)
        return tile:y() == t_y and facing * (tile:x() - t_x) < 0 and self.can_move_to_func(tile)
    
    end)

   

    if #tiles == 0 then 
      --  print("No valid tiles")
        return choose_move(self, field)
    end


    return tiles[math.random(1, #tiles)]
end

function choose_enemy(self, field)
    local team = self:get_team()

    local target = field:find_characters(function(c)
        return c:get_team() ~= team
    end)

    if not target[1] then 
       -- print("No targets")
        return nil
    end

    t_x = target[1]:get_current_tile():x()
    t_y = target[1]:get_current_tile():y()

    local facing = -1
    if target[1]:get_facing() == Direction.Right then 
        facing = 1
    end

    local tile = field:tile_at(t_x+facing, t_y)

    return tile
end

function choose_move_back(self, field)
    local team = self:get_team()


    local x = 6
    if self:get_facing() == Direction.Right then 
        x = 1
    end

    local tiles = field:find_tiles(function(tile)
        return tile:x() == x and self.can_move_to_func(tile)
    
    end)

    if #tiles == 0 then 
      --  print("No valid tiles")
        return choose_move(self, field)
    end


    return tiles[math.random(1, #tiles)]
end

function choose_move_back_center(self, field)
    local team = self:get_team()

    local x = 6
    local y = 2

    
    if self:get_facing() == Direction.Right then 
        x = 1
    end

    local t = field:tile_at(x, y)

    if not self.can_move_to_func(t) then 
        return choose_move_back(self, field)
    end

    return t
end

function choose_near_front(self, field, p)
    local team = self:get_team()
    
    local x = 6

    local facing = self:get_facing()

    if facing == Direction.Right then 
        x = 1
    end

    local front_tiles = {
        field:tile_at(x, 1),
        field:tile_at(x, 2),
        field:tile_at(x, 3)
    }

    local function find_front_row()
        for i=1, #front_tiles
        do
            t = front_tiles[i]
            for j=1, field:width()
            do
                t = t:get_tile(facing, 1)
                if t and not t:is_edge() and t:get_team() == self:get_team() then 
                    front_tiles[i] = t
                else
                    break
                end
            end
        end
    end


    find_front_row()

    local tiles = {
        front_tiles[2],
        front_tiles[2]:get_tile(Direction.reverse(facing), 1),

        front_tiles[1],
        front_tiles[1]:get_tile(Direction.reverse(facing), 1),

        front_tiles[3],
        front_tiles[3]:get_tile(Direction.reverse(facing), 1)
    }

    if p == self.states.flare then 
        if self.can_move_to_func(tiles[1]) then 
            return tiles[1]
        elseif self.can_move_to_func(tiles[2]) then 
            return tiles[2]
        end
    end


    local j = #tiles
    for i=1, #tiles
    do
        r = math.random(1, #tiles)
        if self.can_move_to_func(tiles[r]) then 
            return tiles[r]
        else
            table.remove(tiles, r)
        end
    end

    return choose_move(self, field)

end

function move_line_up(self)
    if self.first_act then 
        anim:set_state("MOVE_"..self.behavior)

        local tile = choose_move_line_up(self, self:get_field())

        anim:on_frame(3, function()
            if self.can_move_to_func(tile) then 
               -- print("Can reach")
            else
                --print("Can't do it now")
                tile = self:get_current_tile()
            end
            self:teleport(tile, ActionOrder.Voluntary, function()
               -- print("Move")
            end)
        end)

        anim:on_complete(function()
            increment_pattern(self)
        
        end)

        self.first_act = false
    end
end

function move_to_back(self)
    if self.first_act then 
        anim:set_state("MOVE_"..self.behavior)

        local tile = choose_move_back(self, self:get_field())

        anim:on_frame(3, function()
            if self.can_move_to_func(tile) then 
              --  print("Can reach")
            else
                --print("Can't do it now")
                tile = self:get_current_tile()
            end
            self:teleport(tile, ActionOrder.Voluntary, function()
               -- print("Move")
            end)
        end)

        anim:on_complete(function()
            increment_pattern(self)
        
        end)

        self.first_act = false
    end
end

function move_to_back_center(self)
    if self.first_act then 
        anim:set_state("MOVE_"..self.behavior)

        local tile = choose_move_back_center(self, self:get_field())

        anim:on_frame(3, function()
            if self.can_move_to_func(tile) then 
              --  print("Can reach")
            else
                --print("Can't do it now")
                tile = self:get_current_tile()
            end
            self:teleport(tile, ActionOrder.Voluntary, function()
                --print("Move")
            end)
        end)

        anim:on_complete(function()
            increment_pattern(self)
        
        end)

        self.first_act = false
    end
end


function move_near_front(self)
    if self.first_act then 
        anim:set_state("MOVE_"..self.behavior)

        local next = self.pattern[self.pattern_index+1]
        local tile = choose_near_front(self, self:get_field(), next)

        anim:on_frame(3, function()
            if self.can_move_to_func(tile) then 
           --     print("Can reach")
            else
             --   print("Can't do it now")
                tile = self:get_current_tile()
            end
            self:teleport(tile, ActionOrder.Voluntary, function()
               -- print("Move")
            end)
        end)

        anim:on_complete(function()
            increment_pattern(self)
        
        end)

        self.first_act = false
    end
end


function move_to_enemy(self)
    if self.first_act then 
        anim:set_state("MOVE_"..self.behavior)
        local could_move = true
        anim:on_frame(3, function()
            local tile = choose_enemy(self, self:get_field())
            
            if not tile then 
                could_move = false
            else
                self.moving_to_enemy_tile = true
                if self.can_move_to_func(tile) then 
                  --  print("Target tile is ", tile:x(), tile:y())
                    self:teleport(tile, ActionOrder.Voluntary, function()

                    end)
                else
                    could_move = false
                end
            end
        end)

        anim:on_complete(function()
            self.moving_to_enemy_tile = false

            if could_move then 
                increment_pattern(self)
            else
                end_sub_pattern(self)
            end
        
        end)

        self.first_act = false
    end
end


function increment_pattern(self)
   -- print("Pattern increment")
    self.end_attack = false

    self.first_act = true
    self.state_done = false
    if self.should_clear_highlight then 
        self.tiles_to_highlight = {}
    end

    self.pattern_index = self.pattern_index + 1
    if self.pattern_index > #self.pattern then 
        self.pattern_index = 1
    end

    local next_state = self.pattern[self.pattern_index]
    self.state = next_state
   -- print("Moving to state named ", next_state.name)

    if next_state == self.states.start_sub_pattern then 
        self.in_sub_pattern = true
        increment_pattern(self)
    end

    if next_state == self.states.finish_sub_pattern then 
        self.in_sub_pattern = false
        increment_pattern(self)

    end


   -- print("Changing to "..self.pattern_index..", which is "..self.pattern[self.pattern_index].name)

end

function check_obstacles(tile, self)
    local ob = tile:find_obstacles(function(o)
        return o:get_health() > 0 --and o:get_id() ~= self.planet1:get_id() and o:get_id() ~= self.planet2:get_id()
    end)

    return #ob > 0 
end


function check_characters(tile, self)
    local characters = tile:find_characters(function(c)
        return c:get_id() ~= self:get_id() and c:get_team() ~= self:get_team()
    end)

    return #characters > 0

end


function graphic_init(type, x, y, texture, animation, layer, state, user, facing, delete_on_complete, flip)
    flip = flip or false
    delete_on_complete = delete_on_complete or false
    facing = facing or nil
    
    local graphic = nil
    if type == "artifact" then 
        graphic = Battle.Artifact.new()

    elseif type == "spell" then 
        graphic = Battle.Spell.new(user:get_team())
    
    elseif type == "obstacle" then 
        graphic = Battle.Obstacle.new(user:get_team())

    end

    graphic:sprite():set_layer(layer)
    graphic:never_flip(flip)
    graphic:set_texture(texture, true)
    if facing then 
        graphic:set_facing(facing)
    end
    
    if user:get_facing() == Direction.Left then 
        x = x * -1
    end
    graphic:set_offset(x, y)
    local anim = graphic:get_animation()
    anim:load(_folderpath..animation)

    anim:set_state(state)
    anim:refresh(graphic:sprite())

    if delete_on_complete then 
        anim:on_complete(function()
            graphic:delete()
        end)
    end

    return graphic
end