-- Animations and Textures
local CHARACTER_ANIMATION = _folderpath .. "battle.animation"
local CHARACTER_TEXTURE = Engine.load_texture(_folderpath .. "battle.png")
--possible states for character
local states = { DEFAULT = 1, SEEK = 2, ATTACK = 3 }
-- Load character resources
---@param self Entity
function package_init(self, character_info)
    -- Required function, main package information
    local base_animation_path = CHARACTER_ANIMATION
    self:set_texture(CHARACTER_TEXTURE)
    self.animation = self:get_animation()
    self.animation:load(base_animation_path)
    -- Load extra resources
    -- Set up character meta
    -- Common Properties
    self:set_name(character_info.name)
    self.__ezhp_native_max_hp = (character_info.hp)
    self:set_height(character_info.height)

    --Other Setup
    self:set_explosion_behavior(1, 1, false)
    -- entity will spawn with this animation.
    self.animation:set_state("IDLE")
end


-- EZEncounters deferred native HP adapter.
-- The native fallback must not lock max HP in on_spawn_func: some client
-- spawners run on_spawn before their encounter mutate callback.
-- Battle start occurs after encounter mutations and before the first update.
local __ezhp_original_package_init = package_init
package_init = function(character, ...)
    __ezhp_original_package_init(character, ...)
    local __ezhp_original_battle_start = character.battle_start_func
    character.battle_start_func = function(self, ...)
        if self:get_max_health() == 0 then
            local native = tonumber(self.__ezhp_native_max_hp)
            if not native or native ~= native or native <= 0 or native == math.huge then native = 1 end
            native = math.max(1, math.floor(native))
            self:set_health(native)
            print('[EZHP][CLIENT][NATIVE_FALLBACK_BATTLE_START]', tostring(self:get_name()), native,
                'actual', self:get_max_health())
        end
        if __ezhp_original_battle_start then return __ezhp_original_battle_start(self, ...) end
    end
end

return package_init
