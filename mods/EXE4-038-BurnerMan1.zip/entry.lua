local package_id = "com.OFC.mob.EXE4-038-BurnerMan1"
local character_id = "com.OFC.char.EXE4-038-BurnerMan1"

function package_requires_scripts()
    Engine.define_character(character_id, _modpath.."BurnerMan")
end

function package_init(package)
    package:declare_package_id(package_id)
    package:set_name("BurnerMan (EXE4)")
    package:set_description("Test fight with\nBurnerMan\nfrom Rockman EXE4")
    package:set_speed(1)
    package:set_attack(40)
    package:set_health(700)
    package:set_preview_texture_path(_modpath.."preview.png")
end

function package_build(mob)
    local texPath = _modpath.."exe4-tournamentb.png"
    local animPath = _modpath.."exe4-tournamentb.animation"
    mob:set_background(texPath, animPath, 0.12, 0)
    mob:stream_music(_modpath.."exe4-tournament.ogg", 6898, 58550)
    mob:create_spawner(character_id, Rank.V1):spawn_at(6,2)
end  