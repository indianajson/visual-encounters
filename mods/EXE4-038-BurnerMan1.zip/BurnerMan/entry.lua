----
--[[

    BurnerMan boss character from "Rockman EXE4: Tournament Red Sun/Tournament Blue Moon"
    Ported to Open Net Battle (ONB) by K1rbYat1Na


    Moveset:

    BurnerMan moves randomly 5 times, then uses Strike Burner. After that, he uses Burning Jet on every 3rd pattern loop.
    If BurnerMan's Confused or Blinded, his idle time doesn't increase but he can randomly skip Strike Burner and Burning Jet.


    Attacks:

    HEAT CHASERS
    When BurnerMan spawns, two Heat Chasers fly onto the battlefield and land on the squares that are 1 square away from the edge of BurnerMan's field.
    Each of them has 100 HP and Guard (can be destroyed only by Guard-piercing/Break attacks).
    They only act 60f after the battle starts.
    The upper Heat Chaser moves forward until it reaches the Player below, or reaches the other edge of the battlefield, or until it encounters an Obstacle.
    Then it charges up for attack. Then fires a 2-tile range flamethrower for ~60f.
    Then it returns to the edge of BurnerMan's field and the lower Heat Chaser goes into action.
    It acts the same as the upper Heat Chaser. Upon reaching the end, the upper Heat Chaser begins moving again and the cycle begins.
    Heat Chaser can't attack again if it can't return to the field's end.
    If Heat Chaser is destroyed, it starts respawning after ~1450f.
    Despite Heat Chaser being an Obstacle, other Characters and Navis spawned by Navi Chips can pass through it.
    Heat Chaser's body deals Null damage, causes Flinching and Flashing, and can pierce Guard.
    Heat Chaser's flame deals Fire damage, causes Flinching and Flashing.
    If BurnerMan is Confused or Blinded, they stop moving and locks into the center of the current tile. When the status ends and it was moving forward, it chooses a direction and moves towards the closest player.

    STRIKE BURNER
    BurnerMan moves to the tile closest to the Player and fires a 3-tile long flamethrower for ~62f.
    Deals Fire damage. Causes Flinching and Flashing.
    If BurnerMan is Confused or Blind, he's chooses a completly random tile on his field.

    BURNING JET
    BurnerMan charges down the Player's line, until he reached the edge or a hole. Then returns to the original tile. Can be used twice at once.
    Burning Jet has 2 hitboxes.
    The first one deals 0 Fire-elemental damage, pierces Guard, causes Flashing but not Flinching.
    The second one deals Fire-elemental damage, pierces Guard, causes Flashing and Flinching.
    
]]--
----

local print_debug = false -- Turns on/off the debug text.

-- HIT SOUNDS --
local AUDIO_DAMAGE_ENEMY = Engine.load_audio(_folderpath.."sfx/EXE4_270.ogg", true)
local AUDIO_DAMAGE_OBS = Engine.load_audio(_folderpath.."sfx/EXE4_221.ogg", true)
----------------

-- THE CHARACTER GRAPHIC ASSETS --
local CHARACTER_TEXTURE = nil
local CHARACTER_PALETTE = nil
local CHARACTER_ANIMPATH = _folderpath.."gfx/battle.animation"
----------------------------------

-- OTHER GRAPHIC ASSETS --
local STRIKEBURNER_TEXTURE = Engine.load_texture(_folderpath.."gfx/strikeburner.grayscaled.png")
local STRIKEBURNER_ANIMPATH = _folderpath.."gfx/strikeburner.animation"
local HEATCHASER_U_TEXTURE = Engine.load_texture(_folderpath.."gfx/heatchaser_u.grayscaled.png")
local HEATCHASER_U_ANIMPATH = _folderpath.."gfx/heatchaser_u.animation"
local HEATCHASER_D_TEXTURE = Engine.load_texture(_folderpath.."gfx/heatchaser_d.grayscaled.png")
local HEATCHASER_D_ANIMPATH = _folderpath.."gfx/heatchaser_d.animation"
--------------------------

-- HIT GFXS --
local GUARD_TEXTURE = Engine.load_texture(_folderpath.."gfx/guard.grayscaled.png")
local GUARD_PALETTE = Engine.load_texture(_folderpath.."gfx/palette/guard.png")
local GUARD_ANIMPATH = _folderpath.."gfx/guard.animation"
local EFFECT_HC_BODY_TEXTURE = Engine.load_texture(_folderpath.."gfx/effect_hc_body.grayscaled.png")
local EFFECT_HC_BODY_PALETTE = Engine.load_texture(_folderpath.."gfx/palette/effect_hc_body.png")
local EFFECT_HC_BODY_ANIMPATH = _folderpath.."gfx/effect_hc_body.animation"
local EFFECT_FIRE_TEXTURE = Engine.load_texture(_folderpath.."gfx/effect_fire.grayscaled.png")
local EFFECT_FIRE_PALETTE = Engine.load_texture(_folderpath.."gfx/palette/effect_fire.png")
local EFFECT_FIRE_ANIMPATH = _folderpath.."gfx/effect_fire.animation"
--------------

-- OTHER GFXS --
local MOB_MOVE_TEXTURE = Engine.load_texture(_folderpath.."gfx/mob_move.grayscaled.png")
local MOB_MOVE_PALETTE = Engine.load_texture(_folderpath.."gfx/palette/mob_move.png")
local MOB_MOVE_ANIMPATH = _folderpath.."gfx/mob_move.animation"
local BOOM_TEXTURE = Engine.load_texture(_folderpath.."gfx/boom.grayscaled.png")
local BOOM_PALETTE = Engine.load_texture(_folderpath.."gfx/palette/boom.png")
local BOOM_ANIMPATH = _folderpath.."gfx/boom.animation"
----------------

-- OTHER SOUNDS --
local HEATCHASER_AUDIO = Engine.load_audio(_folderpath.."sfx/EXE4_303.ogg", true)
local STRIKEBURNER_AUDIO = Engine.load_audio(_folderpath.."sfx/EXE4_220.ogg", true)
local BURNINGJET_AUDIO = Engine.load_audio(_folderpath.."sfx/EXE4_118.ogg", true)
local GUARD_AUDIO = Engine.load_audio(_folderpath.."sfx/EXE4_49.ogg", true)
local BOOM_AUDIO = Engine.load_audio(_folderpath.."sfx/EXE4_273.ogg", true)
------------------

-- LIBRARIES --
local ObstacleInfo = include("ObstacleInfo.lua")
---------------

-- Prints the debug text.
local function debug_print(text)
    if print_debug then
        print("[BurnerMan] "..text)
    end
end

--(Function by Alrysc, edited by K1rbYat1Na)
local function graphic_init(type, x, y, texture, palette, animation, layer, state, anim_playback, user, facing, delete_on_complete, relative_to_user, flip)
    texture = texture or nil
    animation = animation or nil
    layer = layer or nil
    state = state or nil
    anim_playback = anim_playback or nil
    facing = facing or nil
    delete_on_complete = delete_on_complete or false
    flip = flip or false
    
    local graphic = nil
    if type == "artifact" then 
        graphic = Battle.Artifact.new()
    elseif type == "spell" then 
        graphic = Battle.Spell.new(user:get_team())
    elseif type == "obstacle" then 
        graphic = Battle.Obstacle.new(user:get_team())
    end
    if palette then
        graphic:store_base_palette(palette)
        graphic:set_palette(graphic:get_base_palette())
    end
    if layer then
        graphic:sprite():set_layer(layer)
    end
    graphic:never_flip(flip)
    if texture then
        graphic:set_texture(texture, false)
    end
    if facing then 
        graphic:set_facing(facing)
    end
    
    if relative_to_user and user:get_facing() == Direction.Left then 
        x = x * -1
    end
    graphic:set_offset(x, y)
    local anim = graphic:get_animation()
    if animation then
        graphic:get_animation():load(animation)
    end
    if state then
        graphic:get_animation():set_state(state)
    end
    if anim_playback then
        graphic:get_animation():set_playback(anim_playback)
    end
    anim:refresh(graphic:sprite())

    if delete_on_complete then 
        anim:on_complete(function()
            graphic:delete()
        end)
    end

    return graphic
end

local round = function(val, obj)
    if obj:get_facing() == Direction.Right then
        return math.floor(val)
    else
        return math.ceil(val)
    end
end

-- Hitbox (Burning Jet's both hitboxes)
-- Hits once.
local function create_hitbox_burningjet(user, hit_props, tile, second)
    if not tile or tile:is_edge() then return end
    local field = user:get_field()
    local team = user:get_field()
    local hitbox = Battle.Spell.new(user:get_team())
    hitbox:set_facing(user:get_facing())
    hitbox:set_hit_props(hit_props)
    hitbox.highlightning = true
    hitbox.prev_tile = tile
    hitbox.update_func = function(self)
        if self:get_tile() ~= self.prev_tile then
            self.highlightning = true
            self.prev_tile = self:get_tile()
        end
        if self.highlightning then
            self:highlight_tile(Highlight.Solid)
            self:get_tile():attack_entities(self)
        end
    end
    hitbox.collision_func = function(self, other)
        self.highlightning = false
    end
    hitbox.attack_func = function(self, other)
        if not second then
            local offset_y = math.random(0,5)
            local offset_x = math.random(-6,5)
            local hit_fx = graphic_init("artifact", user:get_tile_offset().x+(offset_x*2), user:get_tile_offset().y+(offset_y*2), EFFECT_FIRE_TEXTURE, EFFECT_FIRE_PALETTE, EFFECT_FIRE_ANIMPATH, -999, "0", Playback.Once, self, self:get_facing(), true, true, true)
            self:get_field():spawn(hit_fx, self:get_tile())
        else
            if not other:get_animation():has_state("HITSOUND_N") and #other:sprite():find_child_nodes_with_tags({"IS_BARRIER"}) <= 0 then
                if not other:get_animation():has_state("HITSOUND_C") and not other:get_animation():has_state("HITSOUND_O") then
    	            if Battle.Obstacle.from(other) == nil then
                        --if Battle.Player.from(user) ~= nil then
		                --	Engine.play_audio(AUDIO_DAMAGE_ENEMY, AudioPriority.Low)
		                --end
                    else
		            	Engine.play_audio(AUDIO_DAMAGE_OBS, AudioPriority.Low)
		            end
                else
                    if other:get_animation():has_state("HITSOUND_C") then
		                --if Battle.Player.from(user) ~= nil then
		                --	Engine.play_audio(AUDIO_DAMAGE_ENEMY, AudioPriority.Low)
		                --end
    	            end
    	            if other:get_animation():has_state("HITSOUND_O") then
		            	Engine.play_audio(AUDIO_DAMAGE_OBS, AudioPriority.Low)
		            end
                end
    	    end
        end
        if Battle.Obstacle.from(other) ~= nil then
            other:delete()
		end
    end
    hitbox.delete_func = function(self)
        --print("NO BOX")
    end
    hitbox.can_move_to_func = function(tile)
        return true
    end
    field:spawn(hitbox, tile)
    return hitbox
end

-- Hitbox (Heat Chaser's flame)
-- Hits once.
local function create_hitbox_heatchaser_fire(user, fire, tile)
    if not tile or tile:is_edge() then return end
    local field = user:get_field()
    local team = user:get_field()
    local hitbox = Battle.Spell.new(user:get_team())
    hitbox:set_facing(user:get_facing())
    hitbox:set_hit_props(
        HitProps.new()
        :dmg(user.damage_heatchaser_fire)
        :impact()
        :flinch()
        :flash()
        :no_counter()
        :from(user:get_context())
        :elem(Element.Fire)
    )
    hitbox.update_func = function(self)
        if not fire or fire:is_deleted() then self:delete() end
        self:highlight_tile(Highlight.Solid)
        self:get_tile():attack_entities(self)
    end
    hitbox.attack_func = function(self, other)
        local offset_y = math.random(-30,-15)
        local offset_x = math.random(-8,7)
        local hit_fx = graphic_init("artifact", (offset_x*2), (offset_y*2), EFFECT_FIRE_TEXTURE, EFFECT_FIRE_PALETTE, EFFECT_FIRE_ANIMPATH, -999, "0", Playback.Once, self, self:get_facing(), true, true, true)
        self:get_field():spawn(hit_fx, self:get_tile())
        if not other:get_animation():has_state("HITSOUND_N") and #other:sprite():find_child_nodes_with_tags({"IS_BARRIER"}) <= 0 then
            if not other:get_animation():has_state("HITSOUND_C") and not other:get_animation():has_state("HITSOUND_O") then
    	        if Battle.Obstacle.from(other) == nil then
                    --if Battle.Player.from(user) ~= nil then
		            --	Engine.play_audio(AUDIO_DAMAGE_ENEMY, AudioPriority.Low)
		            --end
                else
		        	Engine.play_audio(AUDIO_DAMAGE_OBS, AudioPriority.Low)
		        end
            else
                if other:get_animation():has_state("HITSOUND_C") then
		            --if Battle.Player.from(user) ~= nil then
		            --	Engine.play_audio(AUDIO_DAMAGE_ENEMY, AudioPriority.Low)
		            --end
    	        end
    	        if other:get_animation():has_state("HITSOUND_O") then
		        	Engine.play_audio(AUDIO_DAMAGE_OBS, AudioPriority.Low)
		        end
            end
    	end
    end
    field:spawn(hitbox, tile)
    return hitbox
end

-- Hitbox (Heat Chaser's body)
-- Spawns every time there's a Character.
local function create_hitbox_heatchaser(user, tile)
    if not tile or tile:is_edge() then return end
    local field = user:get_field()
    local hitbox = Battle.Spell.new(user:get_team())
    hitbox:set_facing(user:get_facing())
    hitbox:set_hit_props(
        HitProps.new()
        :dmg(user.damage_heatchaser)
        :impact()
        :flinch()
        :flash()
        :breaking()
        :no_counter()
        :from(user:get_context())
        :elem(Element.None)
    )
    hitbox.update_func = function(self)
        self:get_tile():attack_entities(self)
        self:erase()
    end
    hitbox.attack_func = function(self, other)
        local offset_y = math.random(-22,-10)
        local offset_x = math.random(-7,6)
        local hit_fx = graphic_init("artifact", (offset_x*2), (offset_y*2), EFFECT_HC_BODY_TEXTURE, EFFECT_HC_BODY_PALETTE, EFFECT_HC_BODY_ANIMPATH, -999, "0", Playback.Once, self, self:get_facing(), true, true, true)
        self:get_field():spawn(hit_fx, self:get_tile())
        if not other:get_animation():has_state("HITSOUND_N") and #other:sprite():find_child_nodes_with_tags({"IS_BARRIER"}) <= 0 then
            if not other:get_animation():has_state("HITSOUND_C") and not other:get_animation():has_state("HITSOUND_O") then
    	        if Battle.Obstacle.from(other) == nil then
                    --if Battle.Player.from(user) ~= nil then
		            --	Engine.play_audio(AUDIO_DAMAGE_ENEMY, AudioPriority.Low)
		            --end
                else
		        	Engine.play_audio(AUDIO_DAMAGE_OBS, AudioPriority.Low)
		        end
            else
                if other:get_animation():has_state("HITSOUND_C") then
		            --if Battle.Player.from(user) ~= nil then
		            --	Engine.play_audio(AUDIO_DAMAGE_ENEMY, AudioPriority.Low)
		            --end
    	        end
    	        if other:get_animation():has_state("HITSOUND_O") then
		        	Engine.play_audio(AUDIO_DAMAGE_OBS, AudioPriority.Low)
		        end
            end
    	end
    end
    field:spawn(hitbox, tile)
    return hitbox
end

-- Hitbox (Strike Burner)
-- Hits once.
local function create_hitbox_strikeburner(user, fire, tile)
    if not tile or tile:is_edge() then return end
    local field = user:get_field()
    local team = user:get_field()
    local hitbox = Battle.Spell.new(user:get_team())
    hitbox:set_facing(user:get_facing())
    hitbox:set_hit_props(
        HitProps.new()
        :dmg(user.damage_strikeburner)
        :impact()
        :flinch()
        :flash()
        :from(user:get_context())
        :elem(Element.Fire)
    )
    hitbox.do_once = true
    hitbox.update_func = function(self)
        if not fire or fire:is_deleted() then self:delete() end
        self:highlight_tile(Highlight.Solid)
        self:get_tile():attack_entities(self)
    end
    hitbox.attack_func = function(self, other)
        local offset_y = math.random(-30,-15)
        local offset_x = math.random(-8,7)
        local hit_fx = graphic_init("artifact", (offset_x*2), (offset_y*2), EFFECT_FIRE_TEXTURE, EFFECT_FIRE_PALETTE, EFFECT_FIRE_ANIMPATH, -999, "0", Playback.Once, self, self:get_facing(), true, true, true)
        self:get_field():spawn(hit_fx, self:get_tile())
        if not other:get_animation():has_state("HITSOUND_N") and #other:sprite():find_child_nodes_with_tags({"IS_BARRIER"}) <= 0 then
            if not other:get_animation():has_state("HITSOUND_C") and not other:get_animation():has_state("HITSOUND_O") then
    	        if Battle.Obstacle.from(other) == nil then
                    --if Battle.Player.from(user) ~= nil then
		            --	Engine.play_audio(AUDIO_DAMAGE_ENEMY, AudioPriority.Low)
		            --end
                else
		        	Engine.play_audio(AUDIO_DAMAGE_OBS, AudioPriority.Low)
		        end
            else
                if other:get_animation():has_state("HITSOUND_C") then
		            --if Battle.Player.from(user) ~= nil then
		            --	Engine.play_audio(AUDIO_DAMAGE_ENEMY, AudioPriority.Low)
		            --end
    	        end
    	        if other:get_animation():has_state("HITSOUND_O") then
		        	Engine.play_audio(AUDIO_DAMAGE_OBS, AudioPriority.Low)
		        end
            end
    	end
    end
    field:spawn(hitbox, tile)
    return hitbox
end

-- Strike Burner GFX
local function create_strike_burner(user, tile)
    if not tile or tile:is_edge() then return end
    local field = user:get_field()
    local burner = graphic_init("spell", 0, 0, STRIKEBURNER_TEXTURE, user:get_base_palette(), STRIKEBURNER_ANIMPATH, -3, "0", Playback.Loop, user, user:get_facing())
    burner.frames = 0
    burner.on_spawn_func = function()
        Engine.play_audio(STRIKEBURNER_AUDIO, AudioPriority.Low)
    end
    burner.update_func = function(self)
        self.frames = self.frames + 1
        if self.frames%16==0 then Engine.play_audio(STRIKEBURNER_AUDIO, AudioPriority.Low) end
    end
    burner.box1 = create_hitbox_strikeburner(user, burner, tile)
    burner.box2 = create_hitbox_strikeburner(user, burner, tile:get_tile(user:get_facing(), 1))
    burner.box3 = create_hitbox_strikeburner(user, burner, tile:get_tile(user:get_facing(), 2))
    field:spawn(burner, tile)
    return burner
end

-- Creates a Heat Chaser.
local function create_heat_chaser(user, start_state, type)
    local hit_query = function(e)
        return (Battle.Obstacle.from(e) ~= nil or Battle.Character.from(e) ~= nil or Battle.Player.from(e) ~= nil) and not e:is_team(user:get_team()) and e:get_health() > 0
    end
    local char_query = function(c)
        return c:get_health() > 0 and not c:is_team(user:get_team())
    end
    local obs_query = function(o)
        return o:get_health() > 0
    end
    if type == "UPPER" then
        user.heatchaser_u = graphic_init("obstacle", 0, 0, HEATCHASER_U_TEXTURE, CHARACTER_PALETTE, HEATCHASER_U_ANIMPATH, -1, "0", Playback.Loop, user, user:get_facing(), false, true)
        user.heatchaser_u:set_name("HeatChaserU")
        user.heatchaser_u:set_health(100)
        user.heatchaser_u:share_tile(true)
		ObstacleInfo.set_cannot_be_targeted(user.heatchaser_u, true)
		ObstacleInfo.set_cannot_be_manipulated(user.heatchaser_u, true)
		ObstacleInfo.set_obstacle_damage(user.heatchaser_u, Element.None, user.damage_heatchaser)
        user.heatchaser_u.frames = 0
        user.heatchaser_u.state = start_state
        user.heatchaser_u.tileWidth = nil
        user.heatchaser_u.hitbox1 = nil
        user.heatchaser_u.hitbox2 = nil
        user.heatchaser_u.offset_x = 0
        user.heatchaser_u.speed = 1*2
    else
        user.heatchaser_d = graphic_init("obstacle", 0, 0, HEATCHASER_D_TEXTURE, CHARACTER_PALETTE, HEATCHASER_D_ANIMPATH, -1, "0", Playback.Loop, user, user:get_facing(), false, true)
        user.heatchaser_d:set_name("HeatChaserD")
        user.heatchaser_d:set_health(100)
        user.heatchaser_d:share_tile(true)
		ObstacleInfo.set_cannot_be_targeted(user.heatchaser_d, true)
		ObstacleInfo.set_cannot_be_manipulated(user.heatchaser_d, true)
		ObstacleInfo.set_obstacle_damage(user.heatchaser_d, Element.None, user.damage_heatchaser)
        user.heatchaser_d.frames = 0
        user.heatchaser_d.state = start_state
        user.heatchaser_d.tileWidth = nil
        user.heatchaser_d.hitbox1 = nil
        user.heatchaser_d.hitbox2 = nil
        user.heatchaser_d.offset_x = 0
        user.heatchaser_d.speed = 1*2
    end
    local heatchaser_defense = Battle.DefenseRule.new(10, DefenseOrder.Always)
    heatchaser_defense.can_block_func = function(judge, attacker, defender)
        local attacker_hit_props = attacker:copy_hit_props()
        if (attacker_hit_props.flags & Hit.Breaking ~= Hit.Breaking) and attacker_hit_props.element ~= Element.Break and attacker_hit_props.element2 ~= Element.Break then
            judge:block_impact()
            judge:block_damage()
            if attacker_hit_props.damage > 0 then
                Engine.play_audio(GUARD_AUDIO, AudioPriority.Low)
                local offset_y = math.random(-24,-9)
                local offset_x = math.random(-9,8) --math.random(-9,5)
                if type == "UPPER" then
                    local hit_fx = graphic_init("artifact", user.heatchaser_u:get_tile_offset().x+user.heatchaser_u:get_offset().x+(offset_x*2), user.heatchaser_u:get_tile_offset().y+user.heatchaser_u:get_offset().y+(offset_y*2), GUARD_TEXTURE, GUARD_PALETTE, GUARD_ANIMPATH, -999, "0", Playback.Once, user.heatchaser_u, user.heatchaser_u:get_facing(), true, true, true)
                    user.heatchaser_u:get_field():spawn(hit_fx, user.heatchaser_u:get_tile())
                else
                    local hit_fx = graphic_init("artifact", user.heatchaser_d:get_tile_offset().x+user.heatchaser_d:get_offset().x+(offset_x*2), user.heatchaser_d:get_tile_offset().y+user.heatchaser_d:get_offset().y+(offset_y*2), GUARD_TEXTURE, GUARD_PALETTE, GUARD_ANIMPATH, -999, "0", Playback.Once, user.heatchaser_d, user.heatchaser_d:get_facing(), true, true, true)
                    user.heatchaser_d:get_field():spawn(hit_fx, user.heatchaser_d:get_tile())
                end
            end
        end
    end
    if type == "UPPER" then
        user.heatchaser_u:add_defense_rule(heatchaser_defense)
        user.heatchaser_u.slide_dir = user.heatchaser_u:get_facing()
        user.heatchaser_u.do_once = true
        user.heatchaser_u.do_once_cb = true
        user.heatchaser_u.confublind = false
        user.heatchaser_u.update_func = function(hc)
            if hc.state ~= "WAIT_IDLE" and hc.state ~= "WAIT_RETURN" then hc.frames = hc.frames + 1 end
            if user:is_confused() or user:is_blind() then
                if not hc.confublind then
                    hc.confublind = true
                end
            else
                if hc.confublind then
                    hc.confublind = false
                    if user.heatchaser_attack_order == "1" and hc.state == "WAIT_IDLE" then
                        local nearest_enemy = hc:get_field():find_nearest_characters(hc, char_query)
                        if #nearest_enemy > 0 then
                            local dif = hc:get_tile():x() - nearest_enemy[1]:get_tile():x()
                            if dif > 0 then
                                hc.slide_dir = Direction.Left
                            elseif dif < 0 then
                                hc.slide_dir = Direction.Right
                            end
                        end
                    end
                    if hc.state == "WAIT_IDLE" then
                        hc.state = "IDLE"
                    elseif hc.state == "WAIT_RETURN" then
                        hc.state = "RETURN"
                    end
                    hc.frames = 0
                    hc.speed = 1*2
                end
            end
            if #hc:get_tile():find_entities(hit_query) > 0 then
                create_hitbox_heatchaser(user, hc:get_tile())
            end
            if hc.state == "SPAWN" then
                hc:toggle_hitbox(false)
                for i=2, 30, 4 do
                    if hc.frames == i then
                        hc:hide()
                    end
                    if hc.frames == i+2 and i~=30 then
                        hc:reveal()
                    end
                end
                for i=33, 57, 2 do
                    if hc.frames == i then
                        hc:reveal()
                    end
                    if hc.frames == i+1 then
                        hc:hide()
                    end
                end
                if hc.frames == 59 then
                    hc:toggle_hitbox(true)
                    hc:reveal()
                    hc.frames = 0
                    hc.state = "END"
                end
            elseif hc.state == "READY" then
                if hc.frames == user.heatchaser_delay then
                    hc.frames = 0
                    hc.state = "ATTACK"
                    hc:get_animation():set_state("2")
                    hc:get_animation():set_playback(Playback.Loop)
                    hc:get_animation():refresh(hc:sprite())
                    hc.hitbox1 = create_hitbox_heatchaser_fire(user, hc, hc:get_tile(Direction.Down, 1))
                    hc.hitbox2 = create_hitbox_heatchaser_fire(user, hc, hc:get_tile(Direction.Down, 2))
                    Engine.play_audio(HEATCHASER_AUDIO, AudioPriority.Low)
                end
            elseif hc.state == "ATTACK" then
                if hc.frames%16==0 then Engine.play_audio(HEATCHASER_AUDIO, AudioPriority.Low) end
                if hc.frames == 60 then
                    hc.frames = 0
                    hc.state = "RETURN"
                    hc:get_animation():set_state("0")
                    hc:get_animation():set_playback(Playback.Loop)
                    hc:get_animation():refresh(hc:sprite())
                    hc.hitbox1:delete()
                    hc.hitbox2:delete()
                    user.heatchaser_attack_order = "2"
                end
            elseif hc.state == "WAIT_RETURN" then
                if #hc:get_tile(hc:get_facing_away(), 1):find_obstacles(obs_query) <= 0 then
                    hc.frames = 0
                    hc.state = "RETURN"
                end
            elseif hc.state == "RETURN" then
                for i=2, 6 do
                    if hc.frames == 5*i then
                        hc.speed = i*2
                    end
                end
                if hc:get_facing_away() == Direction.Left then
                    hc.offset_x = hc.offset_x - hc.speed
                else
                    hc.offset_x = hc.offset_x + hc.speed
                end
                if (hc:get_facing_away() == Direction.Left and round(hc.offset_x, hc) >= -2 and round(hc.offset_x, hc) < 10)
                or (hc:get_facing_away() == Direction.Right and round(hc.offset_x, hc) <= 2 and round(hc.offset_x, hc) > -10) then
                    if hc.confublind or hc:get_tile(hc:get_facing_away(), 1):is_edge() or #hc:get_tile(hc:get_facing_away(), 1):find_obstacles(obs_query) > 0 then
                        if not hc.confublind then
                            hc.state = "END"
                            hc.slide_dir = hc:get_facing()
                        else
                            if not hc:get_tile(hc:get_facing_away(), 1):is_edge() then
                                hc.state = "WAIT_RETURN"
                            else
                                hc.state = "WAIT_IDLE"
                            end
                        end
                        if #hc:get_tile(hc:get_facing_away(), 1):find_obstacles(obs_query) > 0 then
                            hc.state = "WAIT_RETURN"
                            hc.offset_x = 0
                            hc:set_offset(hc.offset_x, hc:get_offset().y)
                            return
                        end
                        hc.frames = 0
                        hc.offset_x = 0
                        hc.speed = 1*2
                        hc:set_offset(hc.offset_x, hc:get_offset().y)
                    end
                elseif (hc:get_facing_away() == Direction.Left and round(hc.offset_x, hc) < -hc.tileWidth)
                or     (hc:get_facing_away() == Direction.Right and round(hc.offset_x, hc) > hc.tileWidth) then
                    if hc:get_tile(hc:get_facing_away(), 1) then
                        if hc:get_facing_away() == Direction.Left then
                            hc.offset_x = (hc.tileWidth+(hc.offset_x+hc.tileWidth))
                        else
                            hc.offset_x = -(hc.tileWidth-(hc.offset_x-hc.tileWidth))
                        end
                        hc:teleport(hc:get_tile(hc:get_facing_away(), 1), ActionOrder.Immediate)
                        hc:set_offset(hc.offset_x, hc:get_offset().y)
                    else
                        --hc:delete()
                    end
                else
                    hc:set_offset(hc.offset_x, hc:get_offset().y)
                end
            end
            if user.heatchaser_attack_order == "1" and hc.state == "IDLE" then
                for i=2, 6 do
                    if hc.frames == 5*i then
                        hc.speed = i*2
                    end
                end
                if hc.slide_dir == Direction.Left then
                    hc.offset_x = hc.offset_x - hc.speed
                else
                    hc.offset_x = hc.offset_x + hc.speed
                end
                if (hc.slide_dir == Direction.Left and round(hc.offset_x, hc) >= -2 and round(hc.offset_x, hc) < 10)
                or (hc.slide_dir == Direction.Right and round(hc.offset_x, hc) <= 2 and round(hc.offset_x, hc) > -10) then
                    if hc.confublind or hc:get_tile(hc.slide_dir, 1):is_edge() or #hc:get_tile():find_entities(hit_query) > 0 or #hc:get_tile(hc.slide_dir, 1):find_entities(hit_query) > 0 or #hc:get_tile(Direction.Down, 1):find_characters(char_query) > 0 or #hc:get_tile(Direction.Down, 2):find_characters(char_query) > 0 or #hc:get_tile(hc.slide_dir, 1):find_obstacles(obs_query) > 0 then
                        if not hc.confublind then
                            hc.state = "READY"
                            hc:get_animation():set_state("1")
                            hc:get_animation():set_playback(Playback.Loop)
                            hc:get_animation():refresh(hc:sprite())
                        else
                            hc.state = "WAIT_IDLE"
                        end
                        hc.frames = 0
                        hc.offset_x = 0
                        hc.speed = 1*2
                        hc:set_offset(hc.offset_x, hc:get_offset().y)
                    end
                elseif (hc.slide_dir == Direction.Left and round(hc.offset_x, hc) < -hc.tileWidth)
                or     (hc.slide_dir == Direction.Right and round(hc.offset_x, hc) > hc.tileWidth) then
                    if hc:get_tile(hc.slide_dir, 1) then
                        if hc.slide_dir == Direction.Left then
                            hc.offset_x = (hc.tileWidth+(hc.offset_x+hc.tileWidth))
                        else
                            hc.offset_x = -(hc.tileWidth-(hc.offset_x-hc.tileWidth))
                        end
                        hc:teleport(hc:get_tile(hc.slide_dir, 1), ActionOrder.Immediate)
                        hc:set_offset(hc.offset_x, hc:get_offset().y)
                    else
                        --hc:delete()
                    end
                else
                    hc:set_offset(hc.offset_x, hc:get_offset().y)
                end
            end
        end
        user.heatchaser_u.delete_func = function(hc)
            if hc:get_health() <= 0 then
                local boom_fx = graphic_init("artifact", hc:get_offset().x, hc:get_offset().y+(-16*2), BOOM_TEXTURE, BOOM_PALETTE, BOOM_ANIMPATH, -999, "0", Playback.Once, hc, hc:get_facing(), true, false)
                hc:get_field():spawn(boom_fx, hc:get_tile())
	    	    Engine.play_audio(BOOM_AUDIO, AudioPriority.Low)
            end
        end
        user.heatchaser_u.can_move_to_func = function(tile)
            return true
        end
        return user.heatchaser_u
    else
        user.heatchaser_d:add_defense_rule(heatchaser_defense)
        user.heatchaser_d.slide_dir = user.heatchaser_d:get_facing()
        user.heatchaser_d.do_once = true
        user.heatchaser_d.do_once_cb = true
        user.heatchaser_d.confublind = false
        user.heatchaser_d.update_func = function(hc)
            if hc.state ~= "WAIT_IDLE" and hc.state ~= "WAIT_RETURN" then hc.frames = hc.frames + 1 end
            if user:is_confused() or user:is_blind() then
                if not hc.confublind then
                    hc.confublind = true
                end
            else
                if hc.confublind then
                    hc.confublind = false
                    if user.heatchaser_attack_order == "2" and hc.state == "WAIT_IDLE" then
                        local nearest_enemy = hc:get_field():find_nearest_characters(hc, char_query)
                        if #nearest_enemy > 0 then
                            local dif = hc:get_tile():x() - nearest_enemy[1]:get_tile():x()
                            if dif > 0 then
                                hc.slide_dir = Direction.Left
                            elseif dif < 0 then
                                hc.slide_dir = Direction.Right
                            end
                        end
                    end
                    if hc.state == "WAIT_IDLE" then
                        hc.state = "IDLE"
                    elseif hc.state == "WAIT_RETURN" then
                        hc.state = "RETURN"
                    end
                    hc.frames = 0
                    hc.speed = 1*2
                end
            end
            if #hc:get_tile():find_entities(hit_query) > 0 then
                create_hitbox_heatchaser(user, hc:get_tile())
            end
            if hc.state == "SPAWN" then
                hc:toggle_hitbox(false)
                for i=2, 30, 4 do
                    if hc.frames == i then
                        hc:hide()
                    end
                    if hc.frames == i+2 and i~=30 then
                        hc:reveal()
                    end
                end
                for i=33, 57, 2 do
                    if hc.frames == i then
                        hc:reveal()
                    end
                    if hc.frames == i+1 then
                        hc:hide()
                    end
                end
                if hc.frames == 59 then
                    hc:toggle_hitbox(true)
                    hc:reveal()
                end
                if hc.frames >= 70 then
                    hc.frames = 0
                    hc.state = "END"
                end
            elseif hc.state == "READY" then
                if hc.frames == user.heatchaser_delay then
                    hc.frames = 0
                    hc.state = "ATTACK"
                    hc:get_animation():set_state("2")
                    hc:get_animation():set_playback(Playback.Loop)
                    hc:get_animation():refresh(hc:sprite())
                    hc.hitbox1 = create_hitbox_heatchaser_fire(user, hc, hc:get_tile(Direction.Up, 1))
                    hc.hitbox2 = create_hitbox_heatchaser_fire(user, hc, hc:get_tile(Direction.Up, 2))
                    Engine.play_audio(HEATCHASER_AUDIO, AudioPriority.Low)
                end
            elseif hc.state == "ATTACK" then
                if hc.frames%16==0 then Engine.play_audio(HEATCHASER_AUDIO, AudioPriority.Low) end
                if hc.frames == 60 then
                    hc.frames = 0
                    hc.state = "RETURN"
                    hc:get_animation():set_state("0")
                    hc:get_animation():set_playback(Playback.Loop)
                    hc:get_animation():refresh(hc:sprite())
                    hc.hitbox1:delete()
                    hc.hitbox2:delete()
                    user.heatchaser_attack_order = "1"
                end
            elseif hc.state == "WAIT_RETURN" then
                if #hc:get_tile(hc:get_facing_away(), 1):find_obstacles(obs_query) <= 0 then
                    hc.frames = 0
                    hc.state = "RETURN"
                end
            elseif hc.state == "RETURN" then
                for i=2, 6 do
                    if hc.frames == 5*i then
                        hc.speed = i*2
                    end
                end
                if hc:get_facing_away() == Direction.Left then
                    hc.offset_x = hc.offset_x - hc.speed
                else
                    hc.offset_x = hc.offset_x + hc.speed
                end
                if (hc:get_facing_away() == Direction.Left and round(hc.offset_x, hc) >= -2 and round(hc.offset_x, hc) < 10)
                or (hc:get_facing_away() == Direction.Right and round(hc.offset_x, hc) <= 2 and round(hc.offset_x, hc) > -10) then
                    if hc.confublind or hc:get_tile(hc:get_facing_away(), 1):is_edge() or #hc:get_tile(hc:get_facing_away(), 1):find_obstacles(obs_query) > 0 then
                        if not hc.confublind then
                            hc.state = "END"
                            hc.slide_dir = hc:get_facing()
                        else
                            if not hc:get_tile(hc:get_facing_away(), 1):is_edge() then
                                hc.state = "WAIT_RETURN"
                            else
                                hc.state = "WAIT_IDLE"
                            end
                        end
                        if #hc:get_tile(hc:get_facing_away(), 1):find_obstacles(obs_query) > 0 then
                            hc.state = "WAIT_RETURN"
                            hc.offset_x = 0
                            hc:set_offset(hc.offset_x, hc:get_offset().y)
                            return
                        end
                        hc.frames = 0
                        hc.offset_x = 0
                        hc.speed = 1*2
                        hc:set_offset(hc.offset_x, hc:get_offset().y)
                    end
                elseif (hc:get_facing_away() == Direction.Left and round(hc.offset_x, hc) < -hc.tileWidth)
                or     (hc:get_facing_away() == Direction.Right and round(hc.offset_x, hc) > hc.tileWidth) then
                    if hc:get_tile(hc:get_facing_away(), 1) then
                        if hc:get_facing_away() == Direction.Left then
                            hc.offset_x = (hc.tileWidth+(hc.offset_x+hc.tileWidth))
                        else
                            hc.offset_x = -(hc.tileWidth-(hc.offset_x-hc.tileWidth))
                        end
                        hc:teleport(hc:get_tile(hc:get_facing_away(), 1), ActionOrder.Immediate)
                        hc:set_offset(hc.offset_x, hc:get_offset().y)
                    else
                        --hc:delete()
                    end
                else
                    hc:set_offset(hc.offset_x, hc:get_offset().y)
                end
            end
            if user.heatchaser_attack_order == "2" and hc.state == "IDLE" then
                for i=2, 6 do
                    if hc.frames == 5*i then
                        hc.speed = i*2
                    end
                end
                if hc.slide_dir == Direction.Left then
                    hc.offset_x = hc.offset_x - hc.speed
                else
                    hc.offset_x = hc.offset_x + hc.speed
                end
                if (hc.slide_dir == Direction.Left and round(hc.offset_x, hc) >= -2 and round(hc.offset_x, hc) < 10)
                or (hc.slide_dir == Direction.Right and round(hc.offset_x, hc) <= 2 and round(hc.offset_x, hc) > -10) then
                    if hc.confublind or hc:get_tile(hc.slide_dir, 1):is_edge() or #hc:get_tile():find_entities(hit_query) > 0 or #hc:get_tile(hc.slide_dir, 1):find_entities(hit_query) > 0 or #hc:get_tile(Direction.Up, 1):find_characters(char_query) > 0 or #hc:get_tile(Direction.Up, 2):find_characters(char_query) > 0 or #hc:get_tile(hc.slide_dir, 1):find_obstacles(obs_query) > 0 then
                        if not hc.confublind then
                            hc.state = "READY"
                            hc:get_animation():set_state("1")
                            hc:get_animation():set_playback(Playback.Loop)
                            hc:get_animation():refresh(hc:sprite())
                        else
                            hc.state = "WAIT_IDLE"
                        end
                        hc.frames = 0
                        hc.offset_x = 0
                        hc.speed = 1*2
                        hc:set_offset(hc.offset_x, hc:get_offset().y)
                    end
                elseif (hc.slide_dir == Direction.Left and round(hc.offset_x, hc) < -hc.tileWidth)
                or     (hc.slide_dir == Direction.Right and round(hc.offset_x, hc) > hc.tileWidth) then
                    if hc:get_tile(hc.slide_dir, 1) then
                        if hc.slide_dir == Direction.Left then
                            hc.offset_x = (hc.tileWidth+(hc.offset_x+hc.tileWidth))
                        else
                            hc.offset_x = -(hc.tileWidth-(hc.offset_x-hc.tileWidth))
                        end
                        hc:teleport(hc:get_tile(hc.slide_dir, 1), ActionOrder.Immediate)
                        hc:set_offset(hc.offset_x, hc:get_offset().y)
                    else
                        --hc:delete()
                    end
                else
                    hc:set_offset(hc.offset_x, hc:get_offset().y)
                end
            end
        end
        user.heatchaser_d.delete_func = function(hc)
            if hc:get_health() <= 0 then
                local boom_fx = graphic_init("artifact", hc:get_offset().x, hc:get_offset().y+(-16*2), BOOM_TEXTURE, BOOM_PALETTE, BOOM_ANIMPATH, -999, "0", Playback.Once, hc, hc:get_facing(), true, false)
                hc:get_field():spawn(boom_fx, hc:get_tile())
	    	    Engine.play_audio(BOOM_AUDIO, AudioPriority.Low)
            end
        end
        user.heatchaser_d.can_move_to_func = function(tile)
            return true
        end
        return user.heatchaser_d
    end
end

function package_init(self)
    CHARACTER_TEXTURE = Engine.load_texture(_folderpath.."gfx/battle.grayscaled.png")
    CHARACTER_PALETTE = Engine.load_texture(_folderpath.."gfx/palette/battle-NORMAL.png")

    self.next_tile = nil -- The character's next tile to move.
    self.prev_tile = nil -- The character's previous tile before moving.
    self.original_tile = nil -- The character's original tile before moving for an attack.
    self.original_tileWidth = 0
    
    self.do_once_at_start = true -- Does some things once when the battle actually starts.
    self.move_count = 0 -- Counts how many times the pattern was reconstructed. It allows BurnerMan use Burning Jet on every 3rd recontructed pattern.
    self.strikeburner = nil -- Stores Strike Burner. Deletes itself no Flinch.
    self.burningjet_1 = nil -- Stores Burning Jet's 1st hitbox. Deletes itself no Flinch.
    self.burningjet_2 = nil -- Stores Burning Jet's 1st hitbox. Deletes itself no Flinch.

    -- Alrysc:
    -- Chance /16. I'm going to run these when the pattern is complete and when the flinch finishes, respectively
        -- These skips will be very implementation-specific, so don't use them as future references
    self.chance_to_skip_idle_after_flinch = 2
    self.chance_to_halve_idle_after_flinch = 3

    self.base_idle_speed2 = 0 -- Stores the Character's actual idle delay. Can't be changed.

    self:set_name("BurnerMan") -- Sets name.
    self.damage = 40 -- Damage for the Character's collision hitbox.
    self.damage_strikeburner = 40 -- Damage for Strike Burner's hitbox.
    self.damage_burningjet = 60 -- Damage for Burning Jet's 2nd hitbox.
    self.damage_heatchaser = 40 -- Damage for Heat Chaser's body hitbox.
    self.damage_heatchaser_fire = 40 -- Damage for Heat Chaser's flame hitbox.
    self.burningjet_times = 0 -- Sets how many times (-1) BurnerMan can use Burning Jet.
    self.heatchaser_delay = 24 -- Sets the delay for Heat Chaser's charging up.
    self.base_idle_speed2 = 46 -- Sets the actual idle delay.
	local rank = self:get_rank()
    if rank == Rank.V2 then
        -- If the rank is V2.
        self:set_name("BurnrMnV")
        self:set_health(1100)
        self.damage = 80
        self.damage_strikeburner = 80
        self.damage_burningjet = 120
        self.damage_heatchaser = 80
        self.damage_heatchaser_fire = 80
        self.burningjet_times = 0
        self.heatchaser_delay = 17
        self.base_idle_speed2 = 36
    elseif rank == Rank.V3 then
        -- If the rank is V3.
        self:set_name("BurnrMnV")
        self:set_health(1500)
        self.damage = 120
        self.damage_strikeburner = 120
        self.damage_burningjet = 180
        self.damage_heatchaser = 120
        self.damage_heatchaser_fire = 120
        self.burningjet_times = 1
        self.heatchaser_delay = 11
        self.base_idle_speed2 = 26
    elseif rank == Rank.SP then
        -- If the rank is SP.
        CHARACTER_PALETTE = Engine.load_texture(_folderpath.."gfx/palette/battle-HOLY.png") -- Uses alternative palette for SP.
        self:set_health(1900)
        self.damage = 200
        self.damage_strikeburner = 200
        self.damage_burningjet = 300
        self.damage_heatchaser = 200
        self.damage_heatchaser_fire = 200
        self.burningjet_times = 1
        self.heatchaser_delay = 5
        self.base_idle_speed2 = 16
    else
        -- If the rank is V1.
        self:set_health(700) -- Sets max health.
    end
    
    self.burningjet_count = self.burningjet_times -- Counts how many times Burning Jet has been used.

    self.base_idle_speed = self.base_idle_speed2 -- Stores the Character's default idle delay. Changes when the Character is Confused or Blind.
    self.idle_speed = 0 -- The Character's current idle delay.

    self:set_texture(CHARACTER_TEXTURE, true) -- Sets the Character's texture.
    self:store_base_palette(CHARACTER_PALETTE) -- Stores the Character's base palette.
    self:set_palette(self:get_base_palette()) -- Sets the Character's base palette as the current one.

    self:set_height(56) -- Sets BurnerMan's height.
    self:set_explosion_behavior(5, 1, true) -- Creates 5 explosions when the Character gets deleted.
    self:set_offset(0,0) -- Sets offset.
	self:set_facing(Direction.Left)
	self:set_element(Element.Fire) -- BurnerMan is a Fire-elemental Character.
	self:set_float_shoe(false) -- BurnerMan doesn't have Float Shoes.
	self:set_air_shoe(false) -- BurnerMan doesn't have Air Shoes.
    self:share_tile(false) -- BurnerMan doesn't share his current tile (if he's not using Burning Jet).

    self.offset_x = self:get_offset().x
    --[[ 
        The Heat Chaser action order variable. Determines action for both Heat Chasers:
        0 - Starting delay.
        1 - Upper Heat Chaser attacks.
        2 - Lower Heat Chaser attacks.
    ]]
    self.heatchaser_attack_order = "0"
    -- Upper and lower Heat Chasers.
    self.heatchaser_u = create_heat_chaser(self, "END", "UPPER")
    self.heatchaser_d = create_heat_chaser(self, "END", "LOWER")
    -- Fake Heat Chasers for the intro.
    self.heatchaser_u_fake = graphic_init("artifact", -61*2,  27*2, HEATCHASER_U_TEXTURE, CHARACTER_PALETTE, HEATCHASER_U_ANIMPATH, -1, "0", Playback.Loop, self, self:get_facing(), false, true)
    self.heatchaser_d_fake = graphic_init("artifact", -61*2, -48*2, HEATCHASER_D_TEXTURE, CHARACTER_PALETTE, HEATCHASER_D_ANIMPATH, -1, "0", Playback.Loop, self, self:get_facing(), false, true)
    -- Heat Chasers' starting tiles.
    self.heatchaser_u_start_tile = nil
    self.heatchaser_d_start_tile = nil

    -- The Character's animation handled by enemy_base_v1.
    local anim = self:get_animation()
    anim:load(CHARACTER_ANIMPATH)
    self.anim = include("enemy_base_v1/entry.lua")
    anim = self.anim
    anim:set_owner(self)
    anim:set_state("SPAWN", { -- Sets the Spawn animation.
        {duration=1, state="SPAWN"},
    })
    anim:set_playback(Playback.Loop) -- Loops the animation.
    init_boss(self)
end

--(Function by Alrysc)
-- This is to fix something that happens because I'm a cheater.
--[[
    The aggressor of an attack is held in the Context object. 
    ONB leaves this aggressor unset in the Entity's Context until a CardAction is used for the first time.
    So I'll immediately force a CardAction that will hopefully end immediately and not get in the way, but also will fix this.
    This probably goes horribly wrong if the enemy is spawned after the mob intro, but should be fine for now otherwise.
]]
function fix_context(self)
    local action = Battle.CardAction.new(self, "SPAWN")
    action.execute_func = function()
        action:end_action()
    end
    self:card_action_event(action, ActionOrder.Immediate)
end

--(Function by Alrysc)
function init_boss(self)
    -- The Heat Chaser intro animation component. Create the Heat Chaser intro when BurnerMan spawns.
    self.heatchaser_anim = Battle.Component.new(self, Lifetimes.Scene) -- Lifetimes.Scene makes it update on every application update.
    self.heatchaser_anim.frames = 0 -- The frame counter.
    self.heatchaser_anim.state = "NULL" -- The current state.
    -- "NULL" - nothing, "APPEAR" - plays the appearing animation.
    self.heatchaser_anim.pos_u = { -- Stores the offsets for the upper Heat Chaser for every animated frame.
        [1]  = { x=-57 , y= 35 },
        [2]  = { x=-53 , y= 32 },
        [3]  = { x=-48 , y= 30 },
        [4]  = { x=-44 , y= 27 },
        [5]  = { x=-39 , y= 24 },
        [6]  = { x=-35 , y= 22 },
        [7]  = { x=-30 , y= 19 },
        [8]  = { x=-26 , y= 16 },
        [9]  = { x=-21 , y= 13 },
        [10] = { x=-17 , y= 11 },
        [11] = { x=-12 , y=  8 },
        [12] = { x= -8 , y=  5 },
        [13] = { x= -3 , y=  3 },
        [14] = { x=  0 , y=  0 }
    }
    self.heatchaser_anim.pos_d = { -- Stores the offsets for the lower Heat Chaser for every animated frame.
        [1]  = { x=-57 , y=-36 },
        [2]  = { x=-53 , y=-31 },
        [3]  = { x=-48 , y=-25 },
        [4]  = { x=-44 , y=-22 },
        [5]  = { x=-39 , y=-23 },
        [6]  = { x=-35 , y=-21 },
        [7]  = { x=-30 , y=-18 },
        [8]  = { x=-26 , y=-15 },
        [9]  = { x=-21 , y=-17 },
        [10] = { x=-17 , y=-10 },
        [11] = { x=-12 , y= -7 },
        [12] = { x= -8 , y= -4 },
        [13] = { x= -3 , y= -2 },
        [14] = { x=  0 , y=  0 }
    }
    self.heatchaser_anim.update_func = function(hc_a, dt) -- The update function.
        hc_a.frames = hc_a.frames + 1
        if hc_a.state == "NULL" then -- When the state is NULL.
            if hc_a.frames > 11 then
                hc_a.frames = 0 -- Resets the frame counter.
                hc_a.state = "APPEAR" -- Sets the current state as APPEAR.
                local field = self:get_field()
                field:spawn(self.heatchaser_u_fake, self.heatchaser_u_start_tile) -- Spawns the upper fake Heat Chaser.
                field:spawn(self.heatchaser_d_fake, self.heatchaser_d_start_tile) -- Spawns the lower fake Heat Chaser.
                self.heatchaser_u_fake:get_animation():update(dt, self.heatchaser_u_fake:sprite())
                self.heatchaser_d_fake:get_animation():update(dt, self.heatchaser_d_fake:sprite())
            end
        elseif hc_a.state == "APPEAR" then -- When the state is APPEAR.
            for i=1, 14 do
                if hc_a.frames == i then
                    local reverse = -1 -- Needed to flip the fake Heat Chasers for BurnerMan's facing direction.
                    if self:get_facing() == Direction.Right then reverse = -reverse end
                    self.heatchaser_u_fake:set_offset(hc_a.pos_u[i].x*2*reverse,hc_a.pos_u[i].y*2) -- Offsets the upper fake Heat Chaser. Flips the X if BurnerMan's facing right. Doubles the X and Y coordinates, as the pixels in ONB are doubled.
                    self.heatchaser_d_fake:set_offset(hc_a.pos_d[i].x*2*reverse,hc_a.pos_d[i].y*2) -- Offsets the lower fake Heat Chaser. Flips the X if BurnerMan's facing right. Doubles the X and Y coordinates, as the pixels in ONB are doubled.
                    self.heatchaser_u_fake:get_animation():update(dt, self.heatchaser_u_fake:sprite())
                    self.heatchaser_d_fake:get_animation():update(dt, self.heatchaser_d_fake:sprite())
                end
            end
            if hc_a.frames == 15 then
                self.heatchaser_u_fake:erase() -- Removes the upper fake Heat Chaser as it is no longer needed.
                self.heatchaser_d_fake:erase() -- Removes the lower fake Heat Chaser as it is no longer needed.
                local field = self:get_field()
                field:spawn(self.heatchaser_u, self.heatchaser_u_start_tile) -- Spawns the upper real Heat Chaser.
                field:spawn(self.heatchaser_d, self.heatchaser_d_start_tile) -- Spawns the lower real Heat Chaser.
                self.heatchaser_anim:eject() -- Ejects the Heat Chaser intro animation component as it is no longer needed.
            end
        end
    end

    -- The Reserving Obstacle. Allows Obstacles to be placed on tiles reserved by it.
    self.reserving_obstacle = Battle.Obstacle.new(self:get_team())
    self.on_spawn_func = function(self)
        self:get_field():spawn(self.reserving_obstacle,0,0)
        fix_context(self)
        --[[
        self.before_battle_start_animater = Battle.Artifact.new()
        self:get_field():spawn(self.before_battle_start_animater, 7, 4)
        self.before_battle_start_animater.update_func = function()
            self.anim:tick_animation()
        end]]
        local field = self:get_field()
        if self:get_facing() == Direction.Left then
            self.heatchaser_u_start_tile = field:tile_at(field:width()-1,1)
            self.heatchaser_d_start_tile = field:tile_at(field:width()-1,field:height())
        else
            self.heatchaser_u_start_tile = field:tile_at(2,1)
            self.heatchaser_d_start_tile = field:tile_at(2,field:height())
        end
        self.heatchaser_u.tileWidth = self.heatchaser_u_start_tile:width()/2
        self.heatchaser_d.tileWidth = self.heatchaser_d_start_tile:width()/2
        self:register_component(self.heatchaser_anim)
        if self:get_rank() == Rank.SP then
            self:set_name("BurnrMnSP")
        end
    end

    -- The Character's battle start function. Called once when the BATTLE START text appears.
    self.battle_start_func = function(self)
        --self.before_battle_start_animater:delete()
        self.heatchaser_u:set_team(self:get_team())
        self.heatchaser_d:set_team(self:get_team())
    end

    -- Alrysc: Setting names here is just convenience if I want to print the state I'm in later.
    self.states = {
        idle = {name = "idle", func = idle},
        move = {name = "move", func = move},
        move_to_enemy = {name = "move_to_enemy", func = move_to_enemy},
        move_to_back = {name = "move_to_back", func = move_to_back},
        move_to_original = {name = "move_to_original", func = move_to_original},
        flinch = {name = "flinch", func = flinch},
        
        start_sub_pattern = {name = "start_sub_pattern"},
        finish_sub_pattern = {name = "finish_sub_pattern"},

        strike_burner = {name = "strike_burner", func = strike_burner},
        burning_jet = {name = "burning_jet", func = burning_jet}
    }
    
    local s = self.states

    reconstruct_pattern(self)
 
    self.pattern_index = 1
    self.in_sub_pattern = false

    self.first_act = true

    self.state_done = false

    self.state = self.pattern[1]

    self.first_flinch = true

    -- The Character's hit function. Called when the character's gets hit.
    self.hit_func = function(from_stun)
        debug_print("Hit func runs")
        self.counterable_component.timer = 0
        self:toggle_counter(false)
        self.flinching = false
        self.first_act = false
        self.state_done = false
        self.moving_to_enemy_tile = false
        self.burningjet_count = self.burningjet_times
        self.can_move_to_edge = false
        self.collision_available = true
        self:share_tile(false)
        self:set_offset(0,0)
        if self.first_flinch then 
            --self.state.cleanup
            self.last_state = self.state
            debug_print("Hit! Set last state to ", self.state.name)
            if self.state ~= self.states.idle and self.state ~= self.states.move then 
               --increment_pattern(self)
            end
            self.first_flinch = false
        end
        self.state = self.states.flinch
        -- This is unused for this boss.
        --[[
        if self.slide_component ~= nil then 
            debug_print("Hit while moving.")
            self.slide_component:eject()
            self.slide_component = nil
            self:set_offset(0,0)
            if self.slide_dest and self:get_tile() ~= self.slide_dest then 
                debug_print("Hit before reaching destination.")
                self:get_tile():remove_entity_by_id(self.reserving_obstacle:get_id())
                self:get_tile():remove_entity_by_id(self:get_id())
                self.slide_dest:add_entity(self)
                self.slide_dest = nil
            end
        end]]
        flinch(self, from_stun)
    end

    -- The Character's delete function. Called when the character's gets deleted.
    self.delete_func = function(self)
        self.heatchaser_action:eject() -- Ejects the Heat Chaser Action component.
        if self.heatchaser_u and not self.heatchaser_u:is_deleted() then
            self.heatchaser_u:erase() -- Removes the upper Heat Chaser.
        end
        if self.heatchaser_d and not self.heatchaser_d:is_deleted() then
            self.heatchaser_d:erase() -- Removes the lower Heat Chaser.
        end
        self.reserving_obstacle:erase() -- Removes the Reserving Obstacle.
        self.update_func = function(self) -- The Character's delete function's update function. Called every frame the character updates.
            self:get_animation():set_state("FLINCH_2")  -- Sets the Stunned animation.
            self.state = self.states.flinch -- Sets the Flinch state.
        end
    end

    -- Unused for this boss.
    self.moving_to_enemy_tile = false
    self.counter = 0
    self.collision_available = true
    self.counterable = 0
    self.can_move_to_edge = false
    self.do_once_1 = true

    -- The Counter Hit state component. Makes the Character counter-able if the Counter Hit counter is more than 0.
    local ref = self
    self.counterable_component = Battle.Component.new(self, Lifetimes.Battlestep)
    self.counterable_component.timer = 0
    self.counterable_component.update_func = function(self)
        if self.timer > 0 then
            debug_print("COUNTERABLE")
            self.timer = self.timer - 1
            ref:toggle_counter(true)
        else
            ref:toggle_counter(false)
        end
    end
    self:register_component(self.counterable_component)

    self:register_status_callback(Hit.Stun, function() self.hit_func(true) end)
    self:register_status_callback(Hit.Freeze, function() self.hit_func(true) end)
    self:register_status_callback(Hit.Flinch, self.hit_func)
    --self:register_status_callback(Hit.Drag, self.hit_func)

    -- Alrysc: Bring it back next build. For now, relying on the stun callback.
    self.on_countered = function(self)
        debug_print("Countered")
        --self.counterable_component.timer = 0
        --self:toggle_counter(false)
        self.hit_func(true)
    end

    local status_defense = Battle.DefenseRule.new(10, DefenseOrder.Always)
    status_defense.filter_statuses_func = function(hit_props)
        if self.state == self.states.move_to_original or self.state == self.states.burning_jet then
            hit_props.flags = hit_props.flags & (~Hit.Drag)
        end
        return hit_props
    end
    self:add_defense_rule(status_defense)

    -- The checking query for Heat Chasers.
    local hc_query = function(o)
        return o:get_name() == "HeatChaserU" or o:get_name() == "HeatChaserD"
    end
    self.can_move_to_func = function(tile)
        -- Can't be rooted while using Burning Jet.
        if self:is_rooted()
        and self.state ~= self.states.move_to_original and self.state ~= self.states.burning_jet
        then return false end
        -- Can move to not walkable tiles only while using Burning Jet.
        if (tile:is_edge() or not tile:is_walkable()) then
            if self.can_move_to_edge then
                return true
            else
                return false
            end
        end
        -- Can't move to tiles reserved not by the Reserving Obstacle.
        if(tile:is_reserved({self:get_id(),self.reserving_obstacle:get_id()})) then
            return false
        end
        -- Can move to enemy tiles only when allowed to do so.
        if not self.moving_to_enemy_tile and (tile:get_team() ~= self:get_team()) then
            return false
        end
        -- Can move to the Character's current tile.
        if tile == self:get_tile() then
            return true
        end
        -- Can pass through Heat Chasers just like any other Character.
        if #tile:find_obstacles(hc_query) > 0 then
            return true
        end
        -- Can pass through Characters and Obstacles while using Burning Jet.
        if (check_obstacles(tile, self) or check_characters_true(tile, self)) and self.can_move_to_edge then
            return true
        end
        return not check_obstacles(tile, self) and not check_characters_true(tile, self)
    end

    self.do_once_confuse_blind = true
    -- The Character's update function. Called every frame the character updates.
    self.update_func = function(self)
        debug_print("     ", self.state.name, self:get_animation():get_state())
        -- Increases the Character's idle delay when Confused or Blinded. Unused for BurnerMan.
        --[[
        if self:is_confused() or self:is_blind() then
            if self.do_once_confuse_blind then
                self.do_once_confuse_blind = false
                self.base_idle_speed = self.base_idle_speed2+30
            end
        else
            if not self.do_once_confuse_blind then
                self.do_once_confuse_blind = true
                self.base_idle_speed = self.base_idle_speed2
            end
        end]]
        self.state.func(self)
        self.anim:tick_animation()
        --Alrysc: 
        -- When we tick animation, we may run increment_pattern. 
        -- The new state isn't run until next frame, so our anim state lasts one more frame when it finishes
        -- Calling our state one time to set things up will avoid this. Mostly sure this doesn't have major unintended consequences,
        -- especially as most state.func only set state and callbacks for frame 1
        -- Problem is, now I may have a frame 1 callback but I don't run it until next frame
        while self.first_act do
            self.state.func(self)
            self.anim:tick_animation()
        end
        check_collision(self)
    end
end

--(Function by Alrysc, edited by K1rbYat1Na)
function create_collision_attack(user, tile)
    local spell = Battle.Spell.new(user:get_team())
    local hit_props = HitProps.new()
    :dmg(user.damage)
    :impact()
    :flinch()
    :flash()
    :from(user:get_context())
    :elem(user:get_element())
    spell:set_hit_props(hit_props)
    spell.update_func = function(self)
        tile:attack_entities(self)
        self:delete()
    end
    spell.attack_func = function(self, other)
        if not other:get_animation():has_state("HITSOUND_N") and #other:sprite():find_child_nodes_with_tags({"IS_BARRIER"}) <= 0 then
            if not other:get_animation():has_state("HITSOUND_C") and not other:get_animation():has_state("HITSOUND_O") then
    	        if Battle.Obstacle.from(other) == nil then
                    --if Battle.Player.from(user) ~= nil then
		            --	Engine.play_audio(AUDIO_DAMAGE_ENEMY, AudioPriority.Low)
		            --end
                else
		        	Engine.play_audio(AUDIO_DAMAGE_OBS, AudioPriority.Low)
		        end
            else
                if other:get_animation():has_state("HITSOUND_C") then
		            --if Battle.Player.from(user) ~= nil then
		            --	Engine.play_audio(AUDIO_DAMAGE_ENEMY, AudioPriority.Low)
		            --end
    	        end
    	        if other:get_animation():has_state("HITSOUND_O") then
		        	Engine.play_audio(AUDIO_DAMAGE_OBS, AudioPriority.Low)
		        end
            end
    	end
    end
    user:get_field():spawn(spell, tile)
end

--(Function by Alrysc)
-- TODO: When we get is_passthrough or something, check to see if target became flashing before 
    -- we are allowed to spawn another one. Don't want to instakill viruses
-- self.collision_available can do something related to that. Does nothing now
function check_collision(self)
    local t = self:get_tile()
    if self.collision_available and check_characters(t, self) then 
        create_collision_attack(self, t)
    end
end

--(Function by Alrysc, edited by K1rbYat1Na)
function idle(self)
    -- Does once.
    if self.do_once_at_start then
        self.do_once_at_start = false
        self.heatchaser_action = Battle.Component.new(self, Lifetimes.Battlestep)
        self.heatchaser_action.count = {
            false, false
        }
        self.heatchaser_action.frames = 0
        self.heatchaser_action.frames_u = 0
        self.heatchaser_action.frames_d = 0
        self.heatchaser_action.update_func = function(hc)
            hc.frames = hc.frames + 1
            if not self.heatchaser_u or self.heatchaser_u:is_deleted() then
                if hc.frames_u == 1450 then
                    hc.frames_u = 0
                    self.heatchaser_u = create_heat_chaser(self, "SPAWN", "UPPER")
                    self.heatchaser_u:set_team(self:get_team())
                    self.heatchaser_u.tileWidth = self.heatchaser_u_start_tile:width()/2
                    self:get_field():spawn(self.heatchaser_u, self.heatchaser_u_start_tile)
                else
                    hc.frames_u = hc.frames_u + 1
                end
                hc.count[1] = false
            else
                hc.count[1] = true
            end
            if not self.heatchaser_d or self.heatchaser_d:is_deleted() then
                if hc.frames_d == 1450 then
                    hc.frames_d = 0
                    self.heatchaser_d = create_heat_chaser(self, "SPAWN", "LOWER")
                    self.heatchaser_d:set_team(self:get_team())
                    self.heatchaser_d.tileWidth = self.heatchaser_d_start_tile:width()/2
                    self:get_field():spawn(self.heatchaser_d, self.heatchaser_d_start_tile)
                else
                    hc.frames_d = hc.frames_d + 1
                end
                hc.count[2] = false
            else
                hc.count[2] = true
            end
            if self.heatchaser_attack_order == "0" then
                if hc.frames == 60 then
                    hc.frames = 0
                    self.heatchaser_attack_order = "1"
                    if self.heatchaser_u and not self.heatchaser_u:is_deleted() then
                        self.heatchaser_u.frames = 0
                        self.heatchaser_u.state = "IDLE"
                    end
                    --self.heatchaser_d.frames = 0
                    --hc:eject()
                end
            else
                if     hc.count[1] == true  and hc.count[2] == true  then
                    if     self.heatchaser_attack_order == "1" then
                        if self.heatchaser_u.state == "END" and (self.heatchaser_d.state == "RETURN" or self.heatchaser_d.state == "END") then
                            hc.frames = 0
                            --self.heatchaser_attack_order = "2"
                            self.heatchaser_u.frames = 0
                            self.heatchaser_u.state = "IDLE"
                        elseif self.heatchaser_d.state == "END" and self.heatchaser_u.state == "RETURN" then
                            if hc.frames >= 10 then
                                hc.frames = 0
                                self.heatchaser_attack_order = "2"
                                self.heatchaser_d.frames = 0
                                self.heatchaser_d.state = "IDLE"
                            end
                        end
                    elseif self.heatchaser_attack_order == "2" then
                        if self.heatchaser_d.state == "END" and (self.heatchaser_u.state == "RETURN" or self.heatchaser_u.state == "END") then
                            hc.frames = 0
                            --self.heatchaser_attack_order = "1"
                            self.heatchaser_d.frames = 0
                            self.heatchaser_d.state = "IDLE"
                        elseif self.heatchaser_u.state == "END" and self.heatchaser_d.state == "RETURN" then
                            if hc.frames >= 10 then
                                hc.frames = 0
                                self.heatchaser_attack_order = "1"
                                self.heatchaser_u.frames = 0
                                self.heatchaser_u.state = "IDLE"
                            end
                        end
                    end
                elseif hc.count[1] == true  and hc.count[2] == false then
                    if     self.heatchaser_attack_order == "1" then
                        if self.heatchaser_u.state == "END" then
                            hc.frames = 0
                            self.heatchaser_attack_order = "2"
                        end
                    elseif self.heatchaser_attack_order == "2" then
                        if hc.frames >= 10 and self.heatchaser_u.state == "END" then
                            hc.frames = 0
                            self.heatchaser_attack_order = "1"
                            self.heatchaser_u.frames = 0
                            self.heatchaser_u.state = "IDLE"
                        end
                    end
                elseif hc.count[1] == false and hc.count[2] == true  then
                    if     self.heatchaser_attack_order == "1" then
                        if hc.frames >= 10 and self.heatchaser_d.state == "END" then
                            hc.frames = 0
                            self.heatchaser_attack_order = "2"
                            self.heatchaser_d.frames = 0
                            self.heatchaser_d.state = "IDLE"
                        end
                    elseif self.heatchaser_attack_order == "2" then
                        if self.heatchaser_d.state == "END" then
                            hc.frames = 0
                            self.heatchaser_attack_order = "1"
                        end
                    end
                end
            end
        end
        self:register_component(self.heatchaser_action)
    end
    if self.first_act then
        self.first_act = false
        -- This is an old check for when I extended idle time by doing two idle states in a row, when characters have an animated idle
            -- Not needed if I instead use a timer
        if self.anim:get_state() ~= "IDLE" then 
            debug_print("Idle with ", self.idle_speed)
            self.anim:set_state("IDLE", {
                {duration=2, state="IDLE_1"},
                {duration=2, state="IDLE_2"},
            })    
        end
        self.anim:set_playback(Playback.Loop)
        self.counter = 0
    end
    self.counter = self.counter + 1
    if self.counter == 1 then
        if self:is_rooted() and self.pattern[self.pattern_index+1] ~= self.states.move_to_enemy and self.pattern[self.pattern_index+1] ~= self.states.move_to_back then
            self.idle_speed = self.base_idle_speed
            increment_pattern(self)
        end
    elseif self.counter > self.idle_speed then
        -- Extra catch for after leaving attack. Attack will double idle speed once, so making sure to reset it after
        if self:is_rooted() and (self.pattern[self.pattern_index+1] == self.states.move_to_enemy or self.pattern[self.pattern_index+1] == self.states.move_to_back) then
            return -- If BurnerMan's rooted, he waits until he's unrooted to immediately attack.
        end
        if self.idle_speed > self.base_idle_speed then 
            self.idle_speed = self.base_idle_speed
        end
        increment_pattern(self)
    end
    --self.looped = false
    --if self.state_done then 
        --debug_print("State done")
    --end
end

--(Function by Alrysc)
function hit()
    --???
end

--(Function by Alrysc)
function end_sub_pattern(self)
    while self.in_sub_pattern do
        increment_pattern(self)
    end
end

--(Function by Alrysc)
function flinch(self, from_stun)
    debug_print("Flinch played")
    if self.strikeburner ~= nil and not self.strikeburner:is_deleted() then self.strikeburner:delete() end -- Deletes Strike Burner if BurnerMan's flinching.
    if self.burningjet_1 ~= nil and not self.burningjet_1:is_deleted() then self.burningjet_1:delete() end -- Deletes Burning Jet's 1st hitbox if BurnerMan's flinching.
    if self.burningjet_2 ~= nil and not self.burningjet_2:is_deleted() then self.burningjet_2:delete() end -- Deletes Burning Jet's 2nd hitbox if BurnerMan's flinching.
    if not self.original_tile then
        if self:get_tile() == self.next_tile then
            local orig_tile = self.next_tile
            self.next_tile:remove_entity_by_id(self.reserving_obstacle:get_id())
            self.next_tile:remove_entity_by_id(self:get_id())
            self.next_tile = orig_tile
            self.next_tile:add_entity(self)
            self.next_tile = nil
        elseif self:get_tile() == self.prev_tile then
            local orig_tile = self.prev_tile
            self.prev_tile:remove_entity_by_id(self.reserving_obstacle:get_id())
            self.prev_tile:remove_entity_by_id(self:get_id())
            self.prev_tile = orig_tile
            self.prev_tile:add_entity(self)
            self.prev_tile = nil
        elseif self:get_tile() ~= self.next_tile then
            if self.next_tile ~= nil then
                self.next_tile:remove_entity_by_id(self.reserving_obstacle:get_id())
                self.next_tile:remove_entity_by_id(self:get_id())
                self.next_tile = nil
            end
        end
    else
        self:teleport(self.original_tile, ActionOrder.Immediate)
        self:get_tile():remove_entity_by_id(self.reserving_obstacle:get_id())
        self:get_tile():remove_entity_by_id(self:get_id())
        self.original_tile:add_entity(self)
        self.original_tile = nil
    end
    --print("I am flinching")
    if not self.flinching then 
        local frames = {}
        if not from_stun then -- 12f
            for i=1, 11, 2 do
                frames[i+0] = {duration=2, state="FLINCH_1"}
                frames[i+1] = {duration=2, state="FLINCH_2"}
            end
            frames[12] = {duration=1, state="FLINCH_2"}
        else
            frames[1] = {duration=0, state="FLINCH_2"}
        end
        --[[
        for i=1, 12 do
            self.anim:on_frame(i, function()
                print("frame "..i..": ",self:get_tile():x(),self:get_tile():y())
            end)
        end]]
        self.anim:set_state("FLINCH", frames)
        self.anim:on_complete(function()
            -- If we didn't just attack, we want to make sure the idle speed is correct. This is also set in the actual idle, but just for extra measure.
                -- Shouldn't be necessary
            if self.idle_speed > self.base_idle_speed and self.pattern[self.pattern_index] ~= self.states.choose_attack then 
                self.idle_speed = self.base_idle_speed
            end
            local has_skipped = false
            if self.last_state == self.states.idle then 
                debug_print("Attempt skip, because last state was idle")
                has_skipped = maybe_skip_after_flinch(self)
            end
            debug_print("I am done flinching")
            debug_print("Anim done")
            self.flinching = false
            self.state_done = true
            self.first_flinch = true
            debug_print("Done")
            self.state_done = false
            if self.last_state ~= self.states.idle and self.last_state ~= self.states.move then 
            debug_print("Last state was not idle or move", self.last_state.name)
                increment_pattern(self)
            else
                --if not has_skipped then 
                -- If we were in idle or move, go back to it and try again
                    -- Unless we were in a sub pattern. Still end that.
                debug_print("Last state was idle or move")
                if self.in_sub_pattern then 
                    end_sub_pattern(self)
                else
                    self.state = self.last_state
                    self.first_act = true
                end
            end
        end)
    end
    self.flinching = true
end

--(Function by Alrysc)
--[[
    Chance to skip idle or halve idle time, to call after flinching 
    This works by calling increment_pattern an extra time if and only if the last state was Idle
        Remember, last state is the state we will return to after flinching
        Some extra work will need to be done in the self.anim:on_complete of flinch if this is to work with sub patterns. This boss doesn't use them, so it was omitted
    
    Currently, the skip is implemented as setting idle time to 0
    
    A future choice for this function: after calling this function, self.state *may* increment, obsoleting our last state pointer. Returns true if this does happen
        There is a possible additional side effect that the idle time will instead be changed, in which case, last state is preserved and false is returned
]]
function maybe_skip_after_flinch(self)
    local chance_halve = self.chance_to_halve_idle_after_flinch
    local chance_skip = self.chance_to_skip_idle_after_flinch
    local max = chance_halve + chance_skip + (16 - chance_halve - chance_skip)

    local r = math.random(1, max)
    if r <= chance_halve then 
        self.idle_speed = math.floor(self.idle_speed / 2)
        debug_print("We halved")
    elseif r <= (chance_skip + chance_halve) then 
        debug_print("We skipped")
        self.idle_speed = 0
        return true
    end
    return false
end

--(Function by Alrysc)
function highlight_tiles(self, list, time)
    local spell = Battle.Spell.new(self:get_team())
    local ref = self
    spell.update_func = function(self)
        for i=1, #list do 
            local t = list[i]
            if t and not t:is_edge() then 
                t:highlight(Highlight.Solid)
            end
        end
        time = time - 1
        if time == 0 then 
            self:delete()
        end
        if self.flinching then 
            if spell and not spell:is_deleted() then 
                spell:delete()
            end
        end
    end
    self:get_field():spawn(spell, self:get_tile())
    return spell
end

-- Moving.
function move(self)
    if self.first_act then
        self.first_act = false
        if self:is_rooted() then
            self.idle_speed = self.base_idle_speed
            increment_pattern(self)
        else
            self.anim:set_state("MOVE", {
                {duration=3, state="SPAWN"},
                {duration=3, state="SPAWN"},
            })
            self.prev_tile = self:get_tile()
            local tile = choose_move(self)
            self.next_tile = tile
            self.next_tile:reserve_entity_by_id(self.reserving_obstacle:get_id())
            self.next_tile:reserve_entity_by_id(self:get_id())
            self.anim:on_frame(1, function()
                local move_fx = graphic_init("artifact", 0, -16*2, MOB_MOVE_TEXTURE, MOB_MOVE_PALETTE, MOB_MOVE_ANIMPATH, 0, "0", Playback.Once, self, self:get_facing(), true, true, true)
                self:get_field():spawn(move_fx, self.next_tile)
            end)
            self.anim:on_frame(2, function()
                --[[
                if self.can_move_to_func(self.next_tile) then 
                else
                    self.next_tile = self:get_tile()
                end
                ]]
                local ref = self
                self:teleport(ref.next_tile, ActionOrder.Voluntary, function()
                    local move_fx = graphic_init("artifact", 0, -16*2, MOB_MOVE_TEXTURE, MOB_MOVE_PALETTE, MOB_MOVE_ANIMPATH, 0, "1", Playback.Once, ref, ref:get_facing(), true, true, true)
                    ref:get_field():spawn(move_fx, ref.prev_tile)
                end)
                self.next_tile:remove_entity_by_id(self.reserving_obstacle:get_id())
            end)
            self.anim:on_complete(function()
                -- Reset idle speed, since we did a real action
                self.idle_speed = self.base_idle_speed
                increment_pattern(self)
            end)
        end
    end
end

-- Jumping to the closest enemy line.
function move_to_enemy(self)
    if self.first_act then
        self.first_act = false
        -- Skips the move if the Character is Rooted. Can randomly skip the move if Confused or Blinded.
        if self:is_rooted() or ((self:is_confused() or self:is_blind()) and math.random(1,2) == 1) then
            self.idle_speed = self.base_idle_speed
            increment_pattern(self)
            increment_pattern(self)
            increment_pattern(self)
        else
            self.anim:set_state("MOVE", {
                {duration=3, state="SPAWN"},
            })
            self.prev_tile = self:get_tile()
            local tile = choose_move_to_enemy(self)
            if not tile then
                self.idle_speed = self.base_idle_speed
                increment_pattern(self)
                increment_pattern(self)
                increment_pattern(self)
                return
            end
            self.next_tile = tile
            self.next_tile:reserve_entity_by_id(self.reserving_obstacle:get_id())
            self.next_tile:reserve_entity_by_id(self:get_id())
            self.anim:on_frame(1, function()
                local move_fx = graphic_init("artifact", 0, -16*2, MOB_MOVE_TEXTURE, MOB_MOVE_PALETTE, MOB_MOVE_ANIMPATH, 0, "0", Playback.Once, self, self:get_facing(), true, true, true)
                self:get_field():spawn(move_fx, self.next_tile)
            end)
            self.anim:on_complete(function()
                --[[
                if self.can_move_to_func(self.next_tile) then 
                else
                    self.next_tile = self:get_tile()
                end
                ]]
                local ref = self
                self:teleport(ref.next_tile, ActionOrder.Voluntary, function()
                    local move_fx = graphic_init("artifact", 0, -16*2, MOB_MOVE_TEXTURE, MOB_MOVE_PALETTE, MOB_MOVE_ANIMPATH, 0, "1", Playback.Once, ref, ref:get_facing(), true, true, true)
                    ref:get_field():spawn(move_fx, ref.prev_tile)
                end)
                self.next_tile:remove_entity_by_id(self.reserving_obstacle:get_id())
                -- Reset idle speed, since we did a real action
                self.idle_speed = self.base_idle_speed
                increment_pattern(self)
            end)
        end
    end
end

-- Using Strike Burner.
function strike_burner(self)
    if self.first_act then
        self.first_act = false
        local frames = {}
        frames[1] = {duration=40, state="STRIKEBURNER_1"}
        for i=1, 30, 3 do
            frames[i+1] = {duration=2, state="STRIKEBURNER_1"}
            frames[i+2] = {duration=2, state="STRIKEBURNER_2"}
            frames[i+3] = {duration=2, state="STRIKEBURNER_3"}
        end
        self.anim:set_state("STRIKEBURNER", frames)
        self.anim:on_frame(2, function()
            self.counterable_component.timer = 16 -- Makes the Character counter-able for 16f.
            self.strikeburner = create_strike_burner(self, self:get_tile(self:get_facing(), 1))
        end)
        self.anim:on_complete(function()
            self.strikeburner:delete()
            self.idle_speed = 12
            increment_pattern(self)
        end)
    end
end

-- Jumping to the field's back end, towards the closest enemy line.
function move_to_back(self)
    if self.first_act then
        self.first_act = false
        -- Skips the move if the Character is Rooted. Can randomly skip the move if Confused or Blinded.
        if self:is_rooted() or ((self:is_confused() or self:is_blind()) and math.random(1,2) == 1) then
            self.idle_speed = self.base_idle_speed
            increment_pattern(self)
            increment_pattern(self)
            increment_pattern(self)
        else
            self.anim:set_state("MOVE", {
                {duration=3, state="SPAWN"},
            })
            self.prev_tile = self:get_tile()
            local tile = choose_move_to_back(self)
            if not tile then
                self.idle_speed = self.base_idle_speed
                increment_pattern(self)
                increment_pattern(self)
                increment_pattern(self)
                return
            end
            self.next_tile = tile
            self.next_tile:reserve_entity_by_id(self.reserving_obstacle:get_id())
            self.next_tile:reserve_entity_by_id(self:get_id())
            self.anim:on_frame(1, function()
                local move_fx = graphic_init("artifact", 0, -16*2, MOB_MOVE_TEXTURE, MOB_MOVE_PALETTE, MOB_MOVE_ANIMPATH, 0, "0", Playback.Once, self, self:get_facing(), true, true, true)
                self:get_field():spawn(move_fx, self.next_tile)
            end)
            self.anim:on_complete(function()
                --[[
                if self.can_move_to_func(self.next_tile) then 
                else
                    self.next_tile = self:get_tile()
                end
                ]]
                local ref = self
                self:teleport(ref.next_tile, ActionOrder.Voluntary, function()
                    local move_fx = graphic_init("artifact", 0, -16*2, MOB_MOVE_TEXTURE, MOB_MOVE_PALETTE, MOB_MOVE_ANIMPATH, 0, "1", Playback.Once, ref, ref:get_facing(), true, true, true)
                    ref:get_field():spawn(move_fx, ref.prev_tile)
                end)
                self.next_tile:remove_entity_by_id(self.reserving_obstacle:get_id())
                -- Reset idle speed, since we did a real action
                self.idle_speed = self.base_idle_speed
                increment_pattern(self)
            end)
        end
    end
end

-- Using Burning Jet.
function burning_jet(self)
    if self.first_act then
        self.first_act = false
        self.anim:set_state("BURNINGJET1", {
            {duration=19, state="BURNINGJET_1"},
            {duration=1, state="BURNINGJET_1"}
        })
        self.anim:on_frame(2, function()
            --print("frame 2")
            self.counterable_component.timer = 16 -- Makes the Character counter-able for 16f.
            self.prev_tile = self.next_tile
            self.original_tile = self.prev_tile
            self.prev_tile = nil
            self.next_tile = nil
        end)
        self.anim:on_complete(function()
            Engine.play_audio(BURNINGJET_AUDIO, AudioPriority.Low)
            self.anim:set_state("BURNINGJET2", {
                {duration=2, state="BURNINGJET_2"},
                {duration=2, state="BURNINGJET_3"},
            })
            self.anim:set_playback(Playback.Loop)
            self:share_tile(true) -- Can pass through Characters and Obstacles while using Burning Jet.
            self.moving_to_enemy_tile = true
            self.collision_available = false
            self.can_move_to_edge = true
            local hit_props_1 = HitProps.new()
                :dmg(0)
                :impact()
                :flinch()
                --:breaking()
                :from(self:get_context())
                :elem(Element.Fire)
                :elem2(Element.Break)
            local hit_props_2 = HitProps.new()
                :dmg(self.damage_burningjet)
                :impact()
                :flinch()
                :flash()
                --:breaking()
                :from(self:get_context())
                :elem(Element.Fire)
                :elem2(Element.Break)
            self.burningjet_1 = create_hitbox_burningjet(self, hit_props_1, self:get_tile())
            self.burningjet_2 = create_hitbox_burningjet(self, hit_props_2, self:get_tile(self:get_facing(), 1), true)

            self.original_tileWidth = self.original_tile:width()/2
            self.offset_x = self:get_offset().x
        end)
    end
    if self.anim:get_state() == "BURNINGJET2" then
        if self.burningjet_1 and not self.burningjet_1:is_deleted() then
            if self.burningjet_1:get_tile() ~= self:get_tile() then
                self.burningjet_1:teleport(self:get_tile(), ActionOrder.Immediate)
            end
        end
        if self.burningjet_2 and not self.burningjet_2:is_deleted() then
            if self.burningjet_2:get_tile() ~= self:get_tile(self:get_facing(), 1) then
                self.burningjet_2:teleport(self:get_tile(self:get_facing(), 1), ActionOrder.Immediate)
            end
        end
        self.original_tile:reserve_entity_by_id(self.reserving_obstacle:get_id())
        self.original_tile:reserve_entity_by_id(self:get_id())
        --print(self.offset_x)
        if self:get_facing() == Direction.Left then
            self.offset_x = self.offset_x - (4*2)
        else
            self.offset_x = self.offset_x + (4*2)
        end
        if (self:get_facing() == Direction.Left  and round(self.offset_x, self) < -self.original_tileWidth)
        or (self:get_facing() == Direction.Right and round(self.offset_x, self) >  self.original_tileWidth) then
            if self:get_tile(self:get_facing(), 1) then
                if self:get_facing() == Direction.Left then
                    self.offset_x =  (self.original_tileWidth + (self.offset_x + self.original_tileWidth))
                else
                    self.offset_x = -(self.original_tileWidth - (self.offset_x - self.original_tileWidth))
                end
                self:teleport(self:get_tile(self:get_facing(), 1), ActionOrder.Immediate)
                self:set_offset(self.offset_x, self:get_offset().y)
            end
        else
            self:set_offset(self.offset_x, self:get_offset().y)
        end
        if (((self:get_facing() == Direction.Left and round(self.offset_x, self) <= 0) or (self:get_facing() == Direction.Right and round(self.offset_x, self) >= 0)) and self:get_tile(self:get_facing(), 1) == nil)
        or (((self:get_facing() == Direction.Left and round(self.offset_x, self) < -self.original_tileWidth) or (self:get_facing() == Direction.Right and round(self.offset_x, self) > self.original_tileWidth)) and self:get_tile():is_hole() and not self:get_tile():is_edge()) then
            if self.burningjet_count > 0 then
                self.burningjet_count = self.burningjet_count - 1
                local tile = choose_move_to_back2(self)
                self:teleport(tile, ActionOrder.Immediate)
            else
                if self.do_once_1 then
                    self.do_once_1 = false
                    if self.burningjet_1 and not self.burningjet_1:is_deleted() then self.burningjet_1:delete() end
                    if self.burningjet_2 and not self.burningjet_2:is_deleted() then self.burningjet_2:delete() end
                    self:share_tile(false)
                    self.burningjet_count = self.burningjet_times
                    self.moving_to_enemy_tile = false
                    self.collision_available = true
                    self.can_move_to_edge = false
                    self:set_offset(0,0)
                    self.anim:set_state("MOVE2", {
                        {duration=3, state="BURNINGJET_3"},
                        {duration=3, state="SPAWN"},
                    })
                    self.original_tile:reserve_entity_by_id(self.reserving_obstacle:get_id())
                    self.original_tile:reserve_entity_by_id(self:get_id())
                    self.anim:on_frame(1, function()
                        local move_fx = graphic_init("artifact", 0, -16*2, MOB_MOVE_TEXTURE, MOB_MOVE_PALETTE, MOB_MOVE_ANIMPATH, 0, "0", Playback.Once, self, self:get_facing(), true, true, true)
                        self:get_field():spawn(move_fx, self.original_tile)
                    end)
                    self.anim:on_frame(2, function()
                        local ref = self
                        self:teleport(ref.original_tile, ActionOrder.Immediate, function()
                            local move_fx = graphic_init("artifact", ref:get_tile_offset().x, -16*2, MOB_MOVE_TEXTURE, MOB_MOVE_PALETTE, MOB_MOVE_ANIMPATH, 0, "1", Playback.Once, ref, ref:get_facing(), true, false, true)
                            ref:get_field():spawn(move_fx, ref:get_tile())
                        end)
                        self.original_tile:remove_entity_by_id(self.reserving_obstacle:get_id())
                        self.original_tile = nil
                    end)
                    self.anim:on_complete(function()
                        -- Reset idle speed, since we did a real action
                        self.idle_speed = self.base_idle_speed
                        increment_pattern(self)
                    end)
                end
            end
        end
    end
end

function choose_enemy(self, field)
    local team = self:get_team()

    local target = field:find_characters(function(c)
        return c:get_team() ~= team
    end)

    if not target[1] then 
        debug_print("No targets")
        return nil
    end

    local t_x = target[1]:get_tile():x()
    local t_y = target[1]:get_tile():y()

    local tile = field:tile_at(t_x, t_y)

    return tile
end

function choose_move(self)
    local field = self:get_field()
    local team = self:get_team()

    local tiles = field:find_tiles(function(tile)
        return tile ~= self:get_tile() and not tile:is_edge() and tile:get_team() == team and self.can_move_to_func(tile)
    end)

    debug_print("Found ", #tiles, " possible tiles")

    if #tiles == 0 then
        return self:get_tile()
    end

    return tiles[math.random(1, #tiles)]
end

function choose_move_to_enemy(self)
    local field = self:get_field()
    local team = self:get_team()
    local enemy_tile = choose_enemy(self, field)
    if not enemy_tile or self:is_confused() or self:is_blind() then
        return choose_move(self)
    else
        local move_tile = nil
        for i=1, field:width() do
            local tile = enemy_tile:get_tile(self:get_facing_away(), i)
            if tile and not tile:is_edge() and tile:get_team() == team and self.can_move_to_func(tile) then
                move_tile = tile
                break
            end
        end
        --print("Found ", #tiles, " possible tiles")
        if move_tile == nil then 
            return choose_move(self)
        end
        return move_tile
    end
end

function choose_move_to_back(self)
    local facing = self:get_facing()
    local field = self:get_field()
    local team = self:get_team()

    local query = function(c)
        return c:get_health() > 0 and not c:is_team(team)
    end
    local enemy = field:find_nearest_characters(self, query)
    local end_x = field:width()
    if facing == Direction.Right then end_x = 1 end

    local tiles = nil
    if #enemy > 0 and not self:is_confused() and not self:is_blind() then
        tiles = field:find_tiles(function(tile)
            return tile and not tile:is_edge() and tile:get_team() == team and tile:x() == end_x and tile:y() == enemy[1]:get_tile():y() and self.can_move_to_func(tile)
        end)
    else
        return choose_move(self)
    end

    debug_print("Found ", #tiles, " possible tiles")

    return tiles[math.random(1, #tiles)]
end

function choose_move_to_back2(self)
    local facing = self:get_facing()
    local field = self:get_field()
    local team = self:get_team()

    local query = function(c)
        return c:get_health() > 0 and not c:is_team(team)
    end
    local enemy = field:find_nearest_characters(self, query)
    local end_x = field:width()
    if facing == Direction.Right then end_x = 1 end

    local tiles = nil
    if #enemy > 0 and not self:is_confused() and not self:is_blind() then
        tiles = field:find_tiles(function(tile)
            return tile and not tile:is_edge() and tile:get_team() == team and tile:x() == end_x and tile:y() == enemy[1]:get_tile():y() and self.can_move_to_func(tile)
        end)
    else
        tiles = field:find_tiles(function(tile)
            return tile and not tile:is_edge() and tile:get_team() == team and tile:x() == end_x and self.can_move_to_func(tile)
        end)
    end

    debug_print("Found ", #tiles, " possible tiles")

    return tiles[math.random(1, #tiles)]
end

function reconstruct_pattern(self)
    local pattern = {}
    local states = self.states
    self.move_count = self.move_count + 1 -- Counts on every recontruction.

    for i=1, 5 do -- Moves randomly 5 times. 
        table.insert(pattern, states.move)
        table.insert(pattern, states.idle)
    end
    table.insert(pattern, states.move_to_enemy)
    table.insert(pattern, states.strike_burner)
    table.insert(pattern, states.idle)
    if self.move_count%3==0 then -- Uses Burning Jet on every 3rd pattern loop.
        table.insert(pattern, states.move_to_back)
        table.insert(pattern, states.burning_jet)
        table.insert(pattern, states.idle)
    end

    self.pattern = pattern
end

function increment_pattern(self)
    debug_print("Pattern increment")
    self.first_act = true
    self.do_once_1 = true
    self.burningjet_count = self.burningjet_times
    self.can_move_to_edge = false
    self.state_done = false
    self.pattern_index = self.pattern_index + 1
    if self.pattern_index > #self.pattern then 
        reconstruct_pattern(self)
        debug_print("Reconstructed pattern")
        self.pattern_index = 1
    end
    local next_state = self.pattern[self.pattern_index]
    self.state = next_state
    debug_print("Moving to state named ", next_state.name)
    if next_state == self.states.start_sub_pattern then 
        self.in_sub_pattern = true
        increment_pattern(self)
    end
    if next_state == self.states.finish_sub_pattern then 
        self.in_sub_pattern = false
        increment_pattern(self)

    end
    debug_print("Changing to "..self.pattern_index..", which is "..self.pattern[self.pattern_index].name)
end

-- Checks for non-zero-health Obstacles.
function check_obstacles(tile, self)
    local ob = tile:find_obstacles(function(o)
        if o:get_animation():has_state("PASS_THROUGH") or o:get_name() == "CANTINTERACT" then
            return false
        else
            return true
        end
        return o:get_health() > 0
    end)
    return #ob > 0 
end

-- Checks for unfriendly Characters.
function check_characters(tile, self)
    local characters = tile:find_characters(function(c)
        return c:get_id() ~= self:get_id() and c:get_team() ~= self:get_team()
    end)
    return #characters > 0
end

-- Checks for any Characters.
function check_characters_true(tile, self)
    local characters = tile:find_characters(function(c)
        return c:get_health() > 0
    end)
    return #characters > 0
end