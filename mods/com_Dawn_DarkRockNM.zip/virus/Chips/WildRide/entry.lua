nonce = function() end

local chip = {name="WildRide"}

local DAMAGE = 40
local TEXTURE = Engine.load_texture(_folderpath.."puck.png")
local TEXTURE_ANIM = _folderpath.."puck.animation"
local LAUNCH_AUDIO = Engine.load_audio(_folderpath.."pucklaunch.ogg")
local BOUNCE_AUDIO = Engine.load_audio(_folderpath.."puckhit.ogg")
local MOB_MOVE_TEXTURE = Engine.load_texture(_folderpath.."mob_move.png")
local PARTICLE_TEXTURE = Engine.load_texture(_folderpath.."artifact_impact_fx.png")

function package_init(package) 
    package:declare_package_id("com.claris.dark.Hocky")
    package:set_icon_texture(Engine.load_texture(_folderpath.."icon.png"))
    package:set_preview_texture(Engine.load_texture(_folderpath.."preview.png"))
	package:set_codes({'Y'})

    local props = package:get_card_props()
    props.shortname = "DrkHcky"
    props.damage = DAMAGE
    props.time_freeze = false
    props.element = Element.Break
    props.description = "GO FOR A WILD RIDE"
	props.card_class = CardClass.Dark
	props.limit = 1
	props.can_boost = false
	props.long_description = "DARK CHIP (C) NEBULA. DRAG FOE AROUND FIELD."
end

local frame_data = make_frame_data({
	{1, 0.033}, {2, 0.033}, {3, 0.033}, {4, 0.416}
})

chip.card_create_action = function(user)
	local action = Battle.CardAction.new(user, "PLAYER_SWORD")
	
	action:override_animation_frames(frame_data)
	action:set_lockout(make_animation_lockout())

	action.execute_func = function(self, user)
		local actor = self:get_actor()

		self:add_anim_action(2, function()
			user:toggle_counter(true)
			local hilt = self:add_attachment("HILT")
			local hilt_sprite = hilt:sprite()
			hilt_sprite:set_texture(actor:get_texture())
			hilt_sprite:set_layer(-2)
			hilt_sprite:enable_parent_shader(true)
			local hilt_anim = hilt:get_animation()
			hilt_anim:copy_from(actor:get_animation())
			hilt_anim:set_state("HAND")
			hilt_anim:refresh(hilt_sprite)
		end)
				
		self:add_anim_action(3, function()
			local puck = create_puck(user)
			local dir = user:get_facing()
			local tile = user:get_tile(dir, 1)
			user:get_field():spawn(puck, tile)
		end) 

		self:add_anim_action(4, function()
			user:toggle_counter(false)
		end)


	end
	return action
end

function create_puck(user)
    local spell = Battle.Spell.new(user:get_team())
	local tile_count = 11
	local self_team = user:get_team()
    local direction = Direction.join(user:get_facing(), Direction.Down)

    local anim = spell:get_animation()
    anim:load(TEXTURE_ANIM)
    anim:set_state("DEFAULT")
    local sprite = spell:sprite()
    sprite:set_texture(TEXTURE)
    anim:refresh(sprite)
    anim:set_playback(Playback.Loop)

    spell:highlight_tile(Highlight.Flash)

    spell:set_hit_props(
        HitProps.new(
            40, 
            Hit.Impact | Hit.Flinch | Hit.Breaking | Hit.Drag,
            Element.Break,
            user:get_context(),
            Drag.new(direction, 1)
        )
    )
	local spareProps = spell:copy_hit_props()
    spell.update_func = function(self, dt) 
    	local tile = self:get_current_tile()
        tile:attack_entities(self)

		if tile:is_edge() or tile:is_hole() or tile_count < 1 then
			self:delete()
		end
        if not self:is_sliding() then
            local dest
        	local play_bounce
            dest, play_bounce, direction = Bounce(tile, spell, direction, self_team)
            if dest then
	            self:slide(dest, frames(6), frames(0), ActionOrder.Voluntary, nil)
	            if play_bounce then
	            	Engine.play_audio(BOUNCE_AUDIO, AudioPriority.Low)
	            end
	        else
	        	self:delete()
	        end
            tile_count = tile_count - 1
		else
			local dest
        	local dummy
			local drag_direction
            dest, dummy, drag_direction = Bounce(tile, spell, direction, self_team)
			spareProps.drag = Drag.new(drag_direction, 1)
			spell:set_hit_props(spareProps)
        end
    end

	spell.collision_func = function(self, other)
		local fx = Battle.Artifact.new()
		fx:set_texture(PARTICLE_TEXTURE, true)
		fx:get_animation():load(_folderpath.."artifact_impact_fx.animation")
		fx:get_animation():set_state("YELLOW")
		fx:get_animation():refresh(fx:sprite())
		fx:get_animation():on_complete(function()
			fx:erase()
		end)
		spell:get_field():spawn(fx, spell:get_current_tile())
	end

    spell.attack_func = function(self, other) 
    end

    spell.delete_func = function(self)
		if not spell:get_current_tile():is_edge() then
			--if we're not on an edge tile, which happens mostly at the end of battle for some reason,
			--then spawn a mob move to visually vanish the puck when it deletes.
			--presentation!
			local fx = Battle.Artifact.new()
			fx:set_texture(MOB_MOVE_TEXTURE, true)
			fx:get_animation():load(_folderpath.."mob_move.animation")
			fx:get_animation():set_state("DEFAULT")
			fx:get_animation():refresh(fx:sprite())
			fx:get_animation():on_complete(function()
				fx:erase()
			end)
			spell:get_field():spawn(fx, spell:get_current_tile():x(), spell:get_current_tile():y())
		end
		self:erase()
    end

    spell.can_move_to_func = function(tile)
		if tile:is_edge() or tile:is_hole() then
			return false
		end
		return true
    end

	Engine.play_audio(LAUNCH_AUDIO, AudioPriority.High)

    return spell
end

function Bounce(tile, spell, direction, self_team)
	local play_bounce = true
    local new_dir = direction
    local tile_team = tile:get_team()	-- this is the team of the tile we're currently on

    -- no entry if the target tile is friendly and we aren't currently on a friendly tile
    local function teamcheck(new_tile)
    	local new_tile_team = new_tile:get_team()
	    if (new_tile_team == self_team) and not (new_tile_team == tile_team) then
	    	return true
	    end
	    return false
    end
    -- wraps up all the checks into one function and returns true if we can't move to the tile
    local function bad()
    	local new_tile = tile:get_tile(new_dir, 1)
    	if teamcheck(new_tile) then return true end
    	return not spell.can_move_to_func(new_tile)
    end

    -- check if any tile is accessible, 1) no flip, 2) flip x, 3) flip y, 4) flip x and y
    -- (there's no reason to check x before y, it's arbitrary, but the order matters for the other ones)
    if bad() then
	    new_dir = Direction.flip_x(direction)
	    if bad() then
		    new_dir = Direction.flip_y(direction)
		    if bad() then
			    new_dir = Direction.reverse(direction)
			    if bad() then
			    	-- by returning false, we nil some expected returns, but it's ok cuz the puck will die immediately
			    	return false
			    end
			end
	    end
	else
		play_bounce = false
    end

    direction = new_dir
    local dest = tile:get_tile(direction, 1)
	return dest, play_bounce, direction
end

return chip