local chip = {}

local function create_spell(user, target, array)
    local spell = Battle.Spell.new(user:get_team())
    spell:set_texture(Engine.load_texture(_folderpath.."hit.png"))
    local sprite = spell:sprite()
    local animation = spell:get_animation()
    local direction = Direction.Right
    if user:get_team() == Team.Blue then direction = Direction.Left end
    animation:load(_folderpath.."hit.animation")
    animation:set_state("0")
    animation:refresh(sprite)
    animation:on_complete(function()
        spell:erase()
    end)
    spell:set_hit_props(
        HitProps.new(
            30 * #array,
            Hit.Pierce,
            Element.None,
            user:get_context(),
            Drag.None
        )
    )
    spell.update_func = function(self, dt)
        self:get_tile():attack_entities(self)
    end
    local slide_component = Battle.Component.new(target, Lifetimes.Battlestep)
    slide_component.user = user
    slide_component.countdown = 37
    local occupied_query = function(ent)
        return Battle.Obstacle.from(ent) ~= nil or Battle.Character.from(ent) ~= nil
    end
    slide_component.update_func = function(self, dt)
        self.countdown = self.countdown - 1
        if self.countdown <= 0 then self:eject() end
        local owner = self:get_owner()
        local tile = owner:get_tile(direction, 1)
        if tile and tile:is_edge() then self:eject() end
        if tile and not tile:is_edge() and not owner:is_sliding() then
            owner:slide(tile, frames(6), frames(0), ActionOrder.Immediate, nil)
        end
    end
    target:register_component(slide_component)
    return spell
end

function package_init(package)
    package:declare_package_id("com.Rework.A.Chip562")
    package:set_icon_texture(Engine.load_texture(_folderpath .. "icon.png"))
    package:set_preview_texture(Engine.load_texture(_folderpath .. "preview.png"))
    package:set_codes({ '*' })

    local props = package:get_card_props()
    props.shortname = "PushBack"
    props.damage = 0
    props.time_freeze = true
    props.element = Element.None
    props.limit = 1
    props.card_class = CardClass.Standard
    props.can_boost = false
    props.description = "Get enmy out of your area"
    props.long_description = "Push everything out of your area!"
end

chip.card_create_action = function(user)
    local action = Battle.CardAction.new(user, "PLAYER_IDLE")

    action:set_lockout(make_sequence_lockout())

    action.execute_func = function(self, user)
        local step1 = Battle.Step.new()
        local step2 = Battle.Step.new()
        local ref = self
        self.original_owner_tile_array = {}
        local field = user:get_field()
        self.back_row_array = {}
        if user:get_team() == Team.Blue then
            table.insert(self.back_row_array, field:tile_at(6, 1))
            table.insert(self.back_row_array, field:tile_at(6, 2))
            table.insert(self.back_row_array, field:tile_at(6, 3))
            for x = 6, 4, -1 do
                for y = 1, 3, 1 do
                    local check_tile = field:tile_at(x, y)
                    if check_tile and not check_tile:is_edge() then
                        print("tile should be inserted, blue team")
                        table.insert(self.original_owner_tile_array, check_tile)
                    end
                end
            end
        else
            table.insert(self.back_row_array, field:tile_at(1, 1))
            table.insert(self.back_row_array, field:tile_at(1, 2))
            table.insert(self.back_row_array, field:tile_at(1, 3))
            for x = 1, 3, 1 do
                for y = 1, 3, 1 do
                    local check_tile = field:tile_at(x, y)
                    if check_tile and not check_tile:is_edge() then
                        print("tile should be inserted, red team")
                        table.insert(self.original_owner_tile_array, check_tile)
                    end
                end
            end
        end
        local do_once = true
        local do_twice = true
        local is_attack = false
        self.change_back_array = {}
        local occupied_query = function(ent)
            return Battle.Obstacle.from(ent) ~= nil or Battle.Character.from(ent) ~= nil and ent:get_team() ~= user:get_team()
        end
        local t = 0
        step1.update_func = function(self, dt)
            if do_once then
                print("tile array size is "..#ref.original_owner_tile_array)
                for i = 1, #ref.original_owner_tile_array, 1 do
                    local tile = ref.original_owner_tile_array[i]
                    if not user:is_team(tile:get_team()) then
                        if not is_attack then
                            is_attack = true
                            print("we're adding a tile, is attack set to true")
                        end
                        table.insert(ref.change_back_array, tile)
                    end
                    t = t + 1
                end
                do_once = false
            end
            if t >= 9 then
                self:complete_step()
            end
        end
        local has_attacked = false
        a = 0
        step2.update_func = function(self, dt)
            if do_twice then
                for j = 1, #ref.back_row_array, 1 do
                    local tile = ref.back_row_array[j]
                    local foes = tile:find_entities(occupied_query)
                    if #foes > 0 then
                        for e = 1, #foes, 1 do
                            local spell = create_spell(user, foes[e], ref.back_row_array)
                            field:spawn(spell, tile)
                        end
                    end
                end
                print("in step 2 update func do once")
                if not is_attack then
                    print("there's no need to attack, complete the step!")
                    self:complete_step()
                end
                for i = 1, #ref.change_back_array, 1 do
                    local tile = ref.change_back_array[i]
                    local foes = tile:find_entities(occupied_query)
                    if #foes > 0 then
                        for e = 1, #foes, 1 do
                            local spell = create_spell(user, foes[e], ref.change_back_array)
                            field:spawn(spell, tile)
                        end
                    end
                    a = a + 1
                end
                do_twice = false
            end
            if is_attack and a >= #ref.change_back_array then
                self:complete_step()
            end
        end
        self:add_step(step1)
        self:add_step(step2)
    end
    return action
end

return chip