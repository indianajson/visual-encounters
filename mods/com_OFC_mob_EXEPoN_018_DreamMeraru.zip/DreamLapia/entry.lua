local shared_package_init = include("../shared/entry.lua")

function package_init(character)
    local character_info = {
        name = "DrmLapia",
        hp = 60,
        damage = 20,
        palette = _folderpath.."battle_v1.palette.png",
        element = Element.Aqua,
        height = 44,
        frames_between_actions = 30,
        move_speed = 30,
        attack_frame = 13,
        thunderball_speed = 80,
    }
    if character:get_rank() == Rank.V1 then
        character_info.name = "DremLapia"
    elseif character:get_rank() == Rank.V2 then
        character_info.hp = 130
        character_info.damage = 50
        character_info.palette = _folderpath.."battle_v2.palette.png"
        character_info.move_speed = 25
        character_info.attack_frame = 11
    elseif character:get_rank() == Rank.V3 then
        character_info.hp = 190
        character_info.damage = 90
        character_info.palette = _folderpath.."battle_v3.palette.png"
        character_info.move_speed = 20
        character_info.attack_frame = 9
    elseif character:get_rank() == Rank.SP then
        character_info.hp = 260
        character_info.damage = 120
        character_info.palette = _folderpath.."battle_sp.palette.png"
        character_info.move_speed = 15
        character_info.attack_frame = 7
    end
    shared_package_init(character, character_info)
end
