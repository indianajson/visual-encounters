local texture = nil
local SHADOW_TEXTURE = Engine.load_texture(_folderpath.."shadow.png")

local ATTACK_TEXTURE_1 = Engine.load_texture(_folderpath.."attacks1.png")
local ATTACK_TEXTURE_2 = Engine.load_texture(_folderpath.."thunderball.png")
local ATTACK_TEXTURE_3 = Engine.load_texture(_folderpath.."attacks3.png")
local ATTACK_ANIMATION = _folderpath.."attacks.animation"
local ATTACK_ANIMATION_2 = _folderpath.."thunderball.animation"

local MOVE_TEXTURE = Engine.load_texture(_folderpath.."move.png")
local MOVE_ANIMATION =  _folderpath.."move.animation"
--local HIT_TEXTURE = Engine.load_texture(_folderpath.."overlay_fx05_animations.png")
--local HIT_ANIMATION = _folderpath.."overlay_fx05_animations.animation"

local ELEC_SFX = Engine.load_audio(_folderpath.."EXE4_72.ogg")
local SUMMON_SFX = Engine.load_audio(_folderpath.."EXE4_330.ogg")
local HIT_SFX = Engine.load_audio(_folderpath.."hit.ogg")

local EFFECT_TEXTURE = Engine.load_texture(_folderpath.."effect.png")
local EFFECT_ANIMPATH = _folderpath.."effect.animation"
local BOOM_TEXTURE = Engine.load_texture(_folderpath.."boom.png")
local BOOM_ANIMPATH = _folderpath.."boom.animation"
local BOOM_AUDIO = Engine.load_audio(_folderpath.."EXE4_273.ogg")


--[[
    Behavior overview:
    (Frame numbers counted from videos, so have a margin of error. Also, the game runs at like 30 FPS, so I'll double these values for ONB to be a similar speed)

    Wait 26f (V2 - 22f, V3 - 18f, SP - 14f) before moving
    Move 3 times before attacking
        Sometimes see 2 moves, sometimes see instant move with no wait
            I have to take some liberties here. May decide on a move count that will normally be 3, but may be 2 (increase odds at low HP)
                May decide to move instantly after being flinched
    After attacking, wait double idle time before moving again
    Flinch lasts 40f, animates as shaking back and forth (offset 0, offset X, offset 2X, offset 0, repeat, step every 2f)
    
    Has 3 attacks:
    Jamming Wave
        Shoots circle thingy, offset to come off antennae
        Shoots straight forward until off screen
        Rather than sliding, spends 2f on each tile before teleporting, highlighting the tile it's on and the last one
            Unclear whether it damages both
        (K1rbYat1Na: It's supposed to slide, but the game doesn't support fast sliding. (For example, the same thing happened with Rabi Ring))
        -- TODO: Can destroy chips.
        Damage:
        V1 - 60
        V2 - 80
        V3 - 100
        SP - 120

    Jamming Tower
        Summons tower on random enemy tile.
            I have not seen it spawn on the player, and that seems awful for it to, so I've taken steps to prevent doing that
        Tower tile is highlighted entire time. Highlight starts 10f before tower appears, so probably just spawn it and keep invisible with blank state
        Unclear when damage starts being dealt. Will assume when tower starts looped animation
        Each anim frame is 2f, and tower lasts overall for ~190f?
        Damage:
        V1 - 60
        V2 - 80
        V3 - 100
        SP - 120

    Thunder Ball
        Shoots two Thunder Balls. May be coinflip for if second ball if above or below first, but for top and bottom row it should always be below and above, respectively
        Follow enemy horizontally until lined up, then move vertically. Stuns on hit. 
        (K1rbYat1Na: He can't use it again until both spawned Thunder Balls are deleted.)
        40f per tile moved, moves 7 times before fading
        Damage:
        V1 - 80
        V2 - 100
        V3 - 120
        SP - 140
]]
function package_init(self)
    texture = Engine.load_texture(_modpath.."JammingMan.png")
    self:set_name("JamngMan")
	local rank = self:get_rank()
    self.damage = 60
    self.damage_jammingwave = 60
    self.damage_jammingtower = 60
    self.damage_thunderball = 80
    self.flinch_duration = 40
    self.move_count = 3
    
    -- Will set to base_idle_speed normally, but go to *2 after an attack, and sometimes * 1 or * 0 after flinch
    self.base_idle_speed = 52
    self.shot_speed = 4
    self.elecball_speed = 80
    self.tower_lifetime = 380
    self.thunderball1_deleted = true
    self.thunderball2_deleted = true

    -- Chance /16. I'm going to run these when the pattern is complete and when the flinch finishes, respectively
        -- These skips will be very implementation-specific, so don't use them as future references
    self.chance_to_move_twice = 2
    self.chance_to_skip_idle_after_flinch = 2
    self.chance_to_halve_idle_after_flinch = 3 

    -- Going to track which tiles currently have a tower on them, to prevent double spawns
    self.tiles_with_tower = {}

    if rank == Rank.V1 then
        self:set_health(1000)
    elseif rank == Rank.V2 then
        self:set_name("JamngMnV")
		self:set_health(1200)
        self.damage = 80
        self.damage_jammingwave = 80
        self.damage_jammingtower = 80
        self.damage_thunderball = 100
        self.base_idle_speed = 44
    elseif rank == Rank.V3 then
        self:set_name("JamngMnV")
		self:set_health(1500)
        self.damage = 100
        self.damage_jammingwave = 100
        self.damage_jammingtower = 100
        self.damage_thunderball = 120
        self.base_idle_speed = 36
    elseif rank == Rank.SP then
		self:set_health(1700)
        self.damage = 120
        self.damage_jammingwave = 120
        self.damage_jammingtower = 120
        self.damage_thunderball = 140
        self.base_idle_speed = 28
	end

    self.idle_speed = self.base_idle_speed 

	self:set_element(Element.Elec)
    self:set_texture(texture, true)
    self:set_height(60)
    self:share_tile(false)
    self.max_health = self:get_health()
    self:set_explosion_behavior(3, 1, true)


    local anim = self:get_animation()
    anim:load(_modpath.."JammingMan.animation")

    self.anim = include("enemy_base_v1/entry.lua")
    anim = self.anim
    anim:set_owner(self)
    anim:set_state("IDLE", {
        {duration=self.idle_speed, state="IDLE_1"},
    })

    anim:set_playback(Playback.Loop)

    init_boss(self)

end

-- This is to fix something that happens because I'm a cheater
--[[
    The aggressor of an attack is held in the Context object. 
    ONB leaves this aggressor unset in the Entity's Context until a CardAction is used for the first time
    So I'll immediately force a CardAction that will hopefully end immediately and not get in the way, but also will fix this
    This probably goes horribly wrong if the enemy is spawned after the mob intro, but should be fine for now otherwise
]]
function fix_context(self)
    local action = Battle.CardAction.new(self, "IDLE_1")
    action.execute_func = function()
        action:end_action()
    end

    self:card_action_event(action, ActionOrder.Immediate)
end

function init_boss(self)
    self.on_spawn_func = function(self)
        fix_context(self)
    end

    -- Setting names here is just convenience if I want to print the state I'm in later
    self.states = {
        idle = {name = "idle", func = idle},
        move = {name = "move", func = move},
        flinch = {name = "flinch", func = flinch},
        
        start_sub_pattern = {name = "start_sub_pattern"},
        finish_sub_pattern = {name = "finish_sub_pattern"},

        shoot = {name = "shoot", func = shoot},
        tower = {name = "tower", func = tower},
        elecball = {name = "elecball", func = elecball},

        choose_attack = {name = "choose_attack", func = choose_attack}
    }
    


    local s = self.states

    reconstruct_pattern(self)
 
    self.pattern_index = 1
    self.in_sub_pattern = false

    self.first_act = true

    self.state_done = false

    self.state = self.pattern[1]

    self.first_flinch = true


    self.hit_func = function(from_stun)
      --  print("Hit func runs")
        self.flinching = false
        self.first_act = false
        self.state_done = false
        self.moving_to_enemy_tile = false
        if self.first_flinch then 
         --   self.state.cleanup
            self.last_state = self.state
       --     print("Hit! Set last state to ", self.state.name)
            if self.state ~= self.states.idle and self.state ~= self.states.move then 
               -- increment_pattern(self)
            end

            self.first_flinch = false
        end

        self.state = self.states.flinch

        -- This is unused for this boss
        if self.slide_component ~= nil then 
          --  print("Hit while moving.")
            self.slide_component:eject()
            self.slide_component = nil
            self:set_offset(0, 0)

            if self.slide_dest and self:get_current_tile() ~= self.slide_dest then 
            --    print("Hit before reaching destination.")
                self:get_current_tile():remove_entity_by_id(self:get_id())
                self.slide_dest:add_entity(self)
                self.slide_dest = nil
            end

        end

        flinch(self, from_stun)
    end

    self.delete_func = function(self)
        self.update_func = function(self)
            self:get_animation():set_state("FLINCH_1")
            self.state = self.states.flinch
        end

    end

    -- Unused for this boss
    self.moving_to_enemy_tile = false
    self.counter = 0
    self.collision_available = true


    self:register_status_callback(Hit.Stun, function() self.hit_func(true) end)
    self:register_status_callback(Hit.Flinch, self.hit_func)
    self:register_status_callback(Hit.Drag, self.hit_func)
    self:register_status_callback(Hit.Root, function() self.rooted = 120 end)

    -- Bring it back next build. For now, relying on the stun callback
    --[[
    self.on_countered = function(self)
        print("Countered")
        self:toggle_counter(false)
        self.hit_func(self)

    end
    --]]

    self.can_move_to_func = function(tile)
        if self.rooted > 0 then return false end
        if tile:is_edge() or not tile:is_walkable() then
            return false
        end
        if(tile:is_reserved({})) then
            return false
        end

        if not self.moving_to_enemy_tile and (tile:get_team() ~= self:get_team()) then
            return false
        end

        return not check_obstacles(tile, self) --and not check_characters(tile, self)
    end

    self.rooted = 0
    self.update_func = function(self)
       -- print("     ", self.state.name, self:get_animation():get_state())
        if self.rooted > 0  then self.rooted = self.rooted - 1 end
        self.state.func(self)
        self.anim:tick_animation()

        -- When we tick animation, we may run increment_pattern. 
        -- The new state isn't run until next frame, so our anim state lasts one more frame when it finishes
        -- Calling our state one time to set things up will avoid this. Mostly sure this doesn't have major unintended consequences,
        -- especially as most state.func only set state and callbacks for frame 1
        -- Problem is, now I may have a frame 1 callback but I don't run it until next frame
        while self.first_act
        do
            self.state.func(self)
            self.anim:tick_animation()
        end
        check_collision(self)
    end
end

function create_collision_attack(self, tile)
    local spell = Battle.Spell.new(self:get_team())
   
    local hit_props = HitProps.new(
        self.damage,
        Hit.Impact | Hit.Flash | Hit.Flinch,
        self:get_element(), 
        self:get_context(), 
        Drag.None
    )

    spell:set_hit_props(hit_props)

    spell.update_func = function(self)
        tile:attack_entities(self)
        self:delete()
    end

    self:get_field():spawn(spell, tile)
end


-- TODO: When we get is_passthrough or something, check to see if target became flashing before 
    -- we are allowed to spawn another one. Don't want to instakill viruses
-- self.collision_available can do something related to that. Does nothing now
function check_collision(self)
    local t = self:get_current_tile()
    if self.collision_available and check_characters(t, self) then 
        create_collision_attack(self, t)
    end

end

function idle(self)
    if self.first_act then 
        -- This is an old check for when I extended idle time by doing two idle states in a row, when characters have an animated idle
            -- Not needed if I instead use a timer
        if self.anim:get_state() ~= "IDLE" then 
        --    print("Idle with ", self.idle_speed)
            self.anim:set_state("IDLE", {
                {duration=self.idle_speed, state="IDLE_1"},
            })    
        end

        self.anim:set_playback(Playback.Loop)

        self.anim:on_complete(function()
            -- Extra catch for after leaving attack. Attack will double idle speed once, so making sure to reset it after
            if self.idle_speed > self.base_idle_speed then 
                self.idle_speed = self.base_idle_speed
            end
            increment_pattern(self)
        
        end)

        self.first_act = false
    end

    --self.looped = false
    --if self.state_done then 
       -- print("State done")
        
   -- end
end

function hit()
    

end

function end_sub_pattern(self)
    while(self.in_sub_pattern)
    do
        increment_pattern(self)
    end
end

function flinch(self, from_stun)
   -- print("Flinch played")

   -- print("I am flinching")
    if not self.flinching then 
        local frames = {}
        local flinch_time = self.flinch_duration
        if not from_stun then 
            for i=1, flinch_time, 3
            do
                frames[i] = {duration=2, state="FLINCH_1"}
            end
            for i=2, flinch_time, 3
            do
                frames[i] = {duration=2, state="FLINCH_2"}
            end

            for i=3, flinch_time, 3
            do
                frames[i] = {duration=2, state="FLINCH_3"}
            end
        else
            frames[1] = {duration=0, state="FLINCH_1"}
        end

        self.anim:set_state("FLINCH", frames)

        self.anim:on_complete(function()
            -- If we didn't just attack, we want to make sure the idle speed is correct. This is also set in the actual idle, but just for extra measure.
                -- Shouldn't be necessary
            if self.idle_speed > self.base_idle_speed and self.pattern[self.pattern_index] ~= self.states.choose_attack then 
                self.idle_speed = self.base_idle_speed
            end

            local has_skipped = false
            if self.last_state ~= self.states.flinch then 
          --      print("Attempt skip, because last state was idle")
                has_skipped = maybe_skip_after_flinch(self)
            end

            
--         print("I am done flinching")
        --   print("Anim done")
            self.flinching = false
            self.state_done = true
            self.first_flinch = true

        --    print("Done")
            self.state_done = false
            if self.last_state ~= self.states.idle and self.last_state ~= self.states.move then 
        --     print("Last state was not idle or move", self.last_state.name)
 
                increment_pattern(self)

            
            else--if not has_skipped then 
                -- If we were in idle or move, go back to it and try again
                    -- Unless we were in a sub pattern. Still end that.
            --   print("Last state was idle or move")

                if self.in_sub_pattern then 
                    end_sub_pattern(self)
                else
                    self.state = self.last_state
                    self.first_act = true
                end
            end

        end)

    end

    self.flinching = true
end

--[[
    Chance to skip idle or halve idle time, to call after flinching 
    This works by calling increment_pattern an extra time if and only if the last state was Idle
        Remember, last state is the state we will return to after flinching
        Some extra work will need to be done in the self.anim:on_complete of flinch if this is to work with sub patterns. This boss doesn't use them, so it was omitted
    
    Currently, the skip is implemented as setting idle time to 0
    
    A future choice for this function: after calling this function, self.state *may* increment, obsoleting our last state pointer. Returns true if this does happen
        There is a possible additional side effect that the idle time will instead be changed, in which case, last state is preserved and false is returned
]]

function maybe_skip_after_flinch(self)
    local chance_halve = self.chance_to_halve_idle_after_flinch
    local chance_skip = self.chance_to_skip_idle_after_flinch
    local max = chance_halve + chance_skip + (16 - chance_halve - chance_skip)

    local r = math.random(1, max)
    if r <= chance_halve then 
        self.idle_speed = math.floor(self.idle_speed / 2)
       -- print("We halved")
    elseif r <= (chance_skip + chance_halve) then 
       -- print("We skipped")
        self.idle_speed = 0
        return true
    end

    return false
end

function highlight_tiles(self, list, time)
    local spell = Battle.Spell.new(self:get_team())


    local ref = self
    spell.update_func = function(self)
        for i=1, #list
        do 
            local t = list[i]
            if t and not t:is_edge() then 
                t:highlight(Highlight.Solid)
            end

        end


        time = time - 1
        if time == 0 then 
            self:delete()
        end

        if self.flinching then 
            if spell and not spell:is_deleted() then 
                spell:delete()
    
            end
        end
    end


    self:get_field():spawn(spell, self:get_current_tile())

    return spell
end



function move(self)
    if self.first_act then 
        
        self.anim:set_state("MOVE", {
            {duration=1, state="IDLE_1"},
        })

        local tile = choose_move(self, self:get_field())
        self.anim:on_frame(1, function()
            if self.can_move_to_func(tile) then 
            else
                tile = self:get_current_tile()
            end

            self:teleport(tile, ActionOrder.Voluntary, function()
                if tile ~= self:get_current_tile() then 
                    create_move_effect(self)
                end
            end)
        end)

        self.anim:on_complete(function()
            -- Reset idle speed, since we did a real action
            self.idle_speed = self.base_idle_speed
            increment_pattern(self)
        
        end)

        self.first_act = false
    end
end

function create_move_effect(self)
    -- This might normally want to be an Artifact, but I'm not totally sure
    local spell = graphic_init("spell", 0, -38, MOVE_TEXTURE, MOVE_ANIMATION, -1, "2", self, self:get_facing(), true)

    self:get_field():spawn(spell, self:get_current_tile())
end

function choose_attack(self)
    local r = math.random(1, 3)
    if r == 1 then
        self.state = self.states.shoot
    elseif r == 2 then
        self.state = self.states.tower
    else
        if self.thunderball1_deleted and self.thunderball2_deleted then
            self.state = self.states.elecball
        else
            local r2 = math.random(1, 2)
            if r2 == 1 then
                self.state = self.states.shoot
            else
                self.state = self.states.tower
            end
        end
    end

    self.state.func(self)
    self.idle_speed = self.base_idle_speed * 2
end

function shoot(self)
    if self.first_act then 
        self.anim:set_state("SHOOT", {
            {duration=3, state="CHARGE_1"},
            {duration=3, state="CHARGE_2"},
            {duration=3, state="CHARGE_1"},
            {duration=3, state="CHARGE_2"},
            {duration=3, state="CHARGE_1"},
            {duration=8, state="SHOOT_1"},
            {duration=4, state="SHOOT_2"}, -- Offset a pixel back, shoot attack
            {duration=16, state="SHOOT_1"}, -- Reset offset
        })    

        self.anim:on_frame(7, function()
            Engine.play_audio(ELEC_SFX, AudioPriority.Low)
            shoot_attack(self)
        end)

        self.anim:on_complete(function()
            increment_pattern(self)
        
        end)

        self.first_act = false
    end
end

function shoot_attack(self)
    local facing = self:get_facing()
    local spell = graphic_init("spell", 0, -64, ATTACK_TEXTURE_1, ATTACK_ANIMATION, -1, "SHOT", self, facing)
    local prev_tile = nil

    local hit_props = HitProps.new(
        self.damage_jammingwave,
        Hit.Impact | Hit.Flinch | Hit.Flash,
        Element.Elec, 
        self:get_context(), 
        Drag.None
    )

    spell:set_hit_props(hit_props)
    spell.slide_started = false

    --local counter = 0
    local owner = self
    spell.update_func = function(self)
        local t = self:get_current_tile()
        t:attack_entities(self)
        --[[
        counter = counter + 1
        if counter % owner.shot_speed  == 0 then 
            local next_t = self:get_tile(facing, 1)
            if next_t ~= nil then 
                next_t:add_entity(self)
                t:remove_entity_by_id(self:get_id())
                prev_tile = t
                t = next_t
            else
                self:delete() 
            end
        end]]

        t:highlight(Highlight.Solid)
        --[[
        if prev_tile then 
            prev_tile:highlight(Highlight.Solid)
        end]]

        if self:is_sliding() == false then
            if self:get_current_tile():is_edge() and self.slide_started then 
                self:delete()
            end
            local dest = self:get_tile(facing, 1)
            self:slide(dest, frames(2), frames(0), ActionOrder.Voluntary, function()
                owner.slide_started = true 
            end)
        end
    end

    spell.attack_func = function(self, other)
        local o = get_random_offset()
        local hit_effect = graphic_init("artifact", o.x, o.y, EFFECT_TEXTURE, EFFECT_ANIMPATH, -3, "4", self, self:get_facing(), true)
        self:get_field():spawn(hit_effect, other:get_current_tile())

        --Engine.play_audio(HIT_SFX, AudioPriority.Low)
        --(K1rbYat1Na: The player shouldn't hear the hitsound.)
    end

    spell.collision_func = function(self)
        if not self:is_deleted() then 
            self:delete()
            self:hide()
        end
    end

    spell.can_move_to_func = function(tile)
        return true
    end

    self:get_field():spawn(spell, self:get_tile(facing, 1))
end

function tower(self)
    if self.first_act then 
        self.anim:set_state("TOWER", {
            {duration=3, state="CHARGE_1"},
            {duration=3, state="CHARGE_2"},
            {duration=3, state="CHARGE_1"},
            {duration=3, state="CHARGE_2"},
            {duration=3, state="CHARGE_1"},
            {duration=4, state="RAISE_1"},
            {duration=4, state="RAISE_1"}, -- Spawn tower
            {duration=4, state="RAISE_2"}, -- Offset a pixel back
            {duration=16, state="RAISE_1"}, -- Reset offset
        })    

        self.anim:on_frame(7, function()
            make_tower(self)
        end)

        self.anim:on_complete(function()
            increment_pattern(self)
        
        end)

        self.first_act = false
    end
end

function make_tower(self)
    local team = self:get_team()
    local field = self:get_field()
    local tile_list = self:get_field():find_tiles(function(t)
        -- Do not spawn if tile has enemy characters
        if check_characters(t, self) then return false end

        return self.tiles_with_tower[""..t:x()..t:y()] == nil and not t:is_edge() and t:is_walkable() and t:get_team() ~= team
    end)

    if #tile_list == 0 then 
        return 
    end

    local tile = tile_list[math.random(1, #tile_list)]
    self.tiles_with_tower[""..tile:x()..tile:y()] = true
    local spell = graphic_init("spell", 0, -8, ATTACK_TEXTURE_3, ATTACK_ANIMATION, -1, "TOWER", self, self:get_facing())
    spell.lifetime = self.tower_lifetime
    spell.attacking = false

    spell:set_elevation(8)

    local hit_props = HitProps.new(
        self.damage_jammingtower,
        Hit.Impact | Hit.Flinch | Hit.Flash,
        Element.Elec, 
        self:get_context(), 
        Drag.None
    )

    spell:set_hit_props(hit_props)
    
    local anim = spell:get_animation()
    anim:on_complete(function()
        spell:set_shadow(SHADOW_TEXTURE)
        spell:show_shadow(true)
        spell.attacking = true

        anim:set_state("TOWER_LOOP")
        anim:set_playback(Playback.Loop)
        anim:refresh(spell:sprite())
    end)

    spell.update_func = function(self)
        local t = self:get_current_tile()
        t:highlight(Highlight.Solid)
        if self.attacking then 
            t:attack_entities(self)
        end
        self.lifetime = self.lifetime - 1
        if self.lifetime <= 0 then 
            self:delete()
        end

    end

    spell.on_spawn_func = function(self)
        Engine.play_audio(SUMMON_SFX, AudioPriority.Low)
    end

    spell.attack_func = function(self, other)
        local o = get_random_offset()
        local hit_effect = graphic_init("artifact", o.x, o.y, EFFECT_TEXTURE, EFFECT_ANIMPATH, -3, "4", self, self:get_facing(), true)
        self:get_field():spawn(hit_effect, other:get_current_tile())

        --Engine.play_audio(HIT_SFX, AudioPriority.Low)
        --(K1rbYat1Na: The player shouldn't hear the hitsound.)
    end

    spell.collision_func = function(self, other)
        -- TODO: Has hit effect 3:19 (looks like break)
        self:delete()
        self:hide()
    end

    spell.battle_end_func = function(self)
		self:delete()
	end

    local owner = self
    spell.delete_func = function(self)
        -- Anonymous self to be less confusing
        Engine.play_audio(BOOM_AUDIO, AudioPriority.Low)
        local boom_effect = graphic_init("artifact", 0, -10, BOOM_TEXTURE, BOOM_ANIMPATH, -3, "2", self, self:get_facing(), true)
        self:get_field():spawn(boom_effect, self:get_current_tile())
        if not owner:is_deleted() then 
            -- Not self:get_current_tile(), just in case
            owner.tiles_with_tower[""..tile:x()..tile:y()] = nil
        end
    end

    self:get_field():spawn(spell, tile)
end

function elecball(self)
    if self.first_act then 
        self.anim:set_state("ELECBALL", {
            {duration=3, state="CHARGE_1"},
            {duration=3, state="CHARGE_2"},
            {duration=3, state="CHARGE_1"},
            {duration=3, state="CHARGE_2"},
            {duration=3, state="CHARGE_1"},
            {duration=4, state="RAISE_1"},
            {duration=4, state="RAISE_1"}, -- Spawn balls
            {duration=4, state="RAISE_2"}, -- Offset a pixel back
            {duration=16, state="RAISE_1"}, -- Reset offset
        })    

        self.anim:on_frame(7, function()
            Engine.play_audio(ELEC_SFX, AudioPriority.Low)
            local facing = self:get_facing()

            make_elecball(self, self:get_tile(facing, 1), 1)
            local possible_tiles = {}
            
            local dirs = {
                Direction.Up,
                Direction.Down,
                Direction.join(facing, Direction.Up),
                Direction.join(facing, Direction.Down),
            }

            for i=1, #dirs
            do
                local t = self:get_tile(dirs[i], 1)
                if t and not t:is_edge() then 
                    table.insert(possible_tiles, t)
                end
            end
            

            -- This shouldn't be false unless field width or height is 1
            if #possible_tiles > 0 then 
                make_elecball(self, possible_tiles[math.random(1, #possible_tiles)], 2)
            end
        end)

        self.anim:on_complete(function()
            increment_pattern(self)
        
        end)

        self.first_act = false
    end
end

function make_elecball(self, tile, number)
    if not tile or tile:is_edge() then return end

    local field = self:get_field()
    --local spell = graphic_init("spell", 0, -12, ATTACK_TEXTURE_2, ATTACK_ANIMATION_2, -1, "0", self, self:get_facing())
    local spell = graphic_init("spell", 0, (12*2)*-1, ATTACK_TEXTURE_2, ATTACK_ANIMATION_2, -1, "0", self, self:get_facing())
    spell:get_animation():set_playback(Playback.Loop)
    spell.moves = 7
    spell.target = nil
    spell.speed = self.elecball_speed
    spell.lifetime = spell.moves * spell.speed

    local hit_props = HitProps.new(
        self.damage_thunderball,
        Hit.Impact | Hit.Flinch | Hit.Stun,
        Element.Elec,
        self:get_context(),
        Drag.None
    )

    spell:set_hit_props(hit_props)


    local function find_enemy(spell)
        local team = spell:get_team()

        local list = spell:get_field():find_nearest_characters(spell, function(c)
            return c:get_team() ~= team
        end)

        spell.target = list[1]
    end

    spell.last_target_y = 1
    local function determine_next_tile(spell)
        local t = spell:get_current_tile()
        local target = spell.target:get_current_tile()
        local dest = nil

        local distance_check = target:x() - t:x()

        if distance_check < 0 then 
            targetX = -1
        elseif distance_check > 0 then 
            targetX = 1
        else 
            targetX = 0 
        end

        if targetX ~= 0 then 
            dest = field:tile_at((t:x() + targetX), t:y())
        else -- We're lined up horizontally
            distance_check = target:y() - t:y()
            if distance_check < 0 then 
                targetY = -1
            elseif distance_check > 0 then 
                targetY = 1
            else 
                targetY = spell.last_target_y
            end

            spell.last_target_y = targetY
            dest = field:tile_at(t:x(), t:y() + targetY)
        end

        return dest
    end

    spell.update_func = function(self)
        local target = self.target
        
        if not target or target:is_deleted() or not target:get_current_tile() then 
            find_enemy(self)
            target = self.target
        end

        local tile = self:get_current_tile()
        tile:attack_entities(self)
        tile:highlight(Highlight.Solid)

        if not target then return end

        if self:is_sliding() == false then
      --      if self.moves <= 0 then 
        --        self:delete()
          --  end
            if tile:is_edge() then 
                self:delete()
            end
            
            local dest = determine_next_tile(self)
            
            if dest then 
                self:slide(dest, frames(self.speed), frames(0), ActionOrder.Voluntary, function()
            --        self.moves = self.moves - 1
                end)
            end
        end

        self.lifetime = self.lifetime - 1
        if self.lifetime <= 0 then 
            self:delete()
        end
    end

    spell.can_move_to_func = function()
        return true
    end

    spell.attack_func = function(self, other)
        local o = get_random_offset()
        local hit_effect = graphic_init("artifact", o.x, o.y, EFFECT_TEXTURE, EFFECT_ANIMPATH, -3, "4", self, self:get_facing(), true)
        self:get_field():spawn(hit_effect, other:get_current_tile())

        --Engine.play_audio(HIT_SFX, AudioPriority.Low)
        --(K1rbYat1Na: The player shouldn't hear the hitsound.)
    end

    spell.battle_end_func = function(self)
		self:delete()
	end

    spell.collision_func = function(self)
        self:hide()
        self:delete()
    end

    local owner = self

    spell.on_spawn_func = function(self)
        if number == 1 then
            owner.thunderball1_deleted = false
        else
            owner.thunderball2_deleted = false
        end
    end

    spell.delete_func = function(self)
        if number == 1 then
            owner.thunderball1_deleted = true
        else
            owner.thunderball2_deleted = true
        end
    end

    field:spawn(spell, tile)
end


function choose_move(self, field)
    local team = self:get_team()

    local tiles = field:find_tiles(function(tile)
        return tile ~= self:get_current_tile() and self.can_move_to_func(tile)
    
    end)


    --print("Found ", #tiles, " possible tiles")

    if #tiles == 0 then 
        return self:get_current_tile()
    end

    return tiles[math.random(1, #tiles)]
end


function choose_enemy(self, field)
    local team = self:get_team()

    local target = field:find_characters(function(c)
        return c:get_team() ~= team
    end)

    if not target[1] then 
       -- print("No targets")
        return nil
    end

    t_x = target[1]:get_current_tile():x()
    t_y = target[1]:get_current_tile():y()

    local facing = -1
    if target[1]:get_facing() == Direction.Right then 
        facing = 1
    end

    local tile = field:tile_at(t_x+facing, t_y)

    return tile
end


function reconstruct_pattern(self)
    local pattern = {}
    local states = self.states
    local moves = self.move_count
    local r = math.random(1, 16)
   -- print(r)
    if r <= self.chance_to_move_twice then 
        moves = 2
      --  print("Two moves this time")
    end

    for i=1, moves
    do
        table.insert(pattern, states.idle)
        table.insert(pattern, states.move)
    end

    table.insert(pattern, states.idle)
    table.insert(pattern, states.choose_attack)


    self.pattern = pattern
end

function increment_pattern(self)
   -- print("Pattern increment")

    self.first_act = true
    self.state_done = false
    self.pattern_index = self.pattern_index + 1
    if self.pattern_index > #self.pattern then 
        reconstruct_pattern(self)
 --       print("Reconstructed pattern")
        self.pattern_index = 1
    end

    local next_state = self.pattern[self.pattern_index]
    self.state = next_state
  --  print("Moving to state named ", next_state.name)

    if next_state == self.states.start_sub_pattern then 
        self.in_sub_pattern = true
        increment_pattern(self)
    end

    if next_state == self.states.finish_sub_pattern then 
        self.in_sub_pattern = false
        increment_pattern(self)

    end

   -- print("Changing to "..self.pattern_index..", which is "..self.pattern[self.pattern_index].name)

end

function check_obstacles(tile, self)
    local ob = tile:find_obstacles(function(o)
        return o:get_health() > 0 
    end)

    return #ob > 0 
end


function check_characters(tile, self)
    local characters = tile:find_characters(function(c)
        return c:get_id() ~= self:get_id() and c:get_team() ~= self:get_team()
    end)

    return #characters > 0

end

function get_random_offset()
    local x = math.random(0, 40)
    local y = math.random(20, 40)
    
    x = x - 20
    y = y * -1

    return {x = x, y = y}
end

function graphic_init(type, x, y, texture, animation, layer, state, user, facing, delete_on_complete, flip)
    flip = flip or false
    delete_on_complete = delete_on_complete or false
    facing = facing or nil
    
    local graphic = nil
    if type == "artifact" then 
        graphic = Battle.Artifact.new()

    elseif type == "spell" then 
        graphic = Battle.Spell.new(user:get_team())
    
    elseif type == "obstacle" then 
        graphic = Battle.Obstacle.new(user:get_team())

    end

    graphic:sprite():set_layer(layer)
    graphic:never_flip(flip)
    graphic:set_texture(texture, true)
    if facing then 
        graphic:set_facing(facing)
    end
    
    if user:get_facing() == Direction.Left then 
        x = x * -1
    end
    graphic:set_offset(x, y)
    local anim = graphic:get_animation()
    anim:load(animation)

    anim:set_state(state)
    anim:refresh(graphic:sprite())

    if delete_on_complete then 
        anim:on_complete(function()
            graphic:delete()
        end)
    end

    return graphic
end