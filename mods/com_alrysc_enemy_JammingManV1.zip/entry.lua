local package_id = "com.alrysc.enemy.JammingManV1"
local character_id = "com.alrysc.enemy.JammingManEnemy"

function package_requires_scripts()
    Engine.define_character(character_id, _modpath.."enemy")
end

function package_init(package) 
    package:declare_package_id(package_id)
    package:set_name("JammingMan")
    package:set_description("I'm feeling some interference...")
    package:set_speed(1)
    package:set_attack(60)
    package:set_health(1000)
    package:set_preview_texture_path(_modpath.."preview.png")
end

function package_build(mob) 
    local texPath = _modpath.."exepon-mobileareanodennou.png"
    local animPath = _modpath.."exepon-mobileareanodennou.animation"
    --mob:set_background(texPath, animPath, 0.16667, 0.16667)
    mob:set_background(texPath, animPath, 0.0, 0.0)
    mob:stream_music(_modpath.."phantom_boss.ogg", 0, 38409)
   -- 612820,2037590 
    mob:create_spawner(character_id, Rank.V1):spawn_at(5, 2)
    local field = mob:get_field()
    field:tile_at(3, 1):set_state(TileState.Cracked)
    field:tile_at(3, 3):set_state(TileState.Cracked)
    field:tile_at(4, 1):set_state(TileState.Cracked)
    field:tile_at(4, 3):set_state(TileState.Cracked)

end