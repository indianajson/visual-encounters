local guard = include("guard/guard.lua")

guard.name = "IceWave"
guard.codes = {"I","M","R"}
guard.damage = 50
guard.duration = 0
guard.guard_animation = "GUARD1"
guard.description = "Ice Shockwave!"

local chip = {}
chip.card_create_action = guard.card_create_action
return chip
