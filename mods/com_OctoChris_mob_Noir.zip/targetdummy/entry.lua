local noop = function () end
local animation_path = _modpath.."BlueNavi.animation"
local CHARGING = Engine.load_audio(_modpath.."buster_charging.ogg")
local CHARGED = Engine.load_audio(_modpath.."buster_charged.ogg")
local CHARGE_TEXTURE = Engine.load_texture(_modpath.."spell_buster_charge.png")
local CHARGE_ANIMATION = _modpath.."spell_buster_charge.animation"
local SHINE = Engine.load_audio(_modpath.."shine.ogg")
local DEFORM = Engine.load_audio(_modpath.."deform.ogg")
local regen = false

-- entry.lua

local idle_update
local healtimer = 0

local counter = 0

function get_enemy_row(p)
	local field = p:get_field()
	local sht = function(v) return p:get_team() ~= v:get_team() end
	local targets = field:find_characters(sht)
	if #targets >= 1 then
		return targets[1]:get_tile():y()
	end
end

function get_enemy_column(p)
	local field = p:get_field()
	local sht = function(v) return p:get_team() ~= v:get_team() end
	local targets = field:find_characters(sht)
	if #targets >= 1 then
		return targets[1]:get_tile():x()
	end
end

-- Face the nearest living opposing character, not the team's default side.
-- Surrounded encounters can put the same team on either flank.
local function face_nearest_enemy(actor, reference_tile)
    local own_tile = reference_tile or actor:get_current_tile()
    if not own_tile then return nil end
    local targets = actor:get_field():find_nearest_characters(actor, function(other)
        return other:get_team() ~= actor:get_team() and other:get_health() > 0
    end)
    local target = targets[1]
    if not target then return nil end
    local target_tile = target:get_current_tile()
    if not target_tile then return nil end
    if target_tile:x() > own_tile:x() then
        actor:set_facing(Direction.Right)
    elseif target_tile:x() < own_tile:x() then
        actor:set_facing(Direction.Left)
    end
    return target_tile
end

local ChipsLoaded = {}
function load_chip(name)
	if ChipsLoaded[name] == nil then
		ChipsLoaded[name] = include("Chips/"..name.."/entry.lua")
	end
end

local chip_count = 0
function exec_chip(dummy,name)
	if ChipsLoaded[name] ~= nil then
		chip_count = chip_count + 1
		print("Executing attack: "..name)
            face_nearest_enemy(dummy)
		action = ChipsLoaded[name].card_create_action(dummy)
		dummy:card_action_event(action,ActionOrder.Voluntary)
		return true
	end
end

function move_based_on_chip_name(dummy, chip, on_begin)
    local target = face_nearest_enemy(dummy)
    if not target then return false end

    local field = dummy:get_field()
    local own_tile = dummy:get_current_tile()
    local facing = dummy:get_facing()
    local direction = facing == Direction.Right and 1 or -1
    -- Stay on our existing flank and aim *toward* the actual target.
    local candidates = field:find_tiles(function(tile)
        return not tile:is_edge() and tile:is_walkable()
            and tile:get_team() == dummy:get_team()
            and (target:x() - tile:x()) * direction > 0
    end)
    if #candidates == 0 then return false end

    local best, best_score
    for _, tile in ipairs(candidates) do
        local distance_to_enemy = math.abs(target:x() - tile:x())
        local preferred_distance = 1
        if chip == "Medicine" or chip == "PoisSeed" or chip == "LavaSeed"
            or chip == "IceSeed" or chip == "GrasSeed"
            or chip == "HarpNote" or chip == "Roll" or chip == "Bass" then
            preferred_distance = 2
        end
        local score = math.abs(distance_to_enemy - preferred_distance) * 10
            + math.abs(target:y() - tile:y()) * 5
            + math.abs(own_tile:x() - tile:x())
        if not best_score or score < best_score then
            best, best_score = tile, score
        end
    end
    if not best then return false end
    if best == own_tile then
        if on_begin then on_begin() end
        return true
    end
    return dummy:teleport(best, ActionOrder.Voluntary, function()
        face_nearest_enemy(dummy)
        if on_begin then on_begin() end
    end)
end

function move_at_random(dummy,f)
	print("Moving at random")
	local field = dummy:get_field()
	local tiles = field:find_tiles(function(tile) return tile:get_team() == dummy:get_team() and tile:is_walkable() and not tile:is_edge() end)
    if #tiles == 0 then return false end
	local selected_tile = tiles[math.random(1,#tiles)]
	if selected_tile then
        return dummy:teleport(selected_tile, ActionOrder.Voluntary, function()
            face_nearest_enemy(dummy)
            if f then f() end
        end)
	else
		return false
	end
end

function buster_spam_action(dark_rock)
    local spell = Battle.Spell.new(dark_rock:get_team())
    spell.slide_started = false
    spell:set_facing(dark_rock:get_facing())
    local damage = 5
    spell:set_hit_props(
        HitProps.new(
            damage,
            Hit.Impact,
            Element.None,
            dark_rock:get_context(),
            Drag.None
        )
    )
    spell.update_func = function(self, dt) 
        self:get_current_tile():attack_entities(self)
        if self:is_sliding() == false then
            if self:get_current_tile():is_edge() and self.slide_started then 
                self:delete()
            end 
			
            local dest = self:get_tile(spell:get_facing(), 1)
            if not dest or dest:is_edge() then
                self:erase()
                return
            end
            local ref = self
            self:slide(dest, frames(1), frames(0), ActionOrder.Voluntary, 
                function()
                    ref.slide_started = true 
                end
            )
        end
    end
    spell.collision_func = function(self, other)
		self:delete()
	end
    spell.attack_func = function(self, other) 
    end

    spell.delete_func = function(self)
		self:erase()
    end
    spell.can_move_to_func = function(tile)
        return true
    end
    Engine.play_audio(AudioType.BusterPea, AudioPriority.Low)
    return spell
end

function buster_charge_shot(dark_rock)
    local spell = Battle.Spell.new(dark_rock:get_team())
    spell.slide_started = false
    spell:set_facing(dark_rock:get_facing())
    local damage = 50
    spell:set_hit_props(
        HitProps.new(
            damage,
            Hit.Impact,
            Element.None,
            dark_rock:get_context(),
            Drag.None
        )
    )
    spell.update_func = function(self, dt) 
        self:get_current_tile():attack_entities(self)
        if self:is_sliding() == false then
            if self:get_current_tile():is_edge() and self.slide_started then 
                self:delete()
            end 
			
            local dest = self:get_tile(spell:get_facing(), 1)
            if not dest or dest:is_edge() then
                self:erase()
                return
            end
            local ref = self
            self:slide(dest, frames(1), frames(0), ActionOrder.Voluntary, 
                function()
                    ref.slide_started = true 
                end
            )
        end
    end
    spell.collision_func = function(self, other)
		self:delete()
	end
    spell.attack_func = function(self, other) 
    end

    spell.delete_func = function(self)
		self:erase()
    end
    spell.can_move_to_func = function(tile)
        return true
    end
    Engine.play_audio(AudioType.BusterPea, AudioPriority.Low)
    return spell
end

local Noir = {}
Noir.Form = {}
Noir.Form.Base = 0
Noir.Form.Heat = 1
Noir.Form.Ice = 2
Noir.Form.Elec = 3
Noir.Form.Wood = 4
Noir.Form.Wind = 5
Noir.Used = {}
Noir.Used.HeatForm = false
Noir.Used.IceForm = false
Noir.Used.ElecForm = false
Noir.Used.WoodForm = false
Noir.Used.WindForm = false
Noir.Texture = {}
Noir.Texture.BaseForm = Engine.load_texture(_modpath.."BlueNavi.png")
Noir.Texture.HeatForm = Engine.load_texture(_modpath.."forms/Heat/BlueNavi.png")
Noir.Texture.IceForm = Engine.load_texture(_modpath.."forms/Ice/BlueNavi.png")
Noir.Texture.ElecForm = Engine.load_texture(_modpath.."forms/Elec/BlueNavi.png")
Noir.Texture.WoodForm = Engine.load_texture(_modpath.."forms/Wood/BlueNavi.png")
Noir.Texture.WindForm = Engine.load_texture(_modpath.."forms/Wind/BlueNavi.png")
Noir.Element = {}
Noir.Element.BaseForm = Element.None
Noir.Element.HeatForm = Element.Fire
Noir.Element.IceForm = Element.Aqua
Noir.Element.ElecForm = Element.Elec
Noir.Element.WoodForm = Element.Wood
Noir.Element.WindForm = Element.Wind
Noir.Buster = {}
Noir.Buster[Noir.Form.Heat] = include("Busters/HeatBuster/entry.lua")
Noir.Buster[Noir.Form.Ice] = include("Busters/IceBuster/entry.lua")
Noir.Buster[Noir.Form.Elec] = include("Busters/ElecBuster/entry.lua")
Noir.Buster[Noir.Form.Wood] = include("Busters/WoodBuster/entry.lua")
Noir.Buster[Noir.Form.Wind] = include("Busters/WindBuster/entry.lua")

function get_element_weakness(dummy)
	local element = dummy:get_element()
	if element == Element.Wood then
		return Element.Fire
	end
	if element == Element.Fire then
		return Element.Aqua
	end
	if element == Element.Aqua then
		return Element.Elec
	end
	if element == Element.Elec then
		return Element.Wood
	end
	if element == Element.Wind then
		return Element.Sword
	end
	if element == Element.Sword then
		return Element.Break
	end
	if element == Element.Cursor then
		return Element.Wind
	end
end

function change_forms(dummy,form)
	if form == nil then return true end
	if dummy.current_form ~= Noir.Form.Base then return true end
	local form_Texture
	props = Battle.CardProperties.new()
    props.time_freeze = true
	props.skip_time_freeze_intro = true
	if form == Noir.Form.Heat then
	  props.shortname = "HeatForm"
	end
	if form == Noir.Form.Ice then
	  props.shortname = "IceForm"
	end
	if form == Noir.Form.Elec then
	  props.shortname = "ElecForm"
	end
	if form == Noir.Form.Wood then
	  props.shortname = "WoodForm"
	end
	if form == Noir.Form.Wind then
	  props.shortname = "WindForm"
	end
	if Noir.Texture[props.shortname] == nil then return true end
	if Noir.Used[props.shortname] then return true end
    local action = Battle.CardAction.new(dummy, "PLAYER_IDLE")
	action:set_metadata(props)
    action:set_lockout(make_sequence_lockout())
	action.execute_func = function(self,_)
		local step = Battle.Step.new()
		local t = 0
		step.update_func = function(__,dt)
			if form == Noir.Form.Ice then
				local antifreeze = Battle.DefenseRule.new(99999999, DefenseOrder.CollisionOnly)
				antifreeze.filter_statuses_func = function(statuses)
					statuses.flags = statuses.flags & ~Hit.Freeze
					statuses.flags = statuses.flags & ~Hit.Bubble
					return statuses
				end
				dummy:add_defense_rule(antifreeze)
			end
			if form == Noir.Form.Elec then
				local antistun = Battle.DefenseRule.new(99999999, DefenseOrder.CollisionOnly)
				antistun.filter_statuses_func = function(statuses)
					statuses.flags = statuses.flags & ~Hit.Stun
					return statuses
				end
				dummy:add_defense_rule(antistun)
			end
			if form == Noir.Form.Wood then
				local antiroot = Battle.DefenseRule.new(99999999, DefenseOrder.CollisionOnly)
				antiroot.filter_statuses_func = function(statuses)
					statuses.flags = statuses.flags & ~Hit.Root
					return statuses
				end
				dummy:add_defense_rule(antiroot)
			end
			if form == Noir.Form.Wind then
				local antidrag = Battle.DefenseRule.new(99999999, DefenseOrder.CollisionOnly)
				antidrag.filter_statuses_func = function(statuses)
					statuses.flags = statuses.flags & ~Hit.Drag
					return statuses
				end
				dummy:add_defense_rule(antidrag)
			end
			Engine.play_audio(SHINE,AudioPriority.High)
			dummy.current_form = form
			Noir.Used[props.shortname] = true
			dummy:set_texture(Noir.Texture[props.shortname])
			dummy:set_element(Noir.Element[props.shortname])
			step:complete_step()
		end
		self:add_step(step)
	end
	dummy:card_action_event(action, ActionOrder.Voluntary)
	return true
end

idle_update = function(dummy, dt)
  if not dummy:is_teleporting() then
    face_nearest_enemy(dummy)
  end
  if counter >= 1 then counter = 0 end
  counter = counter + dt
  if dummy:is_deleted() then return end
  dummy.cust_screen_time = dummy.cust_screen_time - dt
  if dummy.cust_screen_time <= 0 then
	dummy.goal_teles = math.random(1,3)
	dummy.teles_left = dummy.goal_teles
    dummy.cust_screen_time = 11
    change_forms(dummy,math.random(0,5)) 
	if #dummy.chip_queue == 0 then
	  while #dummy.chip_selection < 8 do
	    if #dummy.chip_folder == 0 then break end
	    table.insert(dummy.chip_selection,table.remove(dummy.chip_folder,math.random(1,#dummy.chip_folder)))
	  end
	  local chipcount = math.random(1,3)
      for x = 1,chipcount do
	    if #dummy.chip_queue >= 5 or #dummy.chip_selection == 0 then break end
	    table.insert(dummy.chip_queue,table.remove(dummy.chip_selection,math.random(1,#dummy.chip_selection)))
	  end
	end
  end
  dummy.move_time = dummy.move_time - dt
  if dummy.should_move and dummy.move_time <= 0 and not dummy:is_teleporting() then
	if not move_at_random(dummy) then return end
    dummy.move_time = dummy.MAX_MOVE_TIME_DFLT
	dummy.teles_left = dummy.teles_left - 1
	if dummy.teles_left <= 0 then
	  dummy.goal_teles = math.random(1,3)
	  dummy.teles_left = dummy.goal_teles
	  dummy.should_atck = true
	  dummy.should_move = false
	end
	return
  end
  if dummy.should_atck and dummy.move_time <= 0 and not dummy:is_teleporting() then
	if #dummy.chip_queue >= 1 and math.random(0,#dummy.chip_queue) == 0 then
	  if not move_based_on_chip_name(dummy,dummy.chip_queue[1]) then return end
      dummy.move_time = dummy.MAX_MOVE_TIME_DFLT
      dummy.should_atck = false
	  dummy.attck_ready = true
	  return
	else
	  if not move_based_on_chip_name(dummy,"Buster") then return end
      dummy.move_time = dummy.MAX_MOVE_TIME_ATCK
	  if not dummy.buster(dummy,math.random(1,6) >= 5) then return end
	  dummy.should_atck = false
	  dummy.should_move = true
	  return
	end
  end
  if dummy.attck_ready and dummy.move_time <= 0 and #dummy.chip_queue >= 1 and not dummy:is_teleporting() then
	if not exec_chip(dummy,dummy.chip_queue[1]) then return end
	table.remove(dummy.chip_queue,1)
    dummy.move_time = dummy.MAX_MOVE_TIME_ATCK
    dummy.attck_ready = false
	dummy.should_move = true
	return
  end
end

function undershirt(player)
    local hit = false;
    local undershirt = Battle.DefenseRule.new(61044,DefenseOrder.CollisionOnly)
    local damage
    local component = Battle.Component.new(player, Lifetimes.Scene)
    local prevHP = player:get_health()


    undershirt.can_block_func = function(judge, attacker, defender)
        damage = attacker:copy_hit_props().damage
		
        if prevHP > 1 and (player:get_health() - damage) <= 0 and damage > 0 then 
            player:set_health(1)
            hit = true
        end
    end
	undershirt.filter_statuses_func = function(hit_props)
		prevHP = player:get_health()
		hit = false
		return hit_props
	end
	
    player:add_defense_rule(undershirt)
end

local CHIPFLDR = {"LghtsOut", "Invisibl", "TableFlp", "TableFlp", "TableFlp", "TableFlp", "Recov50", "Recov50", "Recov100", "Recov100", "Recov100", "PoisSeed", "LavaSeed", "IceSeed", "GrasSeed", "GrabJel1", "GrabJel1", "GrabJel1", "GrabJel1", "WindRack", "WindRack", "HarpNote", "JudgeMan", "HeatMan", "Medicine", "Roll", "Bass"}

function package_init(dummy, ezencounters_data)
    -- EZENCOUNTERS MAX-HP SUPPORT v11 --
    do
        local payload = ezencounters_data
        if type(payload) == "table" then
            local ids = {"com.OctoChris.enemy.Noir"}
            local aliases = {["Noir"]=true}
            local requested = nil
            local conflict = false
            local maxima = payload.__ezencounters_hp_max_by_package
            if type(maxima) == "table" then
                for _, id in ipairs(ids) do
                    local value = tonumber(maxima[id])
                    if value ~= nil and value > 0 and value == value and value ~= math.huge then
                        if requested ~= nil and requested ~= value then conflict = true end
                        requested = value
                    end
                end
            end
            -- Some engine builds pass an independent copy of encounter data
            -- to the Character package. Resolve from original enemy entries
            -- as well, rather than depending on a mutation in package_build.
            if requested == nil and type(payload.enemies) == "table" then
                for _, enemy in ipairs(payload.enemies) do
                    if type(enemy) == "table" and aliases[enemy.name] then
                        local value = tonumber(enemy.max_hp)
                        if value == nil and #payload.enemies == 1 then
                            value = tonumber(payload.max_hp)
                        end
                        if value ~= nil and value > 0 and value == value and value ~= math.huge then
                            if requested ~= nil and requested ~= value then conflict = true end
                            requested = value
                        end
                    end
                end
            end
            if not conflict and requested ~= nil and requested == math.floor(requested) then
                print("[ezencounters hp] INITIAL MAX HP", ids[1], requested)
                dummy:set_health(requested)
            end
        end
    end

  -- private variables

  dummy._idle_state = "PLAYER_IDLE"
  
  -- Boss-related variables
  
  dummy.chip_folder = CHIPFLDR
  for _,chip in pairs(dummy.chip_folder) do
    load_chip(chip)
  end
  dummy.chip_selection = {}
  dummy.chip_queue = {}
  dummy.MAX_MOVE_TIME_DFLT = 0.3
  dummy.MAX_MOVE_TIME_ATCK = 0.3
  dummy.move_time = 1
  dummy.teles_left = 2
  dummy.goal_teles = 2
  dummy.should_move = true
  dummy.should_atck = false
  dummy.attck_ready = false
  dummy.cust_screen_time = 11
  local frame1 = {1, 0.05}
  local frame2 = {2, 0.05}
  local frame3 = {3, 0.05}
  local frame4 = {1, 0.05}
  local frame5 = {2, 0.05}
  local frame6 = {3, 0.05}
  local frame7 = {1, 0.05}
  local frame8 = {2, 0.05}
  local frame9 = {3, 0.05}
  local frame10 = {4, 0.1}
  local frame11 = {1, 0.1}
  local frame_sequence = make_frame_data({frame1, frame2, frame3, frame4, frame5, frame6, frame7, frame8, frame9, frame10})
  local charged_frame_sequence = make_frame_data({frame7, frame8, frame9, frame10})
  local charging_frame_sequence = make_frame_data({frame11,frame11,frame11,frame11,frame11,frame11,frame11,frame11,frame11,frame11,frame11,frame11,frame11,frame11,frame11,frame11,frame11,frame11,frame11,frame11})
  dummy.current_form = Noir.Form.Base
  dummy.buster = function(self,charge)
    if not face_nearest_enemy(self) then return false end
	if charge then
		dummy.move_time = dummy.move_time + 3 + dummy.MAX_MOVE_TIME_DFLT
		local charge_artifact = Battle.Artifact.new()
		charge_artifact.delete_func = function()
			charge_artifact:erase()
		end
		local timer = 0
		local move_timer = 0
		charge_artifact:set_height(48)
		charge_artifact:set_offset(4, -32)
		charge_artifact:show_shadow(false)
		charge_artifact:set_texture(CHARGE_TEXTURE)
		charge_artifact:set_animation(CHARGE_ANIMATION)
		charge_artifact:get_animation():set_state("CHARGING")
		charge_artifact:get_animation():refresh(charge_artifact:sprite())
		charge_artifact:get_animation():set_playback(Playback.Loop)
		charge_artifact:sprite():set_color_mode(ColorMode.Additive)
		charge_artifact:sprite():set_color(Color.new(0, 0, 0, 0))
		local field = self:get_field()
		local tile
		local tile_y
		local distance_target
		tile = self:get_tile()
		tile_y = tile:y()
		distance_target = 1
		if dummy.current_form == Noir.Form.Heat then
			distance_target = tile:x() - 3
		end
		Engine.play_audio(CHARGING,AudioPriority.High)
		field:spawn(charge_artifact,tile)
		charge_artifact.can_move_to_func = function( actor, next_tile )
			return true
		end
		charge_artifact:set_float_shoe(true)
		charge_artifact:set_air_shoe(true)
		charge_artifact.update_func = function(_,dt)
			charge_artifact:teleport(self:get_tile(),ActionOrder.Voluntary)
			move_timer = move_timer + dt
			timer = timer + dt
			if move_timer > dummy.MAX_MOVE_TIME_DFLT and timer <= (3 - dummy.MAX_MOVE_TIME_ATCK) then
				move_timer = 0
				move_at_random(self)
			end
			if timer > 3 then
				for tile_x = 1,6 do
					for tile_y = 1,3 do
						field:tile_at(tile_x,tile_y):highlight(Highlight.None)
					end
				end
				if self.current_form == Noir.Form.Base then
					local action = Battle.CardAction.new(self, "PLAYER_SHOOTING")
					action:override_animation_frames(charged_frame_sequence)
					action:set_lockout(make_animation_lockout())
					action.execute_func = function(act, user)
						local buster = act:add_attachment("BUSTER")
						local sprite = buster:sprite()
						sprite:set_texture(self:get_texture())
						sprite:enable_parent_shader(true)
						sprite:set_layer(-1)
						local buster_anim = buster:get_animation()
						buster_anim:copy_from(self:get_animation())
						buster_anim:set_state("BUSTER")
						buster_anim:refresh(sprite)
						act:add_anim_action(1, function()
							local flare = buster:add_attachment("endpoint")
							local flare_sprite = flare:sprite()
							flare_sprite:set_texture(Engine.load_texture(_modpath.."pew.png", true))
							flare_sprite:set_layer(-1)

							local flare_anim = flare:get_animation()
							flare_anim:load(_modpath.."pew.animation")
							flare_anim:set_state("0")
							flare_anim:refresh(flare_sprite)
							flare_anim:on_complete(function()
								flare_sprite:hide()
							end)
							local spell = buster_charge_shot(self)
							local shot_tile = self:get_tile(self:get_facing(), 1)
                                if shot_tile and not shot_tile:is_edge() then
                                    self:get_field():spawn(spell, shot_tile)
                                else
                                    spell:erase()
                                end
						end)
					end
					self:card_action_event(action, ActionOrder.Voluntary)
				else
					local action = Noir.Buster[self.current_form].card_create_action(self)
					self:card_action_event(action, ActionOrder.Voluntary)
				end
				charge_artifact:erase()
			elseif timer > 2.25 then
				tile = self:get_tile()
				tile_y = tile:y()
				distance_target = 1
				if dummy.current_form == Noir.Form.Heat then
					distance_target = tile:x() - 3
				end
                local max_distance = self.current_form == Noir.Form.Heat and 3 or 6
                for distance = 1, max_distance do
                    local warning_tile = tile:get_tile(self:get_facing(), distance)
                    if not warning_tile or warning_tile:is_edge() then break end
                    warning_tile:highlight(Highlight.Flash)
                end
				if charge_artifact:get_animation():get_state() == "CHARGING" then
					move_based_on_chip_name(self,"Buster",function()
						charge_artifact:teleport(self:get_tile(),ActionOrder.Voluntary)
					end)
					Engine.play_audio(CHARGED,AudioPriority.High)
					if dummy.current_form == Noir.Form.Heat then
						charge_artifact:set_color(Color.new(255, 127, 0, 0))
					elseif dummy.current_form == Noir.Form.Ice then
						charge_artifact:set_color(Color.new(0, 255, 255, 0))
					elseif dummy.current_form == Noir.Form.Elec then
						charge_artifact:set_color(Color.new(255, 255, 0, 0))
					elseif dummy.current_form == Noir.Form.Wood then
						charge_artifact:set_color(Color.new(0, 255, 0, 0))
					elseif dummy.current_form == Noir.Form.Wind then
						charge_artifact:set_color(Color.new(191, 191, 191, 0))
					end
					charge_artifact:get_animation():set_state("CHARGED")
					charge_artifact:get_animation():refresh(charge_artifact:sprite())
					charge_artifact:get_animation():set_playback(Playback.Loop)
				end
			end
		end
		return true
	else
		local action = Battle.CardAction.new(self, "PLAYER_SHOOTING")
		action:override_animation_frames(frame_sequence)
		action:set_lockout(make_animation_lockout())
		action.execute_func = function(act, user)
			local buster = act:add_attachment("BUSTER")
			local sprite = buster:sprite()
			sprite:set_texture(self:get_texture())
			sprite:enable_parent_shader(true)
			sprite:set_layer(-1)

			local buster_anim = buster:get_animation()
			buster_anim:copy_from(self:get_animation())
			buster_anim:set_state("BUSTER")
			buster_anim:refresh(sprite)
			act:add_anim_action(1, function()
				local flare = buster:add_attachment("endpoint")
				local flare_sprite = flare:sprite()
				flare_sprite:set_texture(Engine.load_texture(_modpath.."pew.png", true))
				flare_sprite:set_layer(-1)

				local flare_anim = flare:get_animation()
				flare_anim:load(_modpath.."pew.animation")
				flare_anim:set_state("0")
				flare_anim:refresh(flare_sprite)
				flare_anim:on_complete(function()
					flare_sprite:hide()
				end)
				local spell = buster_spam_action(self)
				local shot_tile = self:get_tile(self:get_facing(), 1)
                                if shot_tile and not shot_tile:is_edge() then
                                    self:get_field():spawn(spell, shot_tile)
                                else
                                    spell:erase()
                                end
			end)
			act:add_anim_action(4, function()
				local flare = buster:add_attachment("endpoint")
				local flare_sprite = flare:sprite()
				flare_sprite:set_texture(Engine.load_texture(_modpath.."pew.png", true))
				flare_sprite:set_layer(-1)

				local flare_anim = flare:get_animation()
				flare_anim:load(_modpath.."pew.animation")
				flare_anim:set_state("0")
				flare_anim:refresh(flare_sprite)
				flare_anim:on_complete(function()
					flare_sprite:hide()
				end)
				local spell = buster_spam_action(self)
				local shot_tile = self:get_tile(self:get_facing(), 1)
                                if shot_tile and not shot_tile:is_edge() then
                                    self:get_field():spawn(spell, shot_tile)
                                else
                                    spell:erase()
                                end
			end)
			act:add_anim_action(7, function()
				local flare = buster:add_attachment("endpoint")
				local flare_sprite = flare:sprite()
				flare_sprite:set_texture(Engine.load_texture(_modpath.."pew.png", true))
				flare_sprite:set_layer(-1)

				local flare_anim = flare:get_animation()
				flare_anim:load(_modpath.."pew.animation")
				flare_anim:set_state("0")
				flare_anim:refresh(flare_sprite)
				flare_anim:on_complete(function()
					flare_sprite:hide()
				end)
				local spell = buster_spam_action(self)
				local shot_tile = self:get_tile(self:get_facing(), 1)
                                if shot_tile and not shot_tile:is_edge() then
                                    self:get_field():spawn(spell, shot_tile)
                                else
                                    spell:erase()
                                end
			end)
		end
		self:card_action_event(action, ActionOrder.Voluntary)
		return true
	end
  end

  -- meta
  dummy:set_name("Noir")
  dummy:set_height(48.0)
  dummy.__ezhp_native_max_hp = (1500)

  dummy:set_texture(Noir.Texture.BaseForm)
  dummy:set_element(Noir.Element.BaseForm)

  local anim = dummy:get_animation()
  anim:load(animation_path)
  anim:set_state(dummy._idle_state)
  --anim:set_playback(Playback.Once)

  -- setup defense rules
  dummy.defense = Battle.DefenseRule.new(math.random(90000000,99999998), DefenseOrder.CollisionOnly)
  dummy.defense.filter_statuses_func = function(status)
	if dummy.current_form ~= Noir.Form.Base and status.element == get_element_weakness(dummy) then
	  local def = Battle.DefenseRule.new(99999999, DefenseOrder.CollisionOnly)
	  dummy:add_defense_rule(def)
	  dummy:remove_defense_rule(def)
	  status.damage = status.damage * 2
	  Engine.play_audio(DEFORM,AudioPriority.High)
	  dummy.current_form = Noir.Form.Base
	  dummy:set_texture(Noir.Texture.BaseForm)
	  dummy:set_element(Noir.Element.BaseForm)
	end
	return status
  end
  dummy:add_defense_rule(dummy.defense)
  dummy:set_float_shoe(true)
  undershirt(dummy)

  -- setup event handlers
  dummy.update_func = idle_update
  dummy.battle_start_func = function(dummy)
    change_forms(dummy,math.random(0,5))
	if #dummy.chip_queue == 0 then
	  while #dummy.chip_selection < 8 do
	    if #dummy.chip_folder == 0 then 
		  dummy.chip_folder = CHIPFLDR
		  break 
		end
	    table.insert(dummy.chip_selection,table.remove(dummy.chip_folder,math.random(1,#dummy.chip_folder)))
	  end
	  local chipcount = math.random(2,5)
      for x = 1,chipcount do
	    if #dummy.chip_queue >= 5 or #dummy.chip_selection == 0 then break end
	    table.insert(dummy.chip_queue,table.remove(dummy.chip_selection,math.random(1,#dummy.chip_selection)))
	  end
	end
  end
  dummy.battle_end_func = noop
  dummy.on_spawn_func = function()
        counter = math.random()
        face_nearest_enemy(dummy)
  end
end

-- EZEncounters deferred native HP adapter.
-- The native fallback must not lock max HP in on_spawn_func: some client
-- spawners run on_spawn before their encounter mutate callback.
-- Battle start occurs after encounter mutations and before the first update.
local __ezhp_original_package_init = package_init
package_init = function(character, ...)
    __ezhp_original_package_init(character, ...)
    local __ezhp_original_battle_start = character.battle_start_func
    character.battle_start_func = function(self, ...)
        if self:get_max_health() == 0 then
            local native = tonumber(self.__ezhp_native_max_hp)
            if not native or native ~= native or native <= 0 or native == math.huge then native = 1 end
            native = math.max(1, math.floor(native))
            self:set_health(native)
            print('[EZHP][CLIENT][NATIVE_FALLBACK_BATTLE_START]', tostring(self:get_name()), native,
                'actual', self:get_max_health())
        end
        if __ezhp_original_battle_start then return __ezhp_original_battle_start(self, ...) end
    end
end
