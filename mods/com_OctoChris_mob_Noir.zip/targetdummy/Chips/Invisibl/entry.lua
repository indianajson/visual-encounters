

function package_init(package) 
    package:declare_package_id("com.Dawn.card.Invisible")
    package:set_icon_texture(Engine.load_texture(_folderpath.."icon.png"))
    package:set_preview_texture(Engine.load_texture(_folderpath.."preview.png"))
	package:set_codes({'*'})

    local props = package:get_card_props()
    props.shortname = "Invisibl"
    props.damage = 0
    props.time_freeze = true
    props.element = Element.None
    props.description = "Invisible for a while"
	props.card_class = CardClass.Standard
	props.limit = 3
	props.long_description = "Become hard to see and hard to hit!"
	props.can_boost = false
end

local chip = {}
function chip.card_create_action(player)
	props = Battle.CardProperties.new()
    props.shortname = "Invisibl"
    props.damage = 0
    props.time_freeze = true
    local action = Battle.CardAction.new(player, "PLAYER_IDLE")
	action:set_metadata(props)
    action.execute_func = function(self, user)
        local ReverentFlicker = Battle.Component.new(player, Lifetimes.Battlestep)
        ReverentFlicker.flicker_cooldown = 3
        ReverentFlicker.alpha_channel_table = {Color.new(0, 0, 0, 0), Color.new(0, 0, 0, 150), Color.new(0, 0, 0, 255)}
        ReverentFlicker.alpha_index = 1
        ReverentFlicker.end_of_invis = 360
        local ReverentDefense = Battle.DefenseRule.new(20000,DefenseOrder.CollisionOnly)
        ReverentDefense.can_block_func = function(judge, attacker, defender)
            local attacker_props = attacker:copy_hit_props()
            if attacker_props.flags & Hit.Pierce ~= Hit.Pierce then
                judge:block_damage()
            end
            if attacker_props.flags & Hit.Retangible == Hit.Retangible then
                defender:remove_defense_rule(ReverentDefense)
                ReverentFlicker:eject()
            end
        end
        ReverentFlicker.owner = user
        ReverentFlicker.update_func = function(self, dt)
            if self.owner:is_deleted() then return end
            if self.end_of_invis <= 0 then
                self.owner:remove_defense_rule(ReverentDefense)
                self:eject()
            else
                self.end_of_invis = self.end_of_invis - 1
            end
            if self.flicker_cooldown <= 0 then
                self.alpha_index = self.alpha_index + 1
                if self.alpha_index > #self.alpha_channel_table then self.alpha_index = 1 end
                self.owner:set_color(self.alpha_channel_table[self.alpha_index])
                self.flicker_cooldown = 3
            else
                self.flicker_cooldown = self.flicker_cooldown - 1
            end
        end
        player:register_component(ReverentFlicker)
        player:add_defense_rule(ReverentDefense)
        Engine.play_audio(AudioType.Invisible, AudioPriority.High)
    end
    return action
end
return chip