---@class FieldHelper
local library = {}



---Returns true if the user is at a disadvantage
---@param user Entity
---@return boolean
library.is_userarea_disadvantaged = function(user)
    local facing = user:get_facing()
    local field = user:get_field()
    if facing == Direction.Right then
        check_row = 2
    else
        check_row = 4
    end
    for y = 1, 3, 1 do
        for x = check_row, check_row + 1, 1 do
            if (field:tile_at(x, y):get_team() ~= user:get_team()) then
                return true
            end
        end
    end
    return false
end

--- Returns if the tile is occupied by a obstacle or player in the opposite team
---@param tile Tile Tile to check_row

library.tile_occupied_by_enemy = function(tile, character)
    local query = function(char) return char:get_team() ~= character:get_team() end
    return #tile:find_characters(query) > 0 or #tile:find_obstacles(query) > 0
end

---Returns stolen tiles, based on 3x3 pvp area.
---@param user Entity
---@return {}
library.get_stolen_tiles = function(user)


    local facing = user:get_facing()
    local field = user:get_field()
    local tile_arr = {}
    if facing == Direction.Right then
        check_row = 2
    else
        check_row = 4
    end
    for y = 1, 3, 1 do
        for x = check_row, check_row + 1, 1 do
            local checked_tile = field:tile_at(x, y)
            if (checked_tile:get_team() ~= user:get_team()) then
                table.insert(tile_arr, checked_tile)
            end
        end
    end
    return tile_arr
end

---Returns columns that can be reclaimed.
---In the case of column 3 being occupied, 2 will also be disqualified to prevent
--- islands..
---@param user Entity
---@return {}
library.get_reclaimable_columns = function(user)
    local facing = user:get_facing()
    local field = user:get_field()
    local column_arr = {}
    local step = 1
    if facing == Direction.Right then
        check_row = 2
    else
        check_row = 5
        step = -1
    end
    for x = check_row, check_row + step, step do
        local book_spawned_in_row = false
        for y = 1, 3, 1 do
            local checked_tile = field:tile_at(x, y)
            if (library.tile_occupied_by_enemy(checked_tile, user)) then
                return column_arr
            end
            if (checked_tile:is_walkable()) then
                book_spawned_in_row = true
            end
        end
        if (book_spawned_in_row) then
            table.insert(column_arr, x)
        else
            return column_arr
        end
    end
    return column_arr
end

--- Find the target in the row, or returns nil if not found.
---@param number y_pos
library.find_target_in_row = function(y_pos, field, team)
    local target_list = field:find_characters(function(other_character)
        return other_character:get_team() ~= team and other_character:get_tile():y() == y_pos and
            other_character:get_health() > 0
    end)
    if #target_list == 0 then
        return nil
    end
    local target_character = target_list[1]
    return target_character
end

--- Find the target in the field or nil if not found
---@param user Entity
library.find_target_in_field = function(user)
    local field = user:get_field()
    local team = user:get_team()
    local target_list = field:find_characters(function(other_character)
        return other_character:get_team() ~= team and other_character:get_health() > 0
    end)
    if #target_list == 0 then
        return nil
    end
    local target_character = target_list[1]
    return target_character
end

--- Find the Y direction which user should move to in order to align with
--- target
library.get_direction_towards_target = function(user)
    local target = library.find_target_in_field(user)
    local userTile = user:get_tile()
    local targetTile = target:get_tile()

    if (userTile:y() > targetTile:y()) then
        return Direction.Up
    elseif (userTile:y() < targetTile:y()) then
        return Direction.Down
    else
        return Direction.None
    end
end

function tiletostring(tile)
    return "Tile: [" .. tostring(tile:x()) .. "," .. tostring(tile:y()) .. "]"
end

return library
