--- Custom Chip: Lights Out (based on tornado toss)

--- Setup Textures, Animations and Sounds
--- modpath refers to the root folder of the chip.
WIND_SFX = Engine.load_audio(_folderpath .. "lightsout.ogg")
HIT_TEXTURE = Engine.load_texture(_folderpath .. "effect.png")
HIT_ANIM_PATH = _folderpath .. "effect.animation"
HIT_SOUND = Engine.load_audio(_folderpath .. "hitsound.ogg")

--Damage property.
DAMAGE = 10

function package_init(package)
    local props = package:get_card_props()
    --standard properties
    -- DisplayName of the chip
    props.shortname = "LghtsOut"
    -- Damage displayed on the chip
    props.damage = DAMAGE
    -- Whether or not this chip uses time freeze.
    props.time_freeze = true
	-- Whether or not other chips can modify this chip.
    props.can_boost = true
    -- Element displayed on this chip.
    props.element = Element.Elec
    -- Description of this chip in the folder.
    props.description = "Atk with Elec/Stun!"
    -- Description of this chip when special button is presssed.
    props.long_description = "Attack with Elec and Stun!"
    -- Package ID. Usually uses some form of the author's name + chip name.
    package:declare_package_id("com.OctoChris.card.LightsOut")
    -- Sets small preview icon.
    package:set_icon_texture(Engine.load_texture(_folderpath .. "icon.png"))
    -- Sets large preview graphic.
    package:set_preview_texture(Engine.load_texture(_folderpath .. "preview.png"))
	-- Sets the limit of this chip per folder.
	props.limit = 1
    -- List of codes this chip will be available as.
    package:set_codes({ "L", "I", "G", "H", "T", "S", "*" })
end

local chip = {}
function chip.card_create_action(user)
	props = Battle.CardProperties.new()
    props.shortname = "LghtsOut"
    props.damage = DAMAGE
    props.time_freeze = true
    props.element = Element.Elec
    -- Creates a new cardAction that will play the play_sword animation
    local action = Battle.CardAction.new(user, "PLAYER_SWORD")
	action:set_metadata(props)
    -- Prevents the user from using other cards during this animation
    action:set_lockout(make_animation_lockout())

    --Function that happens when the card actually executes.
    action.execute_func = function(self, user)
        local actor = self:get_actor()

        -- set:add_anim_action adds functions that execute on certain frames of the
        -- action animation.
        self:add_anim_action(1, function()
        end)
        self:add_anim_action(2, function()
            -- Necessary code to render the hand of the user
            local hilt = self:add_attachment("HILT")
            local hilt_sprite = hilt:sprite()
            hilt_sprite:set_texture(actor:get_texture())
            hilt_sprite:set_layer(-2)
            hilt_sprite:enable_parent_shader(true)
            local hilt_anim = hilt:get_animation()
            hilt_anim:copy_from(actor:get_animation())
            hilt_anim:set_state("HAND")
            hilt_anim:refresh(hilt_sprite)
            -- Play the wind effect defined earlier
            Engine.play_audio(WIND_SFX, AudioPriority.High)
            -- Now control will be handed over to the create_tornado function.
            -- Variables that are needed by that function are passed in here.
            create_tornado(user, DAMAGE)
        end)
        self:add_anim_action(3, function()
        end)
        self:add_anim_action(4, function()
        end)
    end
    return action
end

---comment
---@param user Entity The user casting the spell
---@param damage number The amount of damage the spell will do
---@return spell/null
function create_tornado(user, damage)
	for x = 1,6 do
		for y = 1,3 do
			-- Creates a new spell that belongs to the user's team.
			-- Setup sprite of the spell
			-- Setup animation of the spell
			 local spell = Battle.Spell.new(user:get_team())

			--Set the hit properties of this spell.
			spell:set_hit_props(
				HitProps.new(
					damage,
					Hit.Impact | Hit.Stun | Hit.Pierce | Hit.Retangible | Hit.Breaking,
					Element.Elec,
					user:get_context(),
					Drag.None
				)
			)
			local frame = 0
			spell.update_func = function(self, dt)
				--- Gets the current tile the spell is on.
				--- If that tile is out of bounds, it returns nil
				frame = frame + 1 
				if frame == 1 then
					local tile = self:get_current_tile()
					if tile then
						tile:attack_entities(self)
					end
				elseif frame == 6 then
					self:erase()
				end
			end

			spell.attack_func = function(self, other)
				-- Erases the spell once it hits something
				create_hit_effect(spell:get_field(), spell:get_current_tile(), HIT_TEXTURE, HIT_ANIM_PATH, "8", HIT_SOUND)
			end
			
			local field = user:get_field()
			field:spawn(spell,x,y)
		end
	end
end

--- create hit effect.
---@param field any #A field to spawn the effect on
---@param tile Tile tile to spawn effect on
---@param hit_texture any Texture hit effect. (Engine.load_texture)
---@param hit_anim_path any The animation file path
---@param hit_anim_state any The hit animation to play
---@param sfx any Audio # Audio object to play
---@return any returns the hit fx
function create_hit_effect(field, tile, hit_texture, hit_anim_path, hit_anim_state, sfx)
    -- Create artifact, artifacts do not have hitboxes and are used mostly for special effects
    local hitfx = Battle.Artifact.new()
    hitfx:set_texture(hit_texture, true)
    -- This will randomize the position of the effect a bit.
    hitfx:set_offset(math.random(-25, 25), math.random(-25, 25))
    local hitfx_sprite = hitfx:sprite()
    hitfx_sprite:set_layer(-3)
    local hitfx_anim = hitfx:get_animation()
    hitfx_anim:load(hit_anim_path)
    hitfx_anim:set_state(hit_anim_state)
    hitfx_anim:refresh(hitfx_sprite)
    hitfx_anim:on_frame(1, function()
        Engine.play_audio(sfx, AudioPriority.Highest)
    end)
    hitfx_anim:on_complete(function()
        hitfx:erase()
    end)
    field:spawn(hitfx, tile)
    return hitfx
end

return chip