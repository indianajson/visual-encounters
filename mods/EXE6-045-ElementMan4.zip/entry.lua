local package_id = "com.OFC.mob.EXE6-045-ElementMan4"
local character_id = "com.OFC.char.EXE6-045-ElementMan1"

function package_requires_scripts()
    Engine.requires_character(character_id)
end

function package_init(package) 
    package:declare_package_id(package_id)
    package:set_name("ElementMan RV (EXE6)")
    package:set_description("Test fight with\nElementMan RV\nfrom Rockman EXE6")
    package:set_speed(4)
    package:set_attack(120)
    package:set_health(2000)
    package:set_preview_texture_path(_modpath.."preview.png")
end

function package_build(mob)
    local texPath = _modpath.."09-graveyard.png"
    local animPath = _modpath.."09-graveyard.animation"
    mob:set_background(texPath, animPath, -0.0295, 0)
    mob:stream_music(_modpath.."exe6-boss.ogg", 6817, 58254)
    mob:create_spawner(character_id, Rank.NM):spawn_at(5,2)
end