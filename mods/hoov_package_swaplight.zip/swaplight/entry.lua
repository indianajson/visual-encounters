local noop = function () end
local animation_path = _modpath.."SwapLght.animation"

audio = Engine.load_audio(_modpath.."timebomb.ogg")
effectaudio = Engine.load_audio(_modpath.."panel_change.ogg") --give this thing float shoes so maybe poison can't kill it as easy?

local idle_update
local tileswap

idle_update = function(virus, dt)

  local team = virus:get_team()
  
  local field = virus:get_field()
  virus.switch_timer = virus.switch_timer + 1
  if virus.switch_timer % 42 == 0 then
    Engine.play_audio(audio, AudioPriority.Low)
  end
  if virus.switch_timer == 250 then --$start
    print("statechange")
  if virus.lightstate == true then
    --virus.state = "RED"
    virus.anim:set_state("RED")
    virus.anim:set_playback(Playback.Loop)
    virus.lightstate = false

  else
    --virus.state = "BLUE"
    virus.anim:set_state("BLUE")
    virus.anim:set_playback(Playback.Loop)
    virus.lightstate = true

  end
  tileswap (field)
  Engine.play_audio(effectaudio, AudioPriority.Low)

  virus.switch_timer = 0
  
  end --$end
--Function that toggles the light state every 1400
end

tileswap = function (myfield)
  for xpos = 1, 6, 1 do
    for ypos = 1, 3, 1 do
        local tile = myfield:tile_at(xpos, ypos)
        if tile:get_state() == TileState.Grass then
          tile:set_state(TileState.Poison)

        elseif tile:get_state() == TileState.Poison then
          tile:set_state(TileState.Grass)

        elseif tile:get_state() == TileState.DirectionDown then
          tile:set_state(TileState.DirectionUp)

        elseif tile:get_state() == TileState.DirectionUp then
          tile:set_state(TileState.DirectionDown)
        
        elseif tile:get_state() == TileState.DirectionLeft then
          tile:set_state(TileState.DirectionRight)

        elseif tile:get_state() == TileState.DirectionRight then
          tile:set_state(TileState.DirectionLeft)

        end

    end
  end


end


function package_init(virus, ezencounters_data)
    -- EZENCOUNTERS MAX-HP SUPPORT v11 --
    do
        local payload = ezencounters_data
        if type(payload) == "table" then
            local ids = {"hoov.enemy.swaplight"}
            local aliases = {["SwapLight"]=true}
            local requested = nil
            local conflict = false
            local maxima = payload.__ezencounters_hp_max_by_package
            if type(maxima) == "table" then
                for _, id in ipairs(ids) do
                    local value = tonumber(maxima[id])
                    if value ~= nil and value > 0 and value == value and value ~= math.huge then
                        if requested ~= nil and requested ~= value then conflict = true end
                        requested = value
                    end
                end
            end
            -- Some engine builds pass an independent copy of encounter data
            -- to the Character package. Resolve from original enemy entries
            -- as well, rather than depending on a mutation in package_build.
            if requested == nil and type(payload.enemies) == "table" then
                for _, enemy in ipairs(payload.enemies) do
                    if type(enemy) == "table" and aliases[enemy.name] then
                        local value = tonumber(enemy.max_hp)
                        if value == nil and #payload.enemies == 1 then
                            value = tonumber(payload.max_hp)
                        end
                        if value ~= nil and value > 0 and value == value and value ~= math.huge then
                            if requested ~= nil and requested ~= value then conflict = true end
                            requested = value
                        end
                    end
                end
            end
            if not conflict and requested ~= nil and requested == math.floor(requested) then
                print("[ezencounters hp] INITIAL MAX HP", ids[1], requested)
                virus:set_health(requested)
            end
        end
    end

  virus.state = "BLUE"
  virus:set_name("SwapLght")
  virus:set_height(44)
  virus.__ezhp_native_max_hp = 500
  virus:set_texture(Engine.load_texture(_modpath.."SwapLght.png"))

 
  virus.switch_timer = 0
  virus.lightstate = true
  virus.anim = virus:get_animation()
  virus.anim:load(animation_path)
  virus.anim:set_state(virus.state)
  virus.anim:set_playback(Playback.Loop)
  virus:set_float_shoe(true)
  virus.update_func = idle_update
  local virusdefense = Battle.DefenseVirusBody.new()
  virus:add_defense_rule(virusdefense)
  local previous_battle_start = virus.battle_start_func
  virus.battle_start_func = function(self, ...)
    if self:get_max_health() == 0 then
      self:set_health(self.__ezhp_native_max_hp)
    end
    if previous_battle_start then return previous_battle_start(self, ...) end
  end

end