print("[EZDBG][CLIENT][CHAR_FILE_LOADED] com_Dawn_Shademan.zip:entry.lua")
local package_id = "com.keristero.mob.ShadeMan.EZLiberation"
local character_id = "com.keristero.char.ShadeMan.EZLiberation"

function package_requires_scripts()
    print("[EZDBG][CLIENT][PACKAGE_REQUIRES_SCRIPTS_BEGIN] com_Dawn_Shademan.zip:entry.lua")
    print("[EZDBG][CLIENT][ShadeMan:liberation][CHARACTER_ID]", character_id)
    Engine.define_character(character_id, _modpath.."virus")
    Engine.define_character("com.keristero.char.ShadeMan.EZLiberation.EZHP1200", _modpath.."virus-hp1200")
    Engine.define_character("com.keristero.char.ShadeMan.EZLiberation.EZHP2400", _modpath.."virus-hp2400")
end

function package_init(package)
    print("[EZDBG][CLIENT][PACKAGE_INIT_BEGIN] com_Dawn_Shademan.zip:entry.lua") 
    print("[EZDBG][CLIENT][ShadeMan:liberation][PACKAGE_ID]", package_id)
    package:declare_package_id(package_id)
    package:set_name("Shademan")
    package:set_description("Don't underestimate the Darkloids!")
    package:set_speed(1)
    package:set_attack(40)
    package:set_health(600)
    package:set_preview_texture_path(_modpath.."preview.png")
end

function package_build(mob)
    print("[EZDBG][CLIENT][PACKAGE_BUILD_BEGIN] com_Dawn_Shademan.zip:entry.lua")
    local texPath = _modpath.."BG.png"
    local animPath = _modpath.."BG.animation"
    mob:set_background(texPath, animPath, 0.5, -0.3)
    mob:stream_music(_modpath.."song.mid", 0, 0)
    mob:create_spawner(character_id, Rank.V1):spawn_at(5, 2)
end