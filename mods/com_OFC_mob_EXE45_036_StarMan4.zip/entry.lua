local package_id = "com.OFC.mob.EXE45-036-StarMan4"
local character_id = "com.OFC.char.EXE45-036-StarMan1"

function package_requires_scripts()
    Engine.requires_character(character_id)
end

function package_init(package) 
    package:declare_package_id(package_id)
    package:set_name("StarMan SP (EXE4.5)")
    package:set_description("Test fight with StarManSP from EXE4.5")
    package:set_speed(1)
    package:set_attack(100)
    package:set_health(1500)
    package:set_preview_texture_path(_modpath.."preview.png")
end

function package_build(mob)
    local texPath = _modpath.."exe45-bg-urainternet.png"
    local animPath = _modpath.."exe45-bg-urainternet.animation"
    mob:set_background(texPath, animPath, 0.0, 0.0)
    mob:stream_music(_modpath.."exe45-boss.ogg", 4467, 48046)
    mob:create_spawner(character_id, Rank.SP):spawn_at(5, 2)
end