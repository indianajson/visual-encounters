local battle_helpers = include("battle_helpers.lua")
local flame_trail = include("flame_trail.lua")
local character_animation = _folderpath .. "battle.animation"
local teleport_animation = _folderpath .. "teleport.animation"
local teleport_texture = Engine.load_texture(_folderpath .. "teleport.png")
local anim_speed = 1
local dash_sfx = Engine.load_audio(_folderpath .. "dash.ogg")
local tile_width = 80

local CHARACTER_TEXTURE = Engine.load_texture(_folderpath .. "battle.greyscaled.png")
local move_counter = 0

function package_init(self, character_info)

    -- Required function, main package information

    -- Load character resources
    move_counter = 0


    local base_animation_path = character_animation
    self:set_texture(CHARACTER_TEXTURE, true)
    self.animation = self:get_animation()
    self.animation:load(base_animation_path)
    self.animation:set_playback_speed(anim_speed)
    self:set_palette(Engine.load_texture(character_info.palette))


    -- Load extra resources

    -- Set up character meta
    self:set_name(character_info.name)
    self.__ezhp_native_max_hp = (character_info.hp)
    self:set_height(character_info.height)
    self:set_float_shoe(true)
    self:set_air_shoe(true)
    self.flydelay = character_info.flydelay
    self.floatdelay = character_info.floatdelay
    self.maxdashes = character_info.dashes
    self.damage = character_info.damage
    self.dashes = character_info.dashes
    self:share_tile(true)
    self.flame_trail = character_info.flame_trail
    if (character_info.element == "fire") then
        self:set_element(Element.Fire)
    end
    self.debug = false
    self:set_explosion_behavior(4, 1, false)
    self:set_offset(0, 0)

    self.animation:set_state("IDLE")

    -- Defense rules
    self.defense = Battle.DefenseVirusBody.new()
    self:add_defense_rule(self.defense)
    self.wait = 0
    self.move_direction = Direction.Up
    self.windup_time = 0


    self.started = false
    self.turndir = -1
    self.returnToTile = nil
    self.state = "normal"
    self.yOffset = 0;
    self.dashes = 0
    self:set_shadow(Shadow.Small)
    self:show_shadow(true)

    self.antidrag = Battle.DefenseRule.new(100, DefenseOrder.CollisionOnly)
    self.antidrag.filter_statuses_func = function(statuses)
        statuses.flags = statuses.flags & ~Hit.Drag
        return statuses
    end

    self.can_move_to_func = function(tile)
        if (self.state == "flying" or self.state == "return" or self.state == "loop") then
            return true
        else
            local canMove = is_tile_free_for_movement(tile, self)
            if (not canMove) then
                self.turn(tile)
            end
            return canMove
        end
    end

    -- Initial state

    self.update_func = function()
        if (not self.started) then
            self:get_animation():set_state("TURN_LEFT_2")
            self.started = true
            self.begin_loop_position = 6
            self.direction_value = -1
            if (self:get_facing() == Direction.Right) then
                self.begin_loop_position = 1
                self.direction_value = 1
            end
            self.lookForEnemies()
            tile_width = self:get_tile():width()
        end
        if (self.state == "flying") then
            fly(self)
        elseif (self.state == "normal") then
            move(self)
            self.wait = self.wait + 1
            if (self.wait >= self.floatdelay)
            then
                self.lookForEnemies()
                self.wait = 0
            end
        elseif (self.state == "prepareDash") then
            self:prepareDash()
        elseif (self.state == "loop") then
            loop(self)
        elseif (self.state == "return") then
            -- Return logic
            local started = function()
                self:set_elevation(350)
                self:set_offset(0, 0)
                self.yOffset = 350;
                self:toggle_hitbox(false)
            end
            self:teleport(self.returnToTile, ActionOrder.Immediate, started)
            if (self:get_tile() == self.returnToTile) then
                self.state = "descend"
            end

        elseif (self.state == "descend") then
            if self.yOffset ~= 0 then
                self.yOffset = self.yOffset - 5
                self:set_elevation(self.yOffset)
                if (self.yOffset < 20) then

                    self:toggle_hitbox(true)
                    self:remove_defense_rule(self.antidrag)
                end
                return -- still returning to space.
            else
                self.yOffset = 0
                self.steps = 0
                self.state = "normal"
                self.blocker:erase()
                self.blocker = nil
                self.move_direction = Direction.Up
                self.lookForEnemies()
            end
        end
    end

    self.turn = function(target_tile)
        if (self.move_direction == Direction.Up) then
            self.move_direction = Direction.Down
        else
            self.move_direction = Direction.Up
        end
    end

    self.delete_func = function(self)
        if (self.blocker) then
            self.blocker:erase()
        end
    end

    self.prepareDash = function(self)
        self.windup_time = self.windup_time + 1
        self.returnToTile = self:get_tile()
        self.blocker = Battle.Obstacle.new(self:get_team())
        self.blocker.update_func = function()
            -- self.blocker:get_tile():highlight(Highlight.Solid)
        end
        if (self.windup_time == 25) then
            self:toggle_counter(true)
            Engine.play_audio(dash_sfx, AudioPriority.Highest)
        elseif (self.windup_time == 30) then
            self.windup_time = 0
            self.dashes = self.dashes - 1
            self:toggle_counter(false)
            self.move_direction = self:get_facing()
            self.animation:set_state("FLYING")
            self.state = "flying"
            self:add_defense_rule(self.antidrag)
            self.animation:set_playback(Playback.Loop)
            self:get_field():spawn(self.blocker, self:get_tile())
        end
    end

    self.lookForEnemies = function()
        local enemy_target = battle_helpers.find_target(self)
        if (enemy_target) then
            if (enemy_target:get_tile():y() == self:get_tile():y()) then
                self.dashes = self.maxdashes
                action_dash(self)
            end
        end
    end
end

function is_tile_free_for_movement(tile, character)
    --Basic check to see if a tile is suitable for a chracter of a team to move to

    if tile:get_team() ~= character:get_team() then
        return false
    end
    if (tile:is_edge()) then
        return false
    end
    local occupants = tile:find_entities(function(ent)
        if (Battle.Character.from(ent) ~= nil or Battle.Obstacle.from(ent) ~= nil) then
            return true
        else
            return false
        end
    end)
    if #occupants == 1 and occupants[1]:get_id() == character:get_id() then
        return true
    end
    if #occupants > 0 then
        return false
    end

    return true
end

function alliesOnTargetTile(target_tile, self)

    if (target_tile == nil) then return false end
    local occupants = target_tile:find_entities(function(ent)
        if (Battle.Character.from(ent) ~= nil or Battle.Obstacle.from(ent) ~= nil) then
            if (ent:get_team() == self:get_team()) then
                return true
            else
                return false
            end
        else
            return false
        end
    end)
    if #occupants > 1 then
        return true
    end
    return false
end

function loop(self)
    local ok = function()
        self.state = "flying"
    end
    local enemy_target = battle_helpers.find_target(self)
    local targetY = self:get_tile():y()
    if (enemy_target) then
        targetY = enemy_target:get_tile():y()
    end
    local target_tile = self:get_field():tile_at(self.begin_loop_position, targetY)
    self:teleport(target_tile, ActionOrder.Immediate, ok)
end

---comment
---@param self Entity
function fly(self)
    local current_tile = self:get_tile()
    local next_tile = current_tile:get_tile(self:get_facing(), 1)
    --fishy reached end of map
    if (current_tile:is_edge()) then
        if (self.dashes == 0) then
            self.state = "return"
        else
            --fishy has more dashes left.
            Engine.play_audio(dash_sfx, AudioPriority.Highest)
            self.dashes = self.dashes - 1
            self.state = "loop"
            return
        end
    end
    local hitbox = Battle.Hitbox.new(self:get_team())
    hitbox:set_hit_props(
        HitProps.new(
            self.damage,
            Hit.Flinch | Hit.Impact | Hit.Flash,
            Element.None,
            self:get_context(),
            Drag.None
        )
    )
    local return_logic = function()
        if (alliesOnTargetTile(self:get_tile(), self)) then
            if (self:get_tile() ~= self.returnToTile) then
                self.dashes = 0
                target_tile = nil
                self.state = "return"
                battle_helpers.spawn_visual_artifact(self:get_field(), self:get_tile(), teleport_texture,
                    teleport_animation, "BIG_TELEPORT_FROM", 0, -20)
            end
        end

    end
    return_logic()
    self:get_field():spawn(hitbox, current_tile)
    local fishyOffset = self:get_offset()
    self:set_offset(fishyOffset.x + (self.direction_value * self.flydelay), 0);
    if (self:get_facing() == Direction.Right) then
        if (fishyOffset.x) > (tile_width / 3) then
            if (self.flame_trail) then
                flame_trail.create_flame_trail(self, self.damage, current_tile)
            end
            self:teleport(next_tile, ActionOrder.Immediate, nil)
            self:set_offset(-self.direction_value * tile_width / 2, 0);

        end
    else
        if (fishyOffset.x) < (-tile_width / 3) then
            if (self.flame_trail) then
                flame_trail.create_flame_trail(self, self.damage, current_tile)
            end
            self:teleport(next_tile, ActionOrder.Immediate, nil)
            self:set_offset(-self.direction_value * tile_width / 2, 0);
        end
    end
end

function move(self)

    move_counter = move_counter + 1

    local anim = self:get_animation()
    --anim:set_state("WARP_2")

    local target_tile = self:get_tile(self.move_direction, 1)


    function turn2()
        if (self.move_direction == Direction.Down) then
            anim:set_state("TURN_RIGHT_2")
        elseif (self.move_direction == Direction.Up) then
            anim:set_state("TURN_LEFT_2")
        end
    end

    self:slide(target_tile, frames(self.floatdelay), frames(0), ActionOrder.Voluntary, turn2)
    anim:on_complete(function()
        self.wait_time = 0

    end)

end

function tileToString(tile)
    return "Tile: [" .. tostring(tile:x()) .. "," .. tostring(tile:y()) .. "]"
end

function action_dash(character)
    character.state = "prepareDash";
    character.windup_time = 0
    character:get_animation():set_state("LAUNCH")

end

function getNextTile(direction, spell)
    return spell:get_current_tile():get_tile(direction, 1)
end

function debug_print(entity, string)
    if (entity.debug) then
        print("[fishy] " .. string)
    end
end


-- EZEncounters deferred native HP adapter.
-- The native fallback must not lock max HP in on_spawn_func: some client
-- spawners run on_spawn before their encounter mutate callback.
-- Battle start occurs after encounter mutations and before the first update.
local __ezhp_original_package_init = package_init
package_init = function(character, ...)
    __ezhp_original_package_init(character, ...)
    local __ezhp_original_battle_start = character.battle_start_func
    character.battle_start_func = function(self, ...)
        if self:get_max_health() == 0 then
            local native = tonumber(self.__ezhp_native_max_hp)
            if not native or native ~= native or native <= 0 or native == math.huge then native = 1 end
            native = math.max(1, math.floor(native))
            self:set_health(native)
            print('[EZHP][CLIENT][NATIVE_FALLBACK_BATTLE_START]', tostring(self:get_name()), native,
                'actual', self:get_max_health())
        end
        if __ezhp_original_battle_start then return __ezhp_original_battle_start(self, ...) end
    end
end

return package_init
