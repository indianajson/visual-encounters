local texture = nil
local shadow_texture = nil
local anim = nil

local SHOOT_SFX = nil
local BOMB_SFX = nil
local LASER_SFX = nil
local LASER_EXPLOSION_SFX = nil
local WHIR_SFX = nil

function package_init(self)
    texture = Engine.load_texture(_modpath.."VolcanoMan.png")
    shadow_texture = Engine.load_texture(_modpath.."shadow.png")

    self:set_name("VolcanoMan")
	local rank = self:get_rank()
    self.damage = 90
    self.laser_damage = 200

	if rank == Rank.V1 then
    	self:set_health(2400)
	else
		self:set_health(2700)

	end
	self:set_element(Element.Fire)
    self:set_texture(texture, true)
    self:set_height(60)
    self:share_tile(false)
    self.max_health = self:get_health()
    self:set_explosion_behavior(8, 8, true)


    anim = self:get_animation()
    anim:load(_modpath.."VolcanoMan.animation")
    anim:set_state("IDLE")
    anim:set_playback(Playback.Loop)
    
    SHOOT_SFX = Engine.load_audio(_folderpath.."cannon.ogg")
    BOMB_SFX = Engine.load_audio(_folderpath.."explosion.ogg")
    LASER_SFX = Engine.load_audio(_folderpath.."bombbig.ogg")
    LASER_EXPLOSION_SFX = Engine.load_audio(_folderpath.."bombmiddle.ogg")
    WHIR_SFX = Engine.load_audio(_folderpath.."machineRunning.ogg")



    -- Setting names here is just convenience if I want to print the state I'm in later
    self.states = {
        idle = {name = "idle", func = idle},
        move = {name = "move", func = move},
        move_line_up = {name = "move_line_up", func = move_line_up},
        move_to_back = {name = "move_to_back", func = move_to_back},
        move_to_back_center = {name = "move_to_back_center", func = move_to_back_center},
        move_near_front = {name = "move_near_front", func = move_near_front},
        flinch = {name = "flinch", func = flinch},
        shoot = {name = "shoot", func = shoot},
        bomb = {name = "bomb", func = bomb},
        flare = {name = "flare", func = flare},
        volley = {name = "volley", func = volley},
        laser = {name = "laser", func = laser}
    }
    
    local s = self.states
    self.pattern = {
        s.idle, s.move, s.idle, s.idle, s.move, s.idle, s.idle, s.move_line_up, s.idle, s.shoot, s.idle,
        s.idle, s.move, s.idle, s.idle, s.move, s.idle, s.idle, s.move_near_front, s.bomb, s.idle,
        s.idle, s.move, s.idle, s.idle, s.move, s.idle, s.idle, s.move_near_front, s.flare, s.idle,
        s.idle, s.move, s.idle, s.idle, s.move, s.idle, s.idle, s.move_to_back, s.volley, s.idle,
        s.idle, s.move, s.idle, s.idle, s.move, s.idle, s.idle, s.move_to_back_center, s.laser, s.idle

    }

    self.pattern_index = 1

    self.nloop = 1
    self.idle_count = 0
    self.mloop = 3
    self.move_count = 0
    self.volley_loop = 2
    self.volley_count = 0

    self.acting = false
    self.first_act = true

    self.state_done = false

    self.state = self.pattern[1]

    self.first_flinch = true


    self.hit_func = function()
       -- print("Hit")
        self.flinching = false
        self.first_act = false
        self.state_done = false
        if self.first_flinch then 
         --   self.state.cleanup
            self.last_state = self.state
            if self.state ~= self.states.idle and self.state ~= self.states.move then 
               -- increment_pattern(self)
            end

            self.first_flinch = false
        end
        self.state = self.states.flinch
        flinch(self)

    end

    self.delete_func = function(self)
        self.update_func = function(self)
            anim:set_state("FLINCH")
            self.state = self.states.flinch
        end

    end


    self.end_attack = false

    self:register_status_callback(Hit.Stun, self.hit_func)

    self.on_countered = function(self)
      --  print("Countered")
        self:toggle_counter(false)
        self.hit_func(self)

    end

    self.update_func = function(self)
        self.state.func(self)
    end
end


function idle(self)
    if self.first_act then 
        if anim:get_state() ~= "IDLE" then 
            anim:set_state("IDLE")
        end
        anim:set_playback(Playback.Loop)

        anim:on_complete(function()
            if not self.looped then 
                --self.looped = true
                self.idle_count = self.idle_count+1
               -- print("Complete"..self.idle_count)

                if self.idle_count >= self.nloop then 
                    self.state_done = true
                    
                end
            end

            self.looped = not self.looped
        
        end)

        self.first_act = false
    end

    --self.looped = false
    if self.state_done then 
       -- print("State done")
        self.idle_count = 0
        self.state_done = false
        increment_pattern(self)
    end
end

function hit()
    

end

function flinch(self)
   -- print("Flinch played")
    self.looped = false

    if not self.flinching then 
        anim:set_state("FLINCH")        
        anim:on_complete(function()
           -- print("Anim done")
            self.flinching = false
            self.state_done = true
            self.first_flinch = false

            self.looped = true

        --    print("Done")
            self.state_done = false
            if self.last_state ~= self.states.idle and self.last_state ~= self.states.move then 
           --     print("Last state was not idle or move")
                increment_pattern(self)
            else
             --   print("Last state was idle or move")
                self.state = self.last_state
                self.first_act = true
            end

        end)

    end

    self.flinching = true
   
end


function highlight_tiles(self, list, time)
    local spell = Battle.Spell.new(self:get_team())


    local ref = self
    spell.update_func = function(self)
        for i=1, #list
        do 
            local t = list[i]
            if t and not t:is_edge() then 
                t:highlight(Highlight.Solid)
            end

        end


        time = time - 1
        if time == 0 then 
            self:delete()
        end

        if self.flinching then 
            if spell and not spell:is_deleted() then 
                spell:delete()
    
            end
        end
    end


    self:get_field():spawn(spell, self:get_current_tile())
end



function move(self)
    if self.first_act then 
        anim:set_state("MOVE")

        local tile = choose_move(self, self:get_field())

        anim:on_frame(3, function()
            if can_move_to(tile, self) then 
               -- print("Can reach")
            else
                --print("Can't do it now")
                tile = self:get_current_tile()
            end
            self:teleport(tile, ActionOrder.Voluntary, function()
                --print("Move")
            end)
        end)

        anim:on_complete(function()
            increment_pattern(self)
        
        end)

        self.first_act = false
    end
end


function shoot(self)
    if self.first_act then 
        anim:set_state("SHOOT")

        anim:on_frame(1, function()
            self:toggle_counter(true)
        end)
        anim:on_frame(2, function()
            shoot_rock(self)
            self:toggle_counter(false)
        end)

        anim:on_complete(function()
            increment_pattern(self)
        
        end)

        self.first_act = false
    end

end


function shoot_rock(self)
    local field = self:get_field()
    local spell = graphic_init("spell", 0, -74, texture, "VolcanoMan.animation", -4, "FIREBALL", self, self:get_facing())
    spell:get_animation():set_playback(Playback.Loop)
    local facing = self:get_facing()


    local shadow = graphic_init("spell", 0, 0, shadow_texture, "VolcanoMan.animation", 5, "SHADOW", self, self:get_facing())

    local hit_props = HitProps.new(
            self.damage,
            Hit.Impact | Hit.Flinch | Hit.Flash,
            Element.Fire, 
            self:get_id(), 
            Drag.None
        )

    spell:set_hit_props(hit_props)

    spell.update_func = function(self, dt)
        self:get_tile():attack_entities(self)
        self:get_current_tile():attack_entities(self)
        if self:is_sliding() == false then
            if self:get_current_tile():is_edge() and self.slide_started then 
                self:delete()
                shadow:delete()

            end 
            
            local dest = self:get_tile(facing, 1)
            local ref = self
            self:slide(dest, frames(10), frames(0), ActionOrder.Voluntary,
                function()
                    ref.slide_started = true 
                end
            )
        end
    end


    shadow.update_func = spell.update_func
    spell.collision_func = function()
        spell:delete()
        shadow:delete()
    end

    spell.can_move_to_func = function()
        return true
    end

    shadow.can_move_to_func = function()
        return true
    end
    

    Engine.play_audio(SHOOT_SFX, AudioPriority.Low)
    local tile = self:get_tile(facing, 2)

    if tile then 
        field:spawn(spell, tile)
        field:spawn(shadow, tile)

    end
end

function bomb(self)
    if self.first_act then 
        anim:set_state("SHOOT2")

        anim:on_frame(1, function()
            self:toggle_counter(true)
        end)

        anim:on_frame(3, function()
            shoot_bomb(self)
            self:toggle_counter(false)
        end)

        anim:on_complete(function()
            increment_pattern(self)
        
        end)

        self.first_act = false
    end

end


function shoot_bomb(self)
    local facing = self:get_facing()
    local spawn_tile = self:get_tile(facing, 2)
    local far_tile = self:get_tile(facing, 3)
    local field = self:get_field()

    if not far_tile then 
        return
    end

    local y = -56
    local x = 8
    local spell = graphic_init("spell", x, y, texture, "VolcanoMan.animation", -4, "BOMB", self, self:get_facing())
    local shadow = graphic_init("spell", x, 0, shadow_texture, "VolcanoMan.animation", 5, "SHADOW", self, self:get_facing())

    local max_time = 15
    local d_y = y/max_time
    local d_x = x/max_time
    local time = 0
    local time_shadow = 0

   
    local function create_bomb()
        local bomb = graphic_init("obstacle", 0, 0, texture, "VolcanoMan.animation", -4, "BOMB_ARMED", self, self:get_facing())
        local bomb_collision = Battle.Spell.new(bomb:get_team())
        bomb:set_height(12)
        bomb:share_tile(false)
        bomb:set_health(50)
        local anim = bomb:get_animation()

        bomb_collision.collision_func = function()
            if bomb and not bomb:is_deleted() then 
                bomb:delete()
            end
        end

        bomb_collision.update_func = function()
            if bomb:get_current_tile() and bomb_collision then 
                bomb:get_current_tile():attack_entities(bomb_collision)
            end
        end
        

        anim:on_complete(function()
            spawn_flame(self, bomb:get_team(), bomb:get_current_tile(), true)
            bomb:delete()
        end)
        
        bomb.delete_func = function()
            local t = bomb:get_health() ~= 0
            spawn_flame(self, bomb:get_team(), bomb:get_current_tile(), t)
            bomb_collision:delete()
        end


        
        return {bomb, bomb_collision}
    end

    
    local first = true
    spell.update_func = function(self)
        if first then 
            self:slide(far_tile, frames(max_time), frames(0), ActionOrder.Voluntary, nil)

            first = false
        end

        if time <= max_time then 
            self:set_offset(x - d_x*time, y - d_y*time)

            time = time + 1
        else
            if self:get_current_tile():is_walkable() then 
                local bombs = create_bomb()
                field:spawn(bombs[1], self:get_current_tile())
                field:spawn(bombs[2], self:get_current_tile())
            end
                self:delete()
        end
    end

    local shadow_first = true

    shadow.update_func = function(self)
        if shadow_first then 
            self:slide(far_tile, frames(max_time), frames(0), ActionOrder.Voluntary, nil)

            shadow_first = false
        end

        if time_shadow <= max_time then 
            self:set_offset(x - d_x*time, 0)

            time_shadow = time_shadow + 1
        else
            self:delete()
        end
    end

    spell.can_move_to_func = function()
        return true
    end
    
    shadow.can_move_to_func = function()
        return true
    end

    field:spawn(spell, spawn_tile)
    field:spawn(shadow, spawn_tile)
    Engine.play_audio(SHOOT_SFX, AudioPriority.Low)

end


function spawn_flame(self, team, tile, from_bomb)
    local field = self:get_field()
    local flame = graphic_init("artifact", 0, 0, texture, "VolcanoMan.animation", -4, "FIRE", self, self:get_facing(), true)
    local tiles
    local spell = Battle.Spell.new(team)
    if from_bomb then 
        tiles = {
            tile:get_tile(Direction.Up, 1),
            tile:get_tile(Direction.Left, 1),
            tile:get_tile(Direction.Down, 1),
            tile:get_tile(Direction.Right, 1)
        }
    end

    local hit_props = HitProps.new(
        self.damage,
        Hit.Impact | Hit.Flinch | Hit.Flash,
        Element.Fire, 
        self:get_id(), 
        Drag.None
    )

    spell:set_hit_props(hit_props)

    local lifetime = 12

    
    spell.update_func = function(self)
        self:get_current_tile():attack_entities(self)
        lifetime = lifetime - 1
        if lifetime == 0 then 
            self:delete()
        end
    end

   

    if from_bomb then
        flame:get_animation():on_frame(3, function()
            for i=1, #tiles
            do
                local t = tiles[i]
                if t and not t:is_edge() then 
                    spawn_flame(self, team, t, false)
                end
            end
        end)
        
    
    end

    field:spawn(flame, tile)
    field:spawn(spell, tile)
    Engine.play_audio(BOMB_SFX, AudioPriority.Low)
end

function flare(self)
    if self.first_act then 
        anim:set_state("FLARE")

        anim:on_frame(1, function()
            self:toggle_counter(true)
        end)

        anim:on_frame(2, function()
            highlight_tiles(self, find_flare_tiles(self), 10)
        
        end)
        anim:on_frame(6, function()
            self:toggle_counter(false)
            local list = find_flare_tiles(self)
            local team = self:get_team()
            for i=1, #list
            do
                spawn_flame(self, team, list[i], false)
            end

            
        end)

        anim:on_complete(function()
            increment_pattern(self)
        
        end)

        self.first_act = false
    end

end

function find_flare_tiles(self)
    local facing = self:get_facing()
    local tile = self:get_tile(facing, 1)
    local team = self:get_team()

    local dirs = {
        Direction.Up,
        Direction.Down,
        Direction.join(Direction.Up, facing),
        Direction.join(Direction.Down, facing),
        facing
    }

    local list = {}

    if tile and not tile:is_edge() then 
        table.insert(list, tile)
    end

    for i=1, #dirs
    do
        local t = tile:get_tile(dirs[i], 1)
        if t and not t:is_edge() then 
            table.insert(list, t)
        end
    end

    return list
end


function volley(self)
    if self.first_act then 
        local list
        self.looped = false
        anim:set_state("VOLLEY_START")
        anim:on_frame(1, function()
            self:toggle_counter(true)
        end)
       
        anim:on_complete(function()
            self:toggle_counter(false)
            anim:set_state("VOLLEY_LOOP")
            anim:set_playback(Playback.Loop)
            list = find_valid_volley(self)
            for i=1, 3, 2
            do
                anim:on_frame(i, function()
                    shoot_volley(self, list)
                    Engine.play_audio(SHOOT_SFX, AudioPriority.Low)

                end)
            end

            anim:on_complete(function()
                if not self.looped then 
                    --self.looped = true
                    self.volley_count = self.volley_count+1
                  --  print("Complete"..self.volley_count)
    
                    
                    if self.volley_count > self.volley_loop then 
                    --    print("Should be done")
                        anim:set_state("VOLLEY_END")
                        anim:refresh(self:sprite())

                        anim:on_complete(function()
                      --      print("Done")
                            increment_pattern(self)
                        end)
                        
                        return
                    end
                        
                
                else
                    for i=1, 3, 2
                    do
                        anim:on_frame(i, function()
                            shoot_volley(self, list)
                            Engine.play_audio(SHOOT_SFX, AudioPriority.Low)

                        end)
                    end
                end
                self.looped = not self.looped

            end)
        end)

       

        self.first_act = false
    end

end

function find_valid_volley(self)
    local t = self:get_current_tile()
    local x = t:x()
    return self:get_field():find_tiles(function(tile)
        return not tile:is_edge() and math.abs((tile:x() - x)) > 3
    
    end)
end

function shoot_volley(self, list)
    if #list == 0 then 
        list = find_valid_volley(self)
        if #list == 0 then 
            return nil
        end
    end

    local i = math.random(1, #list)
    local target = list[i]
    table.remove(list, i)


    local max_time = 45
    local time = 0
    local time_shadow = 0
    local y = -112
    local x = -56
    if self:get_facing() == Direction.Right then 
        x = x * -1
    end

    local d_x = x/max_time    
    local d_y = y/max_time
    local spell = graphic_init("spell", 0, y, texture, "VolcanoMan.animation", -4, "VOLLEY_SHOT", self, self:get_facing())
    local shadow = graphic_init("spell", 0, 0, shadow_texture, "VolcanoMan.animation", 5, "SHADOW", self, self:get_facing())

    local first = true
    local shadow_first = true
    local ref = self
    spell.update_func = function(self)
        if first then 
            self:jump(target, 160, frames(max_time), frames(0), ActionOrder.Voluntary, nil)

            first = false
        end

        if time < max_time-10 then 
            target:highlight(Highlight.Flash)
        end

        if time <= max_time then 
            self:set_offset(x - d_x*time, y - d_y*time)

            time = time + 1
        else
            spawn_flame(ref, self:get_team(), target, false)
            self:delete()
        end
    end

    shadow.update_func = function(self)
        if shadow_first then 
            self:slide(target, frames(max_time), frames(0), ActionOrder.Voluntary, nil)

            shadow_first = false
        end

        if time_shadow <= max_time then 
            self:set_offset(x - d_x*time, 0)

            time_shadow = time_shadow + 1
        else
            self:delete()
        end
    end

    spell.can_move_to_func = function()
        return true
    end

    shadow.can_move_to_func = function()
        return true
    end

    self:get_field():spawn(spell, self:get_current_tile())
    self:get_field():spawn(shadow, self:get_current_tile())

end


function laser(self)
    if self.first_act then 
        anim:set_state("LASER")

        anim:on_frame(3, function()
            Engine.play_audio(WHIR_SFX, AudioPriority.Low)
        end)

        anim:on_frame(26, function()
            local laser_graphic = graphic_init("artifact", 0, 0, texture, "VolcanoMan.animation", -3, "LASER_GRAPHIC", self, self:get_facing(), true)

            self:get_field():spawn(laser_graphic, self:get_current_tile())
        end)

        anim:on_frame(25, function()
            Engine.play_audio(LASER_SFX, AudioPriority.Low)
        end)

        anim:on_frame(27, function()
            laser_attack(self)
        end)
        
        anim:on_frame(35, function()
            rock_fall(self)
        end)

        anim:on_complete(function()
            increment_pattern(self)
        
        end)

        self.first_act = false
    end

end

function laser_attack(self)
    local list = {}
    local field = self:get_field()
    local facing = self:get_facing()
    local tile = self:get_tile(facing, 1)

    table.insert(list, tile)

    local check_tile = tile
    for i=2, field:width()
    do
        check_tile = check_tile:get_tile(facing, 1)
        if check_tile and not check_tile:is_edge() then 
            table.insert(list, check_tile)
        else
            break
        end
    end
    
    local function spawn_spell(tile, lifetime)
        local spell = Battle.Spell.new(self:get_team())
        spell.lifetime = lifetime
        local hit_props = HitProps.new(
            self.laser_damage,
            Hit.Impact | Hit.Flinch | Hit.Flash | Hit.Breaking,
            Element.Fire, 
            self:get_id(), 
            Drag.None
        )

        spell:set_hit_props(hit_props)

        spell.update_func = function(self)
            self:get_current_tile():attack_entities(self)
            self.lifetime = self.lifetime - 1
            if self.lifetime == 0 then 
                self:delete()
            end
        end

        field:spawn(spell, tile)
    end


    local function back_laser_attack(tile, lifetime)
        local artifact = graphic_init("artifact", 0, 0, texture, "VolcanoMan.animation", -4, "EXPLOSION", self, self:get_facing(), true)
        local tile1 = tile:get_tile(Direction.Up, 1)
        local tile2 = tile:get_tile(Direction.Down, 1)


        field:spawn(artifact, tile)
        spawn_spell(tile1, 20)
        spawn_spell(tile2, 20)

        Engine.play_audio(LASER_EXPLOSION_SFX, AudioPriority.Low)

    end


    for i=1, #list 
    do
        spawn_spell(list[i], 45)
    end

    back_laser_attack(list[#list], 20)

    local shake_artifact = Battle.Artifact.new()
    local time = 0
    shake_artifact.update_func = function(self)
            
        self:shake_camera(200, 0.016)
        if time == 61 then 
            self:delete()
        end
    
        time = time+1
    end

    field:spawn(shake_artifact, tile)

end

function rock_fall(self)
    local field = self:get_field()
    local team = self:get_team()

    local list = field:find_tiles(function(t)
        return not t:is_edge() and t:get_team() ~= team
    
    end)

    if #list == 0 then return end


    local function spawn_rock(tile)
        local spell = graphic_init("spell", 0, 0, texture, "VolcanoMan.animation", -4, "FALLING_ROCK", self, self:get_facing())
       -- spell:get_animation():set_playback(Playback.Loop)
        local shadow = graphic_init("spell", 0, 0, shadow_texture, "VolcanoMan.animation", 5, "SHADOW", self, self:get_facing())

        local y = 300
        spell:set_elevation(y)
        local max_time = 35
        local time = 0
        local d_y = y/max_time

        local ref = self
        spell.update_func = function(self)
            self:set_elevation(y - time*d_y)
            time = time+1

            if time > max_time then               
                spawn_flame(ref, self:get_team(), self:get_current_tile(), false)
                self:delete()
                shadow:delete()

            end

            if time < max_time - 25 then 
                self:get_current_tile():highlight(Highlight.Flash)
            end
        end

        field:spawn(spell, tile)
        field:spawn(shadow, tile)

    end

    local max_rocks = 5
    
    for i=1, max_rocks
    do
        if #list == 0 then break end
        local r = math.random(1, #list)
        spawn_rock(list[r])
        table.remove(list, r)
    end

end

function choose_move(self, field)
    local team = self:get_team()

    local tiles = field:find_tiles(function(tile)
        return tile ~= self:get_current_tile() and can_move_to(tile, self)
    
    end)


    --print("Found ", #tiles, " possible tiles")

    if #tiles == 0 then 
        return self:get_current_tile()
    end

    return tiles[math.random(1, #tiles)]
end

function choose_move_line_up(self, field)
    local team = self:get_team()

    local target = field:find_characters(function(c)
        return c:get_team() ~= team
    end)

    if not target[1] then 
       -- print("No targets")
        return choose_move(self, field)
    end

    t_x = target[1]:get_current_tile():x()
    t_y = target[1]:get_current_tile():y()

    local facing = -1
    if self:get_facing() == Direction.Right then 
        facing = 1
    end

    local tiles = field:find_tiles(function(tile)
        return tile:y() == t_y and facing * (tile:x() - t_x) < -1 and can_move_to(tile, self)
    
    end)

   

    if #tiles == 0 then 
      --  print("No valid tiles")
        return choose_move(self, field)
    end


    return tiles[math.random(1, #tiles)]
end

function choose_move_back(self, field)
    local team = self:get_team()


    local x = 6
    if self:get_facing() == Direction.Right then 
        x = 1
    end

    local tiles = field:find_tiles(function(tile)
        return tile:x() == x and can_move_to(tile, self)
    
    end)

    if #tiles == 0 then 
      --  print("No valid tiles")
        return choose_move(self, field)
    end


    return tiles[math.random(1, #tiles)]
end

function choose_move_back_center(self, field)
    local team = self:get_team()

    local x = 6
    local y = 2

    
    if self:get_facing() == Direction.Right then 
        x = 1
    end

    local t = field:tile_at(x, y)

    if not can_move_to(t, self) then 
        return choose_move_back(self, field)
    end

    return t
end

function choose_near_front(self, field, p)
    local team = self:get_team()
    
    local x = 6

    local facing = self:get_facing()

    if facing == Direction.Right then 
        x = 1
    end

    local front_tiles = {
        field:tile_at(x, 1),
        field:tile_at(x, 2),
        field:tile_at(x, 3)
    }

    local function find_front_row()
        for i=1, #front_tiles
        do
            t = front_tiles[i]
            for j=1, field:width()
            do
                t = t:get_tile(facing, 1)
                if t and not t:is_edge() and t:get_team() == self:get_team() then 
                    front_tiles[i] = t
                else
                    break
                end
            end
        end
    end


    find_front_row()

    local tiles = {
        front_tiles[2],
        front_tiles[2]:get_tile(Direction.reverse(facing), 1),

        front_tiles[1],
        front_tiles[1]:get_tile(Direction.reverse(facing), 1),

        front_tiles[3],
        front_tiles[3]:get_tile(Direction.reverse(facing), 1)
    }

    if p == self.states.flare then 
        if can_move_to(tiles[1], self) then 
            return tiles[1]
        elseif can_move_to(tiles[2], self) then 
            return tiles[2]
        end
    end


    local j = #tiles
    for i=1, #tiles
    do
        r = math.random(1, #tiles)
        if can_move_to(tiles[r], self) then 
            return tiles[r]
        else
            table.remove(tiles, r)
        end
    end

    return choose_move(self, field)

end

function move_line_up(self)
    if self.first_act then 
        anim:set_state("MOVE")

        local tile = choose_move_line_up(self, self:get_field())

        anim:on_frame(3, function()
            if can_move_to(tile, self) then 
               -- print("Can reach")
            else
                --print("Can't do it now")
                tile = self:get_current_tile()
            end
            self:teleport(tile, ActionOrder.Voluntary, function()
               -- print("Move")
            end)
        end)

        anim:on_complete(function()
            increment_pattern(self)
        
        end)

        self.first_act = false
    end
end

function move_to_back(self)
    if self.first_act then 
        anim:set_state("MOVE")

        local tile = choose_move_back(self, self:get_field())

        anim:on_frame(3, function()
            if can_move_to(tile, self) then 
              --  print("Can reach")
            else
                --print("Can't do it now")
                tile = self:get_current_tile()
            end
            self:teleport(tile, ActionOrder.Voluntary, function()
               -- print("Move")
            end)
        end)

        anim:on_complete(function()
            increment_pattern(self)
        
        end)

        self.first_act = false
    end
end

function move_to_back_center(self)
    if self.first_act then 
        anim:set_state("MOVE")

        local tile = choose_move_back_center(self, self:get_field())

        anim:on_frame(3, function()
            if can_move_to(tile, self) then 
              --  print("Can reach")
            else
                --print("Can't do it now")
                tile = self:get_current_tile()
            end
            self:teleport(tile, ActionOrder.Voluntary, function()
                --print("Move")
            end)
        end)

        anim:on_complete(function()
            increment_pattern(self)
        
        end)

        self.first_act = false
    end
end


function move_near_front(self)
    if self.first_act then 
        anim:set_state("MOVE")

        local next = self.pattern[self.pattern_index+1]
        local tile = choose_near_front(self, self:get_field(), next)

        anim:on_frame(3, function()
            if can_move_to(tile, self) then 
           --     print("Can reach")
            else
             --   print("Can't do it now")
                tile = self:get_current_tile()
            end
            self:teleport(tile, ActionOrder.Voluntary, function()
               -- print("Move")
            end)
        end)

        anim:on_complete(function()
            increment_pattern(self)
        
        end)

        self.first_act = false
    end
end



function increment_pattern(self)
   -- print("Pattern increment")
    self.end_attack = false
    self.volley_count = 0

    self.first_act = true
    self.state_done = false
    self.pattern_index = self.pattern_index + 1
    if self.pattern_index > #self.pattern then 
        self.pattern_index = 1
    end

   -- print("Changing to "..self.pattern_index..", which is "..self.pattern[self.pattern_index].name)
    self.state = self.pattern[self.pattern_index]

end

function check_obstacles(tile, self)
    local ob = tile:find_obstacles(function(o)
        return o:get_health() > 0 and (self.mine1 and not o:get_id() == self.mine1:get_id()) or (self.mine2 and not o:get_id() == self.mine2:get_id())
    end)

    return #ob > 0 
end

function can_move_to(tile, self)
    if tile:is_edge() or not tile:is_walkable() then
        return false
    end
	if(tile:is_reserved({}) or (tile:get_team() ~= self:get_team())) then
		return false
	end
    return not check_obstacles(tile, self)
end



function graphic_init(type, x, y, texture, animation, layer, state, user, facing, delete_on_complete, flip)
    flip = flip or false
    delete_on_complete = delete_on_complete or false
    facing = facing or nil
    
    local graphic = nil
    if type == "artifact" then 
        graphic = Battle.Artifact.new()

    elseif type == "spell" then 
        graphic = Battle.Spell.new(user:get_team())
    
    elseif type == "obstacle" then 
        graphic = Battle.Obstacle.new(user:get_team())

    end

    graphic:sprite():set_layer(layer)
    graphic:never_flip(flip)
    graphic:set_texture(texture, true)
    if facing then 
        graphic:set_facing(facing)
    end
    
    if user:get_facing() == Direction.Left then 
        x = x * -1
    end
    graphic:set_offset(x, y)
    local anim = graphic:get_animation()
    anim:load(_folderpath..animation)

    anim:set_state(state)
    anim:refresh(graphic:sprite())

    if delete_on_complete then 
        anim:on_complete(function()
            graphic:delete()
        end)
    end

    return graphic
end