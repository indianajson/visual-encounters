local texture = nil
local attack_texture = nil
local anim = nil
local GUARD_SOUND = nil
local UMBRELLA_SWING_SFX = nil
local BUBBLE_SFX = nil
local WATER_SFX = nil
local LANCE_SFX = nil
local HIT_SFX = nil
local TRAP_SFX = nil
local APPEAR_SFX = nil

function package_init(self)
    texture = Engine.load_texture(_modpath.."Kogasa.png")
    attack_texture = Engine.load_texture(_modpath.."KogasaAttacks.png")
    alert = Engine.load_texture(_modpath.. "overlay_fx07_animations.png")

    self:set_name("Kogasa")
	local rank = self:get_rank()
	if rank == Rank.V1 then
    	self:set_health(1900)
	elseif rank == Rank.V2 then
		self:set_health(2300)

	else
		self:set_health(2700)

	end
	self:set_element(Element.Aqua)
    self:set_texture(texture, true)
    self:set_height(55)
    self:share_tile(false)
    self.max_health = self:get_health()
    self:set_explosion_behavior(8, 8, true)


    anim = self:get_animation()
    anim:load(_modpath.."Kogasa.animation")
    anim:set_state("IDLE")
    anim:set_playback(Playback.Loop)

    self.flinching = false


    GUARD_SOUND = Engine.load_audio(_folderpath.."tink.ogg")
    UMBRELLA_SWING_SFX = Engine.load_audio(_folderpath.."swing.ogg")
    BUBBLE_SFX = Engine.load_audio(_folderpath.."bubble.ogg")
    WATER_SFX = Engine.load_audio(_folderpath.."water.ogg")
    LANCE_SFX = Engine.load_audio(_folderpath.."lance.ogg")
    HIT_SFX = Engine.load_audio(_folderpath.."hit.ogg")
    TRAP_SFX = Engine.load_audio(_folderpath.."trap.ogg")
    APPEAR_SFX = Engine.load_audio(_folderpath.."appear.ogg")


    -- Setting names here is just convenience if I want to print the state I'm in later
    self.states = {
        idle = {name = "idle", func = idle},
        flinch = {name = "flinch", func = flinch},
        move = {name = "move", func = move},
        wait = {name = "wait", func = wait},
        swipe = {name = "swipe", func = swipe},
        stab = {name = "stab", func = stab},
        trap = {name = "trap", func = trap},
        rain = {name = "rain", func = rain},
        mine = {name = "mine", func = mine}

    }
    
    local s = self.states
    self.pattern = {
        s.idle, s.move, s.idle, s.move, s.idle, s.move,
        s.swipe, 
        s.idle, s.move, s.idle, s.move, s.idle, s.move,
        s.stab, 
        s.idle, s.move, s.idle, s.move, s.idle, s.move,
        s.rain,
        s.idle, s.move, s.idle, s.move, s.idle, s.move,
        s.trap,
        s.idle, s.move, s.idle, s.move, s.idle, s.move,
        s.mine,
    }

    self.pattern_index = 1
    self:set_air_shoe(true)
    self:set_float_shoe(true)

    self.nloop = 1
    self.idle_count = 0
    self.mloop = 3
    self.move_count = 0

    self.acting = false
    self.first_act = true

    self.state_done = false

    self.state = self.pattern[1]

    self.first_flinch = true

    self.mine1 = nil
    self.mine2 = nil

    self.mines = {self.mine1, self.mine2}

    self.hit_func = function()
        --print("Hit")
        self.flinching = false
        self.first_act = false
        self.state_done = false
        if self.first_flinch then 
         --   self.state.cleanup
            self.last_state = self.state
            if self.state ~= self.states.idle and self.state ~= self.states.move then 
               -- increment_pattern(self)
            end

            self.first_flinch = false
        end
        self.state = self.states.flinch
        flinch(self)

    end

    self.delete_func = function(self)
        self.update_func = function(self)
            anim:set_state("FLINCH")
            self.state = self.states.flinch
        end

    end


    self.end_attack = false


    local defense = Battle.DefenseRule.new(224,DefenseOrder.CollisionOnly)

    defense.can_block_func = function(judge, attacker, defender)
        local attacker_hit_props = attacker:copy_hit_props()
        if attacker_hit_props.damage > 0 then
            if attacker_hit_props.flags & Hit.Stun == Hit.Stun then 
                self:toggle_hitbox(true)
                self.end_attack = true
            end

            if attacker:get_name() == "Element.Poison" then 
                attacker_hit_props.damage = attacker_hit_props.damage + attacker_hit_props.damage
                attacker:set_hit_props(attacker_hit_props)

                local alert = graphic_init("artifact", 32, 0, alert, "overlay_fx07_animations.animation", -9, "0", defender, defender:get_facing(), true)
                local y = defender:get_height()+14
                if y < 20 then 
                    y = 40
                end
                alert:set_elevation(y)
                defender:get_field():spawn(alert, defender:get_current_tile())

            end

        end


    end

    self:add_defense_rule(defense)
    self:register_status_callback(Hit.Flinch, self.hit_func)
    self:register_status_callback(Hit.Stun, self.hit_func)

    self.on_countered = function(self)
        --print("Countered")
        self:toggle_counter(false)

    end

    self.update_func = function(self)
        self.state.func(self)
    end
end

function wait(self)

end

function idle(self)
    if self.first_act then 
        if anim:get_state() ~= "IDLE" then 
            anim:set_state("IDLE")
        end
        anim:set_playback(Playback.Loop)

        anim:on_complete(function()
            if not self.looped then 
                --self.looped = true
                self.idle_count = self.idle_count+1
                --print("Complete"..self.idle_count)

                if self.idle_count >= self.nloop then 
                    self.state_done = true
                  --  print("Looped three times")
                    
                end
            end

            self.looped = not self.looped
        
        end)

        self.first_act = false
    end

    --self.looped = false
    if self.state_done then 
       -- print("State done")
        self.idle_count = 0
        self.state_done = false
        increment_pattern(self)
    end
end

function hit()
    

end

function flinch(self)
  --  print("Flinch played")
    self.looped = false

    if not self.flinching then 
        anim:set_state("FLINCH")        
        anim:on_complete(function()
          --  print("Anim done")
            self.flinching = false
            self.state_done = true
            self.first_flinch = false

            self.looped = true

           -- print("Done")
            self.state_done = false
            if self.last_state ~= self.states.idle and self.last_state ~= self.states.move then 
             --   print("Last state was not idle or move")
                increment_pattern(self)
            else
               -- print("Last state was idle or move")
                self.state = self.last_state
                self.first_act = true
            end

        end)

    end

    self.flinching = true
   
end


function swipe(self)
    if self.first_act then 
        
        anim:set_state("SWIPE")
        anim:on_frame(1, function()
            self:toggle_counter(true)
        end)
        anim:on_frame(4, function()
            select_swipe(self)
            self:toggle_counter(false)
        end)

        anim:on_complete(function()
          --  print("Done")
            increment_pattern(self)
        
        end)

        self.first_act = false
    end

end


function select_swipe(self)
    local tile = self:get_current_tile()
    local facing = self:get_facing()
    local field = self:get_field()


    local function select_valid_front()
        while(tile:get_team() == self:get_team())
        do
            local next_tile = tile:get_tile(facing, 1)
            if next_tile:is_edge() then 
                --print("Breaking")
                break
            end

            if next_tile:get_team() == self:get_team() then 
                tile = next_tile
            else
                break
            end
  
        end
        

        tile = field:tile_at(tile:x(), 2)



    end

    local function select_valid_behind()
        local tiles

        if self:get_facing() == Direction.Left then 
            tiles = {
                field:tile_at(1, 2),
                field:tile_at(1, 1),
                field:tile_at(1, 3)
            }
        else 
            tiles = {
                field:tile_at(6, 2),
                field:tile_at(6, 1),
                field:tile_at(6, 3)
            } 
        end

        tile = tiles[1]
    end
  
    local function select_tile_method(facing)
        if facing == self:get_facing() then 
            select_valid_front()
        else
            select_valid_behind()
        end

    end

    if math.random(0, 1) == 1 then 
        facing = self:get_facing_away()
    end

    select_tile_method(facing)

    spawn_swipe(self, tile, facing)

end

function reflect_attack(user, id)
    local spell = Battle.Spell.new(user:get_team())
    spell:set_facing(user:get_facing())
    local facing = spell:get_facing()
    local field = user:get_field()

    local function create_effect()
        local spell2 = graphic_init("spell", 0, 0, attack_texture, "Kogasa.animation", -3, "REFLECT", spell, spell:get_facing(), true)

    end

    local hit_props = HitProps.new(70,
                                    Hit.Impact | Hit.Flinch | Hit.Flash,
                                    Element.None, id, Drag.None)

    spell:set_hit_props(hit_props)

    spell.update_func = function(self)
        self:get_tile():attack_entities(self)
        if self:is_sliding() == false then
            if self:get_current_tile():is_edge() and self.slide_started then 
                self:delete()
            end 
            
            local dest = self:get_tile(facing, 1)
            local ref = self
            self:slide(dest, frames(0), frames(0), ActionOrder.Voluntary, 
                function()                           
                    ref.slide_started = true 
                    field:spawn(graphic_init("spell", 0, 0, attack_texture, "Kogasa.animation", -3, "REFLECT", spell, spell:get_facing(), true), ref:get_current_tile())
                end)
        end
    end

    spell.can_move_to_func = function()
        return true
    end


    field:spawn(spell, user:get_tile(facing, 1))
end

function spawn_swipe(self, tile, facing)
    local field = self:get_field()
    local umbrella = graphic_init("obstacle", 0, 0, attack_texture, "Kogasa.animation", -3, "UMBRELLA_SWIPE", self, facing, true)

    local facing = umbrella:get_facing()
    local guarding = false
    local should_reflect = false
    local guarded = false

    local hit_props = HitProps.new(70,
                                    Hit.Impact | Hit.Flinch | Hit.Flash,
                                    Element.Aqua, self:get_id(), Drag.None)
    
    umbrella:set_hit_props(hit_props)

    local comp = Battle.Component.new(umbrella, Lifetimes.Local)
    comp.update_func = function()
        umbrella:toggle_hitbox(true)
        if should_reflect then 
            --print("Reflecting")
            reflect_attack(umbrella, self:get_id())
            should_reflect = false
        end

    end

    umbrella:register_component(comp)

    local defense = Battle.DefenseRule.new(0,DefenseOrder.Always)

    defense.can_block_func = function(judge, attacker, defender)
        if not guarding then 
            umbrella:toggle_hitbox(false)
            return 
        end
        if guarded then 
            return
        end

        local attacker_hit_props = attacker:copy_hit_props()
        if attacker_hit_props.damage > 0 then
            judge:block_impact()
            judge:block_damage()
            guarded = true
            should_reflect = true

            field:spawn(graphic_init("spell", 0, -32, attack_texture, "Kogasa.animation", -4, "GUARD", umbrella, umbrella:get_facing(), true), umbrella:get_current_tile())
            Engine.play_audio(GUARD_SOUND, AudioPriority.Low)

        end


    end

    umbrella:add_defense_rule(defense)
    umbrella:set_health(9999)
    umbrella:share_tile(true)


    local tile_list = {
        tile:get_tile(facing, 1),
        tile:get_tile(facing, 2),
        tile:get_tile(Direction.Down, 1),
        tile:get_tile(Direction.join(facing, Direction.Up), 1),
        tile:get_tile(Direction.join(facing, Direction.Down), 1)

    }

    local attack_tiles1 = {
        tile_list[2],
        tile_list[4]

    }

    local attack_tiles2 = {
        tile_list[1],
        tile_list[2],
        tile_list[4]

    }

    local attack_tiles3 = {
        tile_list[1],
        tile_list[5]

    }

    local attack_tiles4 = {
        tile_list[3],

    }

    umbrella:get_animation():on_frame(2, function()
        umbrella.update_func = function(self)
            for i=1, #tile_list
            do
                local t = tile_list[i]
                if t and not t:is_edge() then 
                    t:highlight(Highlight.Solid)
                end
            end
    
        end
    
    end)

    umbrella:get_animation():on_frame(6, function()
        Engine.play_audio(UMBRELLA_SWING_SFX, AudioPriority.Low)
        umbrella.update_func = function(self)
            for i=1, #attack_tiles1
            do
                local t = attack_tiles1[i]
                if t and not t:is_edge() then 
                    t:attack_entities(self)
                    t:highlight(Highlight.Solid)
                end

            end
        end
    
    end)

    umbrella:get_animation():on_frame(7, function()
        guarding = true
        umbrella.update_func = function(self)
            for i=1, #attack_tiles2
            do
                local t = attack_tiles2[i]
                if t and not t:is_edge() then 
                    t:attack_entities(self)
                    t:highlight(Highlight.Solid)
                end

            end
        end
    
    end)

    umbrella:get_animation():on_frame(8, function()
        umbrella.update_func = function(self)
            for i=1, #attack_tiles3
            do
                local t = attack_tiles3[i]
                if t and not t:is_edge() then 
                    t:attack_entities(self)
                    t:highlight(Highlight.Solid)
                end

            end
        end
    
    end)

    umbrella:get_animation():on_frame(9, function()
        guarding = false
        umbrella.update_func = function(self)
            for i=1, #attack_tiles4
            do
                local t = attack_tiles4[i]
                if t and not t:is_edge() then 
                    t:attack_entities(self)
                    t:highlight(Highlight.Solid)
                end

            end
        end
    
    end)

    umbrella:get_animation():on_frame(4, function()
        umbrella.update_func = function(self)
           
        end
    
    end)

    umbrella:get_animation():on_frame(10, function()
        umbrella.update_func = function(self)
           
        end
    
    end)
    

    field:spawn(umbrella, tile)
    anim:on_interrupt(function()
        if not umbrella:is_deleted() then 
            umbrella:delete()
        end
    end)

    if self.end_attack then 
        if not umbrella:is_deleted() then 
            umbrella:delete()
            self.end_attack = false

        end
    end

end


function rain(self)
    if self.first_act then 
        local list
        anim:set_state("UMBRELLA_SPIN")
        anim:on_frame(1, function()
            self:toggle_counter(true)
        end)
        -- 5-6 highlight, 8-10 shoot
        local drops = 3
        if self:get_health() <= self.max_health/2 then 
            drops = 5
        end
        anim:on_frame(5, function()
            list = get_rain_tiles(self, drops)
            highlight_tiles(self, list, 18)
        end)

        
        for i=1, drops
        do
            anim:on_frame(7+i, function()
                self:toggle_counter(false)
                throw_rain(self, list[i])
            
            end)
        end

        anim:on_complete(function()
           -- print("Done")
            increment_pattern(self)
        
        end)

        self.first_act = false
    end


end


local function attach_slip(other)
    local c = Battle.Player.from(other)
    if not c then 
        c = Battle.Character.from(other)
    end

    if not c then return end
    other = c

    local sliding_component = nil
    local dir
    local start_tile = other:get_current_tile()

    
    local list = other:get_field():find_entities(function(e) return e:get_name() == "SLIP_CONTROLLER"..other:get_id() end)        
    if list[1] then 
        list[1]:set_name("RESET")
        return
    end

    local artifact = Battle.Spell.new(other:get_team())
    artifact:set_name("SLIP_CONTROLLER"..other:get_id())
    artifact:set_health(1)
    -- artifact:toggle_hitbox(true)
    local time_remaining = 599

    local function find_dir(s, c)
        local dest
        local dir
        local x = s:x() - c:x()

        local y = s:y() - c:y()

        if y > 0 then 
            dir = Direction.Up
        elseif y < 0 then 
            dir = Direction.Down

        end

        if x > 0 then 
            dir = Direction.Left
        elseif x < 0 then 
            dir = Direction.Right
        end

        if not dir then return nil end

        dest = c:get_tile(dir, 1)

        return dir
    end


    local function create_slide(start_tile)
        local component = Battle.Component.new(other, Lifetimes.Battlestep)

        component.update_func = function()
            if not other:is_moving() then 
               -- print("Going to slide")
                local cur_tile = other:get_current_tile()
                --print("Cur tile is ", start_tile:x(), start_tile:y())

                dir = find_dir(start_tile, cur_tile)

                local move = MoveEvent.new() 
                    move.delta_frames = frames(4)
                    move.delay_frames = frames(0)
                    move.endlag_frames = frames(0)
                    move.height = 0
                    move.dest_tile = cur_tile:get_tile(dir, 1)
                    move.on_begin_func = function() end
        
                
        
                -- local slide_succeded = other:slide(cur_tile:get_tile(dir, 1), frames(4), frames(0), ActionOrder.Immediate, nil)
                local slide_succeded = other:raw_move_event(move, ActionOrder.Immediate)
                if not slide_succeded then 
                   -- print("Couldn't slide right now")
                    sliding_component = nil
                    component:eject()
                end
            end
        end
        
        sliding_component = component
        other:register_component(component)

        
    end


    local component = Battle.Component.new(other, Lifetimes.Battlestep)
    local colored = false
    local mode = other:sprite():get_color_mode()
    local defense = Battle.DefenseRule.new(224,DefenseOrder.CollisionOnly)

    component.update_func = function()
        if artifact:get_name() == "RESET" then
            time_remaining = 599
            artifact:set_name("SLIP_CONTROLLER"..other:get_id())
        end


       -- print(other:is_moving())
        if first_move and not sliding_component and start_tile ~= other:get_current_tile() then 
           -- start_tile = other:get_current_tile()
          --  print("Start tile is ", start_tile:x(), start_tile:y())

            create_slide(start_tile)
            first_move = false
        else
            first_move = true
            start_tile = other:get_current_tile()

        end



        if time_remaining == 0 or artifact:get_name() == "DELETE" then 
            artifact:delete()
            component:eject()
            other:sprite():set_color_mode(mode)
            other:remove_defense_rule(defense)
            return
        end
        time_remaining = time_remaining - 1


        if time_remaining % 3 == 1 then 
            other:sprite():set_color_mode(ColorMode.Multiply)

        end
        if time_remaining % 3 == 0 then 
            local color = Color.new(30, 170, 20, 255)
            other:set_color(color)
            other:sprite():set_color_mode(mode)
    
            colored = true
        end


    end


    defense.can_block_func = function(judge, attacker, defender)
    

        local attacker_hit_props = attacker:copy_hit_props()
        if attacker_hit_props.damage > 0 then
            if attacker_hit_props.element == Element.Elec then 
                attacker_hit_props.damage = attacker_hit_props.damage + attacker_hit_props.damage
                attacker:set_hit_props(attacker_hit_props)

                local alert = graphic_init("artifact", 0, -32, alert, "overlay_fx07_animations.animation", -9, "0", defender, defender:get_facing(), true)
                local y = defender:get_height()+14
                if y < 20 then 
                    y = 40
                end
                alert:set_elevation(y)
                defender:get_field():spawn(alert, defender:get_current_tile())
                if sliding_component then 
                    sliding_component:eject()
                    sliding_component = nil
                    defender:sprite():set_color_mode(mode)


                end

                artifact:set_name("DELETE")


            end

        end


    end

    other:add_defense_rule(defense)

    other:register_component(component)
    other:get_field():spawn(artifact, other:get_field():tile_at(1, 1))

end

function throw_rain(self, dest)
    if not dest then return end
    local start = self:get_current_tile()
    local offset = -160
    local time = 42

    local d_y = offset/time

    local rain = graphic_init("spell", 0, offset, attack_texture, "Kogasa.animation", -4, "RAIN", self, self:get_facing())


    local function rain_land()
        local splash = graphic_init("artifact", 0, offset, attack_texture, "Kogasa.animation", -4, "SPLASH", self, self:get_facing(), true)
        local splash_box = Battle.Spell.new(self:get_team())
        
        local hit_props = HitProps.new(
            70,
            Hit.Impact | Hit.Flinch | Hit.Flash,
            Element.Aqua, 
            self:get_id(), 
            Drag.None
        )

        splash_box:set_hit_props(hit_props)

        splash_box.update_func = function(self)
            Engine.play_audio(WATER_SFX, AudioPriority.Low)
            self:get_current_tile():attack_entities(self)
            self:delete()

        end
        
        local first = true
        splash.update_func = function(self)
            if first then 
                self:get_field():spawn(splash_box, dest)
                first = false
            end
            

        end

        splash_box.attack_func = function(self, other)
            if other:get_element() == Element.Aqua then return end
            attach_slip(other)
        end

        self:get_field():spawn(splash, dest)
    end

    rain.update_func = function()
        --print(offset)
        rain:set_offset(0, offset)
        offset = offset - d_y

        if offset >= 0 then 
            rain:delete()
            rain_land()
        end

    end

    rain.can_move_to_func = function()
        return true
    end

    self:get_field():spawn(rain, start)
    Engine.play_audio(BUBBLE_SFX, AudioPriority.Low)


    rain:jump(dest, 150, frames(time), frames(0), ActionOrder.Immediate, function()
        --print("Started jump")
    end) 
end

function highlight_tiles(self, list, time)
    local spell = Battle.Spell.new(self:get_team())


    local ref = self
    spell.update_func = function(self)
        for i=1, #list
        do 
            local t = list[i]
            if t and not t:is_edge() then 
                t:highlight(Highlight.Solid)
            end

        end


        time = time - 1
        if time == 0 then 
            self:delete()
        end

        if self.flinching then 
            if spell and not spell:is_deleted() then 
                spell:delete()
    
            end
        end
    end


    self:get_field():spawn(spell, self:get_current_tile())
end

function get_rain_tiles(self, drops)
    local field = self:get_field()
    local list = {}
    local iter = 1
    local max_tiles = drops
    local team = self:get_team()
    local closest_tile = nil
    local x = self:get_current_tile():x()
    local facing = self:get_facing()

    local function not_behind(tile)
        return facing == Direction.Left and x >= tile:x() or x <= tile:x()
    end

    

    local tile_filter = function(tile)
        return not tile:is_edge() and tile:get_team() ~= team and (not closest_tile or (closest_tile and closest_tile ~= tile)) and not_behind(tile)

    end

    local character_filter = function(character)
        return character:get_team() ~= team and tile_filter(character:get_current_tile())
    end

    local chars = field:find_nearest_characters(self, character_filter)
    if chars[1] then 
        closest_tile = chars[1]:get_current_tile()
        list[1] = closest_tile
        iter = 2
    end

    local p_tiles = field:find_tiles(tile_filter)

    -- If for some reason there are no tiles here, we'll probably infinite loop next
        -- So need to get out now
    if #p_tiles == 0 then 
        return list
    end

    while iter < max_tiles+1
    do
       -- print("Choosing from ", #p_tiles)

        local r = math.random(#p_tiles)
        list[iter] = p_tiles[r]
        table.remove(p_tiles, r)
        if #p_tiles == 0 then 
            p_tiles = field:find_tiles(tile_filter)
        end
      --  print("Chose ", list[iter]:x(), list[iter]:y())

        iter = iter + 1
    end


    --print("Returning list with ", #list)
    return list
end

function create_umbrella_shield(self)
    local umbrella = Battle.Obstacle.new(self:get_team())
    umbrella:set_health(9999)

    umbrella:share_tile(true)

    local defense_rule = Battle.DefenseRule.new(1, DefenseOrder.CollisionOnly)
    defense_rule.can_block_func = function(judge, attacker, defender)
        local attacker_hit_props = attacker:copy_hit_props()
        if attacker_hit_props.damage > 0 then
        --    judge:block_impact()
            judge:block_damage()
            self:get_field():spawn(graphic_init("spell", 0, -16, attack_texture, "Kogasa.animation", -4, "GUARD", self, self:get_facing(), true), umbrella:get_current_tile())
            Engine.play_audio(GUARD_SOUND, AudioPriority.Low)

        end

    end

    umbrella:add_defense_rule(defense_rule)

    umbrella:set_float_shoe(true)
    umbrella:set_air_shoe(true)

    umbrella.can_move_to_func = function()
        return true
    end

    return umbrella
end

function stab(self)
    if self.first_act then 
        anim:set_state("STAB")
        local facing = self:get_facing()

        local field = self:get_field()
        local tiles = {}
        local spell_list = {}
        local start_tile
        local hide_tile = self:get_field():tile_at(7, 4)

        local should_remove = false
        local should_remove2 = false

        local attack_facing 
        local shield

        anim:on_frame(1, function()
            self:toggle_counter(true)
        end)

        local function end_early(second)
            hide_tile:remove_entity_by_id(self:get_id())
            start_tile:add_entity(self)
            should_remove = true
            self:set_facing(facing)
            self:reveal()

            anim:set_state("STAB_END")
            if not second then 
              --  anim:set_playback(Playback.Reverse)
            end
            anim:refresh(self:sprite())

            anim:on_complete(function()
                increment_pattern(self)
            
            end)
        end

        anim:on_frame(4, function()
            start_tile = self:get_current_tile()
          --  print("Hide")
            self:hide()
            self:get_current_tile():remove_entity_by_id(self:get_id())
            hide_tile:add_entity(self)
            self:toggle_hitbox(false)

            tiles = find_stab_tiles(self)
            if not tiles[1] then 
              --  print("End early 1")
                end_early(false)
                return
            end
            attack_facing = tiles[3]
            table.remove(tiles, 3)
            highlight_tiles(self, tiles, 18)


            local component = Battle.Component.new(self, Lifetimes.Local)

            component.update_func = function()
                start_tile:reserve_entity_by_id(self:get_id())
                if should_remove then
                    component:eject()
                end
            end

            start_tile:reserve_entity_by_id(self:get_id())

            --self:register_component(component)

        end)


        
        anim:on_frame(9, function()
            if not can_move_to_stab(tiles[1], self) then 
               -- print("End early 2")
                end_early(true)
                return
            end

            hide_tile:remove_entity_by_id(self:get_id())
            tiles[1]:add_entity(self)
          --  print("Moving")

            self:set_facing(attack_facing)
            shield = create_umbrella_shield(self)

            spell_list[1] = make_stab_attack(self)
            spell_list[2] = make_stab_attack(self)
            field:spawn(spell_list[1], tiles[1])
            field:spawn(spell_list[2], tiles[2])
            field:spawn(shield, tiles[2])



            self:reveal()
            self:toggle_hitbox(true)
        end)

        anim:on_frame(11, function()
            highlight_tiles(self, {self:get_tile(self:get_facing(), 2)}, 18)
        end)

        anim:on_frame(14, function()
            self:toggle_counter(false)
            spell_list[3] = make_stab_attack(self, true)
            field:spawn(spell_list[3], self:get_tile(self:get_facing(), 2))

            Engine.play_audio(LANCE_SFX, AudioPriority.Low)
        end)

        anim:on_frame(16, function()
            shield:slide(shield:get_current_tile():get_tile(attack_facing, 1), frames(0), frames(0), ActionOrder.Immediate, nil)
        
        end)

        anim:on_frame(22, function()
            spell_list[3]:delete()
            shield:delete()

        end)

        anim:on_frame(24, function()
            self:get_current_tile():remove_entity_by_id(self:get_id())
            start_tile:add_entity(self)
            should_remove = true
            self:set_facing(facing)

            for i=1, #spell_list
            do
                local spell = spell_list[i]
                if spell and not spell:is_deleted() then 
                    spell:delete()

                end
            end
        end)


        anim:on_complete(function()
         --   print("Done")
            self:set_facing(facing)
        
            increment_pattern(self)
        end)

        anim:on_interrupt(function()
          --  print("Interrupt")
            self:set_facing(facing)
            if not should_remove and tiles[1] then 
                self:get_current_tile():remove_entity_by_id(self:get_id())
                start_tile:add_entity(self)
                should_remove = true
            end

            for i=1, #spell_list
            do
                local spell = spell_list[i]
                if spell and not spell:is_deleted() then 
                    spell:delete()

                end
            end

            if shield and not shield:is_deleted() then 
                shield:delete()
            end
        end)

        self.first_act = false
    end



end

function find_stab_tiles(self)
    local field = self:get_field()
    local facing = self:get_facing()
    if math.random(0, 1) == 1 then 
       -- print("Coming from behind")
        facing = self:get_facing_away()
    end

    local character_filter = function(character)
        return character:get_team() ~= team
    end

    local chars = field:find_nearest_characters(self, character_filter)

    if not chars[1] then 
        return {}
    end

    local target = chars[1]:get_current_tile()


    local attempt_list = {
        target:get_tile(Direction.reverse(facing), 2),
        target:get_tile(Direction.reverse(facing), 1),
        target:get_tile(facing, 2),
        target:get_tile(facing, 1)
    }

    local tile1 
    for i=1, #attempt_list
    do
        if i == 3 then 
            facing = Direction.reverse(facing)
        end

        local candidate = attempt_list[i]
        if candidate then 
            local allies = candidate:find_characters(function(c) return c ~= self and c:get_team() == self:get_team() end)

            if can_move_to_stab(candidate, self) and not allies[1] then 
                tile1 = candidate
                break
            else
        end

    end

    

    end

    if not tile1 then 
        return {}
    end

    local tile2 = tile1:get_tile(facing, 1)


    return {tile1, tile2, facing}
end

function make_stab_attack(self, third)
    third = false or third
    local spell = Battle.Spell.new(self:get_team())

    elem = Element.None

    if third then 
        elem = Element.Sword
    end
    local hit_props = HitProps.new(
            70,
            Hit.Impact | Hit.Flinch | Hit.Flash,
            elem, 
            self:get_id(), 
            Drag.None
        )

    spell:set_hit_props(hit_props)

    spell.update_func = function(self)
        self:get_current_tile():attack_entities(self)
    end


    return spell
end


function trap(self)
    if self.first_act then 
        anim:set_state("TRAP")
        anim:on_frame(1, function()
            self:toggle_counter(true)
        end)
        -- 5-6 highlight, 8-10 shoot
        anim:on_frame(3, function()
            if self:get_health() <= self.max_health/2 then 
                create_mines(self)
            end
            
        end)

        anim:on_frame(7, function()
            self:toggle_counter(false)
            umbrella_trap(self, 3)
        end)

        anim:on_complete(function()
            --print("Done")
           -- increment_pattern(self)
        
        end)

        self.first_act = false
    end


end


function umbrella_trap(self, times)
    local target_tile = nil
    local field = self:get_field()

 

    local team = self:get_team()
    local character_filter = function(character)
        return character:get_team() ~= team
    end

    local chars = field:find_nearest_characters(self, character_filter)
    if chars[1] then 
        target_tile = chars[1]:get_current_tile()

    end

    local function umbrella_attack(tile, umb)
        local action = Battle.CardAction.new(self, "TRAP_ATTACK")
        action:set_lockout(make_sequence_lockout())

        local function attack()
            local spell = Battle.Spell.new(self:get_team())

            local hit_props = HitProps.new(
                70,
                Hit.Impact | Hit.Flinch | Hit.Flash | Hit.Pierce | Hit.Breaking,
                Element.Aqua, 
                self:get_id(), 
                Drag.None
            )

            spell:set_hit_props(hit_props)

            spell.update_func = function(self)
                self:get_current_tile():attack_entities(self)
                self:delete()
            end

            spell.attack_func = function()
                Engine.play_audio(HIT_SFX, AudioPriority.Low)

            end

            field:spawn(spell, tile)
        end

        local step = Battle.Step.new()
        local first = true

        

        step.update_func = function()

        end


        action.execute_func = function()
            action:get_actor():get_animation():set_state("TRAP_ATTACK")
            action:add_step(step)
            local umbrella = graphic_init("artifact", 0, 0, attack_texture, "Kogasa.animation", -4, "UMBRELLA_TRAP_ATTACK", self, self:get_facing(), true)

            
            for i=1, 3
            do
                umbrella:get_animation():on_frame(7+4*i, function()
                    attack()
                end)
            end
            
            umbrella:get_animation():on_complete(function()
                step:complete_step()
                increment_pattern(self)
            end)

            field:spawn(umbrella, tile)
            if not umb:is_deleted() then
                umb:delete()
            end

        end


        local meta = action:copy_metadata()
        meta.shortname = "Surprise!"
        meta.time_freeze = true
        meta.skip_time_freeze_intro = true
        action:set_metadata(meta)
        self:card_action_event(action, ActionOrder.Voluntary)
        
    end

    local function create_umbrella(tile)
        local umbrella = graphic_init("spell", 0, 0, attack_texture, "Kogasa.animation", -4, "UMBRELLA_TRAP_START", self, self:get_facing(), true)
        local highlighting = true
        local hit = false

        local function land(tile)
            local spell = Battle.Spell.new(team)


            local hit_props = HitProps.new(
                0,
                Hit.Pierce,
                Element.None, 
                self:get_id(), 
                Drag.None
            )
    
            spell:set_hit_props(hit_props)

            spell.update_func = function(self)
               -- print("Attack")

                tile:attack_entities(self)
                self:delete()
            end

            spell.attack_func = function(self, other)
                if umbrella:is_deleted() then 
                    return 
                end
               -- print("HIT")
                local alert = graphic_init("artifact", 0, 0, alert, "overlay_fx07_animations.animation", -9, "0", spell, spell:get_facing(), true)
                local y = other:get_height()+14
                if y < 20 then 
                    y = 40
                end
                alert:set_elevation(y)
                local facing = other:get_facing()
                local x = -32
                if facing == Direction.Right then
                    x = x*-1
                end
                alert:set_offset(x, 0)
                field:spawn(alert, other:get_current_tile())
                Engine.play_audio(TRAP_SFX, AudioPriority.Low)
                umbrella_attack(tile, umbrella)
                hit = true
            end

            field:spawn(spell, tile)
        end

        umbrella.update_func = function()
            if highlighting then 
                tile:highlight(Highlight.Solid)
            end


        end

     
        local anim = umbrella:get_animation()

        anim:on_frame(3, function()
            highlighting = false
        
        end)

        anim:on_frame(5, function()
            land(tile)            
        end)

        anim:on_complete(function()
            if not hit then 
                anim:set_state("UMBRELLA_TRAP_END")
                anim:refresh(umbrella:sprite())
                anim:on_complete(function()
                    umbrella:delete()
                    if times > 1 then 
                        umbrella_trap(self, times-1)
                    else
                        increment_pattern(self)
                    end

                    -- Put stuff for ending Kogasa anim here?
                end)
            end
        
        end)

        self:get_animation():on_interrupt(function()
            if not umbrella:is_deleted() then 
                umbrella:delete()
            end
        end)

        if self.end_attack then 
            if not umbrella:is_deleted() then 
                umbrella:delete()
                self.end_attack = false

            end
        end
        field:spawn(umbrella, tile)
       -- print("Spawning umbrella")

    end


    create_umbrella(target_tile)

end


function mine(self)
    if self.first_act then 
        anim:set_state("SUMMON_MINES")
        anim:on_frame(1, function()
            self:toggle_counter(true)
        end)
        anim:on_frame(4, function()
            self:toggle_counter(false)

            create_mines(self)
        end)

        anim:on_complete(function()
           -- print("Done")
            increment_pattern(self)
        
        end)

        self.first_act = false
    end


end

function create_mines(self)
    local field = self:get_field()
    local tile_list = select_mine_tiles(self)


    local function spawn_fading_mine(tile)
        local mine = graphic_init("artifact", 0, 0, attack_texture, "Kogasa.animation", 4, "MINE_FADE", self, self:get_facing(), true)



        field:spawn(mine, tile)
    end
    
    local function spawn_mine(tile, num)
        local mine = graphic_init("obstacle", 0, 0, attack_texture, "Kogasa.animation", 4, "MINE_APPEAR", self, self:get_facing())
        mine.lifetime = 600

        local hit_props = HitProps.new(
            20,
            Hit.Impact | Hit.Flinch | Hit.Stun,
            Element.Elec, 
            self:get_id(), 
            Drag.None
        )

        local spell = Battle.Spell.new(mine:get_team())
		spell:set_hit_props(hit_props)
        mine:set_health(1)
        mine:share_tile(true)

        spell.update_func = function(self)
            self:get_current_tile():attack_entities(self)
            mine.lifetime = mine.lifetime - 1
            
            if self.lifetime == 0 then
                mine:delete()
            end

        end

        mine.delete_func = function(self)
            spawn_fading_mine(self:get_current_tile())
            if spell and not spell:is_deleted() then 
                spell:delete()
            end

        end
        spell.collision_func = function(self)
            self:delete()
            mine:erase()

        end

        local defense = Battle.DefenseRule.new(0,DefenseOrder.Always)

        defense.can_block_func = function(judge, attacker, defender)
            local attacker_hit_props = attacker:copy_hit_props()


            if attacker_hit_props.damage > 0 and (attacker_hit_props.flags & Hit.Breaking == Hit.Breaking) or (attacker_hit_props.element & Element.Cursor == Element.Cursor) then
               -- print("Mine hit by breaking")
                return

            end

            mine:toggle_hitbox(false)


        end

        mine.update = function(self)
            self:toggle_hitbox(true)
        end

        mine:add_defense_rule(defense)

        self.mines[num] = mine
        field:spawn(mine, tile)
        field:spawn(spell, tile)
        Engine.play_audio(APPEAR_SFX, AudioPriority.Low)
    
    end


    local iter
    for i=1, #tile_list
    do
        if self.mines[i] and not self.mines[i]:is_deleted() then
            self.mines[i]:delete()
        end
        spawn_mine(tile_list[i], i)
    end

end

function select_mine_tiles(self)
    local field = self:get_field()
    local tiles = {}
    local team = self:get_team()
    local tile_filter = function(tile)
        --print("Tile ".. tile:x().. tile:y().. " has "..#(tile:find_characters(function(c) return c ~= self end)))
        return not tile:is_edge() and tile:get_team() ~= team and not (tile:get_state() == TileState.Broken or tile:get_state() == TileState.Empty)
            and not check_obstacles(tile, self) and #(tile:find_characters(function(c) return c ~= self end)) == 0

    end

    local p_tiles = field:find_tiles(tile_filter)

    local iter = 1
    while iter < 3
    do
        --print("Choosing from ", #p_tiles)
        if #p_tiles == 0 then 
            break
        end
        local r = math.random(#p_tiles)
        tiles[iter] = p_tiles[r]
        table.remove(p_tiles, r)
       
       -- print("Chose ", tiles[iter]:x(), tiles[iter]:y())

        iter = iter + 1
    end

    return tiles

end

function move(self)
    if not self.first_act and not self:is_sliding() then 
        increment_pattern(self)
        self:toggle_hitbox(true)
        return
    end

    if self.first_act then 
       -- print("Moving now")
       -- self:get_animation():set_state("MOVE_SLIDE")
        move_slide(self)
        self.first_act = false
    end


end

function move_slide(self)
    local field = self:get_field()
    local dest_tile = self:get_current_tile()
    local start_tile = self:get_current_tile()
    local p_tiles = field:find_tiles(function(tile)
        return can_move_to(tile, self)
    end)



    local search_tile = start_tile

    if #p_tiles > 0 then 
        dest_tile = p_tiles[math.random(1, #p_tiles)]
    end

    

    local move_speed = 12

   -- print("Moving to: ", dest_tile:x(), dest_tile:y())


    local function spawn_afterimage(self)
        local tile = self:get_current_tile()
        local afterimage = graphic_init("artifact", -1*self:get_tile_offset().x, self:get_tile_offset().y, texture, "Kogasa.animation", 4, "AFTERIMAGE", self, self:get_facing(), true)

        afterimage:sprite():set_color_mode(ColorMode.Multiply)

        local color = Color.new(40, 40, 120, 255)
        local sprite = afterimage:sprite()
        afterimage.update_func = function(self)
            sprite:set_color(color)
        end

        afterimage:get_animation():on_frame(3, function()
         --   color = Color.new(40, 40, 80, 255)
        
        end)

        field:spawn(afterimage, tile)
    end
    
    self:slide(dest_tile, frames(move_speed), frames(0), ActionOrder.Voluntary, function()
      --  print("Starting slide")

        if start_tile ~= dest_tile then
            self:toggle_hitbox(false)
 
            local component = Battle.Component.new(self, Lifetimes.Local)

            dest_tile:reserve_entity_by_id(self:get_id())

            local last_x = 0
            local last_y = 0
            local afterimage_time = 0
            component.update_func = function()
             --   print("On ", self:get_current_tile():x(), self:get_current_tile():y())
                
                if afterimage_time % 4 == 0 then 
                --    print("Spawn")
                    spawn_afterimage(self)
                end
                afterimage_time = afterimage_time + 1

                
                if not self:is_sliding() then 
                   -- print("Ejecting")
                    component:eject()
                end
            end

            self:register_component(component)
        end
    end)

end


function increment_pattern(self)
   -- print("Pattern increment")
    self.end_attack = false

    self.first_act = true
    self.state_done = false
    self.pattern_index = self.pattern_index + 1
    if self.pattern_index > #self.pattern then 
        self.pattern_index = 1
    end

   -- print("Changing to "..self.pattern_index..", which is "..self.pattern[self.pattern_index].name)
    self.state = self.pattern[self.pattern_index]

end

function can_move_to_stab(tile, self)
    if not tile then 
        return false
    end

    if (tile:is_edge()) then 
        return false
    end

    return not check_obstacles(tile, self)

end 

function check_obstacles(tile, self)
    local ob = tile:find_obstacles(function(o)
        return o:get_health() > 0 and (self.mine1 and not o:get_id() == self.mine1:get_id()) or (self.mine2 and not o:get_id() == self.mine2:get_id())
    end)

    return #ob > 0 
end

function can_move_to(tile, self)
    if tile:is_edge() then
        return false
    end
	if(tile:is_reserved({}) or (tile:get_team() ~= self:get_team())) then
		return false
	end
    return not check_obstacles(tile, self)
end



function graphic_init(type, x, y, texture, animation, layer, state, user, facing, delete_on_complete, flip)
    flip = flip or false
    delete_on_complete = delete_on_complete or false
    facing = facing or nil
    
    local graphic = nil
    if type == "artifact" then 
        graphic = Battle.Artifact.new()

    elseif type == "spell" then 
        graphic = Battle.Spell.new(user:get_team())
    
    elseif type == "obstacle" then 
        graphic = Battle.Obstacle.new(user:get_team())

    end

    graphic:sprite():set_layer(layer)
    graphic:never_flip(flip)
    graphic:set_texture(texture, true)
    if facing then 
        graphic:set_facing(facing)
    end
    
    if user:get_facing() == Direction.Left then 
        x = x * -1
    end
    graphic:set_offset(x, y)
    local anim = graphic:get_animation()
    anim:load(_folderpath..animation)

    anim:set_state(state)
    anim:refresh(graphic:sprite())

    if delete_on_complete then 
        anim:on_complete(function()
            graphic:delete()
        end)
    end

    return graphic
end