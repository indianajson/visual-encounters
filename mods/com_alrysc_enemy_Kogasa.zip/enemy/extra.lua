local texture = nil
local attack_texture = nil
local anim = nil

function package_init(self)
    texture = Engine.load_texture(_modpath.."enemy/Kogasa.png")
    attack_texture = Engine.load_texture(_modpath.."enemy/KogasaAttack.png")

    self:register_status_callback(Hit.Flinch, flinch)

    self:set_name("Kogasa")
	local rank = self:get_rank()
	if rank == Rank.V1 then
    	self:set_health(1900)
        self.counter_window = 20
	elseif rank == Rank.V2 then
		self:set_health(2300)
        self.counter_window = 16

	else
		self:set_health(2700)
        self.counter_window = 12

	end
	self:set_element(Element.Aqua)
    self:set_texture(texture, true)
    self:set_height(55)
    self:share_tile(false)

    anim = self:get_animation()
    anim:load(_modpath.."enemy/Kogasa.animation")
    anim:set_state("IDLE")
    anim:set_playback(Playback.Loop)

    self.flinching = false


    self.states = {

        idle = {"idle", func = idle, time = 15},
        flinch = {"flinch", func = flinch, time = 16},
        move = {"move", func = move, time = 10},
        stabby,
        trap,
        rain,
        mine

    }
    
    local s = self.states
    self.pattern = {s.idle}
    self.pattern_index = 1

    self.nloop = 3
    self.idle_count = 0

    self.acting = false
    self.first_act = true

    self.state = self.pattern[1]
    self.update_function = function(self)
        if not self.acting then 

            if self.state == self.states.idle and self.idle_count == self.nloop then
                self.idle_count = 0
                self.pattern_index = self.pattern_index + 1
                if self.pattern_index > #self.pattern then 
                    self.pattern_index = 1
                end

                self.state = self.pattern[self.pattern_index]
                self.acting = true
            end


            self.looped = false
        end

        -- For timing reasons, this is not an else with the above if
        if self.acting then 
            self.state.func
        end
    end


end


function idle(self)
    self.acting = false

    anim:set_state("IDLE")
    anim:set_playback(Playback.Loop)

    anim:on_complete(function()
        if not self.looped then 
            self.looped = true
            self.idle_count = self.idle_count+1
        end
    
    end)
    
end

function flinch(self)
    if not self.flinching then 
        self.last_state = self.state
        if self.last_state ~= self.states.idle then 
            increment_pattern(self)
        end
    end
    self.state.cleanup
    self.state = self.states.flinch
    anim:set_state("FLINCH")
    

    anim:on_complete(function()
        self.flinching = false
        idle(self)
    end)

    self.flinching = true

end

function increment_pattern(self)


end


function can_move_to(tile)
    if tile:is_edge() then
        return false
    end
	if(tile:is_reserved({}) or (tile:get_team() == Team.Red) or (not tile:is_walkable())) then
		return false
	end
    return true
end
