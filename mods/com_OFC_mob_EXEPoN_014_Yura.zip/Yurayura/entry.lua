local shared_package_init = include("../shared/entry.lua")

function package_init(character)
    local character_info = {
        name = "Yurayura",
        hp = 100,
        damage = 60,
        palette = _folderpath.."V2.png",
        height = 44,
        idle_time = 35,
        move_speed = 30,
        edge_time = 30,
    }
    shared_package_init(character, character_info)
end