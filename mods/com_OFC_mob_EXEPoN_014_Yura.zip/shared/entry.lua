local AUDIO_DAMAGE_PLAYER = Engine.load_audio(_folderpath.."EXE4_219.ogg")
local AUDIO_DAMAGE_ENEMY = Engine.load_audio(_folderpath.."EXE4_270.ogg")
local AUDIO_DAMAGE_OBS = Engine.load_audio(_folderpath.."EXE4_221.ogg")
local EFFECT_TEXTURE = Engine.load_texture(_folderpath.."effect.png")
local EFFECT_ANIMPATH = _folderpath.."effect.animation"

local CHARACTER_ANIMATION = _folderpath.."battle.animation"
local CHARACTER_TEXTURE = Engine.load_texture(_folderpath.."battle.grayscaled.png")
local RUSHING_SFX = Engine.load_audio(_folderpath.."EXE4_72.ogg")
local MOB_MOVE_TEXTURE = Engine.load_texture(_folderpath.."mob_move.png")
local MOB_MOVE_ANIMPATH = _folderpath.."mob_move.animation"

--possible states for character
local states = { IDLE = 1, RUSH = 2, EDGE = 3 }
local debug = false

function debug_print(str)
    if debug then
        print("[Yura] "..str)
    end
end

function package_init(self, character_info)
    -- Required function, main package information
    local base_animation_path = CHARACTER_ANIMATION
    self:set_texture(CHARACTER_TEXTURE)
    self.animation = self:get_animation()
    self.animation:load(base_animation_path)
    -- Set up character meta
    self:set_palette(Engine.load_texture(character_info.palette))
    self:set_name(character_info.name)
    self.name = character_info.name
    self:set_health(character_info.hp)
    self:set_height(44)
    self.damage = (character_info.damage)
    self:set_element(Element.Elec)
    self:set_explosion_behavior(3, 1, false)
    self.animation:set_state("SPAWN")
    self.frame_counter = 0
    self.idle_time = character_info.idle_time
    self.move_speed = character_info.move_speed
    self.edge_time = character_info.edge_time
    self.moving = false
    self.on_edge = false
    self.reserving = false
    self:share_tile(false)
    self:set_air_shoe(true)
    self:set_float_shoe(true)
    self.original_tile = self:get_current_tile()

    self.defense_rule = Battle.DefenseRule.new(0, DefenseOrder.Always)
    --Status Guard
    self.defense_rule.filter_statuses_func = function(statuses)
		statuses.flags = statuses.flags & ~Hit.Flinch
		statuses.flags = statuses.flags & ~Hit.Stun
		statuses.flags = statuses.flags & ~Hit.Freeze
        statuses.flags = statuses.flags & ~Hit.Blind
		return statuses
	end
    self:add_defense_rule(self.defense_rule)

    self.battle_start_func = function(self)
        debug_print("battle_start_func called")
        self.animation:set_state("IDLE")
        self.animation:set_playback(Playback.Loop)
        self.original_tile = self:get_current_tile()
        --tile = self.original_tile
    end

    local pi = math.pi
    local tile = nil
    local tileWidth = nil
    local tileHeight = nil

    local x_speed = nil
    
    self.x_coord = 0
    self.time = 0
    --local start_y = user:get_tile():y()
    local start_y = nil
    local tileOffsetY = 0

    local round = function(val)
        if self:get_facing() == Direction.Right then
            return math.floor(val)
        else
            return math.ceil(val)
        end
    end

    self.action_idle = function(frame)
        if frame == 1 then
            if self.loop_anim then
                self.animation:set_state("IDLE")
                self.animation:set_playback(Playback.Loop)
            end
        end
        if frame == self.idle_time then
            self.set_state(states.RUSH)
        end
    end

    local query_HP = function(ent)
        if ent:get_health() > 0 then
            return true
        end
    end
    self.action_rush = function(frame)
        if frame == 1 then
            local new_tile = self:get_field():tile_at(self:get_current_tile():x(),2)
            if self:get_current_tile():y() ~= 2 then
                self:teleport(new_tile, ActionOrder.Immediate, nil)
            end

            tile = new_tile
            tileWidth = tile:width()
            tileHeight = tile:height()
            x_speed = tileWidth / self.move_speed
            if self:get_facing() == Direction.Left then
                x_speed = -x_speed
            end
            start_y = tile:y()

            Engine.play_audio(RUSHING_SFX, AudioPriority.Low)
            create_collision_attack(self, new_tile, self.original_tile)
            self:share_tile(true)
            self.reserving = true
            self.moving = true
        end
        ----
        --(Function by louise)
        if self.moving then
            self.x_coord = self.x_coord + x_speed
            self.y_coord = -round(math.sin((pi * self.time) / (self.move_speed)) * tileHeight)
            -- Once shakey has moved half a tile, needs to change its tile
            if (self.y_coord > tileHeight / 2) then
                --in bottom tile
                tileOffsetY = 1
            elseif (self.y_coord < -tileHeight / 2) then
                --in top tile
                tileOffsetY = -1
            else
                -- same row
                tileOffsetY = 0
            end
            local prospective_y = tileOffsetY + start_y
            if (self:get_current_tile():y() ~= prospective_y) then
                --check if tile should be updated
                if #self:get_field():tile_at(self:get_current_tile():x(), prospective_y):find_obstacles(query_HP) <= 0 then
                    self:teleport(self:get_field():tile_at(self:get_current_tile():x(), prospective_y))
                else
                    self:teleport(self.original_tile, ActionOrder.Immediate, function()
                        self:reveal()
                        self.on_edge = false
                        self.reserving = false
                        self:share_tile(false)
                        self:get_field():spawn(create_mob_move(self, false), self:get_current_tile())
                        self:get_field():spawn(create_mob_move(self, true), self.original_tile)
                        self.set_state(states.IDLE)
                    end)
                end
            end
            if (self:get_facing() == Direction.Right and round(self.x_coord) >= tileWidth / 2) then
                if #self:get_tile(Direction.Right, 1):find_obstacles(query_HP) <= 0 then
                    self:teleport(self:get_tile(Direction.Right, 1), ActionOrder.Immediate)
                    self.x_coord = -tileWidth / 2
                else
                    self:teleport(self.original_tile, ActionOrder.Immediate, function()
                        self:reveal()
                        self.on_edge = false
                        self.reserving = false
                        self:share_tile(false)
                        self:get_field():spawn(create_mob_move(self, false), self:get_current_tile())
                        self:get_field():spawn(create_mob_move(self, true), self.original_tile)
                        self.set_state(states.IDLE)
                    end)
                end
            elseif (self:get_facing() == Direction.Left and round(self.x_coord) <= -tileWidth / 2) then
                if #self:get_tile(Direction.Left, 1):find_obstacles(query_HP) <= 0 then
                    self:teleport(self:get_tile(Direction.Left, 1), ActionOrder.Immediate)
                    self.x_coord = tileWidth / 2
                else
                    self:teleport(self.original_tile, ActionOrder.Immediate, function()
                        self:reveal()
                        self.on_edge = false
                        self.reserving = false
                        self:share_tile(false)
                        self:get_field():spawn(create_mob_move(self, false), self:get_current_tile())
                        self:get_field():spawn(create_mob_move(self, true), self.original_tile)
                        self.set_state(states.IDLE)
                    end)
                end
            end
            --Teleporting increases the offsetY.
            local relativeOffsetY = (tileOffsetY * (tileHeight * 0.8))
            local adjusted_y = self.y_coord - relativeOffsetY
            self:set_offset(self.x_coord, adjusted_y)
            self.time = self.time + 1
            if (self.time == self.move_speed * 2) then
                self.time = 0
            end
            --print("TILE: ("..self:get_current_tile():x()..";"..self:get_current_tile():y()..")")
            if self:get_current_tile():is_edge() then
                if (self:get_facing() == Direction.Right and self:get_offset().x >= 2) or (self:get_facing() == Direction.Left and self:get_offset().x <= -2) then
                    self.moving = false
                    self:hide()
                    self:set_offset(0,0)
                    self.on_edge = true
                    self.set_state(states.EDGE)
                end
            end
        end
        if self.reserving then
            self.original_tile:reserve_entity_by_id(self:get_id())
        end
        ----
    end

    self.action_edge = function(frame)
        if frame == self.edge_time then
            self:teleport(self.original_tile, ActionOrder.Immediate, function()
                self:reveal()
                self.on_edge = false
                self.reserving = false
                self:share_tile(false)
                self:get_field():spawn(create_mob_move(self, true), self.original_tile)
                self.set_state(states.IDLE)
            end)
        end
        if self.reserving then
            self.original_tile:reserve_entity_by_id(self:get_id())
        end
    end

    self.can_move_to_func = function(tile)
        return true
    end

    self.set_state = function(state)
        self.state = state
        self.frame_counter = 0
    end

    local actions = { [1] = self.action_idle, [2] = self.action_rush, [3] = self.action_edge }

    self.spawn_func = function(self)
        debug_print("spawn_func called")
        local num = ""
        if self:get_rank() == 1 then
            self:set_name("Yurayura")
        elseif self:get_rank() == 2 then
            self:set_name("Yurarion")
        end
    end
    
    self.update_func = function()
        self.frame_counter = self.frame_counter + 1
        if not self.started then
            self.current_direction = self:get_facing()
            self.enemy_dir = self:get_facing()
            self.started = true
            self.set_state(states.IDLE)
        else
            local action_func = actions[self.state]
            action_func(self.frame_counter)
        end
    end

end

function create_mob_move(enemy, is_appear)
    if not enemy or enemy and enemy:is_deleted() then return end --Don't bother if the mob is deleted
    local movement = Battle.Spell.new(enemy:get_team()) --Use a spell so it doesn't animate during time freeze
    movement:set_texture(MOB_MOVE_TEXTURE) --Use the stored texture
    local anim = movement:get_animation()
    anim:load(MOB_MOVE_ANIMPATH)
    --determine the state to use
    anim:set_state("MOB_MOVE")
    if is_appear then
        anim:set_state("MOB_APPEAR")
    end
    anim:on_complete(function()
        movement:erase()
    end)
    anim:refresh(movement:sprite())
    movement:sprite():set_layer(-2) --Set layer so it appears over the enemy
    movement:set_offset(0, -30)
    return movement
end

function is_tile_free_for_movement(tile, character)
    --Basic check to see if a tile is suitable for a chracter of a team to move to

    if tile:get_team() ~= character:get_team() then
        return true
    end
    if (tile:is_edge()) then
        return true
    end
    local occupants = tile:find_entities(function(ent)
        if (Battle.Character.from(ent) ~= nil or Battle.Obstacle.from(ent) ~= nil) then
            return true
        else
            return false
        end
    end)
    if #occupants == 1 and occupants[1]:get_id() == character:get_id() then
        return true
    end
    if #occupants > 0 then
        return false
    end

    return true
end

--(Function by Alrysc)
function create_collision_attack(self, tile, orig_tile)
    local spell = Battle.Spell.new(self:get_team())
    spell:set_facing(self:get_facing())
   
    local hit_props = HitProps.new(
        self.damage,
        Hit.Impact | Hit.Flash | Hit.Flinch,
        Element.Elec, 
        self:get_id(), 
        Drag.None
    )

    spell:set_hit_props(hit_props)

    spell.moving = true

    local pi = math.pi
    local tileWidth = tile:width()
    local tileHeight = tile:height()

    local x_speed = tileWidth / self.move_speed
    if self:get_facing() == Direction.Left then
        x_speed = -x_speed
    end
    
    spell.x_coord = 0
    spell.time = 0
    --local start_y = user:get_tile():y()
    local start_y = tile:y()
    local tileOffsetY = 0

    local round = function(val)
        if spell:get_facing() == Direction.Right then
            return math.floor(val)
        else
            return math.ceil(val)
        end
    end

    local ref = self
    spell.update_func = function(self)
        self:get_current_tile():highlight(Highlight.Solid)
        self:get_current_tile():attack_entities(self)
        if ref:is_deleted() then
            self:erase()
        end
        --self:delete()
        if self.moving then
            self:teleport(ref:get_current_tile(), ActionOrder.Immediate, nil)
            if self:get_current_tile():is_edge() or (self:get_current_tile() == orig_tile and ref:get_current_tile() == orig_tile and not ref.moving) then
                self:erase()
            end
        end
    end
    spell.attack_func = function(self, ent)
        create_effect(Direction.Right, EFFECT_TEXTURE, EFFECT_ANIMPATH, "4", math.random(-30,30), math.random(-50,-30), true, -999999, self:get_field(), ent:get_current_tile())
        if Battle.Obstacle.from(ent) == nil then
            --[[
            if Battle.Player.from(user) ~= nil then
                Engine.play_audio(AUDIO_DAMAGE_PLAYER, AudioPriority.Low)
            end
            ]]
        else
            Engine.play_audio(AUDIO_DAMAGE_OBS, AudioPriority.Low)
        end
    end

    spell.can_move_to_func = function(tile)
        return true
    end

    self:get_field():spawn(spell, tile)
end

function create_effect(effect_facing, effect_texture, effect_animpath, effect_state, offset_x, offset_y, flip, offset_layer, field, tile)
    local hitfx = Battle.Artifact.new()
    hitfx:set_facing(effect_facing)
    hitfx:set_texture(effect_texture, true)
    hitfx:set_offset(offset_x, offset_y)
    hitfx:never_flip(flip)
    local hitfx_sprite = hitfx:sprite()
    hitfx_sprite:set_layer(offset_layer)
    local hitfx_anim = hitfx:get_animation()
	hitfx_anim:load(effect_animpath)
	hitfx_anim:set_state(effect_state)
	hitfx_anim:refresh(hitfx_sprite)
    hitfx_anim:on_complete(function()
        hitfx:erase()
    end)
    field:spawn(hitfx, tile)

    return hitfx
end

return package_init