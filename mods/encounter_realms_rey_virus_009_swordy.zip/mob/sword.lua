local TEXTURE_SLASH=Engine.load_texture(_modpath.."swordy_slashes.png")
local ANIMPATH_SLASH=_modpath.."spell_sword_slashes.animation"

local AUDIO_SLASH=Engine.load_audio(_modpath.."slash.ogg")
local AUDIO_DAMAGE=Engine.load_audio(_modpath.."hitsound.ogg")

local HIT_TEXTURE=Engine.load_texture(_modpath.."/lib/effect.png")
local HIT_ANIM=_modpath.."/lib/effect.animation"
local swordattack={}

function alert_mark(other,alert_state)
	local frame=0
	local alert=Battle.Artifact.new()
	alert:hide()
	local alert_sprite=alert:sprite()
	alert_sprite:set_texture(Engine.load_texture(_modpath.."alerts/alerts.png",true))
	local alert_anim=alert:get_animation()
	alert_anim:load(_modpath.."alerts/alerts.anim")
	alert_anim:set_state(alert_state)

	local x=32
	if other:get_facing()==Direction.Left then 
		x=x * -1
	end

	alert.update_func=function(self)
		local size=alert_sprite:get_height()
		if frame==0 then
			alert_sprite:set_height(12)
			alert_sprite:set_width(12)
			alert:reveal()
		elseif frame > 0 and frame < 8 then
			alert_sprite:set_height(size+12)
			alert_sprite:set_width(size+12)
		elseif frame >= 28 and frame < 36 then
			alert_sprite:set_height(size-12)
			alert_sprite:set_width(size-12)
		elseif frame >= 36 then
			alert:delete()
		end
		frame=frame+1
	end

	alert:set_facing(other:get_facing())
	alert:set_offset(x,0)
	alert_anim:refresh(alert_sprite)
	local y=other:get_height()+14
	if y < 20 then 
		y=40
	end
	alert:set_elevation(y)
	other:get_field():spawn(alert,other:get_current_tile())
end

--- swordtype can be "WIDE" or "LONG"
swordattack.create_slash=function(agent,hit_damage,swordtype)
	--swordattack.gobby=false
	local swordstrike=Battle.Spell.new(agent:get_team())
	local damage=hit_damage
	local priority_elem=Element.Sword
	local strike_elem=nil
	local field=agent:get_field()
	Engine.play_audio(AUDIO_SLASH,AudioPriority.High)
	local forward=agent:get_facing()
	local up=Direction.Up
	local down=Direction.Down
	swordstrike.hitlist={}

	local swordstrike_animation=swordstrike:get_animation()
	local hit_elem=agent:get_element()
	local elem_name="DEFAULT"
	if hit_damage==0 then
		elem_name="WEAKNESS"
		hit_elem=Element.None
	elseif (hit_elem==Element.Fire) then
		elem_name="FIRE"
	elseif (hit_elem==Element.Aqua) then
		elem_name="AQUA"
	elseif (hit_elem==Element.Elec) then
		elem_name="Elec"
	elseif (hit_elem==Element.Wood) then
		elem_name="WOOD"
	elseif (hit_elem==Element.Wind) then
		elem_name="WIND"
	elseif (hit_elem==Element.Cursor) then
		elem_name="CURSOR"
	elseif (hit_elem==Element.Break) then
		elem_name="BREAK"
	else
		hit_elem=Element.Sword
	end
	if hit_damage==8 then
		--swordattack.gobby=true
		local hit_rand={1,20,20,40,40,60,60,60,60,80,80,100,100,240}
		hit_damage=hit_rand[math.random(1,#hit_rand)]
		elem_name="SPLOSION"
	end
	swordstrike:set_facing(forward)
	if elem_name=="CURSOR" then
		damage=0
		priority_elem=hit_elem
		strike_elem=Element.Sword
	elseif elem_name~="DEFAULT" then
		damage=0
		priority_elem=Element.Sword
		strike_elem=hit_elem
	end

	if strike_elem~=nil then
		swordstrike:set_hit_props(
			HitProps.new(
				damage,
				Hit.Impact,
				priority_elem,
				agent:get_context(),
				Drag.None
			)
		)
		
		swordstrike.hitweak=HitProps.new(
			hit_damage*2,
			Hit.Impact|Hit.Flash|Hit.Flinch,
			strike_elem,
			agent:get_context(),
			Drag.None
		)

		swordstrike.hitelse=HitProps.new(
			hit_damage,
			Hit.Impact|Hit.Flash|Hit.Flinch,
			strike_elem,
			agent:get_context(),
			Drag.None
		)
	else
		swordstrike:set_hit_props(
			HitProps.new(
				damage,
				Hit.Impact|Hit.Flash|Hit.Flinch,
				hit_elem,
				agent:get_context(),
				Drag.None
			)
		)
	end
	swordstrike.target_hit=false
	swordstrike:set_facing(forward)
	swordstrike_animation:load(ANIMPATH_SLASH)
	swordstrike_animation:set_state(swordtype)
	swordstrike:set_texture(TEXTURE_SLASH)
	swordstrike_animation:refresh(swordstrike:sprite())
	swordstrike:sprite():set_layer(-2)
	swordstrike_animation:on_complete(function()
		swordstrike:erase()
	end)
	swordstrike:set_palette(agent:get_current_palette())
	local startTile=agent:get_tile(forward,1)
	--local hitbox1=nil
	--local hitbox2=nil
	if not startTile:is_edge() then
		table.insert(swordstrike.hitlist,startTile)
		if (swordtype=="WIDE") then
			if not startTile:get_tile(up,1):is_edge() then
				--field:spawn(swordstrike,startTile:get_tile(up,1))
				--hitbox1=spawn_wide_hitbox(field,swordstrike,startTile:get_tile(up,1),elem_name)
				table.insert(swordstrike.hitlist,startTile:get_tile(up,1))
			end
			if not startTile:get_tile(down,1):is_edge() then
				--field:spawn(swordstrike,startTile:get_tile(down,1))
				--hitbox2=spawn_wide_hitbox(field,swordstrike,startTile:get_tile(down,1),elem_name)
				table.insert(swordstrike.hitlist,startTile:get_tile(down,1))
			end
		elseif (swordtype=="LONG") and not startTile:get_tile(forward,1):is_edge() then
			--field:spawn(swordstrike,startTile:get_tile(forward,1))
			--hitbox1=spawn_wide_hitbox(field,swordstrike,startTile:get_tile(forward,1),elem_name)
			table.insert(swordstrike.hitlist,startTile:get_tile(forward,1))
		end
	end
	field:spawn(swordstrike,startTile)

	--[[swordstrike.update_func=function(self,dt)
		--self:get_current_tile():attack_entities(self)
		hitbox1:get_current_tile():attack_entities(hitbox1)
		if (hitbox2) then
			hitbox2:get_current_tile():attack_entities(hitbox2)
		end
	end]]

	--[[swordstrike.execute_func=function(self)
		swordstrike:add_anim_action(3,function()
			if #swordstrike.hitlist>0 then
				for atkTile=1,#swordstrike.hitlist do
					swordstrike.hitlist[atkTile]:attack_entities(swordstrike)
				end
			end
		end)
	end]]

	swordstrike.on_spawn_func=function(self)
		for atkTile=1,#swordstrike.hitlist do
			swordstrike.hitlist[atkTile]:attack_entities(swordstrike)
		end
	end

	swordstrike.can_move_to_func=function(self,other)
		return true
	end

	swordstrike.collision_func=function(self,other)
		swordstrike.target_hit=true
		local second_hitbox=Battle.Hitbox.new(self:get_team())
		if (elem_name=="CURSOR" and other:get_element()==Element.Break) or (elem_name~="DEFAULT" and other:get_element()==Element.Wind) or (elem_name=="WEAKNESS" and other:get_element()~=Element.None) then
			if elem_name=="WEAKNESS" then
				if other:get_element()==Element.Fire then
					elem_name="AQUA"
				elseif other:get_element()==Element.Aqua then
					elem_name="ELEC"
				elseif other:get_element()==Element.Elec then
					elem_name="WOOD"
				elseif other:get_element()==Element.Wood then
					elem_name="FIRE"
				elseif other:get_element()==Element.Sword then
					elem_name="BREAK"
				elseif other:get_element()==Element.Wind then
					elem_name="DEFAULT"
				elseif other:get_element()==Element.Cursor then
					elem_name="WIND"
				elseif other:get_element()==Element.Break then
					elem_name="CURSOR"
				else
					elem_name="DAMAGE"
				end
			end
			second_hitbox:set_hit_props(swordstrike.hitweak)
			self:get_field():spawn(second_hitbox,other:get_current_tile())
			alert_mark(other,"ELEM_WEAK")
		elseif elem_name~="DEFAULT" then
			second_hitbox:set_hit_props(swordstrike.hitelse)
			self:get_field():spawn(second_hitbox,other:get_current_tile())
		end
		create_basic_effect(swordstrike:get_field(),other:get_current_tile(),HIT_TEXTURE,HIT_ANIM,elem_name,swordattack.gobby)
		Engine.play_audio(AUDIO_DAMAGE,AudioPriority.Highest)
	end

	swordstrike.battle_end_func=function(self)
		swordstrike:erase()
	end

	--[[swordstrike.attack_func=function(self,other)
		print("It attacked something.")
		swordstrike.target_hit=true
		local second_hitbox=Battle.Hitbox.new(self:get_team())
		if (elem_name=="CURSOR" and other:get_element()==Element.Break) or (elem_name~="DEFAULT" and other:get_element()==Element.Wind) or (elem_name=="WEAKNESS" and other:get_element()~=Element.None) then
			if elem_name=="WEAKNESS" then
				if other:get_element()==Element.Fire then
					elem_name="AQUA"
				elseif other:get_element()==Element.Aqua then
					elem_name="ELEC"
				elseif other:get_element()==Element.Elec then
					elem_name="WOOD"
				elseif other:get_element()==Element.Wood then
					elem_name="FIRE"
				elseif other:get_element()==Element.Sword then
					elem_name="BREAK"
				elseif other:get_element()==Element.Wind then
					elem_name="DEFAULT"
				elseif other:get_element()==Element.Cursor then
					elem_name="WIND"
				elseif other:get_element()==Element.Break then
					elem_name="CURSOR"
				else
					elem_name="DAMAGE"
				end
			end
			second_hitbox:set_hit_props(swordstrike.hitweak)
			self:get_field():spawn(second_hitbox,other:get_current_tile())
			alert_mark(other,"ELEM_WEAK")
		elseif elem_name~="DEFAULT" then
			second_hitbox:set_hit_props(swordstrike.hitelse)
			self:get_field():spawn(second_hitbox,other:get_current_tile())
		end
		create_basic_effect(swordstrike:get_field(),other:get_current_tile(),HIT_TEXTURE,HIT_ANIM,elem_name)
		Engine.play_audio(AUDIO_DAMAGE,AudioPriority.Highest)
	end]]
end

function create_basic_effect(field,tile,hit_texture,hit_anim_path,hit_anim_state,gobby)
	local fx=Battle.Artifact.new()
	local fx_sprite=fx:sprite()
	local fx_anim=fx:get_animation()
	fx:set_texture(hit_texture,true)
	fx_anim:load(hit_anim_path)
	if gobby~=true then
		fx_anim:set_state(hit_anim_state)
	else
		fx_anim:set_state("SPLOSION")
		Engine.play_audio(Engine.load_audio(_modpath.."splosions/splosion.ogg"),AudioPriority.Highest)
	end
	fx_sprite:set_layer(-3)
	fx_anim:refresh(fx_sprite)
	fx_anim:on_complete(function()
		fx:erase()
	end)
	field:spawn(fx,tile)
	return fx
end

function Tiletostring(tile)
	return "Tile: ["..tostring(tile:x())..","..tostring(tile:y()).."]"
end

return swordattack
