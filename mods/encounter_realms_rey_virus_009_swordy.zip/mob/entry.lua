local shared_package_init=include("./character.lua")
local mantle=include("enemy/mantle.lua")




local setswordyname=function(character)
	if character:get_rank()==1 then
		character:set_name("Burny")
	elseif character:get_rank()==2 then
		character:set_name("Splashy")
	elseif character:get_rank()==3 then
		character:set_name("Shocky")
	elseif character:get_rank()==4 then
		character:set_name("Sappy")
	elseif character:get_rank()==5 then
		character:set_name("Breezy")
	elseif character:get_rank()==6 then
		character:set_name("Scummy")
	elseif character:get_rank()==7 then
		character:set_name("Achey")
	elseif character:get_rank()==8 then
		character:set_name("\u{0027}Splodey")
		mantle_details={
			["element"]=Element.Sword
		}
		mantle(character,mantle_details)
	elseif character:get_rank()>=9 then
		character:set_name("Shady")
	end
end

function package_init(character)
	local characterrank=character:get_rank()
	if characterrank < 0 or characterrank > 9 then characterrank=0 end
    local character_info={
        name="Swordy",
        hp=90,
        damage=30,
        height=44,
        move_speed=52,
        element=Element.Sword,
        palette=_folderpath.."palette"..characterrank..".png"
    }

    if characterrank==1 then
        character_info.hp=120
        character_info.damage=60
        character_info.move_speed=42
        character_info.element=Element.Fire
    elseif characterrank==2 then
        character_info.hp=150
        character_info.damage=90
        character_info.move_speed=32
        character_info.element=Element.Aqua
    elseif characterrank==3 then
        character_info.hp=180
        character_info.damage=120
        character_info.move_speed=16
        character_info.element=Element.Elec
    elseif characterrank==4 then
        character_info.hp=210
        character_info.damage=150
        character_info.move_speed=10
        character_info.element=Element.Wood
    elseif characterrank==5 then
        character_info.hp=240
        character_info.damage=180
        character_info.move_speed=10
        character_info.element=Element.Wind
    elseif characterrank==6 then
        character_info.hp=270
        character_info.damage=210
        character_info.move_speed=10
        character_info.element=Element.Cursor
    elseif characterrank==7 then
        character_info.hp=300
        character_info.damage=240
        character_info.move_speed=10
        character_info.element=Element.Break
    elseif characterrank==8 then
        character_info.hp=600
        character_info.damage=8
        character_info.move_speed=8
        character_info.element=Element.Sword
	elseif character:get_rank() >= 9 then
        character_info.hp=99999
        character_info.damage=0
        character_info.move_speed=5
        character_info.element=Element.None
    end

    shared_package_init(character,character_info)
	character.on_spawn_func=setswordyname
end
