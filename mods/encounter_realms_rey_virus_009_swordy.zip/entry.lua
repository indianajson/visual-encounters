local id={}
id.pk="encounter.realms.rey.virus.009.swordy"
-- Modified from com.louise.Swordy
id.en="mob.realms.rey.virus.009.swordy"
-- Modified from com.louise.enemy.Swordy

function package_requires_scripts()
	Engine.define_character(id.en,_modpath.."mob")
end

function package_init(package)
	package:declare_package_id(id.pk)
	package:set_name("Swordy")
	package:set_description("Rey Realms\u{0027} version.\nSupports ranks! Rank determines element.")
	package:set_speed(1)
	package:set_attack(50)
	package:set_health(80)
	package:set_preview_texture_path(_modpath.."preview.png")
end

function package_build(mob)

	mob
		:spawn_player(1,2,2)

	--[[mob
		:create_spawner(id.en,1)
			:spawn_at(4,2)]]

	mob
		:create_spawner(id.en,Rank.V1)
			:spawn_at(5,2)

	--[[mob
		:create_spawner(character_id.."Swordy",Rank.V1)
			:spawn_at(4,2)

	mob
		:create_spawner(character_id.."Swordy",Rank.V2)
			:spawn_at(5,3)

	mob
		:create_spawner(character_id.."Swordy",Rank.V3)
			:spawn_at(6,2)]]
end
