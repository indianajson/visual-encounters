local package_id = "com.OFC.mob.EXE6-045-ElementMan3"
local character_id = "com.OFC.char.EXE6-045-ElementMan1"

function package_requires_scripts()
    Engine.requires_character(character_id)
end

function package_init(package) 
    package:declare_package_id(package_id)
    package:set_name("ElementMan SP (EXE6)")
    package:set_description("Test fight with\nElementMan SP\nfrom Rockman EXE6")
    package:set_speed(3)
    package:set_attack(70)
    package:set_health(1700)
    package:set_preview_texture_path(_modpath.."preview.png")
end

function package_build(mob)
    local texPath = _modpath.."07d-skyarea.png"
    local animPath = _modpath.."07-internetarea.animation"
    mob:set_background(texPath, animPath, 0.225, 0.225)
    mob:stream_music(_modpath.."exe6-boss.ogg", 6817, 58254)
    mob:create_spawner(character_id, Rank.SP):spawn_at(5,2)
end