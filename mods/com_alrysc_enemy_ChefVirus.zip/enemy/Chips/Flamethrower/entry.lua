local hit_fx = Engine.load_texture(_folderpath .. "FireFX.png")
local AUDIO = Engine.load_audio(_folderpath .. "sfx.ogg")

local heat = {}

local function create_flame_spell(user, damage)
    local spell = Battle.Spell.new(user:get_team())
    spell:set_texture(Engine.load_texture(_folderpath .. "flame.png"))
    local animation = spell:get_animation()
    spell:set_hit_props(
        HitProps.new(
            damage,
            Hit.Impact | Hit.Flinch | Hit.Flash,
			Element.Fire,
            user:get_context(),
            Drag.None
        )
    )
    spell:highlight_tile(Highlight.Solid)
    animation:load(_folderpath .. "flame.animation")
    animation:set_state("0")
    animation:set_playback(Playback.Loop)
    local sprite = spell:sprite()
    sprite:set_layer(-2)
    animation:refresh(sprite)
    spell:set_facing(user:get_facing())
    spell.has_spawned = false
    local tile = nil
    spell.on_spawn_func = function(self)
        tile = self:get_tile()
        self.has_spawned = true
        if self.tile == nil then self.tile = self:get_tile() end
        self.has_spawned = true
    end

    spell.collision_func = function(self, other)
        local fx = Battle.Spell.new(self:get_team())
        fx:set_texture(hit_fx)
        local anim = fx:get_animation()
        local fx_sprite = fx:sprite()
        anim:load(_folderpath .. "FireFX.animation")
        anim:set_state("FIRE")
        sprite:set_layer(-3)
        anim:refresh(fx_sprite)
        anim:on_complete(function ()
            fx:erase()
        end)
        self:get_field():spawn(fx, tile)
    end

    spell.update_func = function(self, dt)
        tile:attack_entities(self)
    end
    return spell
end


heat.action = function(self)
    if self.first_act then 
        local frames = {
            {duration=1, state="CHEF_FLAMETHROWER_1"},
            {duration=3, state="CHEF_FLAMETHROWER_2"},
            {duration=2, state="CHEF_FLAMETHROWER_1"}
        }
       

        local function f(num)
            local choice = frames[num]
            return {duration = choice.duration, state = choice.state}
        end

        self.anim:set_state("CHEF_FLAMETHROWER", {
            f(1),
            f(2), f(3), f(2), f(3), f(2), f(3), f(2), f(2), f(3), f(2), f(2), f(3), f(2),
            f(2), f(3), f(2), f(3), f(2), f(3), f(2), f(2), f(3), f(2), f(2), f(3), f(2),
            f(2), f(3), f(2), f(3), f(2), f(3), f(2), f(2), f(3), f(2), f(2), f(3), f(2)
        })

        self:set_counterable()


        local field = self:get_field()
        local tile_array = {}

        local increment = 1
        local facing = self:get_facing()
        local start_tile = self:get_tile()
        for i = 1, 3
        do
            local t = start_tile:get_tile(facing, i)
            if t and not t:is_edge() then 
                table.insert(tile_array, t)
            else
                break
            end
        end

        local flame1 = nil
        local flame2 = nil
        local flame3 = nil

    
        self.anim:on_frame(5, function()
            Engine.play_audio(AUDIO, AudioPriority.High)
            if #tile_array > 0 then
                flame1 = create_flame_spell(self, self.damage_flamethrower)
                field:spawn(flame1, tile_array[1])
            end
        end)

        self.anim:on_frame(9, function()
            if tile_array[1] then
                flame2 = create_flame_spell(self, self.damage_flamethrower)
                field:spawn(flame2, tile_array[2])
            end
        end)

        self.anim:on_frame(13, function()
            if tile_array[2] then
                flame3 = create_flame_spell(self, self.damage_flamethrower)
                field:spawn(flame3, tile_array[3])
            end
        end)

        self.anim:on_frame(32, function()
            if tile_array[3] then
                local anim = flame1:get_animation()
                anim:set_state("1")
                anim:refresh(flame1:sprite())
                anim:on_complete(function()
                    flame1:erase()
                end)
            end
        end)

        self.anim:on_frame(36, function()
            if flame2 then
                local anim = flame2:get_animation()
                anim:set_state("1")
                anim:refresh(flame2:sprite())
                anim:on_complete(function()
                    flame2:erase()
                end)
            end
        end)

        self.anim:on_frame(40, function()
            if flame3 then
                local anim = flame3:get_animation()
                anim:set_state("1")
                anim:refresh(flame3:sprite())
                anim:on_complete(function()
                    flame3:erase()
                end)
            end
        end)

        local function complete()
            if flame1 and not flame1:is_deleted() then flame1:erase() end
            if flame2 and not flame2:is_deleted() then flame2:erase() end
            if flame3 and not flame3:is_deleted() then flame3:erase() end
        end

        self.anim:on_complete(function()
            increment_pattern(self)
            complete()
        end)
        self.anim:on_interrupt(complete)      

        self.first_act = false
    end
end

return heat
