local SLASH_TEXTURE = Engine.load_texture(_folderpath.."spell_sword_slashes.png")
local AUDIO = Engine.load_audio(_folderpath.."sfx.ogg")


local dagger = {}


dagger.action = function(self)
    if not self.first_act then 
        return 
    end

    self.anim:set_state("CHEF_KNIFE", {
        {duration=2, state="PLAYER_MOVE_1"},
        {duration=2, state="PLAYER_MOVE_2"},
        {duration=2, state="PLAYER_MOVE_3"},
        {duration=2, state="PLAYER_MOVE_2"},
        {duration=2, state="PLAYER_MOVE_1"},
        {duration=12, state="IDLE_1"},
        {duration=8, state="CHEF_KNIFE_1"},
        {duration=2, state="CHEF_KNIFE_2"},
        {duration=10, state="CHEF_KNIFE_3"},
        {duration=2, state="PLAYER_MOVE_1"},
        {duration=2, state="PLAYER_MOVE_2"},
        {duration=2, state="PLAYER_MOVE_3"},
        {duration=2, state="PLAYER_MOVE_2"},
        {duration=2, state="PLAYER_MOVE_1"},
    })

    local did_move = false

    self.anim:on_frame(4, function()
        self.moving_to_enemy_tile = true

        local tile = find_target_tile(self)

        -- find_target_tile only returns if self.can_move_to_func(tile)
        if tile then 
            did_move = true
            self.retained_tile = self:get_current_tile()
        else
            self.moving_to_enemy_tile = false
            tile = self:get_current_tile()
        end

        self:teleport(tile, ActionOrder.Voluntary, nil)
    end)

    self.anim:on_frame(6, function()
        if not did_move then 
            increment_pattern(self)
        end
    end)

    self.anim:on_frame(7, function()
        self:set_counterable()
    end)

    self.anim:on_frame(9, function()
        local field = self:get_field()
        local sword = create_slash(self)
        local tile = self:get_tile(self:get_facing(), 1)
        local fx = Battle.Artifact.new()
        fx:set_facing(sword:get_facing())
        local anim = fx:get_animation()
        fx:set_texture(SLASH_TEXTURE, true)
        anim:load(_folderpath.."spell_sword_slashes.animation")
        anim:set_state("DEFAULT")
        anim:on_complete(function()
            fx:erase()
            if not sword:is_deleted() then sword:delete() end
        end)
        field:spawn(sword, tile)
        field:spawn(fx, tile)
    end)

    self.anim:on_frame(13, function()
        self.moving_to_enemy_tile = false
        local t = self:get_current_tile()
        t:remove_entity_by_id(self:get_id())
        self.retained_tile:add_entity(self)

        self.retained_tile = nil
    end)

  
    self.anim:on_complete(function()
        increment_pattern(self)
    end)

    self.first_act = false
end

function create_slash(user)
	local spell = Battle.Spell.new(user:get_team())
	spell:set_facing(user:get_facing())

	spell:set_hit_props(
		HitProps.new(
			user.damage_knife,
			Hit.Impact | Hit.Flinch | Hit.Flash,
			Element.Sword,
			user:get_context(),
			Drag.None
		)
	)

	spell.update_func = function(self, dt) 
		self:get_tile():attack_entities(self)
	end

	spell.can_move_to_func = function(tile)
		return true
	end

	Engine.play_audio(AUDIO, AudioPriority.Low)

	return spell
end

function find_target_tile(self)
    local team = self:get_team()
    local characters = self:get_field():find_characters(function(c)
        return c:get_team() ~= team
    end)

    local facing_away = self:get_facing_away()
    for _, c in pairs(characters)
    do
        local t = c:get_tile(facing_away, 1)
        if self.can_move_to_func(t) then 
            return t
        end
    end
end

return dagger