local thunderbolt_texture = Engine.load_texture(_folderpath .. "fork.png")
local thunderbolt_anim = _folderpath .. "fork.animation"
local HIT_TEXTURE = Engine.load_texture(_folderpath .. "effect.png")
local HIT_ANIM_PATH = _folderpath .. "effect.animation"
local THUNDERBOLT_SFX = Engine.load_audio(_folderpath .. "sfx.ogg")

local fork = {}


function highlight_tiles(self, list, time, highlight)
    highlight = highlight or Highlight.Solid
    local spell = Battle.Spell.new(self:get_team())

    spell.update_func = function(self)
        for i=1, #list
        do 
            local t = list[i]
            if t and not t:is_edge() then 
                t:highlight(highlight)
            end

        end

        time = time - 1
        if time == 0 then 
            self:delete()
        end
    end


    self:get_field():spawn(spell, self:get_current_tile())

    return spell
end

fork.action = function(self)
    if not self.first_act then 
        return 
    end
    
    self:set_counterable()

    local frame1_dur = 8

    self.anim:set_state("CHEF_FORK", {
        {duration=frame1_dur, state="CHEF_FORK_1"},
        {duration=2, state="CHEF_FORK_2"},
        {duration=10, state="CHEF_FORK_3"}
    })

    
    local targets = find_targets(self)
    highlight_tiles(self, targets, frame1_dur, Highlight.Flash)
    
    self.anim:on_frame(2, function()
        for index, value in ipairs(targets) do
            create_thunderbolt(self, value, self.damage_fork)
        end
    end)

    self.anim:on_complete(function()
        increment_pattern(self)
    end)

    self.first_act = false
end

function create_thunderbolt(owner, target, damage)
    local tile = target
    local owner_id = owner:get_id()
    local team = owner:get_team()
    local field = owner:get_field()
    local spell = Battle.Spell.new(team)
    Engine.play_audio(THUNDERBOLT_SFX, AudioPriority.High)
    spell:set_hit_props(HitProps.new(damage, Hit.Flash | Hit.Flinch | Hit.Impact, Element.None, owner:get_context(), Drag.None))
    spell:set_texture(thunderbolt_texture)
    local spell_animation = spell:get_animation()
    spell:set_facing(owner:get_facing())
    spell_animation:load(thunderbolt_anim)
    spell_animation:set_state("1")
    spell_animation:refresh(spell:sprite())
    spell_animation:on_complete(function()
        spell:erase()
    end)
    spell:sprite():set_layer(-2)
    spell.update_func = function()
        spell:get_current_tile():attack_entities(spell)
        spell:get_current_tile():set_state(TileState.Cracked)
    end
    spell.collision_func = function(self, other)
        local artifact = Battle.Artifact.new()
        artifact:set_texture(HIT_TEXTURE)
        artifact:set_animation(HIT_ANIM_PATH)
        --FX
        local anim = artifact:get_animation()
        anim:set_state("DAMAGE")
        artifact:get_animation():refresh(artifact:sprite())
        anim:on_complete(function()
            artifact:erase()
        end)
        field:spawn(artifact, tile)
    end
    field:spawn(spell, tile)
    return spell

end

--find target tiles
function find_targets(self)
    local field = self:get_field()
    local team = self:get_team()
    local result = {}
    local target_list = field:find_characters(function(other_entity)
        return other_entity:get_team() ~= team
    end)
    
    for index, value in ipairs(target_list) do
        table.insert(result, target_list[index]:get_tile())
    end
    return result
end

return fork