local CHEF_TEXTURE = nil
local CHEF_ANIMATION = nil


function package_init(self)
    CHEF_TEXTURE = Engine.load_texture(_modpath.."chef.png")
    CHEF_ANIMATION = _folderpath.."chef.animation"
    self:set_name("Chef")
	local rank = self:get_rank()
    
    
    -------- [Start stat stuff] --------

    self.max_health = 300

    self.damage = 30
    self.damage_fork = self.damage
    self.damage_knife = self.damage
    self.damage_flamethrower = self.damage


    self.attack_chance_percentile = 3
    -- Chance out of self.attack_chance_percentile that the given 
    -- attack will be chosen randomly. Use whole numbers. Should 
    -- add up to self.attack_chance_percentile, but actually the 
    -- flamethrower chance is slightly ignored and will be whatever is 
    -- left over after the other chances.
    -- This could be implemented a lot better, but this was less work for now.
    self.fork_chance = 1
    self.knife_chance = 1
    self.flamethrower_chance = 1

    self.base_idle_speed = 48
    -- If idle time after an attack should be different from normal.
    self.idle_speed_after_attack = self.base_idle_speed
    -- Counterable time at the start of an action. 
    -- 16 is standard for BN6 chip actions.
    self.counter_duration = 16
    self.counter_time = 0

    -- Number of times to move before attacking
    self.move_count = 3
    
    -- Chance /16. I'm going to run these when the pattern is complete and when the flinch finishes, respectively
        -- These skips will be very implementation-specific, so don't use them as future references
    -- Set any of these to 0 if you don't want them.
    self.chance_to_move_twice = 2
    self.chance_to_skip_idle_after_flinch = 2
    self.chance_to_halve_idle_after_flinch = 3 

    self.flinch_duration = 22
    self.should_flinch = true

    -------- [End stat stuff] --------

    --[[ 
        Setting to true will allow movement into tiles not matching this Character's Team.
        If an action moves to one of those tiles, set it true before checking and doing 
        movement, and set false after returning.

        This is also set false in the flinch function.
    ]]
    self.moving_to_enemy_tile = false

    --[[
        Set this to the original tile before movement, if the tile moved from is intended 
        to be returned to. The retained_tile may also want to be reserved, as per BN standard.
        Won't be in this mod, just because this enemy is likely to get deleted before battle ends, 
        and then the tile will stay reserved.

        The flinch function will immediately return this Character to this tile if non-nil, and 
        set it to nil. This will happen regardless of whether or not the Character can still 
        stand on that tile. Reserving would more likely keep the tile in a state where it could 
        be stood on 
    ]]
    self.retained_tile = nil

    self.idle_speed = self.base_idle_speed 
	self:set_element(Element.None)
    self:set_texture(CHEF_TEXTURE, true)
    self:set_height(40)
    self:share_tile(false)
    self:set_health(self.max_health)
    self:set_explosion_behavior(8, 8, true)


    local anim = self:get_animation()
    anim:load(CHEF_ANIMATION)

    self.anim = include("enemy_base_v1/entry.lua")
    anim = self.anim
    anim:set_owner(self)
    anim:set_state("IDLE", {
        {duration=9, state="IDLE_1"},
        {duration=9, state="IDLE_2"},
        {duration=9, state="IDLE_3"},
        {duration=9, state="IDLE_4"},

    })

    anim:set_playback(Playback.Loop)

    init_boss(self)

end

-- This is to fix something that happens because I'm a cheater
--[[
    The aggressor of an attack is held in the Context object. 
    ONB leaves this aggressor unset in the Entity's Context until a CardAction is used for the first time
    So I'll immediately force a CardAction that will hopefully end immediately and not get in the way, but also will fix this
    This probably goes horribly wrong if the enemy is spawned after the mob intro, but should be fine for now otherwise
]]
function fix_context(self)
    local action = Battle.CardAction.new(self, "IDLE_1")
    action.execute_func = function()
        action:end_action()
    end

    self:card_action_event(action, ActionOrder.Immediate)
end

function init_boss(self)
    self.on_spawn_func = function(self)
        fix_context(self)
        
        self.before_battle_start_animater = Battle.Artifact.new()
        self:get_field():spawn(self.before_battle_start_animater, 7, 4)
        self.before_battle_start_animater.update_func = function()
            self.anim:tick_animation()
        end
    end

    self.battle_start_func = function(self)
        self.before_battle_start_animater:delete()
    end

    -- Setting names here is just convenience if I want to print the state I'm in later
    self.states = {
        idle = {name = "idle", func = idle},
        move = {name = "move", func = move},
        flinch = {name = "flinch", func = flinch},
        
        start_sub_pattern = {name = "start_sub_pattern"},
        finish_sub_pattern = {name = "finish_sub_pattern"},
        
        flamethrower = {name = "flamethrower", func = include("Chips/Flamethrower/entry.lua").action},
        fork = {name = "fork", func = include("Chips/Fork/entry.lua").action},
        knife = {name = "knife", func = include("Chips/Knife/entry.lua").action},
        choose_attack = {name = "choose_attack", func = choose_attack}
    }
    


    local s = self.states

    reconstruct_pattern(self)
    
 
    self.pattern_index = 1
    self.in_sub_pattern = false

    self.first_act = true

    self.state_done = false

    self.state = self.pattern[1]

    self.first_flinch = true


    self.hit_func = function(from_stun)
      --  print("Hit func runs")
        self.flinching = false
        self.first_act = false
        self.state_done = false
        self.moving_to_enemy_tile = false
        if self.retained_tile then 
            local t = self:get_current_tile()
            t:remove_entity_by_id(self:get_id())
            self.retained_tile:add_entity(self)

            self.retained_tile = nil
        end

        if self.first_flinch then 
         --   self.state.cleanup
            self.last_state = self.state
       --     print("Hit! Set last state to ", self.state.name)
            if self.state ~= self.states.idle and self.state ~= self.states.move then 
               -- increment_pattern(self)
            end

            self.first_flinch = false
        end

        self.state = self.states.flinch

        -- This is unused for this boss
        if self.slide_component ~= nil then 
          --  print("Hit while moving.")
            self.slide_component:eject()
            self.slide_component = nil
            self:set_offset(0, 0)

            if self.slide_dest and self:get_current_tile() ~= self.slide_dest then 
            --    print("Hit before reaching destination.")
                self:get_current_tile():remove_entity_by_id(self:get_id())
                self.slide_dest:add_entity(self)
                self.slide_dest = nil
            end

        end

        flinch(self, from_stun)
    end

    self.delete_func = function(self)
        self.update_func = function(self)
            self:get_animation():set_state("FLINCH_1")
            self.state = self.states.flinch
        end

    end

    self.moving_to_enemy_tile = false
    self.counter = 0
    self.collision_available = true


    if self.should_flinch then 
        self:register_status_callback(Hit.Flinch, self.hit_func)
        self:register_status_callback(Hit.Drag, self.hit_func)
    end
    self:register_status_callback(Hit.Root, function() self.rooted = 120 end)

    -- Bring it back next build. For now, relying on the stun callback
    --[[
    self.on_countered = function(self)
        print("Countered")
        self:toggle_counter(false)
        self.hit_func(self)

    end
    --]]

    self.can_move_to_func = function(tile)
        if self.rooted > 0 then return false end
        if tile:is_edge() or not tile:is_walkable() then
            return false
        end
        if(tile:is_reserved({})) then
            return false
        end

        if not self.moving_to_enemy_tile and (tile:get_team() ~= self:get_team()) then
            return false
        end

        return not check_obstacles(tile, self) --and not check_characters(tile, self)
    end

    self.rooted = 0
    self.update_func = function(self)
       -- print("     ", self.state.name, self:get_animation():get_state())
        if self.rooted > 0  then self.rooted = self.rooted - 1 end
        if self.counter_time > 0 then 
            self.counter_time = self.counter_time - 1
            if self.counter_time <= 0 then 
                self:toggle_counter(false)
            end
        end
        self.state.func(self)
        self.anim:tick_animation()

        -- When we tick animation, we may run increment_pattern. 
        -- The new state isn't run until next frame, so our anim state lasts one more frame when it finishes
        -- Calling our state one time to set things up will avoid this. Mostly sure this doesn't have major unintended consequences,
        -- especially as most state.func only set state and callbacks for frame 1
        -- Problem is, now I may have a frame 1 callback but I don't run it until next frame
        while self.first_act
        do
            self.state.func(self)
            self.anim:tick_animation()
        end
        check_collision(self)
    end

    self.set_counterable = function(self)
        self:toggle_counter(true)
        self.counter_time = self.counter_duration
    end
end

function create_collision_attack(self, tile)
    local spell = Battle.Spell.new(self:get_team())
   
    local hit_props = HitProps.new(
        self.damage,
        Hit.Impact | Hit.Flash | Hit.Flinch,
        self:get_element(), 
        self:get_context(), 
        Drag.None
    )

    spell:set_hit_props(hit_props)

    spell.update_func = function(self)
        tile:attack_entities(self)
        self:delete()
    end

    self:get_field():spawn(spell, tile)
end


-- TODO: When we get is_passthrough or something, check to see if target became flashing before 
    -- we are allowed to spawn another one. Don't want to instakill viruses
-- self.collision_available can do something related to that. Does nothing now
function check_collision(self)
    local t = self:get_current_tile()
    if self.collision_available and check_characters(t, self) then 
        create_collision_attack(self, t)
    end

end

function idle(self)
    if self.first_act then 
        -- This is an old check for when I extended idle time by doing two idle states in a row, when characters have an animated idle
            -- Not needed if I instead use a timer
        if self.anim:get_state() ~= "IDLE" then 
            self.anim:set_state("IDLE", {
                {duration=9, state="IDLE_1"},
                {duration=9, state="IDLE_2"},
                {duration=9, state="IDLE_3"},
                {duration=9, state="IDLE_4"},

            })
        end

        self.anim:set_playback(Playback.Loop)
        self.counter = 0
        
        self.first_act = false
    end

    self.counter = self.counter + 1
    if self.counter >= self.idle_speed then 
        -- Extra catch for after leaving attack. Attack will double idle speed once, so making sure to reset it after
        if self.idle_speed ~= self.base_idle_speed then 
            self.idle_speed = self.base_idle_speed
        end

        increment_pattern(self)
    end

end

function end_sub_pattern(self)
    while(self.in_sub_pattern)
    do
        increment_pattern(self)
    end
end

function flinch(self, from_stun)
   -- print("Flinch played")

   -- print("I am flinching")
    if not self.flinching then 
        local frames = {}
        local flinch_time = self.flinch_duration
        if not from_stun then 
            frames[1] = {duration=flinch_time, state="PLAYER_HIT"}
        else
            frames[1] = {duration=0, state="FLINCH_1"}
        end

        self.anim:set_state("FLINCH", frames)

        self.anim:on_complete(function()
            -- If we didn't just attack, we want to make sure the idle speed is correct. This is also set in the actual idle, but just for extra measure.
                -- Shouldn't be necessary
            if self.idle_speed ~= self.base_idle_speed and self.pattern[self.pattern_index] ~= self.states.choose_attack then 
                self.idle_speed = self.base_idle_speed
            end

            local has_skipped = false
            if self.last_state ~= self.states.flinch then 
          --      print("Attempt skip, because last state was idle")
                has_skipped = maybe_skip_after_flinch(self)
            end

            
--         print("I am done flinching")
        --   print("Anim done")
            self.flinching = false
            self.state_done = true
            self.first_flinch = true

        --    print("Done")
            self.state_done = false
            if self.last_state ~= self.states.idle and self.last_state ~= self.states.move then 
        --     print("Last state was not idle or move", self.last_state.name)
 
                increment_pattern(self)

            
            else--if not has_skipped then 
                -- If we were in idle or move, go back to it and try again
                    -- Unless we were in a sub pattern. Still end that.
            --   print("Last state was idle or move")

                if self.in_sub_pattern then 
                    end_sub_pattern(self)
                else
                    self.state = self.last_state
                    self.first_act = true
                end
            end

        end)

    end

    self.flinching = true
end

--[[
    Chance to skip idle or halve idle time, to call after flinching 
    This works by calling increment_pattern an extra time if and only if the last state was Idle
        Remember, last state is the state we will return to after flinching
        Some extra work will need to be done in the self.anim:on_complete of flinch if this is to work with sub patterns. This boss doesn't use them, so it was omitted
    
    Currently, the skip is implemented as setting idle time to 0
    
    A future choice for this function: after calling this function, self.state *may* increment, obsoleting our last state pointer. Returns true if this does happen
        There is a possible additional side effect that the idle time will instead be changed, in which case, last state is preserved and false is returned
]]

function maybe_skip_after_flinch(self)
    local chance_halve = self.chance_to_halve_idle_after_flinch
    local chance_skip = self.chance_to_skip_idle_after_flinch

    if chance_halve and chance_skip <= 0 then 
        return false
    end
    
    local max = chance_halve + chance_skip + (16 - chance_halve - chance_skip)

    local r = math.random(1, max)
    if r <= chance_halve then 
        self.idle_speed = math.floor(self.idle_speed / 2)
    elseif r <= (chance_skip + chance_halve) then 
        self.idle_speed = 0
        return true
    end

    return false
end

function highlight_tiles(self, list, time, highlight)
    highlight = highlight or Highlight.Solid
    local spell = Battle.Spell.new(self:get_team())


    local ref = self
    spell.update_func = function(self)
        for i=1, #list
        do 
            local t = list[i]
            if t and not t:is_edge() then 
                t:highlight(highlight)
            end

        end


        time = time - 1
        if time == 0 then 
            self:delete()
        end

        if self.flinching then 
            if spell and not spell:is_deleted() then 
                spell:delete()
    
            end
        end
    end


    self:get_field():spawn(spell, self:get_current_tile())

    return spell
end

function move(self)
    if self.first_act then 
        
        self.anim:set_state("MOVE", {
            {duration=2, state="PLAYER_MOVE_1"},
            {duration=2, state="PLAYER_MOVE_2"},
            {duration=2, state="PLAYER_MOVE_3"},
            {duration=2, state="PLAYER_MOVE_2"},
            {duration=2, state="PLAYER_MOVE_1"},
        })

        local tile = choose_move(self, self:get_field())
        self.anim:on_frame(4, function()
            if self.can_move_to_func(tile) then 
            else
                tile = self:get_current_tile()
            end

            self:teleport(tile, ActionOrder.Voluntary, nil)
        end)

        self.anim:on_complete(function()
            -- Reset idle speed, since we did a real action
            self.idle_speed = self.base_idle_speed
            increment_pattern(self)
        
        end)

        self.first_act = false
    end
end

function choose_attack(self)
    local r = math.random(1, self.attack_chance_percentile)
    if r <= self.fork_chance then 
        self.state = self.states.fork
        self.idle_speed = self.idle_speed_after_attack
    elseif r <= (self.knife_chance + self.fork_chance) then 
        self.state = self.states.fork
        self.idle_speed = self.idle_speed_after_attack
    else
        self.state = self.states.flamethrower
        self.idle_speed = self.idle_speed_after_attack
    end

    self.state.func(self)
end

function choose_move(self, field)
    local team = self:get_team()

    local tiles = field:find_tiles(function(tile)
        return tile ~= self:get_current_tile() and self.can_move_to_func(tile)
    
    end)


    --print("Found ", #tiles, " possible tiles")

    if #tiles == 0 then 
        return self:get_current_tile()
    end

    return tiles[math.random(1, #tiles)]
end


function choose_enemy(self, field)
    local team = self:get_team()

    local target = field:find_characters(function(c)
        return c:get_team() ~= team
    end)

    if not target[1] then 
       -- print("No targets")
        return nil
    end

    t_x = target[1]:get_current_tile():x()
    t_y = target[1]:get_current_tile():y()

    local facing = -1
    if target[1]:get_facing() == Direction.Right then 
        facing = 1
    end

    local tile = field:tile_at(t_x+facing, t_y)

    return tile
end


function reconstruct_pattern(self)
    local pattern = {}
    local states = self.states
    local moves = self.move_count
    local r = math.random(1, 16)
   -- print(r)
    if r <= self.chance_to_move_twice then 
        moves = 2
      --  print("Two moves this time")
    end

    for i=1, moves
    do
        table.insert(pattern, states.idle)
        table.insert(pattern, states.move)
    end

    table.insert(pattern, states.idle)
    table.insert(pattern, states.choose_attack)


    self.pattern = pattern
end

function increment_pattern(self)
   -- print("Pattern increment")

    self.first_act = true
    self.state_done = false
    self.pattern_index = self.pattern_index + 1
    if self.pattern_index > #self.pattern then 
        reconstruct_pattern(self)
 --       print("Reconstructed pattern")
        self.pattern_index = 1
    end

    local next_state = self.pattern[self.pattern_index]
    self.state = next_state
  --  print("Moving to state named ", next_state.name)

    if next_state == self.states.start_sub_pattern then 
        self.in_sub_pattern = true
        increment_pattern(self)
    end

    if next_state == self.states.finish_sub_pattern then 
        self.in_sub_pattern = false
        increment_pattern(self)

    end

   -- print("Changing to "..self.pattern_index..", which is "..self.pattern[self.pattern_index].name)

end

function check_obstacles(tile, self)
    local ob = tile:find_obstacles(function(o)
        return o:get_id() ~= self:get_id() and o:get_health() > 0 
    end)

    return #ob > 0 
end


function check_characters(tile, self)
    local characters = tile:find_characters(function(c)
        return c:get_id() ~= self:get_id() and c:get_team() ~= self:get_team()
    end)

    return #characters > 0

end

function get_random_offset()
    local x = math.random(0, 40)
    local y = math.random(20, 40)
    
    x = x - 20
    y = y * -1

    return {x = x, y = y}
end

function graphic_init(type, x, y, texture, animation, layer, state, user, facing, delete_on_complete, flip)
    flip = flip or false
    delete_on_complete = delete_on_complete or false
    facing = facing or nil
    
    local graphic = nil
    if type == "artifact" then 
        graphic = Battle.Artifact.new()

    elseif type == "spell" then 
        graphic = Battle.Spell.new(user:get_team())
    
    elseif type == "obstacle" then 
        graphic = Battle.Obstacle.new(user:get_team())

    end

    graphic:sprite():set_layer(layer)
    graphic:never_flip(flip)
    graphic:set_texture(texture, true)
    if facing then 
        graphic:set_facing(facing)
    end
    
    if user:get_facing() == Direction.Left then 
        x = x * -1
    end
    graphic:set_offset(x, y)
    local anim = graphic:get_animation()
    anim:load(animation)

    anim:set_state(state)
    anim:refresh(graphic:sprite())

    if delete_on_complete then 
        anim:on_complete(function()
            graphic:delete()
        end)
    end

    return graphic
end