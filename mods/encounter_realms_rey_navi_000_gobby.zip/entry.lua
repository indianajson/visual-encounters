local id={}
id.pk="encounter.realms.rey.navi.000.gobby"
id.en="mob.realms.rey.navi.000.gobby"
--[[disclaimer: if you have any additional questions on how stuff works,either check out this 
link:https://protobasilisk.github.io/OpenNetBattleDocs/api/#overview,or visit the onb discord server.]]
function package_requires_scripts()
	Engine.define_character(id.en,_modpath.."mob")
end

function package_init(package)
	package:declare_package_id(id.pk)
	package:set_name("Gobby (Enemy Package)") --boss name in mob select menu
	package:set_description("Gobby as a boss!\nSupports ranks!\nR1=DS, R2=BX, NM=DB") --boss description in mob select menu
	package:set_preview_texture_path(_modpath.."package/screen.png") --sets the image shown as the preview for this in mob select menu.
	package:set_health(1000) --boss hp in mob select menu
	package:set_attack(1) --boss attack in mob select menu
	package:set_speed(1) --boss speed in mob select menu
	--package:set_charge(1) --boss charge in mob select menu
end

function package_build(mob)
	local field = mob:get_field()
	--[[field
		:tile_at(1,1)
			:set_team(Team.Red,false)
	field
		:tile_at(1,2)
			:set_team(Team.Red,false)
	field
		:tile_at(1,3)
			:set_team(Team.Red,false)
	field
		:tile_at(2,1)
			:set_team(Team.Red,false)
	field
		:tile_at(2,2)
			:set_team(Team.Red,false)
	field
		:tile_at(2,3)
			:set_team(Team.Red,false)
	field
		:tile_at(3,1)
			:set_team(Team.Blue,false)
	field
		:tile_at(3,2)
			:set_team(Team.Blue,false)
	field
		:tile_at(3,3)
			:set_team(Team.Blue,false)
	field
		:tile_at(4,1)
			:set_team(Team.Red,false)
	field
		:tile_at(4,2)
			:set_team(Team.Red,false)
	field
		:tile_at(4,3)
			:set_team(Team.Red,false)
	field
		:tile_at(5,1)
			:set_team(Team.Blue,false)
	field
		:tile_at(5,2)
			:set_team(Team.Blue,false)
	field
		:tile_at(5,3)
			:set_team(Team.Blue,false)
	field
		:tile_at(6,1)
			:set_team(Team.Blue,false)
	field
		:tile_at(6,2)
			:set_team(Team.Blue,false)
	field
		:tile_at(6,3)
			:set_team(Team.Blue,false)]]
	field
		:tile_at(1,2)
			:set_state(TileState.Empty)
	--[[field
		:tile_at(3,1)
			:set_state(TileState.DirectionLeft)
	field
		:tile_at(3,2)
			:set_state(TileState.DirectionLeft)
	field
		:tile_at(3,3)
			:set_state(TileState.DirectionLeft)]]
	field
		:tile_at(6,1)
			:set_state(TileState.Empty)
	field
		:tile_at(6,3)
			:set_state(TileState.Empty)
	mob
		:spawn_player(1,2,2)
	mob
		:spawn_player(2,1,1)
	mob
		:create_spawner(id.en,Rank.V1) --creates spawner for the boss
		:spawn_at(5,2) --spawns boss at the given co-ords (x,y)
		--
	mob:stream_music(_modpath.."package/loop_boss_battle2.ogg",11996,31752) --[[change first value to name of the song you want (said song must
be in folder),second and third control the loop points in the track (second is lo op star,third is loop end). Setting up that part can 
be tricky,as dispite what documentation says it's not 100% accurate to miliseconds. Experiment to get it to a good point,and try to 
use earlier points in the track for a closer value to milisecond equivalent. Alternatively you could just comment this line out and it'll
play the in engine normal battle theme.]]
end