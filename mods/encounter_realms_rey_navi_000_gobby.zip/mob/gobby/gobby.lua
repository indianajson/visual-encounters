local gobby={}
gobby.gobnade={}
gobby.rankhandle={
	[0]="v1",
	[1]="v2",
	[2]="v3",
	[3]="extra",
	[4]="special",
	[5]="darksoul",
	[6]="beastcross",
	[7]="darkbeast"
}
--[[gobby.gobnade.rankhandle={
	[0]="base",
	[1]="dark",
	[2]="nightmare"
}]]
--[[gobby.rankcodes={
	[0]=" V1",
	[1]=" V2",
	[2]=" V3",
	[3]=" EX",
	[4]=" SP",
	[5]=" DS",
	[6]=" BX",
	[7]=" DB"
}]]
gobby.modenames={
	[0]="Version 1",
	[1]="Version 2",
	[2]="Version 3",
	[3]="Extra",
	[4]="Special",
	[5]="Dark Soul",
	[6]="Beast Cross",
	[7]="Dark Beast"
}
gobby.modecodes={
	[0]="",
	[1]="V2",
	[2]="V3",
	[3]="EX",
	[4]="SP",
	[5]="DS",
	[6]="BX",
	[7]="DB"
}
gobby.attack={}
gobby.attack.rank={
	[0]="BASE",
	[1]="DARK",
	[2]="NIGHTMARE",
}
gobby.attack.type={
	[0]="NORMAL",
	[1]="CHARGED",
	[2]="SPECIAL"
}
gobby.namelist={
	[0]="Gobby",
	[1]="GobbyV2",
	[2]="GobbyV3",
	[3]="GobbyEX",
	[4]="GobbySP",
	[5]="GobbyDS",
	[6]="GobbyBX",
	[7]="GobbyDB"
}
gobby.attack.class="BASE_NORMAL_"
gobby.splosion={}
gobby.formtype={}
gobby.formtype.base=""
gobby.formtype.beast="Beast"
gobby.formtype.cross="Cross"
gobby.formtype.silver="Cross (silver)"
gobby.formtype.gold="Cross (gold)"
gobby.formname={}
gobby.formname.base=""
gobby.formname.vixi="Vizin "
gobby.formname.sol="Sol"
gobby.formname.bass="Bass"
gobby.formname.cyan="Cyan "
gobby.ignore={}
gobby.ignore.notwalkable=false
gobby.chance={}
gobby.chance.announce=0
gobby.chance.comment=0
gobby.summon=false
gobby.element={}
gobby.element.fire=false
gobby.element.wood=false
gobby.element.elec=false
gobby.element.aqua=false
gobby.element.sword=false
gobby.element.wind=false
gobby.element.cursor=false
gobby.element.breaker=false
gobby.element.recover=false
gobby.element.plus=false
gobby.element.ground=false
gobby.element.stealth=false
gobby.element.object=false
gobby.audio={}
gobby.audio.gobnade={}
gobby.audio.gobnade.toss=Engine.load_audio(_modpath.."gobnades/toss.ogg")
gobby.audio.splosion={}
gobby.audio.splosion.mono=Engine.load_audio(_modpath.."splosions/splosion.ogg")
gobby.audio.splosion.mass=Engine.load_audio(_modpath.."splosions/massplosion.ogg")
gobby.audio.splosion.hit=Engine.load_audio(_modpath.."splosions/hit.ogg")
gobby.texture={}
gobby.texture.gobnade=Engine.load_texture(_modpath.."gobnades/gobnades.png")
gobby.texture.splosion=Engine.load_texture(_modpath.."splosions/base/splosion.png")
gobby.animation={}
gobby.animation.gobnade=_modpath.."gobnades/gobnades.animation"
gobby.animation.splosion=_modpath.."splosions/splosion.animation"
gobby.splosion={}
gobby.splosion.rank="base"
gobby.splosion.type="splosion"
gobby.rank=0
gobby.gobnade.level=0
gobby.gobnade.rank=0
--gobby.lockout={}
--gobby.lockout.buster=30
--gobby.lockout.special=30
gobby.lockout=30
gobby.hitprops=HitProps.new(
	0,
	Hit.Impact,
	Element.None,
	0,
	Drag.None
)
gobby.gobnade_type=function()
	if gobby.attack.type[gobby.gobnade.level] == nil then
		gobby.gobnade.level=0
	end
	if gobby.attack.rank[gobby.gobnade.rank] == nil then
		gobby.gobnade.rank=0
	end
	gobby.attack.class=gobby.attack.rank[gobby.gobnade.rank].."_"..gobby.attack.type[gobby.gobnade.level].."_"
end
return gobby