local gobby=include("gobby/gobby.lua")
--local gobnades=include("enemy/gobnades.lua")
local splosions=include("splosions/splosions.lua")
local mantle=include("enemy/mantle.lua")
--[[Welcome to the boss template. I've tried my hardest to make it easer for user to do some basic things BN style bosses do. Theres plenty of comments here
to help explain what does what, so make sure to read them. If your unsure about something and the comments aren't enough for you to understand it, visit 
https://protobasilisk.github.io/OpenNetBattleDocs/api/#overview or the offical ONB discord server!]]
-- P.S.: Virus, Mob, and Boss are used interangably here to identify the boss. Please forgive my ability to keep things consistent in documentation -_-

--local virus_texture=(Engine.load_texture(_modpath.."gobby/battle.png")) --sets modpath for texture of the boss
--local virus_animpath=_modpath.."gobby/battle.animation" --sets modpath for animation of the boss
--local shot_texture=(Engine.load_texture(_modpath.."cirkilbullet.png")) --sets modpath for texture of the projectile spell.  Animations can be loaded when needed.
--local sword_texture=(Engine.load_texture(_modpath.."slash.png")) --sets modpath for texture of the slash artifact.
--local shot_audio=Engine.load_audio(_modpath .. "gun.ogg") --sets modpath for the shooting sound. other two are same but for different sources.
--local sword_audio=Engine.load_audio(_modpath .. "sword.ogg")
--local hit_audio=Engine.load_audio(_modpath .. "hitsound.ogg")

--NOTICE: main functions marked as CORE are nessicary to a bosses functionality. Be careful with modification to these, and and especially if you intend to remove one.



function package_init(enemygobby) --CORE
	--gobby.team=enemygobby:get_team()

	--[[enemygobby.all_enemy=function(e)
		return e:get_team()~=enemygobby.team
	end]]

	enemygobby.previous_tile={}
	enemygobby.rank=enemygobby:get_rank()
	if enemygobby.rank>7 then enemygobby.rank=7 elseif enemygobby.rank<0 then enemygobby.rank=0
	end
	enemygobby.corename="gobby"
	enemygobby.texpath=Engine.load_texture(_modpath.."enemy/enemy.gobby.png")
	enemygobby.animpath=_modpath.."enemy/enemy.gobby.anim"
	enemygobby.palpath=Engine.load_texture(_modpath.."gobby/palette.base.png")
	enemygobby.mantle_voice_file="engagemantle.ogg"
	enemygobby.mantle_voice_path=_modpath.."voice"
	enemygobby.mantle_texpath=Engine.load_texture(_modpath.."enemy/enemy.gobbycloaked.png")
	--initalizes the mob. Virus will be the mobs variable name thingy. 
	enemygobby:set_name("Gobby") --mobs name in battle.
	enemygobby:set_height(54) --mobs height in pixels.
	enemygobby:set_element(Element.Sword)

	if enemygobby.rank==1 then
		enemygobby:set_health(1500) --mobs health.
		gobby.global_cooldown=35 --represents the cooldown the virus must wait for before it acts again. Note that this instance of it isn't a global cooldown, its just the inital cooldown.
	elseif enemygobby.rank==2 then
		enemygobby:set_health(2000)
		gobby.global_cooldown=35
	elseif enemygobby.rank==3 then
		enemygobby:set_health(2500)
		gobby.global_cooldown=30
	elseif enemygobby.rank==4 then
		enemygobby.palpath=Engine.load_texture(_modpath.."gobby/palette.special.png")
		enemygobby:set_health(3000)
		gobby.global_cooldown=30
	elseif enemygobby.rank==5 then
		enemygobby.animpath=_modpath.."enemy/enemy.darkgobby.anim"
		enemygobby.palpath=Engine.load_texture(_modpath.."gobby/palette.dark.png")
		enemygobby:set_health(3500)
		gobby.global_cooldown=25
	elseif enemygobby.rank==6 then
		enemygobby.palpath=Engine.load_texture(_modpath.."gobby/palette.special.png")
		enemygobby:set_health(4000)
		gobby.global_cooldown=25
	elseif enemygobby.rank==7 then
		enemygobby.animpath=_modpath.."enemy/enemy.evilgobby.anim"
		enemygobby.palpath=Engine.load_texture(_modpath.."gobby/palette.dark.png")
		enemygobby:set_health(5000)
		gobby.global_cooldown=20
	else
		enemygobby:set_health(1000)
		gobby.global_cooldown=35
	end



	--local field=enemygobby:get_field()
	enemygobby.global_cooldown=gobby.global_cooldown
	enemygobby:set_texture(enemygobby.texpath) --mobs texture.
	enemygobby:set_palette(enemygobby.palpath)
	enemygobby:set_animation(enemygobby.animpath)


	--enemygobby.sprite=enemygobby:sprite()
	--local anim=enemygobby:get_animation()
	enemygobby.anim=enemygobby:get_animation()
	--enemygobby.anim:load(Engine.Animation.new(enemygobby.animpath))
	enemygobby.anim:set_state("IDLE")--sets animation state
	--enemygobby.anim:refresh(enemygobby.sprite)
	--enemygobby.animrefresh()
	--enemygobby.anim:set_playback(Playback.Loop)
	--enemygobby:set_air_shoe(true)
	--enemygobby:set_float_shoe(true)
	enemygobby.flinched=false --GENERAL USE
	enemygobby.home_tile=enemygobby:get_current_tile() --this is designed to function with virus.displaced. see that for more details.



	--[[ Bosses can't call functions directly due to limited paramiter input space. 
	You'll need to make sub functions for every action you want your boss to do. 
	I'll call these list action functions. Due to the way lists work with paramiters, 
	you should only set user in this function and have the rest be preset]]
	--list action functions:
	--action functions can be added and removed to your hearts content

	function warp_1(agent) 
		--print("warp_1")
		local cooldown=gobby.global_cooldown
		local destination=random_movement_choose(enemygobby,false)
		virusmove(enemygobby,cooldown,destination,1,0,0,false,false)
	end

	--[[function slide_1(agent) 
		--print("warp_1")
		local destination=random_movement_choose(enemygobby,false)
		virusmove(enemygobby,50,destination,2,20,0,false,false)
	end

	function jump_1(agent) 
		--print("warp_1")
		local destination=random_movement_choose(enemygobby,false)
		virusmove(enemygobby,50,destination,3,20,120,false,false)
	end

	function warp_2(agent)
		--print("warp_2")
		local destination=random_movement_choose(enemygobby,false)
		virusmove(enemygobby,10,destination,1,0,0,false,false)
	end

	function warp_torow(agent)
		--print("warp_torow")
		local targettile=find_target_tile(enemygobby,1)
		local destination=axis_movement_choose(enemygobby,false,targettile,false)
		virusmove(enemygobby,50,destination,1,0,0,false,false)
		--virusmove(enemygobby,50,2,1,destination,true,false,false)
	end

	function warp_infront(agent)
		--print("warp_infront")
		local destination=find_target_tile(enemygobby,2)
		virusmove(enemygobby,50,destination,1,0,0,false,true)
	end

	function slide_infront(agent)
		--print("warp_infront")
		local destination=find_target_tile(enemygobby,2)
		virusmove(enemygobby,20,destination,2,15,0,false,true)
	end]]


	function spam_move(agent)
		if enemygobby.target_tile~=enemygobby:get_current_tile() then
			virusmove(enemygobby,0,enemygobby.target_tile,1,0,0,false,true)
		end
	end

	function final_spam_move(agent)
		if enemygobby.previous_tile[1]~=enemygobby:get_current_tile() then
			virusmove(enemygobby,gobby.global_cooldown,enemygobby.previous_tile[1],1,0,0,false,false)
		end
	end

	function action_list_chooser(agent) --GENERAL USE. an example of a way one could add randomization to their boss while still using the list system
		enemygobby.action_step_memory=enemygobby.action_step
		local choice_list={1,2,3,2,1,4,2,4,1,2,1,4,3,5,3,5,1,3,2,1,1,2,3,1,4,4,2,1,3,2}
		local rand_number=math.random(1,#choice_list)
		enemygobby.action_channel=choice_list[rand_number]
		enemygobby.action_list=enemygobby.action_lists[enemygobby.action_channel]
		enemygobby.current_list_max=#enemygobby.action_list
		enemygobby.action_step=1
		enemygobby.action_timer=0
		enemygobby.can_act=true
		--print(rand_number)
	end

	function action_list_reset(agent) --GENERAL USE. an example of a way one could add randomization to their boss while still using the list system
		enemygobby.action_list=enemygobby.action_lists[0]
		enemygobby.current_list_max=#enemygobby.action_list
		enemygobby.action_step=enemygobby.action_step_memory
		enemygobby.action_timer=0
		enemygobby.can_act=true
		--print(rand_number)
	end

	--[[function action_list_chooser(agent) --GENERAL USE. an example of a way one could add randomization to their boss while still using the list system
		local choice_list={1,2,3,2,1,4,2,4,1,2,1,4,3,5,3,5,1,3,2,1,1,2,3,1,4,4,2,1,3,2}
		local rand_number=math.random(1,#choice_list)
		agent.action_channel=choice_list[rand_number]
		--print(rand_number)
	end]]
	function gobnade_spam_attack1(agent)
		--print("gobnade_spam_attack")
		local mutevoices=false
		local voice_mute_table=enemygobby:get_field():tile_at(0,0):find_entities(function(entity)
			return entity:get_name()=="Hi\u{0021} You need to stop talking now\u{002C} okay\u{003F}"
		end)
		if #voice_mute_table>0 then mutevoices=true end
		--print(mutevoices)
		setup_gobnade_attack(enemygobby,mutevoices,gobby.global_cooldown,enemygobby.action_channel,1,"triple") 
		--[[enemygobby.action_timer=gobby.global_cooldown+24
		enemygobby.can_act=true]]
	end
	function gobnade_spam_attack2(agent)
		--print("gobnade_spam_attack")
		local mutevoices=false
		local voice_mute_table=enemygobby:get_field():tile_at(0,0):find_entities(function(entity)
			return entity:get_name()=="Hi\u{0021} You need to stop talking now\u{002C} okay\u{003F}"
		end)
		if #voice_mute_table>0 then mutevoices=true end
		--print(mutevoices)
		setup_gobnade_attack(enemygobby,mutevoices,gobby.global_cooldown,enemygobby.action_channel,2,"triple") 
		--[[enemygobby.action_timer=gobby.global_cooldown+24
		enemygobby.can_act=true]]
	end
	function gobnade_spam_attack3(agent)
		--print("gobnade_spam_attack")
		local mutevoices=false
		local voice_mute_table=enemygobby:get_field():tile_at(0,0):find_entities(function(entity)
			return entity:get_name()=="Hi\u{0021} You need to stop talking now\u{002C} okay\u{003F}"
		end)
		if #voice_mute_table>0 then mutevoices=true end
		--print(mutevoices)
		setup_gobnade_attack(enemygobby,mutevoices,gobby.global_cooldown,enemygobby.action_channel,3,"triple") 
		--[[enemygobby.action_timer=gobby.global_cooldown+24
		enemygobby.can_act=true]]
	end


	function gobnade_attack(agent) 
		--print("gobnade_attack")
		local mutevoices=false
		local voice_mute_table=enemygobby:get_field():tile_at(0,0):find_entities(function(entity)
			return entity:get_name()=="Hi\u{0021} You need to stop talking now\u{002C} okay\u{003F}"
		end)
		if #voice_mute_table>0 then mutevoices=true end
		--print(mutevoices)
		setup_gobnade_attack(enemygobby,mutevoices,gobby.global_cooldown,enemygobby.action_channel,1,"single")
		--[[enemygobby.action_timer=gobby.global_cooldown+24
		enemygobby.can_act=true]]
	end


	function skipA_start(agent) --these two start and end a action skip state, during which if a boss is flinched/stunned they will skip to a given action.
		action_skip(enemygobby,true,11)
	end
	function skipA_end(agent)
		action_skip(enemygobby,false,1)
	end

	
	function tile_picker(agent)
		choose_open_tile(enemygobby,enemygobby:get_field())
		enemygobby.action_timer=0
		enemygobby.can_act=true
	end

	function attack_init(agent)
		enemygobby.previous_tile={enemygobby:get_current_tile()}
		enemygobby.action_timer=0
		enemygobby.can_act=true
	end

	function SpamSkip_start(agent) --these two start and end a action skip state, during which if a boss is flinched/stunned they will skip to a given action.
		action_skip(enemygobby,true,11)
	end
	function SpamSkip_end(agent)
		local field=enemygobby:get_field()
		local function all_enemy(e)
			return e:get_team()~=enemygobby:get_team() and e:is_deleted()==false and e:get_current_tile():is_hole()==false
		end
		local enemy_table=field:find_characters(all_enemy)
		enemygobby:teleport(enemygobby.previous_tile[1],ActionOrder.Involuntary,nil)
		if enemygobby.previous_tile[1]:get_team()==Team.Red then
			enemygobby:set_facing(Direction.Right)
		elseif enemygobby:get_team()==Team.Blue then
			enemygobby.previous_tile[1]:set_facing(Direction.Left)
		else
			if #enemy_table==0 then
				if enemygobby.previous_tile[1]:x()>3 then enemygobby:set_facing(Direction.Left) else enemygobby:set_facing(Direction.Right) end
			else
				if enemygobby.previous_tile[1]:x()>enemy_table[math.random(1,#enemy_table)]:get_current_tile():x() then enemygobby:set_facing(Direction.Left) else enemygobby:set_facing(Direction.Right) end
			end
		end
		enemygobby.ignoreteam=false
		enemygobby.ignorereserve=false
		action_skip(enemygobby,false,1)
	end

	--[[function random1(agent) --GENERAL USE. an example of a way one could add randomization to their boss while still using the list system
		local choice_list={shot_attack,slide_infront}
		--enemygobby.ignore_action1=false
		local rand_number=math.random(1,#choice_list)
		choice_list[rand_number](enemygobby)
		if rand_number~=2 then
			--print("skip")
			--enemygobby.ignore_action1=false
		end
		enemygobby.action_channel=rand_number
		--print(rand_number)
	end]]


	--[[Sometimes you need certain functions to play in result of others being chosen. 
	Instead of dealing with multiple possible actions list, I've devised Channels. Certain actions
	can decide to do different things based on what the current channel is. See sword_attack_special1 for
	example.]]
	enemygobby.action_channel=0
	--[[virus actions in this system work off a list system. Action_step determines what entry on the list is to be called upon. 
	When the cooldown, the action_timer expires, and can_act is true, the action_step is increased. Admittedly in this case I could 
	probably only use cooldown, but theres probably a edge case where that secondary check is useful.]]
	--warp_1, warp_veryspecific, warp_torow, shot_attack, warp_1, skipA_start, warp_infront, sword_attack, skipA_end
	enemygobby.action_lists={
		[0]={
			warp_1,action_list_chooser,warp_1,action_list_chooser,warp_1,warp_1,warp_1,action_list_chooser,warp_1,action_list_chooser,
			warp_1,warp_1,warp_1,action_list_chooser,warp_1,warp_1,warp_1,action_list_chooser,warp_1,warp_1,
			warp_1,warp_1,warp_1,action_list_chooser,warp_1,action_list_chooser,warp_1,warp_1,warp_1,
			action_list_chooser,warp_1,warp_1,warp_1,warp_1,action_list_chooser,warp_1,warp_1,action_list_chooser,
			warp_1,warp_1,warp_1,action_list_chooser,action_list_chooser,warp_1,warp_1,warp_1,action_list_chooser,warp_1,
			warp_1,action_list_chooser,warp_1,warp_1,warp_1,warp_1,action_list_chooser,warp_1,warp_1,warp_1,
			action_list_chooser,warp_1,warp_1,action_list_chooser,warp_1,warp_1
		},
		[1]={
			attack_init,gobnade_attack,action_list_reset
		},
		[2]={
			attack_init,gobnade_attack,action_list_reset
		},
		[3]={
			SpamSkip_start,attack_init,tile_picker,spam_move,gobnade_spam_attack1,tile_picker,spam_move,gobnade_spam_attack2,
			tile_picker,spam_move,gobnade_spam_attack3,final_spam_move,SpamSkip_end,action_list_reset
		},
		[4]={
			SpamSkip_start,attack_init,tile_picker,spam_move,gobnade_spam_attack1,tile_picker,spam_move,gobnade_spam_attack2,
			tile_picker,spam_move,gobnade_spam_attack3,final_spam_move,SpamSkip_end,action_list_reset
		},
		[5]={
			attack_init,gobnade_attack,action_list_reset
		}
	}
	enemygobby.action_list=enemygobby.action_lists[enemygobby.action_channel]	--this list contains the list action functions the virus will call upon in order.
	--enemygobby.pinch_list={warp_2,warp_2,warp_torow,random1,gobnade_attack,warp_1} --if one wants to do major phase changes with their virus, they could use multiple lists for it.
	enemygobby.action_step=1 --represents the entry on the action_list that will be called upon for the viruses next action
	enemygobby.action_step_memory=1
	enemygobby.action_timer=gobby.global_cooldown --represents the cooldown the virus must wait for before it acts again. Note that this instance of it isn't a global cooldown, its just the inital cooldown.
	enemygobby.can_act=true -- if true, and action_timer=0, then the virus can act again. must be set to true
	enemygobby.displaced=false --[[this+home_tile are meant to warp the virus back to a tile on it's field if its on your side and gets 
	hit. if your doing a shanghai style boss, you'll probably have no need for this.]]
	enemygobby.current_list_max=#enemygobby.action_list --just a int containing the max of the list. Useful for making sure actions loop.
	--print(#enemygobby.action_list,"  is list length")


	enemygobby.can_out_of_bounds=false --[[if you need your virus to go out of bounds for something, toggle this true for the duration 
	of said something. Maybe also toggle off their hitbox]]
	enemygobby.ignoreteam=false
	enemygobby.ignorereserve=false
	--enemygobby.ignorewalkable=false
	enemygobby.ignorecharacter=false
	--enemygobby.phase=1 --used to determine which phase the boss is on, if it has multiple.
	local phase1=true --a do_once type boolean to make sure the stuff on phase change only runs once. You'll probably need 1 per phase.
	enemygobby.action_skip_num=0 --used for the action_skip function, specifically whhich action it'll skip to.
	enemygobby.can_skip=false --used to determine if it can use the action_skip function.

	local onhit_effect=function(is_stun) --CORE. triggers wqhen the virus is hit by a attack that flinches or stuns it
		--is_stun is only true if the virus is stunned
		enemygobby.flinched=true
		if is_stun==true then
			enemygobby.anim:set_state("HIT") --sets to stun anim. prolly comment out if you want unique stun animation with the flinch.
			--print("stun hit")
			--enemygobby.anim:refresh(enemygobby.sprite)
			--remove commenting on above if you want a unique stun animation with the flinch. Otherwise flinch animation over-rides
		else
			enemygobby.anim:set_state("HIT") --sets to flinch anim
			--print("flinch hit")

		end
		--enemygobby.anim:refresh(enemygobby.sprite)
		if enemygobby.displaced==true then --used to move the virus back it it's home tile if its flinched.
			enemygobby:teleport(enemygobby.home_tile,ActionOrder.Voluntary,nil) 
			enemygobby.can_out_of_bounds=false 
			enemygobby.ignoreteam=false
			enemygobby.ignorereserve=false
			enemygobby.ignorecharacter=false
			enemygobby.displaced=false
		end
		if enemygobby.can_skip==true then --used to handle the action skip stuff
			enemygobby.action_step=enemygobby.action_skip_num
			enemygobby.can_skip=false
			--print("skipped")
		end
		enemygobby.anim:on_complete(function() --ends the flinch effect formally.
			--print("onhit done")
			enemygobby.anim:set_state("IDLE")
			enemygobby.anim:set_playback(Playback.Loop)
			enemygobby.flinched=false
		end)
	end
	enemygobby:register_status_callback(Hit.Flinch,function() onhit_effect(false) end) --set flinch callback
	enemygobby:register_status_callback(Hit.Stun,function() onhit_effect(true) end) --set stun callback
	--Note: if you want to do a boss with super armor, you can just remove/comment out the flinch callback register.

	enemygobby.update_func=function(self,dt)
		if enemygobby.action_timer==nil then enemygobby.action_timer=1 end
		if enemygobby.flinched==false and enemygobby.action_timer>0 then --prevents cooldown progression while flinched.
			enemygobby.action_timer=enemygobby.action_timer-1 --decrease cooldown.
		end
		 --just a check function for debugging, remove comments if needed
		--if enemygobby.home_tile==nil then --print("we have problem") 
		--else enemygobby.home_tile:highlight(Highlight.Solid) end
		--[[if enemygobby:get_health()<=500 and phase1==true then --phase change code. Copy paste this if you want more then two phases, or delete it if you only want 1.
			--print("phase change")
			enemygobby.phase=2
			enemygobby.action_step=1 --reset action count to 1
			enemygobby.current_list_max=#enemygobby.pinch_list --you should set new current_list_max on phase change if it brings a new list
			enemygobby.can_skip=false --better safe then sorry.
			phase1=false
		end]]
		if enemygobby.action_timer<=0 and enemygobby.can_act==true then
			--print("current step is ",enemygobby.action_step)
			--print("phase is ",enemygobby.phase)
			enemygobby.can_act=false --makes sure the boss doesn't act until it's current action is done.
			--if enemygobby.phase==1 then --this stuff detemines
				--enemygobby.action_list[enemygobby.action_step](enemygobby)
				enemygobby.action_list[enemygobby.action_step](enemygobby)
			--[[elseif enemygobby.phase==2 then
				enemygobby.pinch_list[enemygobby.action_step](enemygobby)
			end]]
			--enemygobby.can_act=false
			if enemygobby.action_step<enemygobby.current_list_max then --increases action count, causing boss to move onto next action.
				enemygobby.action_step=enemygobby.action_step+1
			else --makes the action count loop. In theory you could change the enemygobby.action_step=to be higher then 1 if you want certain actions to not repeat.
				--print("reset order")
				enemygobby.action_step=1
			end
			--print("action performed")
			--enemygobby.anim:refresh(enemygobby.sprite)
		end
		if enemygobby:get_health()<=0 then --triggers code on boss's death.
			enemygobby.anim:set_state("HIT")
			--print("boss slain")
			--any other on deletion stuff you want
		end
		--following is testing stuff. turn it back on if you want help with keeping track of if actions are properly progressing.
		--print(enemygobby.action_step)
		--print(enemygobby.action_timer," is my cooldown")
		--[[if enemygobby.can_act==false then
			--print("waiting")
		end]]
	end


	enemygobby.anim:on_interrupt(function()
		--print("prime interrupt state is ",enemygobby.anim:get_state())
	end)
	--insert copies of stuff from traversable here
 
	enemygobby.can_move_to_func=function(tile)
		--print("20%")
		if enemygobby.can_out_of_bounds==false then
			if tile==nil or not tile:is_walkable() or tile:is_edge() then
				--print("Move Fault: Nil tile")
				return false
			end
		end



		--print("40%")
		if tile:is_reserved({}) and enemygobby.ignorereserve==false then
			--print("Move Fault: Reserved tile")
			return false
		end
		--print("60%")
		if tile:get_team()~=enemygobby:get_team() and enemygobby.ignoreteam==false then
			if tile:get_team()~=Team.Other then
				--print("Move Fault: Wrong team")
				--tile:highlight(Highlight.Solid)
				--print("Move Fault: Wrong team")
				return false
			end
		end
		--print("80%")
		local query=function(ent) --a simple function that returns that number of characters or obstacles in a given space.
			return Battle.Obstacle.from(ent)~=nil or Battle.Character.from(ent)~=nil
		end
		--print("90%")
		if #tile:find_entities(query) > 0 and enemygobby.ignorecharacter==false then --uses said function to check.
			--print("Move Fault: tile has entity")
			return false
		end
		--print("moving")
		return true
	end


	enemygobby.battle_start_func=function(enemygobby)
		local voice_mute_table=enemygobby:get_field():tile_at(0,0):find_entities(function(entity)
			return entity:get_name()=="Hi\u{0021} You need to stop talking now\u{002C} okay\u{003F}"
		end)
		if #voice_mute_table>0 then
			local battllestartlinechance=0
		else
			local battllestartlinechance=70
		end
		if battllestartlinechance~=nil and math.random(0,99)<battllestartlinechance then Engine.play_audio(Engine.load_audio(_modpath.."voice/battllestart.ogg"),AudioPriority.High) end
	end

	enemygobby.on_spawn_func=function(enemygobby)
		local mantle_details={}
		if enemygobby.rank==1 then
			enemygobby:set_name("GobbyV2")
			mantle_details={
				["element"]=Element.Sword
			}
			mantle(enemygobby,mantle_details)
		elseif enemygobby.rank==2 then
			enemygobby:set_name("GobbyV3")
			mantle_details={
				["element"]=Element.Sword,
				["level"]=2
			}
		elseif enemygobby.rank==3 then
			enemygobby:set_name("GobbyEX")
			mantle_details={
				["element"]=Element.Sword,
				["level"]=3
			}
		elseif enemygobby.rank==4 then
			enemygobby:set_name("GobbySP")
			mantle_details={
				["element"]=Element.Sword,
				["level"]=4
			}
		elseif enemygobby.rank==5 then
			enemygobby:set_name("GobbyDS")
			mantle_details={
				["element"]=Element.Sword,
				["level"]=5,
				["karma"]="dark"
			}
		elseif enemygobby.rank==6 then
			enemygobby:set_name("GobbyBX")
			mantle_details={
				["element"]=Element.None,
				["level"]=6
			}
		elseif enemygobby.rank==7 then
			enemygobby:set_name("GobbyDB")
			mantle_details={
				["element"]="evil",
				["level"]=7
			}
		end
		if enemygobby.rank>0 then
			mantle(enemygobby,mantle_details)
			Engine.play_audio(Engine.load_audio(_modpath.."mantle/barrier.ogg"),AudioPriority.Low) -- Normalized -0.1
		end
	end


end

function traversecheck(agent,tile,ignorerules)
	 --[[Used to check if a tile could in theory be moved too. Returns true if the user can and false if the user can't. parameter info below:
	tile:tile being checked for if it's traversable.
	agent:character checking if tile is traversable.
	ignorerules:boolean. if true, will return true no matter what.]]
	--print(agent:get_team())
	if ignorerules==true then --effectively ignores this whole function if true
		return true
	end
	--checks if tile is nil
	if tile==nil then 
		--print("Check Fault: Nil tile") --these fault lines are made for testing purposes. activiate them if you need to check stuff.
		return false
	end
	--check if tile is unwalkable, such as it being a pit or a edge tile.
	if tile:is_edge() or not tile:is_walkable() then
		--print("Check Fault: Unwalkable tile")
		return false --note: as of writing this there is no way to check if user has airshoes. if your boss has airshoes, you may need to change code here.
	end
	--checks if tile is on your team or neutral
	if tile:get_team()~=agent:get_team() then -- or Team.Other
		if tile:get_team()~=Team.Other then
			--print("Check Fault: Wrong team")
			--tile:highlight(Highlight.Solid)
			return false
		end
	end
	--query function needed for function below
	local query=function(ent) --a simple function that returns that number of characters or obstacles in a given space.
		return Battle.Obstacle.from(ent)~=nil or Battle.Character.from(ent)~=nil
	end
	--checks if tile is occupied
	if #tile:find_entities(query) > 0 or tile:is_reserved({}) then --uses said function to check.
		--print("Check Fault: tile has entity")
		return false
	end
	return true -- if nothing comes up it returns true

end

function random_movement_choose(agent,ignorerules) --CORE
	--this function picks a random tile to travel to.
	--[[variable info:
	agent: character. the one using this function, usually will be the virus
	ignorerules:boolean. if true, will ignore if you could in theory 
	actually move to a tile when making selections.]]
	local myfield=agent:get_field()
	--[[notes: specifictile gives a specific tile to use as reference if you want to be a certain row 
	or column. Dispite the name, one can easily use it for non movement things, just set ignoreinhabitants to true.]]
	--myteam works just like teamtype in traversable; 0 is your team, 1 is any team, 2 is not your team.

	local possibletiles=myfield:find_tiles(function(tile) --makes a list of every traversable tile on the field
		return tile~=agent:get_current_tile() and traversecheck(agent,tile,ignorerules)==true --to replace
	end) --makes a list of every traversable tile on the field  traversable(tile,agent,myteam,ignoreinhabitants,false,ignoreinhabitants)==true

	if #possibletiles==0 then --fallback if it cant find any suitable tiles
		--print("no tiles")
		return agent:get_current_tile()
	end
	--print("ready to return")

	local result_tile=possibletiles[math.random(1,#possibletiles)] --
	return result_tile

end

function axis_movement_choose(agent,vertical,specifictile,ignorerules) --CORE
	--[[this function works by combining one axis of a randomly chose tile with the opposite axis of a 
	different, preset tile]]
	--[[variable info:
	agent: character. the one using this function, usually will be the virus
	vertical: boolean. if true, will be randomized on the y axis. otherwise will be randomized on the x axis.
	specifictile: tile. used as the preset tile.
	ignorerules:boolean. if true, will ignore if you could in theory 
	actually move to a tile when making selections.]]
	local spec_x
	local spec_y
	local myfield=agent:get_field()

	local randtile=random_movement_choose(agent,ignorerules)
	--randtile:highlight(Highlight.Solid) --highlights the result tile of the chooser. good for testing,
	local rand_x=randtile:x()
	local rand_y=randtile:y()
	if specifictile~=nil and specifictile~="na" then
		--specifictile:highlight(Highlight.Solid) --remove commenting if you want to see where it selected.
		spec_x=specifictile:x()
		spec_y=specifictile:y()
		--print(spec_x," as well as ",spec_y)
		--print("AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA")
	end

	--print(rand_x," and also ",rand_y)
	local result_tile --registering variable before setting it
	--result_tile:highlight(Highlight.Solid) --again another testing thing

	if vertical==false then --result is tile at random x, specific y
		result_tile=myfield:tile_at(rand_x,spec_y)
		--print("x rand")
	else--result is tile at specific x, random y
		result_tile=myfield:tile_at(spec_x,rand_y)
		--print("y rand")
	end
	--result_tile:highlight(Highlight.Solid) 

	return result_tile --if true, return it

end

function find_target_tile(agent,mode) --CORE
	--GENERAL USE. used to find the nearest opposing characters tile, i.e. the player.
	--[[variable info:
	agent: character. the one using this function, usually will be the virus
	vertical: boolean. if true, will be randomized on the y axis. otherwise will be randomized on the x axis.
	specifictile: tile. used as the preset tile.
	ignorerules:boolean. if true, will ignore if you could in theory 
	actually move to a tile when making selections.]]
	local possibletile
	local targtile
	local agentteam=agent:get_team()
	local target=agent:get_field():find_nearest_characters(agent,function(character)
		return character:get_team()~=agentteam
	end)
	--print(#target)
	if target[1]~=nil then
		targtile=target[1]:get_current_tile() --:get_current_tile()
		--targtile:highlight(Highlight.Solid) --remove commenting to see result in game
		--print("travel ready")
		-- if you want to create/move something directly infront/behind the target, then change the mode.
		if mode==2 then 
			possibletile=targtile:get_tile(agent:get_facing_away(),1) --use if you want the target tile to be infront of target
		elseif mode==3 then
			possibletile=targtile:get_tile(agent:get_facing(),1) --use if you want the target tile to be behind target
		elseif mode==1 then
			possibletile=targtile --use if you want the target tile to be exact tile of target.
		end
	else 
		--possibletile=agent:get_current_tile()
		--print("could not travel") end
	end
	return possibletile --returns the tile it chose as a result. from there any other function can use the chosen tile.
end

function action_skip(agent,is_skipping,targetnum) --CORE
	--use this function if you want your boss to skip over multiple actions if flinched.
	if is_skipping==true then  
		--print("skip set. skip location: ",targetnum)
		agent.can_skip=true --sets if it can skip to true
		agent.action_skip_num=targetnum --sets what num of action it skips too.
	else
		--print("skip end")
		agent.can_skip=false --sets if it can skip to false
	end

	--agent.anim:set_state("IDLE")
	agent.action_timer=0 --Note: don't set action_timer to 0, that seems to break things. [Fixed]
	agent.can_act=true

end


--rename to virusmove
function virusmove(agent,cooldown,destination_tile,movement_type,speed,height,forced,displacing) --CORE
	local has_moved=false
	local movement_control=Battle.Component.new(agent,Lifetimes.Local)
	if displacing==true then-- sets can_move_to_func ignores for if its displacing or not
		--agent.home_tile=currenttile 
		--agent.displaced=true
		agent.ignoreteam=true
		agent.ignorereserve=true
	else
		--agent.home_tile=targtile
		--agent.displaced=false
		agent.ignoreteam=false
		agent.ignorereserve=false
	end
	local ignore_redundancy=false
	local currenttile=agent:get_current_tile() --the current tile before the agent actually moves.
	if agent.can_move_to_func(destination_tile)==false then
		--print("cannot move to destination")
	end
	agent:register_component(movement_control) --battle.components like movement_control need to be registered to take effect.
	--they also need to be ejected when your done with them otherwise they'll keep running in the background.

	--if movement_type==1 then
		agent.anim:set_state("WARPMOVE") --sets animation state. set it to your boss's movement .animations movement state.
		--[[change the number in on_frame to what ever frame would be in the middle of your animation. if your animation is split 
		in two (dissapear then re-appear), replace on_frame() with on_complete and set second half after. ]]
		agent.anim:on_frame(5,function()

			agent:teleport(destination_tile,ActionOrder.Involuntary,nil)

			local field=agent:get_field()
			local function all_enemy(e)
				return e:get_team()~=agent:get_team() and e:is_deleted()==false and e:get_current_tile():is_hole()==false
			end
			local enemy_table=field:find_characters(all_enemy)

			if destination_tile:get_team()==Team.Red then
				agent:set_facing(Direction.Right)
			elseif destination_tile:get_team()==Team.Blue then
				agent:set_facing(Direction.Left)
			else
				if #enemy_table==0 then
					if destination_tile:x()>3 then agent:set_facing(Direction.Left) else agent:set_facing(Direction.Right) end
				else
					if destination_tile:x()>enemy_table[math.random(1,#enemy_table)]:get_current_tile():x() then agent:set_facing(Direction.Left) else agent:set_facing(Direction.Right) end
				end
			end


			--print("warped")
			virus_set_displaced()
			agent.anim:on_complete(function() --runs on animation complete
				has_moved=true
			end)
			--warp function
		end)

	movement_control.update_func=function()
		if has_moved==true and agent:is_moving()==false then
			--print('movement done')
			ignore_redundancy=true
			agent.anim:set_state("IDLE") --sets the users animation back to the idle state...
			agent.anim:set_playback(Playback.Loop)
			agent.action_timer=cooldown --sets the action_timer to cooldown. ajust it to control how fast or slow the boss acts.
			agent.can_act=true -- toggles if boss cxan do another action. Remember to always set agent.can_act=true and set agent.action_timer on action function completion!
			movement_control:eject() --ejects movement_control when its no longer needed.

		end
		if agent:get_health()<=0 then --moreso just a safe guard to ensure its all ejected on battle end.
			--print("oops I died")
			movement_control:eject()
		end

	end

	agent.anim:on_interrupt(function() --runs when the current animation is interupted.
		if forced==true then --again, if true the user is made sure to reach their destination, by warping the user there if the teleport is interrupted.
			agent:teleport(destination_tile,ActionOrder.Voluntary,nil)
			virus_set_displaced()
		end
		--print("interrupt state is ",agent.anim:get_state()) --shows you what state it was on when it got interrupted. useful for debugging.
		if ignore_redundancy==false then
			--print("action interupted. ending.")
			agent.action_timer=cooldown 
			agent.can_act=true
			movement_control:eject()
		end --Remember to always set agent.can_act=true and set agent.action_timer on action function completion!
	end)

	function virus_set_displaced() --internal function for easily changing if its in displaced mode or not.
		--if displacing is true, it sets the tile it was previously on as it's home tile, so on hit it's warped back there.
		if displacing==true then
			agent.home_tile=currenttile
			agent.displaced=true
		else
			agent.home_tile=destination_tile
			agent.displaced=false
		end
	end

end

--normal attack--
function setup_gobnade_attack(agent,mutevoices,final_cooldown,action_channel_nonsense,throw_num,mode)
	--print("setup_gobnade_attack")
	gobby.rank=agent.rank
	local roll4damage={}
	local attack_level
	--print("Attack level: "..attack_level)
	if action_channel_nonsense==1 or action_channel_nonsense==3 then
		if agent.rank==5 or agent.rank==7 then
			gobby.gobnade.rank=1
		elseif agent.rank==6 then
			gobby.gobnade.rank=2
		else
			gobby.gobnade.rank=0
		end
		gobby.gobnade.level=0
		gobby.element.sword=false
		gobby.element.wind=false
		gobby.ignore.notwalkable=false
		if mutevoices then
			gobby.chance.announce=0
			gobby.chance.comment=0
		elseif throw_num==1 and mode=="triple" then
			gobby.chance.announce=100
			gobby.chance.comment=64
		elseif mode=="triple" then
			gobby.chance.announce=0
			gobby.chance.comment=64
		else
			gobby.chance.announce=36
		end
		if agent.rank==7 then
			attack_level=5
			roll4damage={1,23,23,25,25,27,27,27,27,29,29,31,31,55}
		else
			attack_level=(agent.rank+1)
			roll4damage={1,8,8,10,10,12,12,12,12,14,14,16,16,30}
		end
	elseif action_channel_nonsense==2 or action_channel_nonsense==4 then
		if agent.rank==5 or agent.rank==7 then
			gobby.gobnade.rank=1
		elseif agent.rank==6 then
			gobby.gobnade.rank=2
		else
			gobby.gobnade.rank=0
		end
		gobby.gobnade.level=1
		gobby.element.sword=false
		gobby.element.wind=false
		gobby.ignore.notwalkable=false
		if mutevoices then
			gobby.chance.announce=0
			gobby.chance.comment=0
		elseif throw_num==1 and mode=="triple" then
			gobby.chance.announce=100
		elseif mode=="triple" then
			gobby.chance.announce=0
			gobby.chance.comment=64
		else
			gobby.chance.announce=36
			gobby.chance.comment=64
		end
		if agent.rank==7 then
			attack_level=5
			roll4damage={1,26,26,28,28,30,30,30,30,32,32,34,34,60}
		else
			attack_level=(agent.rank+1)
			roll4damage={1,11,11,13,13,15,15,15,15,17,17,19,19,35}
		end
	elseif action_channel_nonsense==5 then
		if agent.rank==5 or agent.rank==7 then
			gobby.gobnade.rank=1
		elseif agent.rank==6 then
			gobby.gobnade.rank=2
		else
			gobby.gobnade.rank=0
		end
		if agent.rank==7 then
			gobby.element.sword=false
			gobby.element.wind=false
			gobby.ignore.notwalkable=true
			attack_level=1
			roll4damage={1,115,115,117,117,120,120,120,120,123,123,125,125,150}
		elseif agent.rank==6 then
			gobby.element.sword=false
			gobby.element.wind=false
			gobby.ignore.notwalkable=true
			attack_level=(agent.rank+1)
			roll4damage={1,14,14,16,16,18,18,18,18,20,20,22,22,40}
		else
			gobby.element.sword=true
			gobby.element.wind=true
			gobby.ignore.notwalkable=false
			attack_level=(agent.rank+1)
			roll4damage={1,14,14,16,16,18,18,18,18,20,20,22,22,40}
		end
		gobby.gobnade.level=2
		if mutevoices then
			gobby.chance.announce=0
			gobby.chance.comment=0
		else
			gobby.chance.announce=100
			gobby.chance.comment=64
		end
	end
	gobby.gobnade_type()
	gobby.hitprops.damage=attack_level*roll4damage[math.random(1,#roll4damage)]
	if (throw_num==3 or mode=="single") and agent:get_current_tile()~=agent.previous_tile[1] then cooldown=final_countdown else cooldown=0 end
	create_gobnade_attack(agent,gobby,cooldown,throw_num,action_channel_nonsense,mode)
end

-- throwing animation--
function toss_gobnade(agent,textures,toss_height,target_tile,frames_in_air,aoe_collected,arrival_callback)
	--print("toss_gobnade")
	local aoe_hilite=Battle.Spell.new(Team.Other)
	aoe_hilite.update_func=function(self)
		local aoe_local=aoe_collected
		if aoe_local.timer>0 then
			for i,target in ipairs(aoe_local.list) do
				target:highlight(Highlight.Flash)
			end
			aoe_local.timer=aoe_local.timer-1
		else
			self:delete()
		end
	end

	local starting_height=-110
	local start_tile=agent:get_current_tile()
	local field=agent:get_field()
	local gobnade_proj=Battle.Spell.new(agent:get_team())
	local gobnade_anim=gobnade_proj:get_animation()
	gobnade_proj:set_shadow(Shadow.Small)
	gobnade_anim:load(gobby.animation.gobnade)
	gobnade_anim:set_state(gobby.attack.class.."THROWN")
	gobnade_anim:set_playback(Playback.Loop)
	if agent:get_height()>1 then
		starting_height=-(agent:get_height()*2)
	end

	gobnade_proj.jump_started=false
	gobnade_proj.starting_y_offset=starting_height
	gobnade_proj.starting_x_offset=10
	if agent:get_facing()==Direction.Left then
		gobnade_proj.starting_x_offset=-10
	end
	gobnade_proj.y_offset=gobnade_proj.starting_y_offset
	gobnade_proj.x_offset=gobnade_proj.starting_x_offset
	local sprite=gobnade_proj:sprite()
	sprite:set_texture(gobby.texture.gobnade)
	gobnade_proj:set_offset(gobnade_proj.x_offset,gobnade_proj.y_offset)

	gobnade_proj.update_func=function(self)
		if not gobnade_proj.jump_started then
			self:jump(target_tile,toss_height,frames(frames_in_air),frames(frames_in_air),ActionOrder.Voluntary)
			self.jump_started=true
		end
		if self.y_offset<0 then
			self.y_offset=self.y_offset+math.abs(self.starting_y_offset/frames_in_air)
			self.x_offset=self.x_offset-math.abs(self.starting_x_offset/frames_in_air)
			self:set_offset(self.x_offset,self.y_offset)
		else
			arrival_callback()
			self:delete()
		end
	end
	gobnade_proj.can_move_to_func=function(tile)
		return true
	end
	field:spawn(aoe_hilite,target_tile)
	field:spawn(gobnade_proj,start_tile)
end


function throw_gobnade(agent,gobby,gobnade_spawn,frame_trigger)
	--print("throw_gobnade")
	local tileteam
	local agentteam
	local field=agent:get_field()
	local facing=agent:get_facing()
	local hit={sound=false}
	local tile_list={}
	local splosions_split
	local splosions_spots
	local aoe={}
	aoe.list={}
	aoe.timer=30
	local boomshape
	local tile
	local function all_enemy(e)
		if gobby.ignore.notwalkable==true then
			return e:get_team()~=agent:get_team() and e:is_deleted()==false
		else
			return e:get_team()~=agent:get_team() and e:get_current_tile():is_hole()==false and e:is_deleted()==false
		end
	end
	local enemy_table=field:find_characters(all_enemy)
	local target_tile
	local attachment=gobnade_spawn:add_attachment("HAND")
	local attachment_sprite=attachment:sprite()
	local attachment_animation=attachment:get_animation()
	attachment_sprite:set_texture(gobby.texture.gobnade)
	attachment_sprite:set_layer(-2)
	attachment_animation:load(gobby.animation.gobnade)
	attachment_animation:set_state(gobby.attack.class.."SPAWN")
	gobnade_spawn:add_anim_action(frame_trigger,function()
		attachment_sprite:hide()
		local frames_in_air=40
		local toss_height=70
		if #enemy_table==0 then
			for ypos=1,3 do
				for xpos=1,6 do
					tile=field:tile_at(xpos,ypos)
					if gobby.ignore.notwalkable==true then
						if tile:get_team()~=agent.team and tile~=agent:get_current_tile() then
							table.insert(tile_list,tile)
						end
					else
						if tile:get_team()~=agent.team and tile~=agent:get_current_tile() and tile:is_hole()==false then
							table.insert(tile_list,tile)
						end
					end
				end
			end
			target_tile=tile_list[math.random(1,#tile_list)]
		else
			target_tile=enemy_table[math.random(1,#enemy_table)]:get_current_tile()
		end
		if not target_tile then
			return
		end
		if gobby.gobnade.level==2 then
			aoe.list={
				target_tile,
				target_tile:get_tile(Direction.Up,1),
				target_tile:get_tile(Direction.Left,1),
				target_tile:get_tile(Direction.Down,1),
				target_tile:get_tile(Direction.Right,1),
				target_tile:get_tile(Direction.UpRight,1),
				target_tile:get_tile(Direction.UpLeft,1),
				target_tile:get_tile(Direction.DownLeft,1),
				target_tile:get_tile(Direction.DownRight,1)
			}
		elseif gobby.gobnade.level==1 then
			boomshape=math.random(0,1)
			if boomshape==0 then
				aoe.list={
					target_tile,
					target_tile:get_tile(Direction.Up,1),
					target_tile:get_tile(Direction.Left,1),
					target_tile:get_tile(Direction.Down,1),
					target_tile:get_tile(Direction.Right,1)
				}
			else
				aoe.list={
					target_tile,
					target_tile:get_tile(Direction.UpRight,1),
					target_tile:get_tile(Direction.UpLeft,1),
					target_tile:get_tile(Direction.DownLeft,1),
					target_tile:get_tile(Direction.DownRight,1)
				}
			end
		else
			boomshape=math.random(0,3)
			if boomshape==0 then
				aoe.list={
					target_tile,
					target_tile:get_tile(Direction.Up,1),
					target_tile:get_tile(Direction.Down,1)
				}
			elseif boomshape==1 then
				aoe.list={
					target_tile,
					target_tile:get_tile(Direction.UpRight,1),
					target_tile:get_tile(Direction.DownLeft,1)
				}
			elseif boomshape==2 then
				aoe.list={
					target_tile,
					target_tile:get_tile(Direction.Left,1),
					target_tile:get_tile(Direction.Right,1)
				}
			else
				aoe.list={
					target_tile,
					target_tile:get_tile(Direction.UpLeft,1),
					target_tile:get_tile(Direction.DownRight,1)
				}
			end
		end
		gobnade_spawn.on_landing=function ()
			local can_splode=aoe.list[1]:is_walkable()
			if gobby.ignore.notwalkable==true and not aoe.list[1]:is_edge() then
				can_splode=true
			end
			if can_splode then
				if gobby.gobnade.level==2 then
					for i,target in ipairs(aoe.list) do
						if not target:is_edge() then
							splosions_split=splosions.split(agent,gobby,target,field,hit,true)
						end
					end
					Engine.play_audio(gobby.audio.splosion.mass,AudioPriority.Low)
					splosions_spots=splosions.spots(agent,gobby,aoe.list,field,"splosion","MASS")
					if gobby.element.wind then splosions_spots=splosions.spots(agent,gobby,aoe.list,field,"wind","MASS") end
					if gobby.element.sword then splosions_spots=splosions.spots(agent,gobby,aoe.list,field,"slash","MASS") end
				else
					Engine.play_audio(gobby.audio.splosion.mono,AudioPriority.Low)
					for i,target in ipairs(aoe.list) do
						if not target:is_edge() then
							splosions_split=splosions.split(agent,gobby,target,field,hit,false)
						end
					end
				end
			end
		end
		toss_gobnade(agent,textures,toss_height,target_tile,frames_in_air,aoe,gobnade_spawn.on_landing)
	end)
	Engine.play_audio(gobby.audio.gobnade.toss,AudioPriority.Low)
end


function create_gobnade_attack(agent,gobby,current_cooldown,throw_num,action_channel_nonsense,mode)
	--print("create_gobnade_attack")
	local field=agent:get_field()
	local override_frames={{1,0.066},{2,0.066},{3,0.066},{4,0.066},{5,0.066},{6,0.066},{6,0.00}}
	--lockout_frames={{1,0.066},{2,0.066},{3,0.066},{4,0.066},{5,0.066}}
	local frame_data=make_frame_data(override_frames)
	local gobnade_spawns={}
	gobnade_spawns[throw_num]=Battle.CardAction.new(agent,"THROW")
	gobnade_spawns[throw_num]:set_lockout(make_animation_lockout())
	gobnade_spawns[throw_num]:override_animation_frames(frame_data)
	gobnade_spawns[throw_num].execute_func=function(self,user)
		local commentaudio={
			[1]=Engine.load_audio(_modpath.."voice/gobam.ogg"),
			[2]=Engine.load_audio(_modpath.."voice/goboom.ogg"),
			[3]=Engine.load_audio(_modpath.."voice/gobkerboom.ogg"),
			[4]=Engine.load_audio(_modpath.."voice/splosions.ogg")
		}
		local announceaudio={}
		gobnade_spawns[throw_num]:add_anim_action(1,function()
			if mode~="triple" then
				if gobby.gobnade.level==2 then
					announceaudio={
						[1]=Engine.load_audio(_modpath.."voice/hypergobnade.ogg")
					}
				elseif gobby.gobnade.level==1 then
					announceaudio={
						[1]=Engine.load_audio(_modpath.."voice/powergobnade0.ogg"),
						[2]=Engine.load_audio(_modpath.."voice/powergobnade1.ogg")
					}
				else
					announceaudio={
						[1]=Engine.load_audio(_modpath.."voice/gobnade0.ogg"),
						[2]=Engine.load_audio(_modpath.."voice/gobnade1.ogg"),
						[3]=Engine.load_audio(_modpath.."voice/gobnade2.ogg")
					}
				end
			elseif throw_num==1 then
				announceaudio={
					[1]=Engine.load_audio(_modpath.."voice/gobnadespam0.ogg"),
					[2]=Engine.load_audio(_modpath.."voice/gobnadespam1.ogg"),
					[3]=Engine.load_audio(_modpath.."voice/itssplosiontime0.ogg"),
					[4]=Engine.load_audio(_modpath.."voice/itssplosiontime1.ogg")
				}
			end
			if math.random(0,99)<gobby.chance.announce and throw_num==1 then
				Engine.play_audio(announceaudio[math.random(1,#announceaudio)],AudioPriority.Highest)
			end
			agent:toggle_counter(true)
			throw_gobnade(agent,gobby,gobnade_spawns[throw_num],3)
		end)
		gobnade_spawns[throw_num]:add_anim_action(3,function()
			agent:toggle_counter(false)
		end)
	end

	gobnade_spawns[throw_num].action_end_func=function ()
		agent.action_timer=current_cooldown
		agent.can_act=true
	end

	agent:card_action_event(gobnade_spawns[throw_num],ActionOrder.Involuntary)
end

function choose_open_tile(agent,warpfield)
	--print("choose_open_tile")
	local open_list={}
	local tile
	for ypos=1,3 do
		tile=warpfield:tile_at(1,ypos)
		if #agent.previous_tile>2 then
			if not is_occupied(tile) and tile:is_walkable() and not tile==agent.previous_tile[1] and not tile==agent.previous_tile[2] and not tile==agent.previous_tile[3] then
				table.insert(open_list,tile)
			end
		elseif #agent.previous_tile==2 then
			if not is_occupied(tile) and tile:is_walkable() and not tile==agent.previous_tile[1] and not tile==agent.previous_tile[2] then
				table.insert(open_list,tile)
			end
		else
			if not is_occupied(tile) and tile:is_walkable() and not tile==agent.previous_tile[1] then
				table.insert(open_list,tile)
			end
		end
	end
	for ypos=1,3 do
		tile=warpfield:tile_at(6,ypos)
		if #agent.previous_tile>2 then
			if not is_occupied(tile) and tile:is_walkable() and not tile==agent.previous_tile[1] and not tile==agent.previous_tile[2] and not tile==agent.previous_tile[3] then
				table.insert(open_list,tile)
			end
		elseif #agent.previous_tile==2 then
			if not is_occupied(tile) and tile:is_walkable() and not tile==agent.previous_tile[1] and not tile==agent.previous_tile[2] then
				table.insert(open_list,tile)
			end
		else
			if not is_occupied(tile) and tile:is_walkable() and not tile==agent.previous_tile[1] then
				table.insert(open_list,tile)
			end
		end
	end
	if #open_list<4 then
		for ypos=1,3 do
			tile=warpfield:tile_at(2,ypos)
			if #agent.previous_tile>2 then
				if not is_occupied(tile) and tile:is_walkable() and tile~=agent.previous_tile[1] and tile~=agent.previous_tile[2] and tile~=agent.previous_tile[3] then
					table.insert(open_list,tile)
				end
			elseif #agent.previous_tile==2 then
				if not is_occupied(tile) and tile:is_walkable() and tile~=agent.previous_tile[1] and tile~=agent.previous_tile[2] then
					table.insert(open_list,tile)
				end
			else
				if not is_occupied(tile) and tile:is_walkable() and tile~=agent.previous_tile[1] then
					table.insert(open_list,tile)
				end
			end
		end
		for ypos=1,3 do
			tile=warpfield:tile_at(5,ypos)
			if #agent.previous_tile>2 then
				if not is_occupied(tile) and tile:is_walkable() and tile~=agent.previous_tile[1] and tile~=agent.previous_tile[2] and tile~=agent.previous_tile[3] then
					table.insert(open_list,tile)
				end
			elseif #agent.previous_tile==2 then
				if not is_occupied(tile) and tile:is_walkable() and tile~=agent.previous_tile[1] and tile~=agent.previous_tile[2] then
					table.insert(open_list,tile)
				end
			else
				if not is_occupied(tile) and tile:is_walkable() and tile~=agent.previous_tile[1] then
					table.insert(open_list,tile)
				end
			end
		end
	end
	if #open_list==0 and agent:get_current_tile()~=agent.previous_tile[1] then
		agent.target_tile=agent.previous_tile[1]
	elseif #open_list==0 and #agent.previous_tile>1 then
		agent.target_tile=agent.previous_tile[2]
	elseif #open_list==0 then
		agent.target_tile=agent:get_current_tile()
	elseif #agent.previous_tile<=3 then
		agent.target_tile=open_list[math.random(1,#open_list)]
		table.insert(agent.previous_tile,agent.target_tile)
	end
end

function is_occupied(tile)
	return #tile:find_characters(all_query)>0 or #tile:find_obstacles(all_query)>0
end

function all_query()
	return true
end

