--based on Alrysc's fast (fist?) mantle and Rune's LifeAura.
--local mantle_sound=Engine.load_audio(_modpath.."mantle/mantle.ogg") -- Normalized -0.1

-------------------------------------------------[[ Mantle Details ]]------------------------------------------------

--[[
	details are:
	<mantle_details.element>,[mantle_details.level],[mantle_details.karma]
	
	mantle_details.element is required, and the mantle will fail if it is excluded.
	Use the Element.<Element> values or one of the valid strings to set the mantle's element.
	Valid elements for (standard*) mantles are Element.Sword, Element.Wind, Element.Cursor, Element.Break, "dark", and "evil".
	The list of valid Element.<Element> values are:
	Element.Fire
	Element.Aqua
	Element.Elec
	Element.Wood
	Element.Sword
	Element.Wind
	Element.Cursor
	Element.Break
	Element.None
	There are some strings that can be used in place of the Element.<Element>:
	"fire", "heat" for Element.Fire
	"water", "aqua" for Element.Aqua
	"electric", "elec" for Element.Elec
	"wood" for Element.Wood
	"sword", "swrd" for Element.Sword
	"wind" for Element.Wind
	"cursor", "crsr" for Element.Cursor
	"break", "brak" for Element.Break
	"normal", "norm", "none", "null" for Element.None
	In addition to these nine elements,there are to additional elements,as mentioned earlier:
	"dark"
	"evil"
	And these two are functionally Element.None, they also have a weakness to holy\light attacks that use the same
	karma system Rey Realms created... in exchange for a buff to the mantle's health,limit,and timer due to said karma.
	You really shouldn't use normal\none\null elemental mantle aside from "dark" or "evil". It's an option more for edge cases,
	like for bosses and such. Balancing issues and all.



	mantle_details.level defaults to 1 if omitted.
	Valid level values are 1 to 12. Going over 12 is treated as 12,going under 1 will be treated as 1, and nil or any non-number
	values are also treated as 1.
	Level determines health, limit, and time.
	Level 1 has 100 health and 40 limit, with each level above 1 getting an additional 25 health and 10 limit per level.
	And for the timer,at level 1 to 4 a mantle has 5000 frames it will last for... so just under ten seconds. At levels 5 to 8 it lasts
	for 10000 frames,and at levels 9 to 12 lasts for 15000 frames.
	Surpassing certain levels also alters the green tint. Level 1 to 4 have no tint, 5 to 8 have a green tint, 9 to 12 have a dark green tint.

	As for a mantle's limit,dealing damage equal to the limit will cause it to be dismissed immediately. This may or may not be potentially
	removed in the future.



	mantle_details.karma is the default 'dark' and 'evil' level of the barrier. "dark" element defaults to "dark", "evil" element
	defaults to "evil", other elements default to "mantle".
	If mantle_details.karma is omitted, or invalid, it will be set to "mantle".
	This karma system is actually where the buffs to the mantle comes from for aforementioned "dark" and "evil" element mantles,
	but the holy\light weakness in exchange for mantle buffs can be applied to any element using this karma system. It should be
	noted that if the player meets the criteria for a non-neutral tier they may push the mantle's karma in that direction,overwriting
	your setting here to some extent.
	The changes from karma are as follows:
	"dark":
		level's health + 25
		level's limit + 10
		level's timer + (base timer divided by 2)
		level's tint + purple tint
		weakness to holy\light
	"evil":
		level's health + 50
		level's limit + 20
		level's timer + base timer
		level's tint + red tint
		big weakness to holy\light



	Important things to note:
		> If you use any strings in the details make sure they are entirely lowercase. ONB did not support string.lower() (or string.upper()
		  for that matter) when this mantle script was made,so strings must be in all lowercase since the strings they are checked against
		  are all lowercase.
		> These are the only three variables that are stored in mantle_details that the mantle script will check when mantle_details is passed
		  to the main script. Setting mantle_details.timer or mantle_details.health and so on will not effect the mantle at all.
		> level will only accept numbers. Any decimals will be rounded down to a whole number.
		> karma will only accept strings.
		> element accepts strings,and numbers. Any decimals will be rounded down to a whole number. However,using raw numbers is highly
		  discouraged. Just use the Element.<Element> or one of the valid strings to maintain future compatability.
]]--

-------------------------------------------------[[ Mantle Function ]]-----------------------------------------------

function create_mantle(agent,mantle_details)
	local core_name=agent.corename
	--print(agent.mantle_texpath)
	local mantle_texture_path=nil
	local mantle_animation_path=nil
	local mantle=nil
	local mantle_texture=nil
	local mantle_animation=nil
	local mantle_type=nil
	local mantle_default_countdown=5000
	local mantle_fade_countdown=mantle_default_countdown*1
	local mantle_attach=nil
	local mantle_attach_texture=nil
	local mantle_attach_animation=nil
	local mantle_attach_point=nil
	local destroy_mantle=false
	local weakness=Element.None
	local mantleRef={}
	mantleRef.remove_mantle=false
	local mantle_voiceline_delay=3

--------------------------------------------------[[ Mantle Setup ]]-------------------------------------------------

	if type(mantle_details.element)=="string" then
		if mantle_details.element=="dark" or mantle_details.element=="evil" then
			mantle_type="DARK"
		elseif mantle_details.element=="fire" or mantle_details.element=="heat" then
			mantle_details.element=Element.Fire
			mantle_type="FIRE"
			weakness=Element.Aqua
		elseif mantle_details.element=="water" or mantle_details.element=="aqua" then
			mantle_details.element=Element.Aqua
			mantle_type="WATER"
			weakness=Element.Elec
		elseif mantle_details.element=="electric" or mantle_details.element=="elec" then
			mantle_details.element=Element.Elec
			mantle_type="ELECTRIC"
			weakness=Element.Wood
		elseif mantle_details.element=="wood" then
			mantle_details.element=Element.Wood
			mantle_type="WOOD"
			weakness=Element.Fire
		elseif mantle_details.element=="sword" or mantle_details.element=="swrd" then
			mantle_details.element=Element.Sword
			mantle_type="SWORD"
			weakness=Element.Break
		elseif mantle_details.element=="wind" then
			mantle_details.element=Element.Wind
			mantle_type="WIND"
			weakness=Element.Sword
		elseif mantle_details.element=="cursor" or mantle_details.element=="crsr" then
			mantle_details.element=Element.Cursor
			mantle_type="CURSOR"
			weakness=Element.Wind
		elseif mantle_details.element=="break" or mantle_details.element=="brak" then
			mantle_details.element=Element.Break
			mantle_type="BREAK"
			weakness=Element.Cursor
		elseif mantle_details.element=="normal" or mantle_details.element=="norm" or mantle_details.element=="none" or mantle_details.element=="null" then
			mantle_details.element=Element.None
			mantle_type="NULL"
		else
			mantle_details.element="invalid"
		end
	elseif type(mantle_details.element)=="number" then
		if math.floor(mantle_details.element)==Element.Fire then
			mantle_type="FIRE"
			weakness=Element.Aqua
		elseif math.floor(mantle_details.element)==Element.Aqua then
			mantle_type="WATER"
			weakness=Element.Elec
		elseif math.floor(mantle_details.element)==Element.Elec then
			mantle_type="ELECTRIC"
			weakness=Element.Wood
		elseif math.floor(mantle_details.element)==Element.Wood then
			mantle_type="WOOD"
			weakness=Element.Fire
		elseif math.floor(mantle_details.element)==Element.Sword then
			mantle_type="SWORD"
			weakness=Element.Break
		elseif math.floor(mantle_details.element)==Element.Wind then
			mantle_type="WIND"
			weakness=Element.Sword
		elseif math.floor(mantle_details.element)==Element.Cursor then
			mantle_type="CURSOR"
			weakness=Element.Wind
		elseif math.floor(mantle_details.element)==Element.Break then
			mantle_type="BREAK"
			weakness=Element.Cursor
		elseif math.floor(mantle_details.element)==Element.None then
			mantle_type="NULL"
		else
			mantle_details.element="invalid"
		end
	else
		mantle_details.element="invalid"
	end

	if type(mantle_details.element)=="string" and mantle_details.element=="invalid" then print("Can't produce the desired mantle for "..core_name.." due to invalid elemnt.") return end

	if mantle_details.level==nil or type(mantle_details.level)~="number" or mantle_details.level<1 then mantle_details.level=1 elseif mantle_details.level>12 then mantle_details.level=12 end
	mantle_details.level=math.floor(mantle_details.level)

	if mantle_details.level>=1 and mantle_details.level<=10 then
		mantle_details.hp=(25*mantle_details.level)+75
		mantle_details.limit=(10*mantle_details.level)+30
	end

	if agent:get_animation():has_state("IS_EVIL_ELEMENT_FLAG_STATE") or mantle_details.element=="evil" or mantle_details.karma=="evil" then
		mantle_details.texture="mantle_evil"
		mantle_animation_path=_modpath.."mantle/evilmantle.animation"
		mantle_details.hp=mantle_details.hp+50
		mantle_details.limit=mantle_details.limit+20
		mantle_fade_countdown=mantle_fade_countdown+mantle_default_countdown
	elseif agent:get_animation():has_state("IS_DARK_ELEMENT_FLAG_STATE") or mantle_details.element=="dark" or mantle_details.karma=="dark" then
		mantle_details.texture="mantle_dark"
		mantle_animation_path=_modpath.."mantle/darkmantle.animation"
		mantle_details.hp=mantle_details.hp+25
		mantle_details.limit=mantle_details.limit+10
		mantle_fade_countdown=mantle_fade_countdown+(math.floor(mantle_default_countdown/2))
	else
		mantle_details.texture="mantle"
	end

	if mantle_details.level>8 then
		mantle_details.texture="powerful_"..mantle_details.texture
		mantle_fade_countdown=mantle_default_countdown*3
	elseif mantle_details.level>4 then
		mantle_details.texture="strong_"..mantle_details.texture
		mantle_fade_countdown=mantle_default_countdown*2
	end

	if mantle_details.texture~=nil then mantle_texture_path=Engine.load_texture(_modpath.."mantle/"..mantle_details.texture..".png") else mantle_texture_path=Engine.load_texture(_modpath.."mantle/mantle.png") end

	if mantle_animation_path==nil then mantle_animation_path=_modpath.."mantle/mantle.animation" end

------------------------------------------------[[ Mantle Attachment ]]------------------------------------------------


	if agent.mantle_texpath then
		agent:set_texture(agent.mantle_texpath)
	end



	local mantle_voice_component=Battle.Component.new(agent,Lifetimes.Scene)
	mantle_voice_component.update_func=function(self,dt)
		local voice_mute_table=agent:get_field():tile_at(0,0):find_entities(function(entity)
			return entity:get_name()=="Hi\u{0021} You need to stop talking now\u{002C} okay\u{003F}"
		end)
		if #voice_mute_table>0 then
			mantle_voice_component:eject()
		else
			if mantle_voiceline_delay>0 then
				mantle_voiceline_delay=mantle_voiceline_delay-1
			else
				--print("Does "..core_name.." have a mantle_voice_file or mantle_voice_files property?")
				if agent.mantle_voice_files==nil and agent.mantle_voice_file==nil then
					--[[print("No, "..core_name.." does not have a mantle_voice_name or mantle_voice_names property.")
					print(core_name.." will not use a mantle voice.")]]
				else
					--[[print("Yes, "..core_name.." does have a mantle_voice_name or mantle_voice_names property.")
					print("Does "..core_name.." have a mantle_voice_path property?")]]
					if agent.mantle_voice_path==nil then
						--[[print("No, "..core_name.." does not have a mantle_voice_path property.")
						print(core_name.." will not use a mantle voice.")]]
					else
						--[[print("Yes, "..core_name.." does have a mantle_voice_path property.")
						print("Will attempt to play (one of) "..core_name.."'s mantle voice(s).")]]
						if agent.mantle_voice_files~=nil then
							Engine.play_audio(Engine.load_audio(agent.mantle_voice_path.."/"..(agent.mantle_voice_files[math.random(1,#agent.mantle_voice_files)])),AudioPriority.Low)
						else
							Engine.play_audio(Engine.load_audio(agent.mantle_voice_path.."/"..agent.mantle_voice_file),AudioPriority.Low)
						end
					end
				end
				mantle_voice_component:eject()
			end
		end
	end

-------------------------------------------------[[ Applying Mantle ]]-------------------------------------------------

	--[[local offsetY=-2*(agent:get_height()-48) -- MegaMan is 48 and I built around that, so I'm just offsetting for different heights by a bit
	--print(offsetY)
	if offsetY > 0 then offsetY=0 end
	local isWind=false]]
	local fading=false
	local isWeak=false
	local remove_mantle=false

	mantle=agent:create_node()

	mantle:set_layer(3)
	mantle:set_texture(mantle_texture_path, true)
	mantle_animation=Engine.Animation.new(mantle_animation_path)

	mantle_animation:set_state(mantle_type.."_ACTIVE")
	mantle_animation:refresh(mantle)
	mantle_animation:set_playback(Playback.Loop)

	--mantle:set_offset(mantle_animation:point("origin"))
	--number:set_offset(0, 12)

---------------------------------------------------[[ Defense Rule ]]--------------------------------------------------

	local mantle_defense_rule=Battle.DefenseRule.new(1,DefenseOrder.Always) -- Keristero's Guard is 0
	mantle_defense_rule.can_block_func=function(judge,attacker,defender)
		local attacker_hit_props=attacker:copy_hit_props()
	
		--[[if attacker_hit_props.element==Element.Wind then
			isWind=true
		end]]
		if attacker_hit_props.element==weakness and weakness~=Element.None then
			isWeak=true
		end

		if attacker_hit_props.damage>=2 then
			if not isweak then
				if attacker_hit_props.damage>=mantle_details.limit then destroy_mantle=true	return end
				mantle_details.hp=mantle_details.hp - (attacker_hit_props.damage - math.floor(attacker_hit_props.damage/2))
			else
				if (attacker_hit_props.damage - math.floor(attacker_hit_props.damage*2))>=mantle_details.limit then destroy_mantle=true return end
				mantle_details.hp=mantle_details.hp - attacker_hit_props.damage*2
			end
			attacker_hit_props.damage=math.floor(attacker_hit_props.damage/2)
			attacker:set_hit_props(attacker_hit_props)
		elseif attacker_hit_props.damage>=0 then
			if not isweak then
				mantle_details.hp=mantle_details.hp - attacker_hit_props.damage
			else
				mantle_details.hp=mantle_details.hp - attacker_hit_props.damage*2
			end
			judge:block_damage()
		end
	end
	--Engine.play_audio(mantle_sound,AudioPriority.Highest)

--------------------------------------------------[[ Update Mantle ]]--------------------------------------------------

	local mantle_animate_component=Battle.Component.new(agent,Lifetimes.Scene)

	mantle_animate_component.update_func=function(self,dt)
		local field=agent:get_field()
		local agentteam=agent:get_team()
		local function all_enemy(e)
			return e:get_team()~=agentteam and e:is_deleted()==false
		end
		local enemy_table=field:find_characters(all_enemy)
		if #enemy_table>0 then
			mantle_animation:update(dt,mantle)
		end
	end

	local mantle_fade_component=Battle.Component.new(agent, Lifetimes.Battlestep)
	mantle_fade_component.update_func=function(self, dt)
		if mantle_fade_countdown <= 0 then
			destroy_mantle=true
		else
			mantle_fade_countdown=mantle_fade_countdown - 1
		end
	end

--------------------------------------------------[[ Remove Mantle ]]--------------------------------------------------

	local function remove_mantle_attach()
		--[[print(mantle_attach)
		print("Does "..core_name.." have an active mantle attachment?")]]
		if mantle_attach~=nil then
			--[[print("Yes, "..core_name.." does have an active mantle attachment.")
			print("Attempting to remove "..core_name.."'s mantle attachment.")]]
			agent:set_texture(agent.texpath)
			mantle_attach=nil
		else
			--print("No, "..core_name.." does not have an active mantle attachment.")
		end
	end

	local mantle_destroy_component=Battle.Component.new(agent, Lifetimes.Scene)
	mantle_destroy_component.update_func=function(self, dt)
		--[[if isWind and not fading then
			remove_mantle=true
		end]]

		if destroy_mantle and not fading then
			remove_mantle=true
		end

		if mantle_details.hp <= 0 and not fading then
			remove_mantle=true
		end

		if mantle_defense_rule:is_replaced() then
			remove_mantle=true
		end

		if (remove_mantle or mantleRef.remove_mantle) and not fading then
			fading=true
			agent:remove_defense_rule(mantle_defense_rule)
			--agent.mantle_on=false --Why did I have this line? Where did it come from? The variable doesn't seem to be used anywhere either. . .
			remove_mantle_attach()

			mantle_animation:set_state(mantle_type.."FADE")
			mantle_animation:refresh(mantle)
			mantle_animation:set_playback(Playback.Once)

			mantle_animation:on_complete(function()
				agent:remove_node(mantle)
				mantle_fade_component:eject()
				mantle_animate_component:eject()
				mantle_destroy_component:eject()
			end)

			--[[if isWind then
				local initialX=mantle:get_offset().x
				local initialY=mantle:get_offset().y
				local facing_check=1
				if agent:get_facing() == Direction.Left then
					facing_check=-1
				end

				mantle_animation:on_frame(1, function()
					mantle:set_offset(facing_check * (-25 - initialX), -20+initialY)
				end)

				mantle_animation:on_frame(2, function()
					mantle:set_offset(facing_check * (-50 - initialX), -40+initialY)
				end)

				mantle_animation:on_frame(3, function()
					mantle:set_offset(facing_check * (-75 - initialX), -60+initialY)
				end)
			end]]
		end
	end

------------------------------------------------[[ Register Mantle ]]--------------------------------------------------

	agent:add_defense_rule(mantle_defense_rule)
	agent:register_component(mantle_fade_component)
	agent:register_component(mantle_destroy_component)
	agent:register_component(mantle_animate_component)
	agent:register_component(mantle_voice_component)
end
return create_mantle