local splosions={}

--splosion splitter--
splosions.split=function(agent,gobby,tile,field,hit,blank)
	if blank then
		splosions_blast(agent,gobby,tile,field,hit,blank)
	else
		splosions_hit(agent,gobby,tile,field,hit,blank)
	end
end

--blank--
function splosions_blast(agent,gobby,tile,field,hit,blank)
	--local spell=Battle.Spell.new(attack_team)
	local spell=Battle.Spell.new(agent:get_team())
	local windbox=HitProps.new(
		0,
		Hit.None,
		Element.Wind,
		agent:get_id(),
		Drag.None
	)
	spell:set_hit_props(windbox)
	spell.has_attacked=false
	spell.update_func=function(self)
		if not spell.has_attacked then
			spell:get_current_tile():attack_entities(self)
			spell.has_attacked=true
		else
			splosions_hit(agent,gobby,tile,field,hit,blank)
			self:delete()
		end
	end
	field:spawn(spell,tile)
end

--splosion--
function splosions_hit(agent,gobby,tile,field,hit,blank)
	local commenttimer=27
	--local spell=Battle.Spell.new(attack_team)
	local spell=Battle.Spell.new(agent:get_team())
	if gobby.gobnade.level==2 then
		gobby.hitprops.flags=Hit.Impact | Hit.Flinch | Hit.Flash
		if gobby.element.sword==true then
			gobby.hitprops.element=Element.Sword
		else
			gobby.hitprops.element=Element.None
		end
	else
		gobby.hitprops.flags=Hit.Impact
	end
	spell:set_hit_props(gobby.hitprops)
	spell.has_attacked=false
	spell.update_func=function(self)
		if commenttimer~=2 and commenttimer~=0 then
			commenttimer=commenttimer-1
		elseif commenttimer==2 then
			if gobby.chance.comment>0 then
				splosions.commentaudio={
					[1]=Engine.load_audio(_modpath.."voice/gobam.ogg"),
					[2]=Engine.load_audio(_modpath.."voice/goboom.ogg"),
					[3]=Engine.load_audio(_modpath.."voice/gobkerboom.ogg"),
					[4]=Engine.load_audio(_modpath.."voice/splosions.ogg")
				}
			end
			if math.random(0,99)<gobby.chance.comment and not blank then
				Engine.play_audio(splosions.commentaudio[math.random(1,#splosions.commentaudio)],AudioPriority.Low)
			end
			commenttimer=commenttimer-1
		end
		if not spell.has_attacked then
			spell:get_current_tile():attack_entities(self)
			spell.has_attacked=true
		elseif not spell.has_hit then
			if not blank then
				create_splosion(agent,gobby,tile,field,"splosion","DEFAULT")
			end
			spell.has_hit=true
		elseif commenttimer<=0 then
			self:delete()
		end
	end
	field:spawn(spell,tile)
	spell.attack_func=function(self,other)
		if hit.sound==false then
			Engine.play_audio(gobby.audio.splosion.hit,AudioPriority.Highest)
			hit.sound=true
		end
	end
end

--splosion generaton code
splosions.spots=function(agent,gobby,list,field,splode_type,splode_state)
	local commenttimer=52
	local randblast_handler=Battle.Artifact.new()
	shuffle(list)
	local tilenum=1
	local cooldown=0
	--agent:shake_camera(10, 0.5)
	randblast_handler.update_func=function (self,dt) --this is where the random splosion magic happens
		if commenttimer~=2 and commenttimer~=0 then
			commenttimer=commenttimer-1
		elseif commenttimer==2 then
			if gobby.chance.comment>0 then
				splosions.commentaudio={
					[1]=Engine.load_audio(_modpath.."voice/gobam.ogg"),
					[2]=Engine.load_audio(_modpath.."voice/goboom.ogg"),
					[3]=Engine.load_audio(_modpath.."voice/gobkerboom.ogg"),
					[4]=Engine.load_audio(_modpath.."voice/splosions.ogg")
				}
			end
			if math.random(0,99)<gobby.chance.comment and not blank then
				Engine.play_audio(splosions.commentaudio[math.random(1,#splosions.commentaudio)],AudioPriority.Low)
			end
			commenttimer=commenttimer-1
		end
		if tilenum <= #list and cooldown % 12==0 then
			local currenttile=list[tilenum]
            create_splosion(agent,gobby,currenttile,field,splode_type,splode_state)
			tilenum=tilenum+1
			cooldown=0
		end
		if tilenum >= #list and commenttimer<=0 then
			self:delete()
			--print("splosions ended")
		end
		cooldown=cooldown+4
	end
	field:spawn(randblast_handler,agent:get_current_tile())
end

--shuffling code
function shuffle(tbl) --shuffle tables. very useful code
	for i=#tbl, 2, -1 do
		local j=math.random(i)
		tbl[i], tbl[j]=tbl[j], tbl[i]
	end
	return tbl
end

--make the splosion fx
function create_splosion(agent,gobby,tile,field,splode_type,splode_state)
	if gobby.attack.type[gobby.gobnade.level]==nil then
		gobby.gobnade.level=0
	end
	if gobby.attack.rank[gobby.gobnade.rank]==nil then
		gobby.gobnade.rank=0
	end
	if gobby.gobnade.rank==1 then
		if gobby.gobnade.level==2 then
			gobby.splosion.rank="darksoul"
		else
			gobby.splosion.rank="dark"
		end
	elseif gobby.gobnade.rank==2 then
		gobby.splosion.rank="xanthic"
	else
		gobby.splosion.rank="base"
	end
	local fx=Battle.Artifact.new()
	fx:set_texture(Engine.load_texture(_modpath.."splosions/"..gobby.splosion.rank.."/"..splode_type..".png"),true)
	fx:get_animation():load(_modpath.."splosions/"..splode_type..".animation")
	fx:get_animation():set_state(splode_state)
	fx:get_animation():on_complete(function()
		fx:erase()
	end)
	fx:set_height(-16.0)
	field:spawn(fx,tile)
	fx:get_animation():refresh(fx:sprite())
end

return splosions