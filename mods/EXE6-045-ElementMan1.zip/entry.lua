local package_id = "com.OFC.mob.EXE6-045-ElementMan1"
local character_id = "com.OFC.char.EXE6-045-ElementMan1"

function package_requires_scripts()
    Engine.define_character(character_id, _modpath.."ElementMan")
end

function package_init(package)
    package:declare_package_id(package_id)
    package:set_name("ElementMan (EXE6)")
    package:set_description("Test fight with\nElementMan\nfrom Rockman EXE6")
    package:set_speed(1)
    package:set_attack(30)
    package:set_health(900)
    package:set_preview_texture_path(_modpath.."preview.png")
end

function package_build(mob)
    local texPath = _modpath.."14-weatherkunnodennou2.png"
    local animPath = _modpath.."14-weatherkunnodennou.animation"
    mob:set_background(texPath, animPath, 0.125, 0.125)
    mob:stream_music(_modpath.."exe6-boss.ogg", 6817, 58254)
    mob:create_spawner(character_id, Rank.V1):spawn_at(5,2)
end