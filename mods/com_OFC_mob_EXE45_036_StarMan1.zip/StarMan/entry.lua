local print_debug = false

local AUDIO_DAMAGE_PLAYER = Engine.load_audio(_folderpath.."sfx/EXE4_219.ogg", true)
local AUDIO_DAMAGE_ENEMY = Engine.load_audio(_folderpath.."sfx/EXE4_270.ogg", true)
local AUDIO_DAMAGE_OBS = Engine.load_audio(_folderpath.."sfx/EXE4_221.ogg", true)

local STARMAN_TEXTURE = nil
local STARMAN_PALETTE = nil
local STARMAN_ANIMPATH = _folderpath.."gfx/starman.animation"

local KIRAKIRAMETEOR_TEXTURE = Engine.load_texture(_folderpath.."gfx/kirakirameteor.png")
local KIRAKIRAMETEOR_ANIMPATH = _folderpath.."gfx/kirakirameteor.animation"
local STARARROW_TEXTURE = Engine.load_texture(_folderpath.."gfx/stararrow.png")
local STARARROW_ANIMPATH = _folderpath.."gfx/stararrow.animation"
local MOONDANCE_TEXTURE = Engine.load_texture(_folderpath.."gfx/moondance.png")
local MOONDANCE_ANIMPATH = _folderpath.."gfx/moondance.animation"

local KIRAKIRAMETEOR_AUDIO = Engine.load_audio(_folderpath.."sfx/starfall.ogg", true)
local STARARROW_AUDIO = Engine.load_audio(_folderpath.."sfx/EXE4_354.ogg", true)
local MOONDANCE_SPAWN_AUDIO = Engine.load_audio(_folderpath.."sfx/EXE4_138.ogg", true)
local MOONDANCE_SHOOT_AUDIO = Engine.load_audio(_folderpath.."sfx/EXE4_143.ogg", true)

local EFFECT_TEXTURE = Engine.load_texture(_folderpath.."gfx/effect.png")
local EFFECT_ANIMPATH = _folderpath.."gfx/effect.animation"
local EFFECTS_TEXTURE = Engine.load_texture(_folderpath.."gfx/effects.png")
local EFFECTS_ANIMPATH = _folderpath.."gfx/effects.animation"

local function debug_print(text)
    if print_debug then
        print("[StarMan] "..text)
    end
end

local function graphic_init(g_type, x, y, texture, animation, state, anim_playback, layer, user, facing, flip)
    flip = flip or false
    facing = facing or nil
    
    local graphic = nil
    if g_type == "artifact" then 
        graphic = Battle.Artifact.new()
    elseif g_type == "spell" then 
        graphic = Battle.Spell.new(user:get_team())
    end

    if layer then
        graphic:sprite():set_layer(layer)
    end
    graphic:never_flip(flip)
    if texture then
        graphic:set_texture(texture, false)
    end
    if facing then
        graphic:set_facing(facing)
    end
    
    if user:get_facing() == Direction.Left then 
        x = x * -1
    end
    graphic:set_offset(x, y)
    if animation then
        graphic:get_animation():load(animation)
    end
    if state then
        graphic:get_animation():set_state(state)
    end
    graphic:get_animation():refresh(graphic:sprite())
    if anim_playback then
        graphic:get_animation():set_playback(anim_playback)
    end

    return graphic
end

local function create_sparkles(user, tile, tiled, field)
    local rng_flip = math.random(1,4)
    local rng_x = (math.random(-9,10)*2)
    local rng_y = (math.random(-30,-10)*2)
    if tiled then
        rng_y = (math.random(-10,9)*2)
    end
    local sparkles = graphic_init("artifact", rng_x, rng_y, EFFECTS_TEXTURE, EFFECTS_ANIMPATH, "SPARKLE_"..rng_flip.."T", Playback.Once, -99, user, Direction.Right, true)
    sparkles:get_animation():on_complete(function() sparkles:erase() end)
    field:spawn(sparkles, tile)
    return sparkles
end

local function create_sparkles_spawner(user, tile, tiled)
    local field = user:get_field()
    local sparkles_spawner = graphic_init("spell", 0, 0, false, false, false, false, false, user, user:get_facing())
    sparkles_spawner.frames = 0
    sparkles_spawner.update_func = function(self)
        if self.frames < 26 then
            self.frames = self.frames + 1
            for i=1, 4 do
                if self.frames == i then
                    create_sparkles(user, tile, tiled, field)
                end
            end
            for i=8, 11 do
                if self.frames == i then
                    create_sparkles(user, tile, tiled, field)
                end
            end
            for i=15, 18 do
                if self.frames == i then
                    create_sparkles(user, tile, tiled, field)
                end
            end
            for i=22, 25 do
                if self.frames == i then
                    create_sparkles(user, tile, tiled, field)
                end
            end
        else
            self:erase()
        end
    end
    field:spawn(sparkles_spawner, tile)
    return sparkles_spawner
end

local function create_kirakirameteor(user, tile)
    local stararrow = graphic_init("spell", 0, 0, KIRAKIRAMETEOR_TEXTURE, KIRAKIRAMETEOR_ANIMPATH, "0", Playback.Loop, -3, user, user:get_facing())
    stararrow:set_hit_props(
        HitProps.new(
            user.damage_kirakirameteor,
            Hit.Impact | Hit.Flinch | Hit.Flash,
            user:get_element(), 
            user:get_context(), 
            Drag.None
        )
    )
    stararrow.offset_y = -150*2
    stararrow.offset_y_mod = 5*2
    stararrow.offset_x = 120*2
    stararrow.offset_x_mod = 4*2
    if stararrow:get_facing() == Direction.Right then
        stararrow.offset_x = -stararrow.offset_x
        stararrow.offset_x_mod = -stararrow.offset_x_mod
    end
    stararrow:set_offset(stararrow.offset_x, stararrow.offset_y)
    stararrow.on_spawn_func = function()
        debug_print("KirakiraMeteor spawned at tile ("..tile:x()..";"..tile:y()..")")
        Engine.play_audio(KIRAKIRAMETEOR_AUDIO, AudioPriority.Low)
    end
    stararrow.frame_spawner = 1
    stararrow.update_func = function(self)
        if self.offset_y >= 0 then
            create_sparkles_spawner(user, tile, true)
            self:get_tile():attack_entities(self)
            self:erase()
        else
            self:highlight_tile(Highlight.Flash)
            self.offset_x = self.offset_x - self.offset_x_mod
            self.offset_y = self.offset_y + self.offset_y_mod
            self:set_offset(self.offset_x, self.offset_y)
        end
        if self.frame_spawner == 1 then
            local star = graphic_init("artifact", -self.offset_x, self.offset_y, KIRAKIRAMETEOR_TEXTURE, KIRAKIRAMETEOR_ANIMPATH, "1", Playback.Once, -3, user, user:get_facing())
            star:get_animation():on_complete(function() star:erase() end)
            user:get_field():spawn(star, tile)
        end
        self.frame_spawner = self.frame_spawner + 1
        if self.frame_spawner >= 3 then self.frame_spawner = 1 end
    end
    stararrow.attack_func = function(self, other)
        local hit_effect = graphic_init("artifact", (math.random(-8,9)*2), (math.random(-3,2)*2), EFFECT_TEXTURE, EFFECT_ANIMPATH, "0", Playback.Once, -99, user, Direction.Right, true)
        hit_effect:get_animation():on_complete(function() hit_effect:erase() end)
        user:get_field():spawn(hit_effect, other:get_tile())
        if Battle.Obstacle.from(other) == nil then
            --[[
			if Battle.Player.from(proto) ~= nil then
				Engine.play_audio(AUDIO_DAMAGE_ENEMY, AudioPriority.Low)
			end
            ]]
		else
			Engine.play_audio(AUDIO_DAMAGE_OBS, AudioPriority.Low)
		end
    end
    user:get_field():spawn(stararrow, tile)
    return stararrow
end

local function create_stararrow(user, tile)
    local stararrow = graphic_init("spell", 0, 0, STARARROW_TEXTURE, STARARROW_ANIMPATH, "0", Playback.Loop, -3, user, user:get_facing())
    stararrow:set_hit_props(
        HitProps.new(
            user.damage_stararrow,
            Hit.Impact | Hit.Flinch | Hit.Flash,
            user:get_element(), 
            user:get_context(), 
            Drag.None
        )
    )
    local round = function(val)
        if facing == Direction.Right then
            return math.floor(val)
        else
            return math.ceil(val)
        end
    end
    local tileWidth = tile:width()/2
    local tileHeight = tile:height()/2
    stararrow.x_coord = -tileWidth
    stararrow.x_speed = 10
    if stararrow:get_facing() == Direction.Left then
        stararrow.x_coord = -stararrow.x_coord
        stararrow.x_speed = -stararrow.x_speed
    end
    stararrow:set_offset(stararrow.x_coord, -40*2)
    stararrow.on_spawn_func = function()
        debug_print("StarArrow spawned at tile ("..tile:x()..";"..tile:y()..")")
        Engine.play_audio(STARARROW_AUDIO, AudioPriority.Low)
    end
    stararrow.update_func = function(self)
        self:highlight_tile(Highlight.Solid)
        self:get_tile():attack_entities(self)
        if self:get_facing() == Direction.Right and round(self.x_coord) >= tileWidth then
            if not self:get_tile():is_edge() then
                self:teleport(self:get_tile(Direction.Right, 1), ActionOrder.Immediate)
                self.x_coord = -tileWidth
            else
                self:erase()
            end
        elseif self:get_facing() == Direction.Left and round(self.x_coord) <= -tileWidth then
            if not self:get_tile():is_edge() then
                self:teleport(self:get_tile(Direction.Left, 1), ActionOrder.Immediate)
                self.x_coord = tileWidth
            else
                self:erase()
            end
        end
        self.x_coord = self.x_coord + self.x_speed
        self:set_offset(self.x_coord, self:get_offset().y)
    end
    stararrow.attack_func = function(self, other)
        local hit_effect = graphic_init("artifact", self.x_coord, (math.random(-43,-37)*2), EFFECT_TEXTURE, EFFECT_ANIMPATH, "0", Playback.Once, -99, user, Direction.Right, true)
        hit_effect:get_animation():on_complete(function() hit_effect:erase() end)
        user:get_field():spawn(hit_effect, other:get_tile())
        if Battle.Obstacle.from(other) == nil then
            --[[
			if Battle.Player.from(proto) ~= nil then
				Engine.play_audio(AUDIO_DAMAGE_ENEMY, AudioPriority.Low)
			end
            ]]
		else
			Engine.play_audio(AUDIO_DAMAGE_OBS, AudioPriority.Low)
		end
    end
    stararrow.collision_func = function(self)
        self:erase()
    end
    stararrow.can_move_to_func = function(tile)
        return true
    end
    user:get_field():spawn(stararrow, tile)
    return stararrow
end

local function create_moondance(user, tile)
    local moondance = graphic_init("spell", 0, 0, MOONDANCE_TEXTURE, MOONDANCE_ANIMPATH, "0", Playback.Loop, -3, user, user:get_facing())
    moondance:get_animation():set_playback_speed(0)
    moondance:set_hit_props(
        HitProps.new(
            user.damage_moondance,
            Hit.Impact | Hit.Flinch | Hit.Flash,
            user:get_element(), 
            user:get_context(), 
            Drag.None
        )
    )
    moondance:hide()
    moondance.start_y = tile:y()
    moondance.revealed = false
    moondance.frames = 0
    moondance.state = "WAIT"
    moondance.tile1 = nil
    moondance.tile2 = nil
    moondance.tile3 = nil
    moondance.tile4 = nil
    moondance.tile5 = nil
    moondance.movestate = "DOWN"
    moondance.the5tile = false
    moondance.slide_dir = Direction.Down
    if moondance.start_y == 1 then
        moondance.tile1 = tile:get_tile(Direction.Down, 2)
        moondance.tile2 = moondance.tile1:get_tile(moondance:get_facing(), 2)
        moondance.tile3 = moondance.tile2:get_tile(Direction.Up, 2)
        moondance.tile4 = moondance.tile3:get_tile(moondance:get_facing_away(), 2)
    elseif moondance.start_y == 2 then
        moondance.tile1 = tile:get_tile(Direction.Down, 1)
        moondance.tile2 = moondance.tile1:get_tile(moondance:get_facing(), 2)
        moondance.tile3 = moondance.tile2:get_tile(Direction.Up, 2)
        moondance.tile4 = moondance.tile3:get_tile(moondance:get_facing_away(), 2)
        moondance.tile5 = moondance.tile4:get_tile(Direction.Down, 1)
    elseif moondance.start_y == 3 then
        moondance.tile1 = tile:get_tile(moondance:get_facing(), 2)
        moondance.tile2 = moondance.tile1:get_tile(Direction.Up, 2)
        moondance.tile3 = moondance.tile2:get_tile(moondance:get_facing_away(), 2)
        moondance.tile4 = moondance.tile3:get_tile(Direction.Down, 2)
        moondance.movestate = "FORWARD"
        moondance.slide_dir = moondance:get_facing()
    end
    moondance.slide_started = false
    moondance.on_spawn_func = function(self)
        debug_print("MoonDance spawned at tile ("..tile:x()..";"..tile:y()..")")
        Engine.play_audio(MOONDANCE_SPAWN_AUDIO, AudioPriority.Low)
        create_sparkles_spawner(user, tile, false)
    end
    moondance.update_func = function(self)
        self.frames = self.frames + 1
        if self.revealed then
            self:highlight_tile(Highlight.Solid)
            self:get_tile():attack_entities(self)
        end
        if self.state == "WAIT" then
            if self.frames == 31 then
                self:reveal()
                self.revealed = true
            elseif self.frames == 51 then
                self.frames = 0
                self:get_animation():set_playback_speed(1)
                self.state = "MOVE"
            end
        elseif self.state == "MOVE" then
            if self.frames == 1 then
                Engine.play_audio(MOONDANCE_SHOOT_AUDIO, AudioPriority.Low)
            end
            if self:is_sliding() == false then
                if self:get_tile():is_edge() and self.slide_started then 
                    self:erase()
                end
                if self.start_y == 1 then
                    if self:get_tile() == self.tile1 and self.movestate == "DOWN" then
                        self.movestate = "FORWARD"
                        self.slide_dir = self:get_facing()
                    elseif self:get_tile() == self.tile2 and self.movestate == "FORWARD" then
                        self.movestate = "UP"
                        self.slide_dir = Direction.Up
                    elseif self:get_tile() == self.tile3 and self.movestate == "UP" then
                        self.movestate = "BACK"
                        self.slide_dir = self:get_facing_away()
                    elseif self:get_tile() == self.tile4 and self.movestate == "BACK" then
                        self:erase()
                    end
                elseif self.start_y == 2 then
                    if self:get_tile() == self.tile1 and self.movestate == "DOWN" and not self.the5tile then
                        self.movestate = "FORWARD"
                        self.slide_dir = self:get_facing()
                    elseif self:get_tile() == self.tile2 and self.movestate == "FORWARD" then
                        self.movestate = "UP"
                        self.slide_dir = Direction.Up
                    elseif self:get_tile() == self.tile3 and self.movestate == "UP" then
                        self.movestate = "BACK"
                        self.slide_dir = self:get_facing_away()
                    elseif self:get_tile() == self.tile4 and self.movestate == "BACK" then
                        self.movestate = "DOWN"
                        self.slide_dir = Direction.Down
                        self.the5tile = true
                    elseif self:get_tile() == self.tile5 and self.movestate == "DOWN" and self.the5tile then
                        self:erase()
                    end
                elseif self.start_y == 3 then
                    if self:get_tile() == self.tile1 and self.movestate == "FORWARD" then
                        self.movestate = "UP"
                        self.slide_dir = Direction.Up
                    elseif self:get_tile() == self.tile2 and self.movestate == "UP" then
                        self.movestate = "BACK"
                        self.slide_dir = self:get_facing_away()
                    elseif self:get_tile() == self.tile3 and self.movestate == "BACK" then
                        self.movestate = "DOWN"
                        self.slide_dir = Direction.Down
                    elseif self:get_tile() == self.tile4 and self.movestate == "DOWN" then
                        self:erase()
                    end
                end
                local dest = self:get_tile(self.slide_dir, 1)
                local ref = self
                self:slide(dest, frames(16), frames(0), ActionOrder.Voluntary, function()
                    ref.slide_started = true 
                end)
            end
        end
    end
    moondance.attack_func = function(self, other)
        if Battle.Obstacle.from(other) == nil then
            --[[
			if Battle.Player.from(proto) ~= nil then
				Engine.play_audio(AUDIO_DAMAGE_ENEMY, AudioPriority.Low)
			end
            ]]
		else
			Engine.play_audio(AUDIO_DAMAGE_OBS, AudioPriority.Low)
		end
    end
    moondance.collision_func = function(self)
        self:erase()
    end
    moondance.can_move_to_func = function(tile)
        return true
    end
    user:get_field():spawn(moondance, tile)
    return moondance
end

function package_init(self)
    STARMAN_TEXTURE = Engine.load_texture(_folderpath.."gfx/starman.grayscaled.png")
    STARMAN_PALETTE = Engine.load_texture(_folderpath.."gfx/battle_v1.palette.png")
    self:set_name("StarMan")
	local rank = self:get_rank()
    self.damage = 20
    self.damage_kirakirameteor = 20
    self.damage_moondance = 20
    self.damage_stararrow = 20
    self.before_md = 1
    self.patterns_before_md = math.random(3,5)
    self.r_atk = nil

    self.next_tile = nil
    self.prev_tile = nil

    --self.base_idle_speed = 32
    self.base_idle_speed = 52

    -- Chance /16. I'm going to run these when the pattern is complete and when the flinch finishes, respectively
        -- These skips will be very implementation-specific, so don't use them as future references
    self.chance_to_move_zero_times = 2
    self.chance_to_move_six_times = 4 --has a change to move 6 times
    self.chance_to_skip_idle_after_flinch = 2
    self.chance_to_halve_idle_after_flinch = 3

    if rank == Rank.V1 then
        self:set_health(600)
    elseif rank == Rank.V2 then
        self:set_name("StarManV")
        self:set_health(900)
        self.damage = 40
        self.damage_kirakirameteor = 40
        self.damage_moondance = 40
        self.damage_stararrow = 40
        --self.base_idle_speed = 27
        self.base_idle_speed = 42
    elseif rank == Rank.V3 then
        self:set_name("StarManV")
        self:set_health(1200)
        self.damage = 80
        self.damage_kirakirameteor = 80
        self.damage_moondance = 80
        self.damage_stararrow = 80
        --self.base_idle_speed = 24
        self.base_idle_speed = 32
    elseif rank == Rank.SP then
        STARMAN_PALETTE = Engine.load_texture(_folderpath.."gfx/battle_sp.palette.png")
        self:set_health(1500)
        self.damage = 100
        self.damage_kirakirameteor = 100
        self.damage_moondance = 100
        self.damage_stararrow = 100
        self.base_idle_speed = 22
    end

    self.idle_speed = self.base_idle_speed 

    self:set_texture(STARMAN_TEXTURE, true)
    self:set_palette(STARMAN_PALETTE)

    self:set_height(52)
    self:set_explosion_behavior(5, 1, true)
    self:set_offset(0,0)
	self:set_facing(Direction.Left)
	self:set_element(Element.None)
	self:set_float_shoe(true)
	self:set_air_shoe(false)
    self:share_tile(false)

    local anim = self:get_animation()
    anim:load(STARMAN_ANIMPATH)

    self.anim = include("enemy_base_v1/entry.lua")
    anim = self.anim
    anim:set_owner(self)
    anim:set_state("IDLE", {
        {duration=10, state="IDLE_1"},
        {duration=10, state="IDLE_2"},
        {duration=10, state="IDLE_3"},
        {duration=10, state="IDLE_4"},
    })

    anim:set_playback(Playback.Loop)
    init_boss(self)
end

--(Function by Alrysc)
-- This is to fix something that happens because I'm a cheater
--[[
    The aggressor of an attack is held in the Context object. 
    ONB leaves this aggressor unset in the Entity's Context until a CardAction is used for the first time
    So I'll immediately force a CardAction that will hopefully end immediately and not get in the way, but also will fix this
    This probably goes horribly wrong if the enemy is spawned after the mob intro, but should be fine for now otherwise
]]
function fix_context(self)
    local action = Battle.CardAction.new(self, "IDLE_1")
    action.execute_func = function()
        action:end_action()
    end

    self:card_action_event(action, ActionOrder.Immediate)
end

--(Function by Alrysc)
function init_boss(self)
    self.on_spawn_func = function(self)
        fix_context(self)
        --[[
        self.before_battle_start_animater = Battle.Artifact.new()
        self:get_field():spawn(self.before_battle_start_animater, 7, 4)
        self.before_battle_start_animater.update_func = function()
            self.anim:tick_animation()
        end]]
    end

    self.battle_start_func = function(self)
        --self.before_battle_start_animater:delete()
    end

    -- Setting names here is just convenience if I want to print the state I'm in later
    self.states = {
        idle = {name = "idle", func = idle},
        move = {name = "move", func = move},
        move_to_enemy = {name = "move_to_enemy", func = move_to_enemy},
        move_atk = {name = "move_atk", func = move_atk},
        move_to_enemy_atk = {name = "move_to_enemy_atk", func = move_to_enemy_atk},
        move_to_lower_atk = {name = "move_to_lower_atk", func = move_to_lower_atk},
        flinch = {name = "flinch", func = flinch},
        
        start_sub_pattern = {name = "start_sub_pattern"},
        finish_sub_pattern = {name = "finish_sub_pattern"},

        stararrow = {name = "stararrow", func = stararrow},
        moondance = {name = "moondance", func = moondance},

        choose_attack = {name = "choose_attack", func = choose_attack}
    }
    
    local s = self.states

    reconstruct_pattern(self)
 
    self.pattern_index = 1
    self.in_sub_pattern = false

    self.first_act = true

    self.state_done = false

    self.state = self.pattern[1]

    self.first_flinch = true

    self.hit_func = function(from_stun)
        -- print("Hit func runs")
        self:toggle_counter(false)
        self.flinching = false
        self.first_act = false
        self.state_done = false
        self.moving_to_enemy_tile = false
        if self.first_flinch then 
            -- self.state.cleanup
            self.last_state = self.state
            -- print("Hit! Set last state to ", self.state.name)
            if self.state ~= self.states.idle and self.state ~= self.states.move then 
               -- increment_pattern(self)
            end

            self.first_flinch = false
        end

        self.state = self.states.flinch

        -- This is unused for this boss
        if self.slide_component ~= nil then 
            -- print("Hit while moving.")
            self.slide_component:eject()
            self.slide_component = nil
            self:set_offset(0, 0)

            if self.slide_dest and self:get_current_tile() ~= self.slide_dest then 
            -- print("Hit before reaching destination.")
                self:get_current_tile():remove_entity_by_id(self:get_id())
                self.slide_dest:add_entity(self)
                self.slide_dest = nil
            end

        end

        flinch(self, from_stun)
    end

    self.delete_func = function(self)
        self.update_func = function(self)
            self:get_animation():set_state("STUN_1")
            self.state = self.states.flinch
        end
    end

    -- Unused for this boss
    self.moving_to_enemy_tile = false
    self.counter = 0
    self.collision_available = true
    self.counterable = 0

    local ref = self
    self.counterable_component = Battle.Component.new(self, Lifetimes.Battlestep)
    self.counterable_component.timer = 0
    self.counterable_component.update_func = function(self)
        if self.timer > 0 then
            --print("COUNTERABLE")
            self.timer = self.timer - 1
            ref:toggle_counter(true)
        else
            ref:toggle_counter(false)
        end
    end
    self:register_component(self.counterable_component)

    self:register_status_callback(Hit.Stun, function() self.hit_func(true) end)
    self:register_status_callback(Hit.Flinch, self.hit_func)
    self:register_status_callback(Hit.Drag, self.hit_func)
    self:register_status_callback(Hit.Root, function() self.rooted = 120 end)

    -- Bring it back next build. For now, relying on the stun callback
    --[[
    self.on_countered = function(self)
        print("Countered")
        self:toggle_counter(false)
        self.hit_func(self)

    end
    --]]

    self.can_move_to_func = function(tile)
        if self.rooted > 0 then return false end
        if tile:is_edge() or not tile:is_walkable() then
            return false
        end
        if(tile:is_reserved({self:get_id()})) then
            return false
        end
        if tile == self:get_current_tile() then
            return true
        end

        if not self.moving_to_enemy_tile and (tile:get_team() ~= self:get_team()) then
            return false
        end

        return not check_obstacles(tile, self) and not check_characters_true(tile, self)
    end

    --self.do_once_blind_confuse = true

    self.rooted = 0
    self.update_func = function(self)
       -- print("     ", self.state.name, self:get_animation():get_state())
        if self.rooted > 0  then self.rooted = self.rooted - 1 end
        self.state.func(self)
        self.anim:tick_animation()

        -- When we tick animation, we may run increment_pattern. 
        -- The new state isn't run until next frame, so our anim state lasts one more frame when it finishes
        -- Calling our state one time to set things up will avoid this. Mostly sure this doesn't have major unintended consequences,
        -- especially as most state.func only set state and callbacks for frame 1
        -- Problem is, now I may have a frame 1 callback but I don't run it until next frame
        while self.first_act
        do
            self.state.func(self)
            self.anim:tick_animation()
        end
        check_collision(self)

        --[[
        if self:is_blind() or self:is_confused() then
            if self.do_once_blind_confuse then
                self.do_once_blind_confuse = false
                if rank == Rank.V1 then
                    self.base_idle_speed = 52
                elseif rank == Rank.V2 then
                    self.base_idle_speed = 52
                elseif rank == Rank.V3 then
                    self.base_idle_speed = 52
                elseif rank == Rank.SP then
                    self.base_idle_speed = 52
                end
            end
        else
            self.do_once_blind_confuse = true
        end
        ]]
    end
end

--(Function by Alrysc)
function create_collision_attack(self, tile)
    local spell = Battle.Spell.new(self:get_team())
   
    local hit_props = HitProps.new(
        self.damage,
        Hit.Impact | Hit.Flash | Hit.Flinch,
        self:get_element(), 
        self:get_context(), 
        Drag.None
    )

    spell:set_hit_props(hit_props)

    spell.update_func = function(self)
        tile:attack_entities(self)
        self:delete()
    end

    self:get_field():spawn(spell, tile)
end

--(Function by Alrysc)
-- TODO: When we get is_passthrough or something, check to see if target became flashing before 
    -- we are allowed to spawn another one. Don't want to instakill viruses
-- self.collision_available can do something related to that. Does nothing now
function check_collision(self)
    local t = self:get_current_tile()
    if self.collision_available and check_characters(t, self) then 
        create_collision_attack(self, t)
    end
end

--(Function by Alrysc)
function idle(self)
    if self.first_act then
        -- This is an old check for when I extended idle time by doing two idle states in a row, when characters have an animated idle
            -- Not needed if I instead use a timer
        if self.anim:get_state() ~= "IDLE" then 
        --    print("Idle with ", self.idle_speed)
            self.anim:set_state("IDLE", {
                {duration=10, state="IDLE_1"},
                {duration=10, state="IDLE_2"},
                {duration=10, state="IDLE_3"},
                {duration=10, state="IDLE_4"},
            })    
        end
        
        self.anim:set_playback(Playback.Loop)
        self.counter = 0
        
        self.first_act = false
    end

    self.counter = self.counter + 1
    if self.counter == 1 then
        if self.rooted > 0 then
            self.idle_speed = self.base_idle_speed
            increment_pattern(self)
        end
    elseif self.counter > self.idle_speed then
        -- Extra catch for after leaving attack. Attack will double idle speed once, so making sure to reset it after
        if self.idle_speed > self.base_idle_speed then 
            self.idle_speed = self.base_idle_speed
        end
        increment_pattern(self)
    end

    --self.looped = false
    --if self.state_done then 
        --print("State done")
    --end
end

--(Function by Alrysc)
function hit()
    

end

--(Function by Alrysc)
function end_sub_pattern(self)
    while(self.in_sub_pattern)
    do
        increment_pattern(self)
    end
end

--(Function by Alrysc)
function flinch(self, from_stun)
    -- print("Flinch played")
    if self:get_current_tile() == self.next_tile then
        local orig_tile = self.next_tile
        self.next_tile:remove_entity_by_id(self:get_id())
        self.next_tile = orig_tile
        self.next_tile:add_entity(self)
        self.next_tile = nil
    elseif self:get_current_tile() == self.prev_tile then
        local orig_tile = self.prev_tile
        self.prev_tile:remove_entity_by_id(self:get_id())
        self.prev_tile = orig_tile
        self.prev_tile:add_entity(self)
        self.prev_tile = nil
    end
    if self.rooted > 0 then self.rooted = 0 end
    -- print("I am flinching")
    if not self.flinching then 
        local frames = {}
        if not from_stun then
            frames[1] = {duration=4, state="FLINCH_1"}
            frames[2] = {duration=2, state="FLINCH_2"}
            frames[3] = {duration=2, state="FLINCH_3"}
            frames[4] = {duration=2, state="FLINCH_4"}
            frames[5] = {duration=2, state="FLINCH_5"}
            frames[6] = {duration=2, state="FLINCH_6"}
            frames[7] = {duration=4, state="FLINCH_7"}
            frames[8] = {duration=4, state="FLINCH_8"}
            frames[9] = {duration=2, state="FLINCH_9"}
        else
            frames[1] = {duration=0, state="STUN_1"}
        end
        self.anim:set_state("FLINCH", frames)
        self.anim:on_complete(function()
            -- If we didn't just attack, we want to make sure the idle speed is correct. This is also set in the actual idle, but just for extra measure.
                -- Shouldn't be necessary
            if self.idle_speed > self.base_idle_speed and self.pattern[self.pattern_index] ~= self.states.choose_attack then 
                self.idle_speed = self.base_idle_speed
            end

            local has_skipped = false
            if self.last_state == self.states.idle then 
            --      print("Attempt skip, because last state was idle")
                has_skipped = maybe_skip_after_flinch(self)
            end

            
--         print("I am done flinching")
        --   print("Anim done")
            self.flinching = false
            self.state_done = true
            self.first_flinch = true

        --    print("Done")
            self.state_done = false
            if self.last_state ~= self.states.idle and self.last_state ~= self.states.move then 
        --     print("Last state was not idle or move", self.last_state.name)
 
                increment_pattern(self)

            
            else--if not has_skipped then 
                -- If we were in idle or move, go back to it and try again
                    -- Unless we were in a sub pattern. Still end that.
            --   print("Last state was idle or move")

                if self.in_sub_pattern then 
                    end_sub_pattern(self)
                else
                    self.state = self.last_state
                    self.first_act = true
                end
            end

        end)

    end

    self.flinching = true
end

--(Function by Alrysc)
--[[
    Chance to skip idle or halve idle time, to call after flinching 
    This works by calling increment_pattern an extra time if and only if the last state was Idle
        Remember, last state is the state we will return to after flinching
        Some extra work will need to be done in the self.anim:on_complete of flinch if this is to work with sub patterns. This boss doesn't use them, so it was omitted
    
    Currently, the skip is implemented as setting idle time to 0
    
    A future choice for this function: after calling this function, self.state *may* increment, obsoleting our last state pointer. Returns true if this does happen
        There is a possible additional side effect that the idle time will instead be changed, in which case, last state is preserved and false is returned
]]
function maybe_skip_after_flinch(self)
    local chance_halve = self.chance_to_halve_idle_after_flinch
    local chance_skip = self.chance_to_skip_idle_after_flinch
    local max = chance_halve + chance_skip + (16 - chance_halve - chance_skip)

    local r = math.random(1, max)
    if r <= chance_halve then 
        self.idle_speed = math.floor(self.idle_speed / 2)
       -- print("We halved")
    elseif r <= (chance_skip + chance_halve) then 
       -- print("We skipped")
        self.idle_speed = 0
        return true
    end

    return false
end

--(Function by Alrysc)
function highlight_tiles(self, list, time)
    local spell = Battle.Spell.new(self:get_team())

    local ref = self
    spell.update_func = function(self)
        for i=1, #list do 
            local t = list[i]
            if t and not t:is_edge() then 
                t:highlight(Highlight.Solid)
            end
        end

        time = time - 1
        if time == 0 then 
            self:delete()
        end

        if self.flinching then 
            if spell and not spell:is_deleted() then 
                spell:delete()
            end
        end
    end

    self:get_field():spawn(spell, self:get_current_tile())

    return spell
end

--(Function by Alrysc)
function move(self)
    if self.first_act then
        self.first_act = false
        if self.rooted > 0 then
            self.idle_speed = self.base_idle_speed
            increment_pattern(self)
        else
            self.anim:set_state("MOVE", {
                {duration=1, state="WARP_1"},
                {duration=1, state="WARP_2"},
                {duration=1, state="WARP_3"},
                {duration=1, state="WARP_4"},
                {duration=1, state="WARP_5"},
                {duration=1, state="WARP_6"},
                {duration=1, state="WARP_7"},
                {duration=1, state="WARP_8"},
            })
            self.prev_tile = self:get_current_tile()
            local tile = choose_move(self, self:get_field())
            if not tile then
                tile = self:get_current_tile()
            end
            self.next_tile = tile
            self.next_tile:reserve_entity_by_id(self:get_id())
            self.anim:on_frame(1, function()
                create_sparkles_spawner(self, self.prev_tile)
            end)
            self.anim:on_frame(5, function()
                if self.can_move_to_func(self.next_tile) then 
                else
                    self.next_tile = self:get_current_tile()
                end
                self:teleport(self.next_tile, ActionOrder.Voluntary, nil)
                local kirakiratile = nil
                local enemy_query = function(o)
                    return o and not o:is_team(self:get_team()) and o:get_health() > 0
                end
                local clst_enmy = self:get_field():find_nearest_characters(self, enemy_query)
                if math.random(1,2) == 1 then
                    if clst_enmy[1] ~= nil and math.random(1,2) == 1 then
                        kirakiratile = clst_enmy[1]:get_tile()
                    elseif clst_enmy[1] ~= nil and math.random(1,2) ~= 1 then
                        local tiles = {}
                        for i=1, 8 do
                            local clst_tile = clst_enmy[1]:get_tile(i, 1)
                            if clst_tile and not clst_tile:is_edge() and clst_tile:get_team() == clst_enmy[1]:get_team() then
                                table.insert(tiles, clst_tile)
                            end
                        end
                        if tiles[1] then
                            kirakiratile = tiles[math.random(1, #tiles)]
                        end
                    end
                end
                if kirakiratile then
                    create_kirakirameteor(self, kirakiratile)
                end
            end)
            self.anim:on_complete(function()
                -- Reset idle speed, since we did a real action
                self.idle_speed = self.base_idle_speed
                increment_pattern(self)
            end)
        end
    end
end

function move_atk(self)
    if self.first_act then
        self.first_act = false
        if self.rooted > 0 then
            self.idle_speed = self.base_idle_speed
            increment_pattern(self)
        else
            self.anim:set_state("MOVE", {
                {duration=1, state="WARP_1"},
                {duration=1, state="WARP_2"},
                {duration=1, state="WARP_3"},
                {duration=1, state="WARP_4"},
            })
            self.prev_tile = self:get_current_tile()
            local tile = choose_move(self, self:get_field())
            if not tile then
                tile = self:get_current_tile()
            end
            self.next_tile = tile
            self.next_tile:reserve_entity_by_id(self:get_id())
            self.anim:on_frame(1, function()
                create_sparkles_spawner(self, self.prev_tile)
            end)
            self.anim:on_complete(function()
                if self.can_move_to_func(self.next_tile) then 
                else
                    self.next_tile = self:get_current_tile()
                end
                self:teleport(self.next_tile, ActionOrder.Voluntary, nil)
                local kirakiratile = nil
                local enemy_query = function(o)
                    return o and not o:is_team(self:get_team()) and o:get_health() > 0
                end
                local clst_enmy = self:get_field():find_nearest_characters(self, enemy_query)
                if math.random(1,2) == 1 then
                    if clst_enmy[1] ~= nil and math.random(1,2) == 1 then
                        kirakiratile = clst_enmy[1]:get_tile()
                    elseif clst_enmy[1] ~= nil and math.random(1,2) ~= 1 then
                        local tiles = {}
                        for i=1, 8 do
                            local clst_tile = clst_enmy[1]:get_tile(i, 1)
                            if clst_tile and not clst_tile:is_edge() and clst_tile:get_team() == clst_enmy[1]:get_team() then
                                table.insert(tiles, clst_tile)
                            end
                        end
                        if tiles[1] then
                            kirakiratile = tiles[math.random(1, #tiles)]
                        end
                    end
                end
                if kirakiratile then
                    create_kirakirameteor(self, kirakiratile)
                end
                -- Reset idle speed, since we did a real action
                self.idle_speed = self.base_idle_speed
                increment_pattern(self)
            end)
        end
    end
end

function move_to_enemy(self)
    if self.first_act then
        self.first_act = false
        if self.rooted > 0 then
            self.idle_speed = self.base_idle_speed
            increment_pattern(self)
        else
            self.anim:set_state("MOVE", {
                {duration=1, state="WARP_1"},
                {duration=1, state="WARP_2"},
                {duration=1, state="WARP_3"},
                {duration=1, state="WARP_4"},
                {duration=1, state="WARP_5"},
                {duration=1, state="WARP_6"},
                {duration=1, state="WARP_7"},
                {duration=1, state="WARP_8"},
            })
            self.prev_tile = self:get_current_tile()
            local tile = choose_move_to_enemy(self, self:get_field())
            if not tile then
                tile = choose_move2(self, self:get_field())
            end
            if not tile then
                tile = self:get_current_tile()
            end
            self.next_tile = tile
            self.next_tile:reserve_entity_by_id(self:get_id())
            self.anim:on_frame(1, function()
                create_sparkles_spawner(self, self.prev_tile)
            end)
            self.anim:on_frame(5, function()
                if self.can_move_to_func(self.next_tile) then 
                else
                    self.next_tile = self:get_current_tile()
                end
                self:teleport(self.next_tile, ActionOrder.Voluntary, nil)
                local kirakiratile = nil
                local enemy_query = function(o)
                    return o and not o:is_team(self:get_team()) and o:get_health() > 0
                end
                local clst_enmy = self:get_field():find_nearest_characters(self, enemy_query)
                if math.random(1,2) == 1 then
                    if clst_enmy[1] ~= nil and math.random(1,2) == 1 then
                        kirakiratile = clst_enmy[1]:get_tile()
                    elseif clst_enmy[1] ~= nil and math.random(1,2) ~= 1 then
                        local tiles = {}
                        for i=1, 8 do
                            local clst_tile = clst_enmy[1]:get_tile(i, 1)
                            if clst_tile and not clst_tile:is_edge() and clst_tile:get_team() == clst_enmy[1]:get_team() then
                                table.insert(tiles, clst_tile)
                            end
                        end
                        if tiles[1] then
                            kirakiratile = tiles[math.random(1, #tiles)]
                        end
                    end
                end
                if kirakiratile then
                    create_kirakirameteor(self, kirakiratile)
                end
            end)
            self.anim:on_complete(function()
                -- Reset idle speed, since we did a real action
                self.idle_speed = self.base_idle_speed
                increment_pattern(self)
            end)
        end
    end
end

function move_to_enemy_atk(self)
    if self.first_act then
        self.first_act = false
        if self.rooted > 0 then
            self.idle_speed = self.base_idle_speed
            increment_pattern(self)
        else
            self.anim:set_state("MOVE", {
                {duration=1, state="WARP_1"},
                {duration=1, state="WARP_2"},
                {duration=1, state="WARP_3"},
                {duration=1, state="WARP_4"},
            })
            self.prev_tile = self:get_current_tile()
            local tile = choose_move_to_enemy(self, self:get_field())
            if not tile then
                tile = choose_move2(self, self:get_field())
            end
            if not tile then
                tile = self:get_current_tile()
            end
            self.next_tile = tile
            self.next_tile:reserve_entity_by_id(self:get_id())
            self.anim:on_frame(1, function()
                create_sparkles_spawner(self, self.prev_tile)
            end)
            self.anim:on_complete(function()
                if self.can_move_to_func(self.next_tile) then 
                else
                    self.next_tile = self:get_current_tile()
                end
                self:teleport(self.next_tile, ActionOrder.Voluntary, nil)
                local kirakiratile = nil
                local enemy_query = function(o)
                    return o and not o:is_team(self:get_team()) and o:get_health() > 0
                end
                local clst_enmy = self:get_field():find_nearest_characters(self, enemy_query)
                if math.random(1,2) == 1 then
                    if clst_enmy[1] ~= nil and math.random(1,2) == 1 then
                        kirakiratile = clst_enmy[1]:get_tile()
                    elseif clst_enmy[1] ~= nil and math.random(1,2) ~= 1 then
                        local tiles = {}
                        for i=1, 8 do
                            local clst_tile = clst_enmy[1]:get_tile(i, 1)
                            if clst_tile and not clst_tile:is_edge() and clst_tile:get_team() == clst_enmy[1]:get_team() then
                                table.insert(tiles, clst_tile)
                            end
                        end
                        if tiles[1] then
                            kirakiratile = tiles[math.random(1, #tiles)]
                        end
                    end
                end
                if kirakiratile then
                    create_kirakirameteor(self, kirakiratile)
                end
                -- Reset idle speed, since we did a real action
                self.idle_speed = self.base_idle_speed
                increment_pattern(self)
            end)
        end
    end
end

function move_to_lower_atk(self)
    if self.first_act then
        self.first_act = false
        if self.rooted > 0 then
            self.idle_speed = self.base_idle_speed
            increment_pattern(self)
        else
            self.anim:set_state("MOVE", {
                {duration=1, state="WARP_1"},
                {duration=1, state="WARP_2"},
                {duration=1, state="WARP_3"},
                {duration=1, state="WARP_4"},
            })
            self.prev_tile = self:get_current_tile()
            local tile = choose_move_to_lower(self)
            if not tile then
                tile = choose_move2(self, self:get_field())
            end
            self.next_tile = tile
            self.next_tile:reserve_entity_by_id(self:get_id())
            self.anim:on_frame(1, function()
                create_sparkles_spawner(self, self.prev_tile)
            end)
            self.anim:on_complete(function()
                if self.can_move_to_func(self.next_tile) then 
                else
                    self.next_tile = self:get_current_tile()
                end
                self:teleport(self.next_tile, ActionOrder.Voluntary, nil)
                local kirakiratile = nil
                local enemy_query = function(o)
                    return o and not o:is_team(self:get_team()) and o:get_health() > 0
                end
                local clst_enmy = self:get_field():find_nearest_characters(self, enemy_query)
                if math.random(1,2) == 1 then
                    if clst_enmy[1] ~= nil and math.random(1,2) == 1 then
                        kirakiratile = clst_enmy[1]:get_tile()
                    elseif clst_enmy[1] ~= nil and math.random(1,2) ~= 1 then
                        local tiles = {}
                        for i=1, 8 do
                            local clst_tile = clst_enmy[1]:get_tile(i, 1)
                            if clst_tile and not clst_tile:is_edge() and clst_tile:get_team() == clst_enmy[1]:get_team() then
                                table.insert(tiles, clst_tile)
                            end
                        end
                        if tiles[1] then
                            kirakiratile = tiles[math.random(1, #tiles)]
                        end
                    end
                end
                if kirakiratile then
                    create_kirakirameteor(self, kirakiratile)
                end
                -- Reset idle speed, since we did a real action
                self.idle_speed = self.base_idle_speed
                increment_pattern(self)
            end)
        end
    end
end

function choose_attack(self)
    local atk_tbl = {}
    self.state = atk_tbl[self.r_atk]

    self.state.func(self)
    self.idle_speed = self.base_idle_speed * 2
end

function stararrow(self)
    if self.first_act then
        self.anim:set_state("STARARROW", {
            {duration=2, state="STARARROW_1"},
            {duration=3, state="STARARROW_2"},
            {duration=17, state="STARARROW_3"},
            {duration=4, state="STARARROW_3"},
            {duration=4, state="STARARROW_4"},
            {duration=3, state="STARARROW_5"},
            {duration=24, state="STARARROW_6"},
            {duration=2, state="IDLE_1"},
        })
        self.anim:on_frame(1, function()
            self.counterable_component.timer = 20
        end)
        self.anim:on_frame(6, function()
            create_stararrow(self, self:get_tile(self:get_facing(), 1))
        end)
        self.anim:on_complete(function()
            increment_pattern(self)
        end)
        self.first_act = false
    end
end

function moondance(self)
    if self.first_act then
        self.anim:set_state("MOONDANCE", {
            {duration=28, state="MOONDANCE_1"},
            {duration=2, state="MOONDANCE_2"},
            {duration=2, state="MOONDANCE_3"},
            {duration=29, state="MOONDANCE_4"},
            {duration=2, state="IDLE_1"},
        })
        self.anim:on_frame(1, function()
            self.counterable_component.timer = 20
        end)
        self.anim:on_frame(3, function()
            local tile_x = nil
            if self:get_facing() == Direction.Right then
                tile_x = math.random(self:get_tile():x()+1,4)
            else
                tile_x = math.random(3,self:get_tile():x()-1)
            end
            create_moondance(self, self:get_field():tile_at(tile_x, self:get_tile():y()))
        end)
        self.anim:on_complete(function()
            increment_pattern(self)
        end)
        self.first_act = false
    end
end

--(Function by Alrysc)
function find_valid_move_location(self)
	local target_tile
	local field = self:get_field()

	local tiles = field:find_tiles(function(tile)
		return self.can_move_to_func(tile)
	end)
  
	--print (#tiles)
	if #tiles >= 1 then
		target_tile = tiles[math.random(#tiles)]
	else
		target_tile = self:get_tile()
	end
	
	local start_tile = self:get_tile()
	if #tiles > 1 then
		while target_tile == start_tile do
		-- pick another, don't try to jump on the same tile if it's not necessary
		target_tile = tiles[math.random(#tiles)]
		end
	end
  
    return target_tile
end

function choose_enemy(self, field)
    local team = self:get_team()

    local target = field:find_characters(function(c)
        return c:get_team() ~= team
    end)

    if not target[1] then 
       -- print("No targets")
        return nil
    end

    t_x = target[1]:get_current_tile():x()
    t_y = target[1]:get_current_tile():y()

    local facing = -1
    if target[1]:get_facing() == Direction.Right then 
        facing = 1
    end

    local tile = field:tile_at(t_x, t_y)

    return tile
end

function choose_move(self, field)
    local team = self:get_team()

    local tiles = field:find_tiles(function(tile)
        return tile ~= self:get_current_tile() and self.can_move_to_func(tile)
    end)

    --print("Found ", #tiles, " possible tiles")

    if #tiles == 0 then 
        return self:get_current_tile()
    end

    return tiles[math.random(1, #tiles)]
end

function choose_move2(self, field)
    local team = self:get_team()

    local tiles = field:find_tiles(function(tile)
        return self.can_move_to_func(tile)
    end)

    --print("Found ", #tiles, " possible tiles")

    if #tiles == 0 then 
        return self:get_current_tile()
    end

    return tiles[math.random(1, #tiles)]
end

function choose_move_to_enemy(self, field)
    local team = self:get_team()

    local enemy_tile = choose_enemy(self, field)
    local enemy_y = enemy_tile:y()

    local tiles = field:find_tiles(function(tile)
        return tile:y() == enemy_y and self.can_move_to_func(tile)
    end)

    --print("Found ", #tiles, " possible tiles")

    if #tiles == 0 then 
        return self:get_current_tile()
    end

    return tiles[math.random(1, #tiles)]
end

function choose_move_to_lower(self)
    local team = self:get_team()
    local field = self:get_field()
    local facing = self:get_facing()

    local tiles = field:find_tiles(function(tile)
        return tile and not tile:is_edge() and self.can_move_to_func(tile) and ((facing == Direction.Right and tile:x() > 0 and tile:x() < 4) or (facing == Direction.Left and tile:x() > 3 and tile:x() < 7))
    end)

    --print("Found ", #tiles, " possible tiles")

    if #tiles == 0 then 
        return self:get_current_tile()
    end

    return tiles[math.random(1, #tiles)]
end

function reconstruct_pattern(self)
    local pattern = {}
    local states = self.states
    local moves = math.random(4,6)

    for i=1, moves do
        table.insert(pattern, states.move)
        table.insert(pattern, states.idle)
    end
    table.insert(pattern, states.move_to_enemy_atk)
    table.insert(pattern, states.stararrow)
    --table.insert(pattern, states.move_atk)
    table.insert(pattern, states.move_to_enemy_atk)
    table.insert(pattern, states.stararrow)
    if self.before_md >= self.patterns_before_md then
        table.insert(pattern, states.move_to_lower_atk)
        table.insert(pattern, states.moondance)
        self.before_md = 1
        self.patterns_before_md = math.random(3,5)
    else
        self.before_md = self.before_md + 1
    end

    self.pattern = pattern
end

function increment_pattern(self)
   -- print("Pattern increment")

    self.first_act = true
    self.state_done = false
    self.pattern_index = self.pattern_index + 1
    if self.pattern_index > #self.pattern then 
        reconstruct_pattern(self)
 --       print("Reconstructed pattern")
        self.pattern_index = 1
    end

    local next_state = self.pattern[self.pattern_index]
    self.state = next_state
  --  print("Moving to state named ", next_state.name)

    if next_state == self.states.start_sub_pattern then 
        self.in_sub_pattern = true
        increment_pattern(self)
    end

    if next_state == self.states.finish_sub_pattern then 
        self.in_sub_pattern = false
        increment_pattern(self)

    end

   -- print("Changing to "..self.pattern_index..", which is "..self.pattern[self.pattern_index].name)

end

function check_obstacles(tile, self)
    local ob = tile:find_obstacles(function(o)
        return o:get_health() > 0 
    end)

    return #ob > 0 
end

function check_characters(tile, self)
    local characters = tile:find_characters(function(c)
        return c:get_id() ~= self:get_id() and c:get_team() ~= self:get_team()
    end)

    return #characters > 0

end

function check_characters_true(tile, self)
    local characters = tile:find_characters(function(c)
        return true
    end)

    return #characters > 0
end

function shuffle(tbl)
    for i = #tbl, 2, -1 do
        local j = math.random(i)
        tbl[i], tbl[j] = tbl[j], tbl[i]
    end
    return tbl
end