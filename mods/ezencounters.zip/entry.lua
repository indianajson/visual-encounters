local package_prefix = "keristero"
local package_name = "ezencounters"

local mob_package_id = "com."..package_prefix..".mob."..package_name
local loaded_obstacles = {}
local ramdomize_test_scenario = include('random_scenario.lua')

local encounter_info = {
    -- If you need to add an mob do it here based on the character package name. 
    enemy_packages = {
        ShadowManPoN="com.OFC.char.EXEPoN-025-ShadowMan",
        GregarBeast="com.OFC.char.EXE6-051-GregarBeast1",
        ElementMan="com.OFC.char.EXE6-045-ElementMan1",
        BurnerMan="com.OFC.char.EXE4-038-BurnerMan1",
        Gobby="mob.realms.rey.navi.000.gobby",
        Yuki="com.alrysc.enemy.YukiEnemy",--V1,V2
        Yumeko="com.alrysc.enemy.YumekoEnemy",--V1,V2
        VolcanoMan="com.alrysc.enemy.VolcanoManEnemy",--V1,V2
        DreamMeraru="com.OFC.char.EXEPoN-018-DreamMeraru",
        DreamRapia="com.OFC.char.EXEPoN-018-DreamLapia",
        DreamBolt="com.OFC.char.EXEPoN-018-DreamBolt",
        DreamMoss="com.OFC.char.EXEPoN-018-DreamMoss",
        Sparky="com.OFC.char.EXEPoN-014-Yura",
        Yurayura="com.OFC.char.EXEPoN-014-Yurayura",
        Yurarion="com.OFC.char.EXEPoN-014-Yurarion",
        Dharma="com.OFC.char.EXEPoN-011-Dharma",
        Dharga="com.OFC.char.EXEPoN-011-Dharga",
        Dhardara="com.OFC.char.EXEPoN-011-Dhardara",
        KillPlant="com.OFC.char.EXEPoN-010-KillPlant",
        KillWeed="com.OFC.char.EXEPoN-010-KillWeed",
        KillFlower="com.OFC.char.EXEPoN-010-KillFlower",
        Beetank="com.OFC.char.EXEPoN-007-Kabutank", --V1,V2,V3,SP
        SwapLight="hoov.enemy.swaplight",
        QuickMan="com.louise.enemy.Quickman", --V1,V2,V3,SP, NM
        HeelNavi="com.louise.enemy.HeelNavi", --V1,V2,V3,SP
        CircusMan="com.louise.enemy.CircusMan", -- V1 (1), EX (5), SP (4), NM (8)
        RayCannon="com.alrysc.enemy.RayCannon_enemy", --custom ranks based on integer, 0 = SP
        ShadeMan="com.Dawn.Enemy.Shademan", --V1,EX,SP
        Kogasa="com.alrysc.enemy.KogasaEnemy", --V1,V2,V3
        Juraigon="com.alrysc.enemy.juraigonVirus", --V1,V2,V3
        CutMan="com.louise.enemy.Cutman", --V1, EX, SP, NM
        AirMan="com.louise_enemy_AirManV1",--v1,v2,SP
        SwordyEl="mob.realms.rey.virus.009.swordy", -- 1-9
        StarMan="com.OFC.char.EXE45-036-StarMan1", --V1,V2,V3,SP
        Alpha="com.OFC.char.EXE3-061-Proto", --V1, SP
        Bark="com.louise.enemy.Bark", --V1
        Basher="com.EXE3.Basher.Enemy",--V1
        BigBrute="com.keristero.char.BigBrute",
        Bladia2="com.EXE5.Bladia.Enemy2", --Bladia2
        Bladia3="com.EXE5.Bladia.Enemy3", --Bladia3
        Bladia4="com.EXE5.Bladia.Enemy4", --Bladia4
        Bladia5="com.EXE5.Bladia.Enemy5", --Bladia5
        Bladia6="com.EXE5.Bladia.Enemy6", --Bladia6
        Bladia="com.EXE5.Bladia.Enemy1", --Bladia
        BlastMan="com.Thor.enemy.BlastMan_V1", -- V1 (1), EX (5), SP (4), RV (??)
        BombCorn="com.louise.enemy.Corn.BombCorn",--V1,SP,R1,R2
        Boomer="com.louise.enemy.Boomer",
        Breaker="com.louise.enemy.Breaker",
        Bugtank="com.louise.enemy.Bugtank",
        Cacter="com.discord.Konstinople#7692.enemy.cacter",
        Cactikil="com.discord.Konstinople#7692.enemy.cactikil",
        Cactroll="com.discord.Konstinople#7692.enemy.cactroll",
        Canodumb="com.discord.Konstinople#7692.enemy.canodumb",
        Canosmart="com.dawn.enemy.canosmart",
        Catack="com.Dawn.Requested.Enemy.Catack",--V1,V2,V3,SP
        Champy="com.keristero.char.Champy",
        ChefVirus="com.alrysc.enemy.ChefVirusEnemy",
        Chimpy="com.keristero.char.Chimpy",
        Chumpy="com.keristero.char.Chumpy",
        CirCrush="com.louise.enemy.CirCrush",
        CirKill="com.louise.enemy.CirKill",--V1,R1,R2,SP,NM
        CirSmash="com.louise.enemy.CirSmash",
        ColdHead="com.louise.enemy.ColdHead",
        ColdHead="com.louise.enemy.ColdHead",
        Cragger="com.louise.enemy.Cragger",--V1,V2,V3,R1,R2,SP,NM
        DarkMech="com.HNST_SGNL.enemy.DarkMech",--V1,V2,V3,SP,R1,R2
        DarkMega="com.Dawn.Enemy.DarkRock", --V1
        DarkMegaNM="com.Dawn.Enemy.DarkRockNM", --NM
        DemonEye="com.louise.enemy.DemonEye",--V1
        Dominerd="com.louise.enemy.Dominerd",--V1,V2,V3,SP,NM
        Doomer="com.louise.enemy.Doomer",
        DthFire="com.louise.enemy.DthFire",--V1,R1,R2,SP,NM
        Elemperor="com.louise.enemy.Elemperor",--V1,V2,V3,R1,R2,SP,NM
        FighterPlane="com.Dawn.Viruses.Enemy.FighterPlane",--V1,V2,V3,SP
        FireManPoN="com.OFC.char.EXEPoN-022-FireMan", --V1,V2,V3,SP
        Fishy="com.louise.enemy.Fishy",--V1,V2,V3,SP
        Flashy="com.louise.enemy.Flashy",--V1,V2,V3,R1,R2,SP,NM
        Forte="com.OFC.char.EXE4-047-Forte1", --V1, SP, NM
        FulFire="com.louise.enemy.FulFire",--V1,R1,R2,SP,NM
        GigaCorn="com.louise.enemy.Corn.GigaCorn",--V1
        Gloomer="com.louise.enemy.Gloomer",
        Gunner="com.OFC.char.EXE6-023-Gunner",
        GutsManPoN="com.OFC.char.EXEPoN-026-GutsMan", --V1,V2,V3,SP,NM
        HardHead="com.louise.enemy.HardHead",
        HatMan="com.alrysc.enemy.HatManEnemy", --V1,V2,V3,SP
        HauntedCandle="com.louise.enemy.HauntedCandle",--V1,V2,V3,SP,R1,R2
        Hecatia="com.alrysc.enemy.HecatiaEnemy",
        HotHead="com.louise.enemy.HotHead",
        IceManPoN="com.OFC.char.EXEPoN-023-IceMan",--V1,V2,V3,SP
        JammingMan="com.alrysc.enemy.JammingManEnemy", --V1,V2,V3,SP
        JokerEye="com.louise.enemy.JokerEye",--V1
        KillerEye="com.louise.enemy.KillerEye",--V1,SP,R1,R2
        Lark="com.louise.enemy.Lark",--V1,R1,R2,SP,NM
        MegaCorn="com.louise.enemy.Corn.MegaCorn",--V1
        MetFire="com.louise.enemy.MetFire",--V1,R1,R2,SP,NM
        Metrid="com.EXE3.Metrid.Enemy",--V1,V2,V3,SP
        Mettaur="com.OFC.char.EXE6-001-Metall",
        Noir="com.OctoChris.enemy.Noir",
        OldBurner="com.louise.enemy.OldBurner", --Third Version, Spawn @ V1
        OldHeater="com.louise.enemy.OldHeater", --Second Version, Spawn @ V1
        OldStove="com.louise.enemy.OldStove", --First Version, Spawn @ V1/SP/R1/R2/NM
        Piranha="com.louise.enemy.Piranha",
        Powie3="com.discord.Konstinople#7692.enemy.powie3",
        Powie="com.discord.Konstinople#7692.enemy.powie",
        ProtomanPoN="com.OFC.char.EXEPoN-028-Blues", --V1,V2,V3,SP
        Puffy="com.louise.enemy.Puffy",
        Quaker="com.louise.enemy.Quaker",
        RareChampy="com.keristero.char.RareChampy",
        Ratty="com.Dawn.BN3.Enemy.Ratty",--V1,V2,V3,SP
        Roll="com.OFC.char.EXEPoN-027-Roll", --V1
        Scuttle="com.louise.enemy.Scuttle",--V1
        Scuttler="com.louise.enemy.Scuttler",--V1
        Scuttlest="com.louise.enemy.Scuttlest",--V1,SP
        Scuttzer="com.louise.enemy.Scuttzer",--V1
        Scutz="com.louise.enemy.Scutz",--V1
        Shaker="com.louise.enemy.Shaker",
        Shrimpy="com.louise.enemy.Shrimpy",
        Skarab="com.louise.enemy.Skarab",--V1,SP,R1,R2,NM
        Skarry="com.louise.enemy.Skarry",--V1
        Skelly="com.louise.enemy.Skelly",--V1
        Spikey="com.Dawn.char.Spikey",--V1,V2,V3,SP
        Swordy="com.louise.enemy.Swordy",--V1,V2,V3,SP,NM
        Tark="com.louise.enemy.Tark",--V1
        VacuumFan="com.louise.enemy.VacuumFan", --V1/V2/V3/SP
        Volcano="com.louise.enemy.Volcano",--V1,V2,V3,R1,R2,SP,NM
        Volgear="com.louise.char.Volgear",--V1,V2,V3,SP
        WindBox="com.louise.enemy.WindBox", --V1/V2/V3/SP/NM
        WoodmanPoN="com.OFC.char.EXEPoN-024-WoodMan", --V1,V2,V3,SP
        Yort="com.louise.enemy.Yort",--V1,V2,V3,R1,R2,SP,NM
        Zomon="com.OFC.char.EXE5-013-Zaemon",
        Rabiree="com.OFC.char.EXE3-010-Rabiree",
        Cannodumb="com.OFC.char.EXEPoN-002-Cannodumb",
    },
    obstacles = {
        RockCube="obstacles/rock_cube.lua",
        Rock="obstacles/rock.lua",
        Coffin="obstacles/coffin.lua",
        BlastCube="obstacles/blast_cube.lua",
        IceCube="obstacles/ice_cube.lua",
        MysteryData="obstacles/mystery.lua",
    },
    tile_states = {
        0,--normal
        1,--cracked
        2,--broken
        11,--up
        12,--down
        9,--left
        10,--right
        7,--empty
        4,--grass
        17,--hidden
        8,--holy
        3,--ice
        5,--lava
        6,--poison
        13,--volcano
        14,--sea
        15,--sand
        16,--metal
    },
    enemy_ranks = {
        0,--v1
        1,--v2
        2,--v3
        3,--sp
        4,--ex
        5,--rare1
        6,--rare2
        7--nightmare
    },
    field_tiles_default = {
        {1,1,1,1,1,1},
        {1,1,1,1,1,1},
        {1,1,1,1,1,1}
    },
    field_teams_default = {
        {2,2,2,1,1,1},
        {2,2,2,1,1,1},
        {2,2,2,1,1,1}
    }
}

function get_enum_value_by_index(mapping_table,p_index)
    for i, value in ipairs(mapping_table) do
        if tonumber(i) == tonumber(p_index) then
            return value
        end
    end
    print("[ezencounters] WARNING invalid input data, no index",p_index)
end

function package_requires_scripts()
    for mob_alias, package in pairs(encounter_info.enemy_packages) do
        --print('[ezencounters] requiring '..package)
        Engine.requires_character(package)
    end
end

function get_package_id(alias) 
    return encounter_info.enemy_packages[alias]
end

function package_init(package) 
    package:declare_package_id(mob_package_id)
    package:set_name(package_name)
    package:set_description("Initiate custom battles from the server!")
    package:set_preview_texture_path(_modpath.."preview.png")
end


local function make_empty_matrix()
    return {
        {0, 0, 0, 0, 0, 0},
        {0, 0, 0, 0, 0, 0},
        {0, 0, 0, 0, 0, 0},
    }
end

local function get_terrain_columns(terrain)
    if terrain == "advantage" then
        return {1, 2, 3, 4}, {5, 6}
    elseif terrain == "disadvantage" then
        return {1, 2}, {3, 4, 5, 6}
    elseif terrain == "even" then
        return {1, 2, 3}, {4, 5, 6}
    elseif terrain == "surrounded" then
        return {3, 4}, {1, 2, 5, 6}
    end
    return nil, nil
end

local function copy_matrix(matrix)
    local result = make_empty_matrix()
    if type(matrix) ~= "table" then return result end
    for y = 1, 3 do
        if type(matrix[y]) == "table" then
            for x = 1, 6 do
                if matrix[y][x] ~= nil then
                    result[y][x] = matrix[y][x]
                end
            end
        end
    end
    return result
end

local function matrix_cells(matrix, is_occupied)
    local cells = {}
    for y = 1, 3 do
        for x = 1, 6 do
            local value = matrix[y] and matrix[y][x]
            if is_occupied(value) then
                cells[#cells + 1] = {x = x, y = y, value = value}
            end
        end
    end
    return cells
end

local function get_team_at(teams, x, y)
    return teams[y] and tonumber(teams[y][x]) or nil
end

local function list_team_columns(teams, team_id)
    local columns, seen = {}, {}
    for y = 1, 3 do
        for x = 1, 6 do
            if get_team_at(teams, x, y) == team_id and not seen[x] then
                seen[x] = true
                columns[#columns + 1] = x
            end
        end
    end
    table.sort(columns)
    return columns
end

local function get_open_team_cells(teams, team_id, occupied, side)
    local cells = {}
    for y = 1, 3 do
        for x = 1, 6 do
            local on_side = side == nil
                or (side == "left" and x <= 2)
                or (side == "right" and x >= 5)
            local key = tostring(x)..":"..tostring(y)
            if on_side and get_team_at(teams, x, y) == team_id and not occupied[key] then
                cells[#cells + 1] = {x = x, y = y}
            end
        end
    end
    return cells
end

local function sort_cells_near(cells, origin_x, origin_y, side)
    table.sort(cells, function(a, b)
        local a_row = math.abs(a.y - origin_y)
        local b_row = math.abs(b.y - origin_y)
        if a_row ~= b_row then return a_row < b_row end
        local a_col = math.abs(a.x - origin_x)
        local b_col = math.abs(b.x - origin_x)
        if a_col ~= b_col then return a_col < b_col end
        if side == "left" then return a.x > b.x end
        if side == "right" then return a.x < b.x end
        return a.x < b.x
    end)
end

local function normalize_player_positions(data)
    if type(data.player_positions) ~= "table" then return end
    local positions = copy_matrix(data.player_positions)
    local players = matrix_cells(positions, function(value)
        return value ~= nil and value ~= 0
    end)
    local occupied = {}

    -- Keep every player already standing on a player-owned tile. Invalid
    -- placements are moved afterward, preserving their original row/column
    -- as closely as the available player territory permits.
    local to_move = {}
    for _, player in ipairs(players) do
        local key = tostring(player.x)..":"..tostring(player.y)
        if get_team_at(data.teams, player.x, player.y) == 2 and not occupied[key] then
            occupied[key] = true
        else
            to_move[#to_move + 1] = player
            positions[player.y][player.x] = 0
        end
    end

    for _, player in ipairs(to_move) do
        local candidates = get_open_team_cells(data.teams, 2, occupied)
        sort_cells_near(candidates, player.x, player.y)
        local target = candidates[1]
        if target then
            positions[target.y][target.x] = player.value
            occupied[tostring(target.x)..":"..tostring(target.y)] = true
        else
            print("[ezencounters] WARNING no available player-owned tile for player", player.value)
        end
    end
    data.player_positions = positions
end

local function build_enemy_slots(data, terrain, side)
    local slots = {}
    local preferred_columns = {}
    if terrain == "surrounded" then
        if side == "left" then preferred_columns = {2, 1}
        else preferred_columns = {5, 6} end
    else
        preferred_columns = list_team_columns(data.teams, 1)
    end

    for _, y in ipairs({2, 1, 3}) do
        for _, x in ipairs(preferred_columns) do
            if get_team_at(data.teams, x, y) == 1 then
                slots[#slots + 1] = {x = x, y = y}
            end
        end
    end
    return slots
end

local function normalize_enemy_positions(data, terrain)
    if type(data.enemies) ~= "table" then return end

    local positions_were_missing = type(data.positions) ~= "table"
    local positions = copy_matrix(data.positions)
    local enemies = {}
    for index = 1, #data.enemies do
        enemies[index] = {index = index}
    end

    local existing_by_index = {}
    for _, cell in ipairs(matrix_cells(positions, function(value)
        return tonumber(value) ~= nil and tonumber(value) ~= 0
    end)) do
        local index = tonumber(cell.value)
        if index and index >= 1 and index <= #enemies and not existing_by_index[index] then
            existing_by_index[index] = {x = cell.x, y = cell.y}
        end
    end

    -- An omitted positions matrix means every listed enemy should be placed.
    -- A supplied matrix is a manual spawn selection: do not add entries the
    -- author intentionally left out; only normalize the entries it contains.
    local active_indices = {}
    if positions_were_missing then
        for index = 1, #enemies do active_indices[#active_indices + 1] = index end
    else
        for index = 1, #enemies do
            if existing_by_index[index] then
                active_indices[#active_indices + 1] = index
            end
        end
    end

    local occupied = {}
    local placements = {}
    local is_surrounded = terrain == "surrounded"

    if is_surrounded then
        local left_target = math.ceil(#active_indices / 2)
        local right_target = math.floor(#active_indices / 2)
        local left_count, right_count = 0, 0

        -- Retain existing flank placements while each side remains within its
        -- fair share. Excess enemies are reassigned to the opposite flank.
        for _, index in ipairs(active_indices) do
            local old = existing_by_index[index]
            if old then
                local side = old.x <= 2 and "left" or old.x >= 5 and "right" or nil
                if side == "left" and left_count < left_target
                    and get_team_at(data.teams, old.x, old.y) == 1 then
                    placements[index] = {x = old.x, y = old.y, side = side}
                    occupied[tostring(old.x)..":"..tostring(old.y)] = true
                    left_count = left_count + 1
                elseif side == "right" and right_count < right_target
                    and get_team_at(data.teams, old.x, old.y) == 1 then
                    placements[index] = {x = old.x, y = old.y, side = side}
                    occupied[tostring(old.x)..":"..tostring(old.y)] = true
                    right_count = right_count + 1
                end
            end
        end

        for _, index in ipairs(active_indices) do
            if not placements[index] then
                local side
                if left_count < left_target and right_count < right_target then
                    side = left_count <= right_count and "left" or "right"
                elseif left_count < left_target then
                    side = "left"
                else
                    side = "right"
                end
                local source = existing_by_index[index]
                local candidates = get_open_team_cells(data.teams, 1, occupied, side)
                local origin_x = source and source.x or (side == "left" and 2 or 5)
                local origin_y = source and source.y or 2
                sort_cells_near(candidates, origin_x, origin_y, side)
                local target = candidates[1]
                if target then
                    placements[index] = {x = target.x, y = target.y, side = side}
                    occupied[tostring(target.x)..":"..tostring(target.y)] = true
                    if side == "left" then left_count = left_count + 1
                    else right_count = right_count + 1 end
                else
                    print("[ezencounters] WARNING no available enemy tile for enemy", index)
                end
            end
        end
    else
        -- Preserve valid enemy positions; move only entries outside enemy
        -- territory or colliding with an already retained enemy.
        local to_move = {}
        for _, index in ipairs(active_indices) do
            local old = existing_by_index[index]
            if old then
                local key = tostring(old.x)..":"..tostring(old.y)
                if get_team_at(data.teams, old.x, old.y) == 1 and not occupied[key] then
                    placements[index] = {x = old.x, y = old.y}
                    occupied[key] = true
                else
                    to_move[#to_move + 1] = index
                end
            else
                to_move[#to_move + 1] = index
            end
        end
        for _, index in ipairs(to_move) do
            local source = existing_by_index[index]
            local candidates = get_open_team_cells(data.teams, 1, occupied)
            sort_cells_near(candidates, source and source.x or 5, source and source.y or 2)
            local target = candidates[1]
            if target then
                placements[index] = {x = target.x, y = target.y}
                occupied[tostring(target.x)..":"..tostring(target.y)] = true
            else
                print("[ezencounters] WARNING no available enemy tile for enemy", index)
            end
        end
    end

    if positions_were_missing or terrain ~= nil then
        positions = make_empty_matrix()
        for index, placement in pairs(placements) do
            if placement then
                positions[placement.y][placement.x] = index
            end
        end
        data.positions = positions
    end
end

local function prepare_battlefield_data(data)
    if type(data.tiles) ~= "table" then
        data.tiles = copy_matrix(encounter_info.field_tiles_default)
    end

    local terrain = type(data.terrain) == "string" and data.terrain or nil
    local player_columns, enemy_columns = get_terrain_columns(terrain)

    if type(data.teams) ~= "table" then
        if player_columns and enemy_columns then
            local player_column_set = {}
            for _, x in ipairs(player_columns) do player_column_set[x] = true end
            data.teams = make_empty_matrix()
            for y = 1, 3 do
                for x = 1, 6 do
                    data.teams[y][x] = player_column_set[x] and 2 or 1
                end
            end
        else
            data.teams = copy_matrix(encounter_info.field_teams_default)
        end
    else
        data.teams = copy_matrix(data.teams)
    end

    -- Terrain is runtime context, never an encounter-definition requirement.
    -- Only normalize placements when a recognized terrain was supplied.
    if player_columns then
        normalize_player_positions(data)
        normalize_enemy_positions(data, terrain)
    end
end

function package_build(mob,data) 
    --First a work around to not crash the server, include the obstacle scripts here rather than in global scope
    for obstacle_alias, script_path in pairs(encounter_info.obstacles) do
        --print('[ezencounters] including '..script_path)
        loaded_obstacles[obstacle_alias] = include(script_path)
    end
    --work around end

    --TESTING, uncomment to set up custom arrangements of enemies for testing
    --[[local data = {
        enemies = {
            {name="Mettaur",rank=1},
        },
        positions = {
            {0,0,0,0,0,1},
            {0,0,0,0,1,0},
            {0,0,0,1,0,0}
        },
    }]]
    --

    local field = mob:get_field()
    --can setup music, and field here
    if not data then
        --test data here
        local flip_field = false
        data = ramdomize_test_scenario(encounter_info,flip_field)
    end
    -- Prepare default tiles/teams and apply any runtime terrain formation.
    -- `terrain` is supplied in initiate_encounter data, never stored in the
    -- area encounter definition itself.
    prepare_battlefield_data(data)

    for y, x_table in ipairs(data.tiles) do
        for x, tile_state_index in ipairs(x_table) do
            local tile = field:tile_at(x,y)
            local tile_state = get_enum_value_by_index(encounter_info.tile_states,tile_state_index)
            if tile then
                tile:set_state(tile_state)
            end
        end
    end

    -- Team 1 is enemy territory; team 2 is player territory.
    for y, x_table in ipairs(data.teams) do
        for x, team_index in ipairs(x_table) do
            local tile = field:tile_at(x, y)
            if tile then
                tile:set_team(team_index, false)
                if team_index == 1 then
                    tile:set_facing(Direction.Left)
                elseif team_index == 2 then
                    tile:set_facing(Direction.Right)
                end
            else
                print('[ezencounters] WARNING missing team tile at', x, y)
            end
        end
    end

    --load enemies from data
    if not data.enemies then
        print('[ezencounters] WARNING no enemies listed for encounter')
        return
    end
    spawners = {}
    for index, enemy_info in ipairs(data.enemies) do
        local enemy_rank = get_enum_value_by_index(encounter_info.enemy_ranks,enemy_info.rank)
        print("trying to make spawner for ",enemy_info.name,enemy_rank)
        spawners[index] = mob:create_spawner(get_package_id(enemy_info.name),enemy_rank)
    end

    -- Resolve the player's battle-field column so enemies can face inward
    -- even when the encounter places enemies on both sides of the player.
    -- The standard player-side center column is 3 when no explicit position
    -- is supplied (the normal 6x3 encounter field).
    local player_columns = {}
    if type(data.player_positions) == "table" then
        for _, x_table in ipairs(data.player_positions) do
            if type(x_table) == "table" then
                for x, player_id in ipairs(x_table) do
                    if player_id ~= nil and player_id ~= 0 then
                        player_columns[#player_columns + 1] = x
                    end
                end
            end
        end
    end
    if #player_columns == 0 then
        player_columns = list_team_columns(data.teams, 2)
    end
    if #player_columns == 0 then
        player_columns[1] = 3
    end

    local function facing_toward_nearest_player(enemy_x, character)
        local nearest_player_x = player_columns[1]
        local nearest_distance = math.abs(enemy_x - nearest_player_x)
        for index = 2, #player_columns do
            local distance = math.abs(enemy_x - player_columns[index])
            if distance < nearest_distance then
                nearest_distance = distance
                nearest_player_x = player_columns[index]
            end
        end

        if enemy_x < nearest_player_x then
            return Direction.Right
        elseif enemy_x > nearest_player_x then
            return Direction.Left
        end

        -- Same-column placement is unusual; preserve the tile's configured
        -- facing rather than forcing an arbitrary horizontal direction.
        local tile = character:get_tile()
        if tile then
            return tile:get_facing()
        end
        return Direction.Left
    end

    -- Spawn enemies and explicitly set each character's facing. Tile facing
    -- alone is not sufficient for formations that surround the player:
    -- enemies on the left must face Right, while enemies on the right face Left.
    if not data.positions then
        print('[ezencounters] WARNING no enemy spawn positions')
        return
    end
    for y, x_table in ipairs(data.positions) do
        for x, spawner_id in ipairs(x_table) do
            if spawner_id ~= 0 then
                local spawner = spawners[spawner_id]
                local enemy_info = data.enemies[spawner_id]
                local mutator = spawner:spawn_at(x, y)
                mutator:mutate(function (character)
                    character:set_facing(facing_toward_nearest_player(x, character))

                    if enemy_info.nickname ~= nil then
                        character:set_name(enemy_info.nickname)
                    end
                    -- `health` is the canonical current-HP field for an enemy
                    -- entry in data.enemies. Keep starting_hp as a backwards-
                    -- compatible alias for older encounter definitions.
                    -- This mutator runs on the specific spawned character tied
                    -- to this enemy_info entry, so multi-enemy encounters keep
                    -- each enemy's health independent.
                    local starting_health = tonumber(enemy_info.health)
                    if starting_health == nil then
                        starting_health = tonumber(enemy_info.starting_hp)
                    end
                    -- Accept the legacy top-level health field when the
                    -- encounter contains exactly one enemy. Multi-enemy
                    -- encounters must provide per-entry health values.
                    if starting_health == nil and #data.enemies == 1 then
                        starting_health = tonumber(data.health)
                    end
                    if starting_health ~= nil then
                        if starting_health ~= starting_health or starting_health == math.huge
                            or starting_health == -math.huge then
                            print("[ezencounters] WARNING invalid starting health for", enemy_info.name)
                        else
                            starting_health = math.max(0, starting_health)
                            character:set_health(starting_health)
                            print("[ezencounters] applied starting health", enemy_info.name, starting_health)
                        end
                    end

                    -- There is no working max-HP mutator in this package.
                    -- Character/package configuration remains the maximum HP
                    -- authority; `max_hp` is not silently treated as current HP.
                    if enemy_info.max_hp ~= nil then
                        print("[ezencounters] WARNING max_hp is not applied; character package maximum HP remains authoritative for", enemy_info.name, enemy_info.max_hp)
                    end
                end)
            end
        end
    end

    if data.player_positions then
        for y, x_table in ipairs(data.player_positions) do
            for x, player_id in ipairs(x_table) do
                if player_id ~= 0 then
                    mob:spawn_player( player_id, x, y )
                end
            end
        end
    end

    if data.freedom_mission and data.freedom_mission.enabled ~= false then
        local turns = 3
        local can_flip = true
        -- Area encounter definitions use `turn_count`; accept the older
        -- `turns` spelling too so existing data continues to work.
        if data.freedom_mission.turn_count ~= nil then
            turns = data.freedom_mission.turn_count
        elseif data.freedom_mission.turns ~= nil then
            turns = data.freedom_mission.turns
        end
        if data.freedom_mission.player_can_flip ~= nil then
            can_flip = data.freedom_mission.player_can_flip
        end
        mob:enable_freedom_mission(turns,can_flip)
    end

    if type(data.music) == "table" then
        local music_path = data.music.path
        if type(music_path) == "string" and music_path ~= "" then
            local loop_start = tonumber(data.music.loop_start) or 0
            local loop_end = tonumber(data.music.loop_end) or 0
            mob:stream_music(_folderpath.."/music/"..music_path..".mid",loop_start,loop_end)
        end
    end

    if data.obstacle_positions then
        for y, x_table in ipairs(data.obstacle_positions) do
            for x, obstacle_id in ipairs(x_table) do
                if obstacle_id ~= 0 then
                    local obstacle_info = data.obstacles[obstacle_id]
                    local create_obstacle_func = loaded_obstacles[obstacle_info.name]
                    local new_obstacle = create_obstacle_func()
                    --print('spawning obstacle '..obstacle_info.name..' at '..x..','..y)
                    field:spawn(new_obstacle,x,y)
                end
            end
        end
    end

end