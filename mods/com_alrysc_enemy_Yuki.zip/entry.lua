local package_id = "com.alrysc.enemy.Yuki"
local character_id = "com.alrysc.enemy.YukiEnemy"

function package_requires_scripts()
    Engine.define_character(character_id, _modpath.."enemy")
end

function package_init(package) 
    package:declare_package_id(package_id)
    package:set_name("Yuki")
    package:set_description("")
    package:set_speed(1)
    package:set_attack(90)
    package:set_health(2100)
    package:set_preview_texture_path(_modpath.."preview.png")
end

function package_build(mob) 

    local texPath = _modpath.."bg.png"
    local animPath = _modpath.."bg.animation"
    mob:set_background(texPath, animPath, 0.16667, 0.16667)
    mob:stream_music(_modpath.."VSnavi.ogg", 13896, 32307)
   -- 612820,2037590 
    mob:create_spawner(character_id, Rank.V1):spawn_at(5, 2)

end