local shared_package_init = include("../Zaemon/character.lua")

function package_init(character)
    local character_info = {
        name = "Zaemon",
        name_on_spawn = true,
        health = 130,
        damage = 30,
        element = Element.None,
        damage_iainuki = 30,
        attack_frame = 30,
        move_frames1 = 16,
        move_frames2 = 4,
        move_delay = 60,
    }
    if character:get_rank() == Rank.V2 then
        character_info.name = "ZaemonEX"
        character_info.health = 170
        character_info.damage = 60
        character_info.damage_iainuki = 60
        character_info.attack_frame = 26
        character_info.move_frames1 = 15
        character_info.move_frames2 = 4
        character_info.move_delay = 58
    elseif character:get_rank() == Rank.V3 then
        character_info.name = "Zuimon"
        character_info.health = 220
        character_info.damage = 90
        character_info.damage_iainuki = 90
        character_info.attack_frame = 24
        character_info.move_frames1 = 14
        character_info.move_frames2 = 4
        character_info.move_delay = 54
    elseif character:get_rank() == Rank.SP then
        character_info.name = "ZuimonEX"
        character_info.health = 260
        character_info.damage = 120
        character_info.damage_iainuki = 120
        character_info.attack_frame = 22
        character_info.move_frames1 = 13
        character_info.move_frames2 = 3
        character_info.move_delay = 48
    elseif character:get_rank() == Rank.Rare1 then
        character_info.name = "Zerumon"
        character_info.health = 320
        character_info.damage = 160
        character_info.damage_iainuki = 160
        character_info.attack_frame = 20
        character_info.move_frames1 = 12
        character_info.move_frames2 = 3
        character_info.move_delay = 44
    elseif character:get_rank() == Rank.Rare2 then
        character_info.name = "ZerumonEX"
        character_info.health = 360
        character_info.damage = 200
        character_info.damage_iainuki = 200
        character_info.attack_frame = 16
        character_info.move_frames1 = 11
        character_info.move_frames2 = 3
        character_info.move_delay = 40
    else
        character_info.name_on_spawn = false
    end
    shared_package_init(character,character_info)
end