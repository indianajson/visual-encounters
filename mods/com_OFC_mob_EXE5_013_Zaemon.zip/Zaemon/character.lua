--[[
    TODO:
    Needs some restriction on Area Steal usage.
]]
local print_debug = false

local CHARACTER_TEXTURE = Engine.load_texture(_folderpath.."gfx/battle.grayscaled.png")
local CHARACTER_ANIMPATH = _folderpath.."gfx/battle.animation"

local SLASH_TEXTURE = Engine.load_texture(_folderpath.."gfx/slash.grayscaled.png")
local SLASH_PALETTE = Engine.load_texture(_folderpath.."gfx/palette/slash.png")
local SLASH_ANIMPATH = _folderpath.."gfx/slash.animation"
local SLASH_AUDIO = Engine.load_audio(_folderpath.."sfx/EXE5_37.ogg", true)

local ZAEMON_AUDIO = Engine.load_audio(_folderpath.."sfx/EXE5_49.ogg", true)

local WindPush = include("libs/WindPush.lua")

-- Battle Chips
local Chip149 = include("chips/com_OFC_card_EXE5_149_AreaSteal/steal/steal.lua")
Chip149.type = 2

function debug_print(id,str)
    if print_debug then
        print("[Zaemon] (ID: "..id:get_id()..") "..str)
    end
end

--possible states for character
local states = { MOVE_SEARCH = 1, IDLE = 2, MOVE_FOUND = 3, ATTACK = 4, COOLDOWN = 5 }

--(Function by Alrysc, edited by K1rbYat1Na)
local function graphic_init(type, x, y, texture, palette, animation, layer, state, anim_playback, user, facing, delete_on_complete, relative_to_user, flip)
    texture = texture or nil
    animation = animation or nil
    layer = layer or nil
    state = state or nil
    anim_playback = anim_playback or Playback.Once
    facing = facing or user:get_facing()
    delete_on_complete = delete_on_complete or false
    flip = flip or false
    
    local graphic = nil
    if type == "artifact" then 
        graphic = Battle.Artifact.new()
    elseif type == "spell" then 
        graphic = Battle.Spell.new(user:get_team())
    elseif type == "obstacle" then 
        graphic = Battle.Obstacle.new(user:get_team())
    end
    if palette then
        graphic:store_base_palette(palette)
        graphic:set_palette(graphic:get_base_palette())
    end
    if layer then
        graphic:sprite():set_layer(layer)
    end
    graphic:never_flip(flip)
    if texture then
        graphic:set_texture(texture, false)
    end
    if facing then 
        graphic:set_facing(facing)
    end
    
    if relative_to_user and facing == Direction.Left then 
        x = x * -1
    end
    graphic:set_offset(x, y)
    local anim = graphic:get_animation()
    if animation then
        graphic:get_animation():load(animation)
    end
    if state then
        graphic:get_animation():set_state(state)
    end
    if anim_playback then
        graphic:get_animation():set_playback(anim_playback)
    end
    anim:refresh(graphic:sprite())

    if delete_on_complete then 
        anim:on_complete(function()
            graphic:delete()
        end)
    end

    return graphic
end

local function create_slash_hitbox(user, damage, tile)
    if not tile or tile:is_edge() then return end
    local facing = user:get_facing()
    local field = user:get_field()
    local team = user:get_team()
	local hitbox = Battle.Spell.new(team)
    hitbox:set_facing(facing)
    hitbox:set_hit_props(
		HitProps.new()
        :dmg(damage)
        :impact()
        :flinch()
        :elem(Element.Sword)
        :from(user:get_context())
	)
    hitbox.on_spawn_func = function()
        debug_print(user,"attack spawned at tile ("..tile:x()..";"..tile:y()..")")
    end
	hitbox.update_func = function(self)
		tile:attack_entities(self)
		self:erase()
	end
	field:spawn(hitbox, tile)
	return hitbox
end

local function create_slash(user, facing, field, damage, type, tile)
    if not tile or tile:is_edge() then return end
    local facing = user:get_facing()
    local field = user:get_field()
	local slash_fx = graphic_init("artifact", 0, 0, SLASH_TEXTURE, SLASH_PALETTE, SLASH_ANIMPATH, -3, type, Playback.Once, user, facing, true)
    slash_fx:set_elevation(16*2)
	field:spawn(slash_fx, tile)
    if     type == "0_U" or type == "0_D" then
        for i=-1,1 do
            create_slash_hitbox(user, damage, field:tile_at(tile:x(),tile:y()+i))
        end
    elseif type == "1_U" or type == "0_D" then
        create_slash_hitbox(user, damage, tile)
        create_slash_hitbox(user, damage, tile:get_tile(facing, 1))
    end
end

-- A restrictor for the usage of Area Steal.
local function create_artifact(user)
    local artifact = Battle.Artifact.new()
    artifact:set_name("USED_AREA_STEAL")
    local frame = 1
    artifact.update_func = function(self)
        if frame > 300 then
            self:delete()
        end
        frame = frame + 1
    end
	artifact.battle_end_func = function(self)
        self:delete()
    end
	artifact.delete_func = function(self)
        self:erase()
    end
    user:get_field():spawn(artifact,user:get_tile())
    return artifact
end

function package_init(self, character_info)
    -- Required function, main package information
    self.texture = CHARACTER_TEXTURE
    self.animation = self:get_animation()
    self.animation:load(CHARACTER_ANIMPATH)
    -- Load extra resources
    -- Set up character meta
    -- Common Properties
    self:set_name(character_info.name)
    self:set_health(character_info.health)
    self:set_element(character_info.element)
    self:set_texture(self.texture, true)
    self:set_height(61)
    self:set_float_shoe(false)
    self:set_air_shoe(false)
    self:share_tile(false)
    self:set_explosion_behavior(2, 1, false)
    self:set_offset(0,0)
    self:store_base_palette(Engine.load_texture(_folderpath.."gfx/palette/battle-"..self:get_rank()..".png"))
    self:set_palette(self:get_base_palette())
    self.damage = character_info.damage
    -- Zaemon Specific
    self.damage_iainuki = character_info.damage_iainuki
    self.attack_frame = character_info.attack_frame
    self.move_frames1 = character_info.move_frames1
    self.move_frames2 = character_info.move_frames2
    self.move_delay = character_info.move_delay
    -- Other Setup
    self.collision_available = true
    -- entity will spawn with this animation.
    self.animation:set_state("SPAWN")
    --self.animation:refresh(self:sprite())
    self.frame_counter = 0
    self.started = false
    self.is_deleting = false
    -- This defense rule is added to prevent enemy from gaining invincibility after taking damage.
    self.defense = Battle.DefenseVirusBody.new()
    self:add_defense_rule(self.defense)
    -- Can't be Dragged.
    self.guarding = true
    self.defense_rule = Battle.DefenseRule.new(1, DefenseOrder.Always)
    local ref = self
    self.defense_rule.filter_statuses_func = function(statuses)
		statuses.flags = statuses.flags & ~Hit.Flash
        if ref.state == states.MOVE_SEARCH or ref.state == states.MOVE_FOUND or ref:is_sliding() then
            statuses.flags = statuses.flags & ~Hit.Drag
        end
		return statuses
	end
    self:add_defense_rule(self.defense_rule)

    local ref = self
    self.counterable_component = Battle.Component.new(self, Lifetimes.Battlestep)
    self.counterable_component.timer = 0
    self.counterable_component.update_func = function(self)
        if self.timer > 0 then
            debug_print(ref,"COUNTERABLE")
            self.timer = self.timer - 1
            ref:toggle_counter(true)
        else
            ref:toggle_counter(false)
        end
    end
    self:register_component(self.counterable_component)
    self.hit_func = function(from_stun)
        debug_print(ref,"Hit func runs")
        self.counterable_component.timer = 0
        self:toggle_counter(false)
    end
    self.on_countered = function(self)
        debug_print(ref,"Countered")
        self.hit_func(true)
    end
    self:register_status_callback(Hit.Stun, function() self.hit_func(true) end)
    self:register_status_callback(Hit.Freeze, function() self.hit_func(true) end)

    self.slide_component = nil
    self.prev_tile = nil
    self.next_tile = nil

    self.can_move_to_func = function(tile)
        --if self:is_rooted() then return false end
        if tile:is_hole() then
            return false
        end
        if tile:get_team() ~= self:get_team() then
            return false
        end
        -- Can't move to reserved tiles.
        if(tile:is_reserved({self:get_id()})) then
            return false
        end
        if tile == self:get_tile() then
            return true
        end
        return not check_obstacles(tile) and not check_characters_true(tile)
    end

    self.battle_chip_amount = 1
    self.battle_chip = Chip149
    self.battle_chip_id = 149
    self.battle_chip_timer = 200

    self.move_dir = Direction.Up
    if math.random(1,2) == 1 then
        self.move_dir = Direction.Down
    end
    self.main_x = nil
    self.slash_table = {}
    self.is_start = true
    -- Code that runs in the default state
    ---@param frame number
    self.action_move_search = function(frame)
        local facing = self:get_facing()
        if frame == 1 then
            debug_print(self,"MOVE_SEARCH")
            if self.animation:get_state() ~= "PLAYER_IDLE" then
                self.animation:set_state("PLAYER_IDLE")
                self.animation:set_playback(Playback.Loop)
            end
            self.next_tile = nil
            -- ONLY ONCE AT THE START! --
            if self.is_start then
                self.is_start = false
                for i=1,2 do
                    local tile = self:get_tile(facing,i)
                    if tile and check_characters(tile,self) then
                        self.set_state(states.MOVE_FOUND)
                        return
                    end
                end
            end
            -----------------------------
            local tile = self:get_tile(self.move_dir,1)
            if tile and self.can_move_to_func(tile) then
                self.next_tile = tile
            else
                self.move_dir = Direction.reverse(self.move_dir)
                tile = self:get_tile(self.move_dir,1)
                if tile and self.can_move_to_func(tile) then
                    self.next_tile = tile
                end
            end
            if not self.next_tile then
                self.move_dir = Direction.reverse(self.move_dir)
                tile = self:get_tile(self.move_dir,1)
                if tile and self.can_move_to_func(tile) then
                    self.next_tile = tile
                end
            end
            if self.next_tile then
                local ref = self
                self.next_tile:reserve_entity_by_id(self:get_id())
                self:slide(ref.next_tile, frames(ref.move_frames1), frames(0), ActionOrder.Immediate)
                WindPush.make_entity_immune_to_status(self)
            end
        end
        if not self:is_sliding() then
            if frame > math.floor(self.move_frames1/2) then
                self.set_state(states.IDLE)
            end
        end
    end

    ---@param frame number
    self.action_idle = function(frame)
        local facing = self:get_facing()
        local field = self:get_field()
        local team = self:get_team()
        if frame == 1 then
            debug_print(self,"IDLE")
            WindPush.remove_immunity(self)
            if self.animation:get_state() ~= "PLAYER_IDLE" then
                self.animation:set_state("PLAYER_IDLE")
                self.animation:set_playback(Playback.Loop)
            end
        end
        if self:is_sliding() then
            debug_print(self,"IDLE sliding")
        end
        if frame < self.move_delay then
            for i=1,field:width() do
                local tile = self:get_tile(facing,i)
                if tile and ((check_obstacles(tile) or check_characters_true(tile)) and tile:get_team() == team) then
                    debug_print(self,"the path is blocked")
                    break
                else
                    if tile and check_characters(tile,self) and not self:is_sliding() then
                        if math.random(1,2) == 1 and (self:is_confused() or self:is_blind()) then
                            self.set_state(states.MOVE_SEARCH)
                        else
                            self.set_state(states.MOVE_FOUND)
                        end
                        return
                    end
                end
            end
        end
        if frame >= self.move_delay then
            if self.battle_chip_amount > 0 and self.battle_chip_timer <= 0 then
                self.battle_chip_timer = 2000
                local check = field:find_entities(function(e)
                    return e:get_name() == "USED_AREA_STEAL"
                end)
                if #check <= 0 then
                    debug_print(self,"using Chip")
                    self.battle_chip_amount = self.battle_chip_amount - 1
                    local chip_action = self.battle_chip.card_create_action(self)
                    local props = chip_action:copy_metadata()
                    if self.battle_chip_id == 149 then
                        props.shortname = "AreaStel"
                        props.damage = 0
                        props.time_freeze = true
                        props.element = Element.None
                        props.can_boost = false
                    end
                    chip_action = self.battle_chip.card_create_action(self, props)
	                chip_action:set_metadata(props)
                    self:card_action_event(chip_action, ActionOrder.Immediate)
                    create_artifact(self)
                    return
                end
            end
            self.set_state(states.MOVE_SEARCH)
        end
    end
    
    ---@param frame number
    self.action_cooldown = function(frame)
        local facing_away = self:get_facing_away()
        local facing = self:get_facing()
        local field = self:get_field()
        local team = self:get_team()
        if frame == 1 then
            debug_print(self,"COOLDOWN")
            if self.animation:get_state() ~= "PLAYER_IDLE" then
                self.animation:set_state("PLAYER_IDLE")
                self.animation:set_playback(Playback.Loop)
            end
        end
        if frame >= self.move_delay and frame < self.move_delay+10 then
            if self.battle_chip_amount > 0 and self.battle_chip_timer <= 0 then
                self.battle_chip_timer = 2000
                local check = field:find_entities(function(e)
                    return e:get_name() == "USED_AREA_STEAL"
                end)
                if #check <= 0 then
                    debug_print(self,"using Chip")
                    self.battle_chip_amount = self.battle_chip_amount - 1
                    local chip_action = self.battle_chip.card_create_action(self)
                    local props = chip_action:copy_metadata()
                    if self.battle_chip_id == 149 then
                        props.shortname = "AreaStel"
                        props.damage = 0
                        props.time_freeze = true
                        props.element = Element.None
                        props.can_boost = false
                    end
                    chip_action = self.battle_chip.card_create_action(self, props)
	                chip_action:set_metadata(props)
                    self:card_action_event(chip_action, ActionOrder.Immediate)
                    create_artifact(self)
                    return
                end
            end
            for i=1,field:width() do
                local tile = self:get_tile(facing,i)
                if tile and ((check_obstacles(tile) or check_characters_true(tile)) and tile:get_team() == team) then
                    debug_print(self,"the path is blocked")
                    break
                else
                    if tile and check_characters(tile,self) and not self:is_sliding() then
                        if math.random(1,2) == 1 and (self:is_confused() or self:is_blind()) then
                            self.set_state(states.MOVE_SEARCH)
                        else
                            self.set_state(states.MOVE_FOUND)
                        end
                        return
                    end
                end
            end
        end
        if frame >= self.move_delay+10 then
            self.set_state(states.MOVE_SEARCH)
        end
        if not self:is_sliding() then
            if self:get_tile():x() == self.main_x then
                return
            end
            local tile = self:get_tile(facing_away,1)
            if tile and self.can_move_to_func(tile) then
                --self.next_tile = tile
                tile:reserve_entity_by_id(self:get_id())
                local ref = self
                self:slide(tile, frames(ref.move_frames2), frames(0), ActionOrder.Immediate)
                WindPush.make_entity_immune_to_status(self)
            else
                self.main_x = self:get_tile():x()
            end
        end
    end
    
    ---@param frame number
    self.action_move_found = function(frame)
        local facing = self:get_facing()
        local field = self:get_field()
        local team = self:get_team()
        if frame == 1 then
            debug_print(self,"MOVE_FOUND")
            Engine.play_audio(ZAEMON_AUDIO, AudioPriority.Low)
            self.prev_tile = self:get_tile()
            self.next_tile = nil
        end
        if not self:is_sliding() then
            local tile = self:get_tile(facing,1)
            if tile and self.can_move_to_func(tile) then
                debug_print(self,"move next")
                --self.next_tile = tile
                tile:reserve_entity_by_id(self:get_id())
                local ref = self
                self:slide(tile, frames(ref.move_frames2), frames(0), ActionOrder.Immediate)
                WindPush.make_entity_immune_to_status(self)
            else
                debug_print(self,"attack")
                self.set_state(states.ATTACK)
            end
        end
    end
    
    ---@param frame number
    self.action_attack = function(frame)
        local facing = self:get_facing()
        local field = self:get_field()
        if frame == 1 then
            debug_print(self,"ATTACK")
            WindPush.remove_immunity(self)
            self.animation:set_state("READY")
            self.animation:set_playback(Playback.Loop)
        end
        if frame == self.attack_frame-15 or frame == self.attack_frame+30+self.attack_frame-15 then --if frame == 15 or frame == 75 then
            self.counterable_component.timer = 20 -- Becomes counterable for 20 frames.
        end
        if frame == self.attack_frame then -- 30
            for i=1,field:width() do
                local tile = self:get_tile(facing,i)
                if tile and check_characters(tile,self) then
                    self.slash_table = {"1_U","0_D"}
                    break
                else
                    self.slash_table = {"0_U","1_D"}
                end
            end
            self.animation:set_state("ATTACK")
            create_slash(self, facing, field, self.damage_iainuki, self.slash_table[1], self:get_tile(facing,1))
            Engine.play_audio(SLASH_AUDIO, AudioPriority.Low)
        end
        if frame == self.attack_frame+31 then -- 61
            self.animation:set_state("READY2")
            self.animation:set_playback(Playback.Loop)
        end
        if frame == self.attack_frame+30+self.attack_frame then -- 90
            self.animation:set_state("ATTACK2")
            create_slash(self, facing, field, self.damage_iainuki, self.slash_table[2], self:get_tile(facing,1))
            Engine.play_audio(SLASH_AUDIO, AudioPriority.Low)
        end
        if frame >= self.attack_frame+30+self.attack_frame+31 then -- 121
            self.set_state(states.COOLDOWN)
        end
    end

    --utility to set the update state, and reset frame counter
    ---@param state number
    self.set_state = function(state)
        self.state = state
        self.frame_counter = 0
    end
    -- actions for states
    local actions = { [1] = self.action_move_search, [2] = self.action_idle, [3] = self.action_move_found, [4] = self.action_attack, [5] = self.action_cooldown }
    self.on_spawn_func = function(self)
        debug_print(self,"on_spawn_func called")
        if character_info.name_on_spawn then
            self:set_name(character_info.name)
        end
    end
    self.battle_start_func = function()
        debug_print(self,"battle_start_func called")
        self.main_x = self:get_tile():x()
    end
    self.delete_func = function()
        debug_print(self,"delete_func called")
        self.is_deleting = true
    end
    self.update_func = function()
        if self:can_attack() then
            if self.battle_chip_amount > 0 then
                if self.battle_chip_timer > 0 then
                    self.battle_chip_timer = self.battle_chip_timer - 1
                end
            end
            self.frame_counter = self.frame_counter + 1
            if not self.started then
                self.started = true
                self.set_state(states.MOVE_SEARCH)
            else
                local action_func = actions[self.state]
                action_func(self.frame_counter)
            end
            -- collision hitbox
            check_collision(self, self.damage)
        end
    end
end

function create_collision_attack(user, damage, tile)
    local spell = Battle.Spell.new(user:get_team())
    spell:set_facing(user:get_facing())
    spell:set_hit_props(
        HitProps.new()
        :dmg(damage)
        :impact()
        :flinch()
        :flash()
        --:breaking()
        :from(user:get_context())
        :elem(user:get_element())
    )
    spell.update_func = function(self)
        tile:attack_entities(self)
        self:delete()
    end
    user:get_field():spawn(spell, tile)
    return spell
end

function check_collision(user, damage)
    local t = user:get_tile()
    if user.collision_available and check_characters(t, user) then 
        create_collision_attack(user, damage, t)
    end
end

-- Checks for non-zero-health Obstacles.
function check_obstacles(tile)
    local ob = tile:find_obstacles(function(o)
        if o:get_animation():has_state("PASS_THROUGH") or o:get_name() == "CANTINTERACT" then
            return false
        else
            return true
        end
        return o:get_health() > 0
    end)
    return #ob > 0 
end

-- Checks for unfriendly Characters.
function check_characters(tile, self)
    local characters = tile:find_characters(function(c)
        return c:get_health() > 0 and c:get_id() ~= self:get_id() and c:get_team() ~= self:get_team()
    end)
    return #characters > 0
end

-- Checks for any Characters.
function check_characters_true(tile)
    local characters = tile:find_characters(function(c)
        return c:get_health() > 0
    end)
    return #characters > 0
end

function check_characters_true_team(tile, self)
    local characters = tile:find_characters(function(c)
        return c:get_health() > 0 and c:get_tile():get_team() == self:get_tile():get_team()
    end)
    return #characters > 0
end

return package_init