local print_debug = false

local AUDIO_DAMAGE_PLAYER = Engine.load_audio(_folderpath.."sfx/EXE6_149.ogg", true)
local AUDIO_DAMAGE_ENEMY = Engine.load_audio(_folderpath.."sfx/EXE6_50.ogg", true)
local AUDIO_DAMAGE_OBS = Engine.load_audio(_folderpath.."sfx/EXE6_131.ogg", true)

local ROCKMAN_TEXTURE = nil
local ROCKMAN_PALETTE = nil
local ROCKMAN_ANIMPATH = _folderpath.."gfx/rockman.animation"

local CLAW_TEXTURE = Engine.load_texture(_folderpath.."gfx/claw.grayscaled.png")
local CLAW_PALETTE = Engine.load_texture(_folderpath.."gfx/palette/palette-claw.png")
local CLAW_ANIMPATH = _folderpath.."gfx/claw.animation"
local THUNDERBALL_TEXTURE = Engine.load_texture(_folderpath.."gfx/thunderball.grayscaled.png")
local THUNDERBALL_PALETTE = Engine.load_texture(_folderpath.."gfx/palette/palette-thunderball.png")
local THUNDERBALL_ANIMPATH = _folderpath.."gfx/thunderball.animation"
local FIREBREATH_TEXTURE = Engine.load_texture(_folderpath.."gfx/firebreath.grayscaled.png")
local FIREBREATH_PALETTE = Engine.load_texture(_folderpath.."gfx/palette/palette-firebreath.png")
local FIREBREATH_ANIMPATH = _folderpath.."gfx/firebreath.animation"

local EFFECT_TEXTURE_F = Engine.load_texture(_folderpath.."gfx/effect_f.grayscaled.png") -- flip for Player 2
local EFFECT_PALETTE_F = Engine.load_texture(_folderpath.."gfx/palette/palette-effect_f.png")
local EFFECT_ANIMPATH_F = _folderpath.."gfx/effect_f.animation"
local EFFECT_TEXTURE_E = Engine.load_texture(_folderpath.."gfx/effect_e.grayscaled.png") -- flip for Player 2
local EFFECT_PALETTE_E = Engine.load_texture(_folderpath.."gfx/palette/palette-effect_e.png")
local EFFECT_ANIMPATH_E = _folderpath.."gfx/effect_e.animation"
local MUZZLEFLASH_TEXTURE = Engine.load_texture(_folderpath.."gfx/muzzleflash.grayscaled.png")
local MUZZLEFLASH_PALETTE = Engine.load_texture(_folderpath.."gfx/palette/palette-muzzleflash.png")
local MUZZLEFLASH_ANIMPATH = _folderpath.."gfx/muzzleflash.animation"
local BURST_TEXTURE = Engine.load_texture(_folderpath.."gfx/burst.grayscaled.png")
local BURST_PALETTE = Engine.load_texture(_folderpath.."gfx/palette/palette-burst.png")
local BURST_ANIMPATH = _folderpath.."gfx/burst.animation"

local CANNON_AUDIO = Engine.load_audio(_folderpath.."sfx/EXE6_278.ogg", true)
local THUNDERBALL_AUDIO = Engine.load_audio(_folderpath.."sfx/EXE6_71.ogg", true)
local FIREBREATH_AUDIO = Engine.load_audio(_folderpath.."sfx/EXE6_344.ogg", true)
local GREGARCLAW_AUDIO_1 = Engine.load_audio(_folderpath.."sfx/EXE6_107.ogg", true)
local GREGARCLAW_AUDIO_2 = Engine.load_audio(_folderpath.."sfx/EXE6_207.ogg", true)

local function debug_print(text)
    if print_debug then
        print("[GregarBeast] "..text)
    end
end

--[[

    Moveset:
    For the first time, ElementMan moves twice (or thrice for V1). Then he uses Downburst once (or twice, if his element is None) and an elemental attack (if his element is not None). Then he moves twice (or thrice for V1). Then he uses Downburst once. Then he moves twice (or thrice for V1). The he uses the element-changing move. If moves ends successfully, changes his element in order: None, Wood, Fire, Elec, Aqua, repeat.

    Downburst:
    ElementMan creates a tornado in one of two back corners of his field that travels a Boomerang-like path. Can't be spawned inside of a Character/an Obstacle. Bownburst's speed depends on ElementMan's version.

    Tallest Tree:
    ElementMan moves to the back line of his field and creates a Woody Tower that moves forward or up-forward/down-forward (if there's an enemy). When it grows completely, changes current tile into Grass. Can be blocked by Obstacles. Can be used if ElementMan can't move to the back line. Tallest Tree's speed depends on ElementMan's version.

    Meteorite:
    ElementMan drops several meteors. Each meteor targets the closest enemy. If HP < 50 %, he drops more meteors.

    Lightning Drive:
    ElementMan creates a thunderbolt that hits current tile and moves to follows enemies in a ThunderBall-like way. Can hit up to 6 tiles. 

    Diamond Dust:
    ElementMan moves to the tile in front of the closest enemy and creates 3 diamond dusts in a WideSword-like way. The attack always freezes hit Characters. If a hit Character has Status Guard, causes flashing instead.

]]

local function graphic_init(g_type, x, y, texture, animation, state, anim_playback, layer, user, facing, flip)
    flip = flip or false
    facing = facing or nil
    
    local graphic = nil
    if g_type == "artifact" then 
        graphic = Battle.Artifact.new()
    elseif g_type == "spell" then 
        graphic = Battle.Spell.new(user:get_team())
    end

    if layer then
        graphic:sprite():set_layer(layer)
    end
    graphic:never_flip(flip)
    if texture then
        graphic:set_texture(texture, false)
    end
    if facing then
        graphic:set_facing(facing)
    end
    --[[
    if user:get_facing() == Direction.Left then 
        x = x * -1
    end]]
    graphic:set_offset(x, y)
    if animation then
        graphic:get_animation():load(animation)
    end
    if state then
        graphic:get_animation():set_state(state)
    end
    graphic:get_animation():refresh(graphic:sprite())
    if anim_playback then
        graphic:get_animation():set_playback(anim_playback)
    end

    return graphic
end

local function create_breath_sfx(user)
    local sfxer = graphic_init("spell", 0, 0, false, false, false, false, false, user, user:get_facing())
    sfxer.frames = 0
	sfxer.on_spawn_func = function()
		Engine.play_audio(FIREBREATH_AUDIO, AudioPriority.Low)
	end
    sfxer.update_func = function(self)
        if user.flinching then 
            if self and not self:is_deleted() then 
                self:delete()
            end
        end
        self.frames = self.frames + 1
        for i=16, 80, 16 do
            if self.frames == i then
		        Engine.play_audio(FIREBREATH_AUDIO, AudioPriority.Low)
                if i == 80 then
                    self:erase()
                end
            end
        end
    end
    user:get_field():spawn(sfxer, user:get_tile())
    return sfxer
end

local function create_breath_hitbox(user, tile)
	local hitbox = graphic_init("spell", 0, 0, false, false, false, false, false, user, user:get_facing())
	hitbox:set_hit_props(
		HitProps.new(
			user.damage_beastbreath,
			Hit.Impact | Hit.Flinch | Hit.Flash,
			Element.Fire,
			user:get_context(),
			Drag.None
		)
	)
	hitbox.on_spawn_func = function()
        debug_print("BeastBreath hitbox spawned on tile ("..tile:x()..";"..tile:y()..")")
	end
	hitbox.update_func = function(self)
		tile:attack_entities(self)
		self:erase()
	end
	hitbox.attack_func = function(self, other)
		debug_print("BeastBreath attacked tile ("..self:get_tile():x()..";"..self:get_tile():y()..")")
		local offset_y = math.random(-8,5)
		local offset_x = math.random(-7,6)
		if self:get_facing() == Direction.Left then offset_x = -offset_x end
		local hit_fx = graphic_init("artifact", (offset_x*2), (offset_y*2), EFFECT_TEXTURE_F, EFFECT_ANIMPATH_F, "0", Playback.Once, -999, self, self:get_facing(), facing)
        hit_fx:set_palette(EFFECT_PALETTE_F)
		hit_fx:get_animation():on_complete(function() hit_fx:erase() end)
		self:get_field():spawn(hit_fx, self:get_tile())
		if Battle.Obstacle.from(other) == nil then
			--if Battle.Player.from(user) ~= nil then
				--Engine.play_audio(AUDIO_DAMAGE_ENEMY, AudioPriority.Low)
			--end
		else
			Engine.play_audio(AUDIO_DAMAGE_OBS, AudioPriority.Low)
		end
	end
	user:get_field():spawn(hitbox, tile)
	return hitbox
end

local function create_breath(user, tile)
    if not tile or tile:is_edge() then return end
    local fire = graphic_init("spell", 0, 0, FIREBREATH_TEXTURE, FIREBREATH_ANIMPATH, "0", Playback.Loop, -3, user, user:get_facing())
    fire:set_palette(FIREBREATH_PALETTE)
    fire.state = "IDLE"
    fire.frames = 0
	fire.do_once = true
	local hit_query = function(ent)
		return (Battle.Character.from(ent) ~= nil or Battle.Player.from(ent) ~= nil or Battle.Obstacle.from(ent) ~= nil) and ent:get_health() > 0 and not ent:is_team(user:get_team())
	end
    fire.update_func = function(self)
        tile:highlight(Highlight.Solid)
        if user.flinching then 
            if self and not self:is_deleted() then 
                self:delete()
            end
        end
		if #self:get_tile():find_entities(hit_query) > 0 then
			if self.do_once then
				self.do_once = false
				create_breath_hitbox(user, self:get_tile())
			end
		else
			if not self.do_once then
				self.do_once = true
			end
		end
        self.frames = self.frames + 1
        if self.state == "IDLE" then
            if self.frames >= 75 then
                self.state = "END"
                self.frames = 0
                self:get_animation():set_state("1")
                self:get_animation():refresh(self:sprite())
            end
        else
            if self.frames >= 5 then
                self:erase()
            end
        end
    end
    user:get_field():spawn(fire, tile)
    return fire
end

local function create_thunderball(user, spawn_tile)
	local saved_direction = user:get_facing()
	-- remember position of user at time of spawning attack, 
	-- to prevent the user from being able to influence the ball afterwards
	-- The origin is the center of the sprite. Raise thunder upwards 10 pixels
	-- (keep in mind scale is 2, e.g. 10 * 2 = 20)
	local spell = graphic_init("spell", 0, -10*2, THUNDERBALL_TEXTURE, THUNDERBALL_ANIMPATH, "0", Playback.Loop, -3, user, saved_direction)
    spell:set_palette(THUNDERBALL_PALETTE)
	spell:set_hit_props(
		HitProps.new(
			user.damage_thunderball,
			Hit.Impact | Hit.Flinch | Hit.Stun,
			Element.Elec,
			user:get_context(),
			Drag.None
		)
	)
	spell.collided = false
	local ver_choice = 1 -- controls version stats, level 3 is on par with BDT stats
	local version_options = {
		timeout = {300, 390, 480},
		speed = {60, 50, 40},
	}
	local version = {
		timeout = version_options.timeout[ver_choice],
		speed = version_options.speed[ver_choice],
	}

	-- the weak Thunder Ball lasts for 300 frames
	local timeout = version.timeout
	local elapsed = 0
	local target = nil

	local field = user:get_field()
	spell.on_spawn_func = function()
        debug_print("ThunderBall spawned on tile ("..spawn_tile:x()..";"..spawn_tile:y()..")")
		Engine.play_audio(THUNDERBALL_AUDIO, AudioPriority.Low)
	end
	local direction = nil
	spell.update_func = function(self)
		elapsed = elapsed + 1
		if elapsed > timeout then
			self:erase()
		end
		local tile = self:get_tile()
		-- delete when going off field
		if tile:is_edge() then
			self:erase()
		end
		-- Find target if we don't have one
		if not target then
			local closest_dist = math.huge
			field:find_characters(function(character)
				local character_team = character:get_team()
				if (
					character_team == user:get_team() or
					character_team == Team.Other or
					character:will_erase_eof()
				) then
					return false
				end
				if not target then
					target = character
				else
					-- If the distance to one enemy is shorter than the other, target the shortest enemy path
					local dist = math.abs(tile:x() - character:get_tile():x()) + math.abs(tile:y() - character:get_tile():y())

					if dist < closest_dist then
						target = character
						closest_dist = dist
					end
				end
				return false
			end)
			-- We have found a target
			-- Create a notifier so we can null the target when they are deleted
			if target then
				local callback = function()
					target = nil
				end
				field:notify_on_delete(target:get_id(), self:get_id(), callback)
			end
		end
		-- If sliding is flagged to false, we know we've ended a move
		if not self:is_sliding() then
			-- If there are no targets, aimlessly move right or left
			-- (save_direction gets determined once at spawn time)
			direction = saved_direction
			if target then
				local target_tile = target:get_tile()
				if target_tile then
					if target_tile:x() < tile:x() then
						direction = Direction.Left
					elseif target_tile:x() > tile:x() then
						direction = Direction.Right
					elseif target_tile:y() < tile:y() then
						direction = Direction.Up
					elseif target_tile:y() > tile:y() then
						direction = Direction.Down
					end
					-- Poll if target is flagged for deletion, remove our mark
					if target:will_erase_eof() then
						target = nil
					end
				end
			end
			local query = function(o)
				return not o:is_team(self:get_team())
			end
			if not self.collided and #self:get_tile():find_characters(query) <= 0 then
				-- Always slide to the tile we're moving to
				local next_tile = self:get_tile(direction, 1)
				self:slide(next_tile, frames(version.speed), frames(0), ActionOrder.Voluntary, nil)
			end
		end
		-- Always affect the tile we're occupying
		tile:attack_entities(self)
		if self.collided then
			self:highlight_tile(Highlight.None)
			self:get_animation():on_complete(function() self:erase() end)
		else
			self:highlight_tile(Highlight.Solid)
		end
	end
	spell.collision_func = function(self)
		self.collided = true
	end
	spell.attack_func = function(self, other)
		debug_print("ThunderBall attacked tile ("..self:get_tile():x()..";"..self:get_tile():y()..")")
		local offset_y = math.random(-8,7)
		local offset_x = math.random(-8,7)
		if self:get_facing() == Direction.Left then offset_x = -offset_x end
        local hit_fx = graphic_init("artifact", (offset_x*2), (offset_y*2), EFFECT_TEXTURE_E, EFFECT_ANIMPATH_E, "0", Playback.Once, -999, self, self:get_facing(), true)
        hit_fx:set_palette(EFFECT_PALETTE_E)
        hit_fx:get_animation():on_complete(function() hit_fx:erase() end)
        self:get_field():spawn(hit_fx, self:get_tile())
        if Battle.Obstacle.from(other) == nil then
			--if Battle.Player.from(user) ~= nil then
				--Engine.play_audio(AUDIO_DAMAGE_ENEMY, AudioPriority.Low)
			--end
		else
			Engine.play_audio(AUDIO_DAMAGE_OBS, AudioPriority.Low)
		end
	end
	spell.can_move_to_func = function(tile)
		return true
	end
	field:spawn(spell, spawn_tile)
	return spell
end

local function create_buster_hitbox(user, tile)
    if not tile or tile:is_edge() then return end
    local hitbox = graphic_init("spell", 0, 0, false, false, false, false, false, user, user:get_facing())
        hitbox:set_hit_props(
            HitProps.new(
                user.damage_beastbuster_buster,
                Hit.Impact | Hit.Flinch,
                Element.None,
                user:get_context(),
                Drag.None
            )
        )
    hitbox.slide_started = false
    hitbox.on_spawn_func = function()
        debug_print("BeastBuster spawned on tile ("..tile:x()..";"..tile:y()..")")
    end
    hitbox.update_func = function(self)
        self:get_tile():attack_entities(self)
        if not self:is_sliding() then
            if self.slide_started and self:get_tile():is_edge() then
                self:delete()
            end
            local next_tile = self:get_tile(self:get_facing(), 1)
            self:slide(next_tile, frames(1), frames(0), ActionOrder.Immediate, function()
                hitbox.slide_started = true
            end)
        end
    end
    hitbox.collision_func = function(self)
        self:delete()
    end
    hitbox.attack_func = function(self, other)
        debug_print("BeastBuster attacked tile ("..other:get_tile():x()..";"..other:get_tile():y()..")")
        local offset_y = math.random(-22,-9)
        local offset_x = math.random(-9,8)
        if self:get_facing() == Direction.Right then offset_x = -offset_x end
        local burst_fx = graphic_init("artifact", other:get_tile_offset().x+other:get_offset().x+(offset_x*2), other:get_tile_offset().y+other:get_offset().y+(offset_y*2), BURST_TEXTURE, BURST_ANIMPATH, "0", Playback.Once, -999, self, self:get_facing(), true)
        burst_fx:set_palette(BURST_PALETTE)
        burst_fx:get_animation():on_complete(function() burst_fx:erase() end)
        self:get_field():spawn(burst_fx, other:get_tile())
        if Battle.Obstacle.from(other) == nil then
            --if Battle.Player.from(user) ~= nil then
            --    Engine.play_audio(AUDIO_DAMAGE_ENEMY, AudioPriority.Low)
            --end
        else
            Engine.play_audio(AUDIO_DAMAGE_OBS, AudioPriority.Low)
        end
    end
    hitbox.can_move_to_func = function(tile)
        return true
    end
    user:get_field():spawn(hitbox, tile)
    return hitbox
end

local function create_slash_hitbox(user, tile, stunning)
    if not tile or tile:is_edge() then return end
    local hitbox = graphic_init("spell", 0, 0, false, false, false, false, false, user, user:get_facing())
    if stunning then
        hitbox:set_hit_props(
            HitProps.new(
                user.damage_beastbuster_claw,
                Hit.Impact | Hit.Flinch | Hit.Stun,
                Element.None,
                user:get_context(),
                Drag.None
            )
        )
    else
        hitbox:set_hit_props(
            HitProps.new(
                user.damage_gregarclaw,
                Hit.Impact | Hit.Flinch,
                Element.None,
                user:get_context(),
                Drag.None
            )
        )
    end
    local query = function(c)
        return c and c:get_health() > 0 and not c:is_team(hitbox:get_team())
    end
    hitbox.on_spawn_func = function()
        debug_print("GregarClaw spawned on tile ("..tile:x()..";"..tile:y()..")")
    end
    hitbox.update_func = function(self)
        tile:attack_entities(self)
        if stunning and #self:get_tile():find_characters(query) > 0 then
            user.enemy_attacked = true
            user.attacked_tile = self:get_tile()
        end
        self:erase()
    end
    hitbox.collision_func = function(self)
        --if stunning then
            --if #self:get_tile():find_characters(query) > 0 then
                --user.enemy_attacked = true
            --end
        --end
    end
    hitbox.attack_func = function(self, other)
        debug_print("GregarClaw attacked tile ("..self:get_tile():x()..";"..self:get_tile():y()..")")
        if Battle.Obstacle.from(other) == nil then
            --if Battle.Player.from(user) ~= nil then
            --    Engine.play_audio(AUDIO_DAMAGE_ENEMY, AudioPriority.Low)
            --end
        else
            Engine.play_audio(AUDIO_DAMAGE_OBS, AudioPriority.Low)
        end
    end
    user:get_field():spawn(hitbox, tile)
    return hitbox
end

local function create_slash(user, state, tile)
    if not tile or tile:is_edge() then return end
    local claw = graphic_init("artifact", 0, -16*2, CLAW_TEXTURE, CLAW_ANIMPATH, state, Playback.Once, -3, user, user:get_facing())
    claw:set_palette(CLAW_PALETTE)
    claw:get_animation():on_complete(function() claw:erase() end)
    user:get_field():spawn(claw, tile)
    return claw
end

function package_init(self)
    ROCKMAN_TEXTURE = Engine.load_texture(_folderpath.."gfx/rockman.grayscaled.png")
    ROCKMAN_PALETTE = Engine.load_texture(_folderpath.."gfx/palette/palette-rockman.png")
    self:set_name("GrgBeast")
	local rank = self:get_rank()
    self.damage = 10
    self.damage_thunderball = 30
    self.damage_gregarclaw = 60
    self.damage_beastbuster_claw = 30
    self.damage_beastbuster_buster = 5
    self.damage_beastbreath = 0

    self.enemy_attacked = false
    self.attacked_tile = nil

    self.cur_action_number = 1
    self.ball_action_number = math.random(0,3)

    self.next_tile = nil
    self.prev_tile = nil
    self.original_tile = nil

    self.base_idle_speed = 17

    -- Chance /16. I'm going to run these when the pattern is complete and when the flinch finishes, respectively
        -- These skips will be very implementation-specific, so don't use them as future references
    self.chance_to_move_zero_times = 2
    self.chance_to_move_six_times = 4 --has a change to move 6 times
    self.chance_to_skip_idle_after_flinch = 2
    self.chance_to_halve_idle_after_flinch = 3

    if rank == Rank.SP then
        self:set_health(1800)
        self.damage_thunderball = 120
        self.damage_gregarclaw = 240
        self.damage_beastbuster_claw = 120
        self.damage_beastbuster_buster = 20
        self.damage_beastbreath = 300
    else
        self:set_name("GrgrBeast")
        self:set_health(900)
    end

    --self.idle_speed = self.base_idle_speed
    self.idle_speed = 0

    self:set_texture(ROCKMAN_TEXTURE, true)
    self:set_palette(ROCKMAN_PALETTE)

    self:set_height(44)
    self:set_explosion_behavior(5, 1, true)
    self:set_offset(0,0)
	self:set_facing(Direction.Left)
	self:set_element(Element.None)
	self:set_float_shoe(false)
	self:set_air_shoe(true)
    self:share_tile(false)

    local anim = self:get_animation()
    anim:load(ROCKMAN_ANIMPATH)
    self.anim = include("enemy_base_v1/entry.lua")
    anim = self.anim
    anim:set_owner(self)
    anim:set_state("IDLE", {
        {duration=1, state="IDLE_1"},
    })
    anim:set_playback(Playback.Loop)

    init_boss(self)
end

--(Function by Alrysc)
-- This is to fix something that happens because I'm a cheater
--[[
    The aggressor of an attack is held in the Context object. 
    ONB leaves this aggressor unset in the Entity's Context until a CardAction is used for the first time
    So I'll immediately force a CardAction that will hopefully end immediately and not get in the way, but also will fix this
    This probably goes horribly wrong if the enemy is spawned after the mob intro, but should be fine for now otherwise
]]
function fix_context(self)
    local action = Battle.CardAction.new(self, "IDLE_1")
    action.execute_func = function()
        action:end_action()
    end
    self:card_action_event(action, ActionOrder.Immediate)
end

--(Function by Alrysc)
function init_boss(self)
    self.on_spawn_func = function(self)
        fix_context(self)
    end
    self.battle_start_func = function(self)
        --print("COLOR: r("..self:get_color().r..")")
        --print("COLOR: g("..self:get_color().g..")")
        --print("COLOR: b("..self:get_color().b..")")
        --print("COLOR: a("..self:get_color().a..")")
    end

    -- Setting names here is just convenience if I want to print the state I'm in later
    self.states = {
        idle = {name = "idle", func = idle},
        move = {name = "move", func = move},
        flinch = {name = "flinch", func = flinch},
        
        start_sub_pattern = {name = "start_sub_pattern"},
        finish_sub_pattern = {name = "finish_sub_pattern"},

        thunderball = {name = "thunderball", func = thunderball},
        gregarclaw = {name = "gregarclaw", func = gregarclaw},
        beastbuster = {name = "beastbuster", func = beastbuster},
        beastbreath = {name = "beastbreath", func = beastbreath},

        choose_attack = {name = "choose_attack", func = choose_attack}
    }
    
    local s = self.states

    reconstruct_pattern(self)
 
    self.pattern_index = 1
    self.in_sub_pattern = false

    self.first_act = true
    self.second_act = false
    self.third_act = false
    self.fourth_act = false

    self.state_done = false

    self.state = self.pattern[1]

    self.first_flinch = true

    self.hit_func = function(from_stun)
        --debug_print("Hit func runs")
        self:toggle_counter(false)
        self.flinching = false
        self.first_act = false
        self.second_act = false
        self.third_act = false
        self.fourth_act = false
        self.enemy_attacked = false
        self.state_done = false
        self.moving_to_enemy_tile = false
        if self.first_flinch then 
            --self.state.cleanup
            self.last_state = self.state
            --debug_print("Hit! Set last state to ", self.state.name)
            if self.state ~= self.states.idle and self.state ~= self.states.move then 
               --increment_pattern(self)
            end
            self.first_flinch = false
        end
        local delaying = false
        if self.original_tile then
            delaying = true
        end
        if not delaying then
            self.state = self.states.flinch
        end
        -- This is unused for this boss
        if self.slide_component ~= nil then 
            --debug_print("Hit while moving.")
            self.slide_component:eject()
            self.slide_component = nil
            self:set_offset(0,0)
            if self.slide_dest and self:get_tile() ~= self.slide_dest then 
                --debug_print("Hit before reaching destination.")
                self:get_tile():remove_entity_by_id(self:get_id())
                self.slide_dest:add_entity(self)
                self.slide_dest = nil
            end
        end
        flinch(self, from_stun)
    end

    self.delete_func = function(self)
        self.update_func = function(self)
            self:get_animation():set_state("FLINCH_3")
            self.state = self.states.flinch
        end
    end

    -- Unused for this boss
    self.moving_to_enemy_tile = false
    self.counter = 0
    self.collision_available = true
    self.counterable = 0

    local ref = self
    self.counterable_component = Battle.Component.new(self, Lifetimes.Battlestep)
    self.counterable_component.timer = 0
    self.counterable_component.update_func = function(self)
        if self.timer > 0 then
            debug_print("COUNTERABLE")
            self.timer = self.timer - 1
            ref:toggle_counter(true)
        else
            ref:toggle_counter(false)
        end
    end
    self:register_component(self.counterable_component)

    local super_armor = Battle.DefenseRule.new(813, DefenseOrder.CollisionOnly)
	super_armor.filter_statuses_func = function(statuses)
        debug_print("filter_statuses")
        if statuses.flags & Hit.Drag ~= Hit.Drag then
            debug_print("remove flinch")
		    statuses.flags = statuses.flags & (~Hit.Flinch)
		    return statuses
        end
		return statuses
	end
	self:add_defense_rule(super_armor)

    self:register_status_callback(Hit.Stun, function() self.hit_func(true) end)
    self:register_status_callback(Hit.Flinch, self.hit_func)
    --self:register_status_callback(Hit.Drag, self.hit_func)
    self:register_status_callback(Hit.Root, function() self.rooted = 120 end)

    -- Bring it back next build. For now, relying on the stun callback
    self.on_countered = function(self)
        debug_print("Countered")
        --self.counterable_component.timer = 0
        --self:toggle_counter(false)
        self.hit_func(true)
    end

    self.rooted = 0
    self.can_move_to_func = function(tile)
        if self.rooted > 0 then return false end
        if tile:is_edge() --[[or not tile:is_walkable()]] then
            return false
        end
        if(tile:is_reserved({self:get_id()})) then
            return false
        end
        if tile == self:get_tile() then
            return true
        end
        if not self.moving_to_enemy_tile and (tile:get_team() ~= self:get_team()) then
            return false
        end
        return not check_obstacles(tile, self) and not check_characters_true(tile, self)
    end

    --self.do_once_blind_confuse = true

    self.update_func = function(self)
        --debug_print("     ", self.state.name, self:get_animation():get_state())
        if self.rooted > 0 then self.rooted = self.rooted - 1 end
        self.state.func(self)
        self.anim:tick_animation()
        -- When we tick animation, we may run increment_pattern. 
        -- The new state isn't run until next frame, so our anim state lasts one more frame when it finishes
        -- Calling our state one time to set things up will avoid this. Mostly sure this doesn't have major unintended consequences,
        -- especially as most state.func only set state and callbacks for frame 1
        -- Problem is, now I may have a frame 1 callback but I don't run it until next frame
        while self.first_act
        do
            self.state.func(self)
            self.anim:tick_animation()
        end
        check_collision(self)
    end
end

--(Function by Alrysc)
function create_collision_attack(self, tile)
    local spell = Battle.Spell.new(self:get_team())
    local hit_props = HitProps.new(
        self.damage,
        Hit.Impact | Hit.Flash | Hit.Flinch,
        self:get_element(), 
        self:get_context(), 
        Drag.None
    )
    spell:set_hit_props(hit_props)
    spell.update_func = function(self)
        tile:attack_entities(self)
        self:delete()
    end
    self:get_field():spawn(spell, tile)
end

--(Function by Alrysc)
-- TODO: When we get is_passthrough or something, check to see if target became flashing before 
-- we are allowed to spawn another one. Don't want to instakill viruses
-- self.collision_available can do something related to that. Does nothing now
function check_collision(self)
    local t = self:get_tile()
    if self.collision_available and check_characters(t, self) then 
        create_collision_attack(self, t)
    end
end

--(Function by Alrysc)
function idle(self)
    if self.first_act then
        self.first_act = false
        -- This is an old check for when I extended idle time by doing two idle states in a row, when characters have an animated idle
        -- Not needed if I instead use a timer
        if self.anim:get_state() ~= "IDLE" then 
            --debug_print("Idle with ", self.idle_speed)
            self.anim:set_state("IDLE", {
                {duration=4, state="IDLE_1"},
            })    
        end
        self.anim:set_playback(Playback.Loop)
        self.counter = 0
    end
    self.counter = self.counter + 1
    if self.counter == 1 then
        if self.rooted > 0 then
            self.idle_speed = self.base_idle_speed
            increment_pattern(self)
        end
    elseif self.counter > self.idle_speed then
        -- Extra catch for after leaving attack. Attack will double idle speed once, so making sure to reset it after
        if self.idle_speed > self.base_idle_speed then 
            self.idle_speed = self.base_idle_speed
        end
        increment_pattern(self)
    end
    --self.looped = false
    --if self.state_done then 
        --print("State done")
    --end
end

--(Function by Alrysc)
function hit()

end

--(Function by Alrysc)
function end_sub_pattern(self)
    while(self.in_sub_pattern)
    do
        increment_pattern(self)
    end
end

--(Function by Alrysc)
function flinch(self, from_stun)
    debug_print("Flinch played")
    local delaying = false
    if self.original_tile then
        delaying = true
        self:teleport(self.original_tile, ActionOrder.Immediate)
        self:get_tile():remove_entity_by_id(self:get_id())
        self.original_tile:add_entity(self)
        self.original_tile = nil
    end
    if delaying or from_stun then
        if self:get_tile() == self.next_tile then
            local orig_tile = self.next_tile
            self.next_tile:remove_entity_by_id(self:get_id())
            self.next_tile = orig_tile
            self.next_tile:add_entity(self)
            self.next_tile = nil
        elseif self:get_tile() == self.prev_tile then
            local orig_tile = self.prev_tile
            self.prev_tile:remove_entity_by_id(self:get_id())
            self.prev_tile = orig_tile
            self.prev_tile:add_entity(self)
            self.prev_tile = nil
        elseif self:get_tile() ~= self.next_tile then
            if self.next_tile ~= nil then
                self.next_tile:remove_entity_by_id(self:get_id())
                self.next_tile = nil
            end
        end
        if self.rooted > 0 then self.rooted = 0 end
        debug_print("I am flinching")
        if not self.flinching then
            local frames = {}
            if not from_stun then
                frames[1] = {duration=22, state="IDLE_1"} -- or 5?
                --[[
                frames[1] = {duration=4, state="FLINCH_1"}
                frames[2] = {duration=2, state="FLINCH_2"}
                frames[3] = {duration=2, state="FLINCH_3"}
                frames[4] = {duration=2, state="FLINCH_2"}
                frames[5] = {duration=2, state="FLINCH_3"}
                frames[6] = {duration=4, state="FLINCH_2"}
                frames[7] = {duration=5, state="BREATH_1"}
                frames[8] = {duration=3, state="IDLE_1"}
                ]]
            else
                frames[1] = {duration=1, state="FLINCH_3"}
            end
            self.anim:set_state("FLINCH", frames)
            self.anim:on_complete(function()
                -- If we didn't just attack, we want to make sure the idle speed is correct. This is also set in the actual idle, but just for extra measure.
                -- Shouldn't be necessary
                if self.idle_speed > self.base_idle_speed and self.pattern[self.pattern_index] ~= self.states.choose_attack then 
                    self.idle_speed = self.base_idle_speed
                end

                local has_skipped = false
                if self.last_state == self.states.idle then 
                    --debug_print("Attempt skip, because last state was idle")
                    has_skipped = maybe_skip_after_flinch(self)
                end

                --debug_print("I am done flinching")
                --debug_print("Anim done")
                self.flinching = false
                self.state_done = true
                self.first_flinch = true

                --debug_print("Done")
                self.state_done = false
                if self.last_state ~= self.states.idle and self.last_state ~= self.states.move then 
                    --debug_print("Last state was not idle or move", self.last_state.name)
                    increment_pattern(self)
                else
                    --if not has_skipped then 
                    -- If we were in idle or move, go back to it and try again
                    -- Unless we were in a sub pattern. Still end that.
                    --debug_print("Last state was idle or move")
                    if self.in_sub_pattern then 
                        end_sub_pattern(self)
                    else
                        self.state = self.last_state
                        self.first_act = true
                    end
                end
            end)
        end
        self.flinching = true
    end
end

--(Function by Alrysc)
--[[
    Chance to skip idle or halve idle time, to call after flinching 
    This works by calling increment_pattern an extra time if and only if the last state was Idle
        Remember, last state is the state we will return to after flinching
        Some extra work will need to be done in the self.anim:on_complete of flinch if this is to work with sub patterns. This boss doesn't use them, so it was omitted
    
    Currently, the skip is implemented as setting idle time to 0
    
    A future choice for this function: after calling this function, self.state *may* increment, obsoleting our last state pointer. Returns true if this does happen
        There is a possible additional side effect that the idle time will instead be changed, in which case, last state is preserved and false is returned
]]
function maybe_skip_after_flinch(self)
    local chance_halve = self.chance_to_halve_idle_after_flinch
    local chance_skip = self.chance_to_skip_idle_after_flinch
    local max = chance_halve + chance_skip + (16 - chance_halve - chance_skip)

    local r = math.random(1, max)
    if r <= chance_halve then 
        self.idle_speed = math.floor(self.idle_speed / 2)
       -- print("We halved")
    elseif r <= (chance_skip + chance_halve) then 
       -- print("We skipped")
        self.idle_speed = 0
        return true
    end

    return false
end

--(Function by Alrysc)
function highlight_tiles(self, list, time, type)
    local spell = Battle.Spell.new(self:get_team())
    local ref = self
    spell.update_func = function(self)
        for i=1, #list do 
            local t = list[i]
            if t and not t:is_edge() then 
                t:highlight(type)
            end
        end
        time = time - 1
        if time == 0 then 
            self:delete()
        end
        if self.flinching then 
            if spell and not spell:is_deleted() then 
                spell:delete()
            end
        end
    end
    self:get_field():spawn(spell, self:get_tile())
    return spell
end

--(Function by Alrysc)
function move(self)
    if self.first_act then
        self.first_act = false
        if self.rooted > 0 then
            self.idle_speed = self.base_idle_speed
            increment_pattern(self)
        else
            self.anim:set_state("MOVE", {
                {duration=2, state="IDLE_1"},
                {duration=1, state="WARP_1"},
                {duration=1, state="WARP_2"},
                {duration=1, state="WARP_1"},
                {duration=2, state="IDLE_1"},
            })
            self.prev_tile = self:get_tile()
            local tile = choose_move(self, self:get_field())
            if not tile then
                tile = self:get_tile()
            end
            self.next_tile = tile
            self.next_tile:reserve_entity_by_id(self:get_id())
            self.anim:on_frame(3, function()
                if self.can_move_to_func(self.next_tile) then 
                else
                    self.next_tile = self:get_tile()
                end
                self:teleport(self.next_tile, ActionOrder.Voluntary, nil)
            end)
            self.anim:on_complete(function()
                -- Reset idle speed, since we did a real action
                self.idle_speed = self.base_idle_speed
                increment_pattern(self)
            end)
        end
    end
end

function choose_attack(self)
    local atk_tbl = {
        [1] = self.states.gregarclaw,
        [2] = self.states.beastbuster,
        [3] = self.states.thunderball,
        [4] = self.states.beastbreath
    }
    local atk_nmb = 0
    if self.damage_beastbreath > 0 then
        if (self.cur_action_number == 1 or self.cur_action_number == 2 or self.cur_action_number == 3) or (self.cur_action_number == 5 or self.cur_action_number == 6 or self.cur_action_number == 7) then
            if self.cur_action_number == self.ball_action_number then
                atk_nmb = 3
            else
                atk_nmb = 1
            end
        elseif self.cur_action_number == 4 then
            atk_nmb = 2
        else
            atk_nmb = 4
        end
    else
        if (self.cur_action_number == 1 or self.cur_action_number == 2 or self.cur_action_number == 3) then
            atk_nmb = math.random(1,2)
        else
            atk_nmb = 3
        end
    end

    debug_print("Attack No. "..atk_nmb)
    self.state = atk_tbl[atk_nmb]
    self.state.func(self)
    self.idle_speed = self.base_idle_speed

    self.cur_action_number = self.cur_action_number + 1
    if self.damage_beastbreath > 0 then
        if self.cur_action_number == 5 then
            self.ball_action_number = math.random(0,3)
        elseif self.cur_action_number > 8 then
            self.ball_action_number = math.random(0,3)
            self.cur_action_number = 1
        end
    else
        if self.cur_action_number > 4 then
            self.cur_action_number = 1
        end
    end
end

function gregarclaw(self)
    if self.first_act then
        self.first_act = false
        if self.rooted > 0 then
            self.moving_to_enemy_tile = false
            self.idle_speed = self.base_idle_speed
            increment_pattern(self)
        else
            self.anim:set_state("GREGARCLAW", {
                {duration=2, state="IDLE_1"},
                {duration=1, state="WARP_1"},
                {duration=1, state="WARP_2"},
                {duration=1, state="WARP_1"},
                {duration=2, state="IDLE_1"},

                {duration=10, state="IDLE_1"},
                {duration=21, state="IDLE_1"},
                {duration=1, state="IDLE_1"}, --counterable
                {duration=2, state="CLAW_1"},
                {duration=2, state="CLAW_2"},
                {duration=2, state="CLAW_3"}, --hitbox
                {duration=14, state="CLAW_4"},
                {duration=13, state="CLAW_4"},
                {duration=1, state="CLAW_4"}, --counterable
                {duration=2, state="CLAW_1"},
                {duration=2, state="CLAW_2"},
                {duration=2, state="CLAW_3"}, --hitbox
                {duration=36, state="CLAW_4"},

                {duration=1, state="WARP_2"},
                {duration=1, state="WARP_1"},
                {duration=2, state="IDLE_1"},
                {duration=11, state="IDLE_1"},
            })
            self.moving_to_enemy_tile = true
            self.prev_tile = self:get_tile()
            self.original_tile = self.prev_tile
            local tile = choose_move_to_enemy(self, self:get_field())
            if not tile then
                self.moving_to_enemy_tile = false
                self.idle_speed = self.base_idle_speed
                increment_pattern(self)
            else
                self.next_tile = tile
                self.next_tile:reserve_entity_by_id(self:get_id())
            end
            self.anim:on_frame(3, function()
                if self.can_move_to_func(self.next_tile) then
                    self:teleport(self.next_tile, ActionOrder.Voluntary)
                else
                    self.moving_to_enemy_tile = false
                    self.idle_speed = self.base_idle_speed
                    increment_pattern(self)
                end
            end)
            self.anim:on_frame(6, function()
                -- Reset idle speed, since we did a real action
                self.idle_speed = self.base_idle_speed
            end)
            self.anim:on_frame(7, function()
                local list = 
                {
                    [1] = self:get_tile(self:get_facing(), 1),
                    [2] = self:get_tile(self:get_facing(), 2)
                }
                highlight_tiles(self, list, 22, Highlight.Flash)
            end)
            self.anim:on_frame(8, function()
                self.counterable_component.timer = 24+2 -- Makes GregarBeast counterable for 24+2 frames.
            end)
            self.anim:on_frame(9, function()
                Engine.play_audio(GREGARCLAW_AUDIO_1, AudioPriority.Low)
                create_slash(self, "0", self:get_tile(self:get_facing(), 1))
            end)
            self.anim:on_frame(11, function()
                create_slash_hitbox(self, self:get_tile(self:get_facing(), 1))
                create_slash_hitbox(self, self:get_tile(self:get_facing(), 2))
            end)
            self.anim:on_frame(13, function()
                local list = 
                {
                    [1] = self:get_tile(Direction.join(self:get_facing(), Direction.Up), 1),
                    [2] = self:get_tile(self:get_facing(), 1),
                    [3] = self:get_tile(Direction.join(self:get_facing(), Direction.Down), 1)
                }
                highlight_tiles(self, list, 14, Highlight.Flash)
            end)
            self.anim:on_frame(14, function()
                self.counterable_component.timer = 24+2 -- Makes GregarBeast counterable for 24+2 frames.
            end)
            self.anim:on_frame(15, function()
                Engine.play_audio(GREGARCLAW_AUDIO_2, AudioPriority.Low)
                create_slash(self, "1", self:get_tile(self:get_facing(), 1))
            end)
            self.anim:on_frame(17, function()
                create_slash_hitbox(self, self:get_tile(Direction.join(self:get_facing(), Direction.Up), 1))
                create_slash_hitbox(self, self:get_tile(self:get_facing(), 1))
                create_slash_hitbox(self, self:get_tile(Direction.join(self:get_facing(), Direction.Down), 1))
            end)
            self.anim:on_frame(19, function()
                self:teleport(self.original_tile, ActionOrder.Immediate)
                self.original_tile = nil
            end)
            self.anim:on_complete(function()
                self.moving_to_enemy_tile = false
                self.idle_speed = 0
                increment_pattern(self)
            end)
        end
    end
end

function beastbuster(self)
    if self.first_act then
        self.first_act = false
        if self.rooted > 0 then
            self.moving_to_enemy_tile = false
            self.enemy_attacked = false
            self.idle_speed = self.base_idle_speed
            increment_pattern(self)
        else
            self.anim:set_state("BEASTBUSTER_CLAW", { --27
                {duration=2, state="IDLE_1"},
                {duration=1, state="WARP_1"},
                {duration=1, state="WARP_2"},
                {duration=1, state="WARP_1"},
                {duration=2, state="IDLE_1"},

                {duration=10, state="IDLE_1"},
                {duration=21, state="IDLE_1"},
                {duration=1, state="IDLE_1"}, --counterable
                {duration=2, state="CLAW_1"},
                {duration=2, state="CLAW_2"},
                {duration=2, state="CLAW_3"}, --hitbox
                {duration=14, state="CLAW_4"},
                {duration=14, state="CLAW_4"},

                {duration=1, state="WARP_2"},
                {duration=1, state="WARP_1"},
                {duration=11, state="IDLE_1"},
            })
            self.moving_to_enemy_tile = true
            self.prev_tile = self:get_tile()
            self.original_tile = self.prev_tile
            local tile = choose_move_to_enemy(self, self:get_field())
            if not tile then
                self.moving_to_enemy_tile = false
                self.enemy_attacked = false
                self.idle_speed = self.base_idle_speed
                increment_pattern(self)
            else
                self.next_tile = tile
                self.next_tile:reserve_entity_by_id(self:get_id())
            end
            self.anim:on_frame(3, function()
                if self.can_move_to_func(self.next_tile) then
                    self:teleport(self.next_tile, ActionOrder.Voluntary)
                end
            end)
            self.anim:on_frame(6, function()
                if not self.can_move_to_func(self.next_tile) then
                    self.moving_to_enemy_tile = false
                    self.enemy_attacked = false
                    self.idle_speed = self.base_idle_speed
                    increment_pattern(self)
                end
            end)
            self.anim:on_frame(7, function()
                local list = 
                {
                    [1] = self:get_tile(self:get_facing(), 1),
                    [2] = self:get_tile(self:get_facing(), 2)
                }
                highlight_tiles(self, list, 22, Highlight.Flash)
            end)
            self.anim:on_frame(9, function()
                Engine.play_audio(GREGARCLAW_AUDIO_1, AudioPriority.Low)
                create_slash(self, "0", self:get_tile(self:get_facing(), 1))
            end)
            self.anim:on_frame(11, function()
                create_slash_hitbox(self, self:get_tile(self:get_facing(), 1), true)
                create_slash_hitbox(self, self:get_tile(self:get_facing(), 2), true)
            end)
            self.anim:on_frame(13, function()
                if self.enemy_attacked == true then
                    self.second_act = true
                end
            end)
            self.anim:on_frame(14, function()
                if self.enemy_attacked == false then
                    self:teleport(self.original_tile, ActionOrder.Immediate)
                    self.original_tile = nil
                end
            end)
            self.anim:on_complete(function()
                if not self.second_act and not self.third_act and not self.fourth_act then
                    self.moving_to_enemy_tile = false
                    self.enemy_attacked = false
                    self.idle_speed = 0
                    increment_pattern(self)
                end
            end)
        end
    end
    if self.second_act then
        self.second_act = false
        local frames = {}
        frames[1] = {duration=1, state="CLAW_4"}
        frames[2] = {duration=2, state="IDLE_1"}
        frames[3] = {duration=1, state="WARP_1"}
        frames[4] = {duration=1, state="WARP_2"}
        frames[5] = {duration=1, state="WARP_1"}
        frames[6] = {duration=2, state="IDLE_1"}
        frames[7] = {duration=31, state="IDLE_1"}
        frames[8] = {duration=1, state="BUSTER_1"}
        frames[9] = {duration=2, state="BUSTER_2"}
        frames[10] = {duration=1, state="BUSTER_3"}
        for i=1, 49, 3 do
            frames[10+i+0] = {duration=1, state="BUSTER_1"}
        end
        for i=1, 49, 3 do
            frames[10+i+1] = {duration=2, state="BUSTER_2"}
        end
        for i=1, 49, 3 do
            frames[10+i+2] = {duration=2, state="BUSTER_3"}
        end
        frames[10+49+2+1] = {duration=11, state="BUSTER_1"}
        self.anim:set_state("BEASTBUSTER_BUSTER", frames)
        local tile = choose_move_back(self, self:get_field())
        self.anim:on_frame(2, function()
            if tile then
                tile:reserve_entity_by_id(self:get_id())
            else
                self.third_act = true
            end
        end)
        self.anim:on_frame(4, function()
            if self.can_move_to_func(tile) then
                self:teleport(tile, ActionOrder.Voluntary)
            end
        end)
        self.anim:on_frame(6, function()
            if not self.can_move_to_func(tile) then
                self.moving_to_enemy_tile = false
                self.enemy_attacked = false
                self.idle_speed = self.base_idle_speed
                increment_pattern(self)
            end
        end)
        if not self.third_act and not self.fourth_act then
            for i=1, 52, 3 do
                self.anim:on_frame(7+i, function()
                    local offset_x = -51*2
                    if self:get_facing() == Direction.Right then offset_x = -offset_x end
                    local muzzle_fx = graphic_init("spell", offset_x, -20*2, MUZZLEFLASH_TEXTURE, MUZZLEFLASH_ANIMPATH, "0", Playback.Once, -99, self, self:get_facing())
                    muzzle_fx:set_palette(MUZZLEFLASH_PALETTE)
                    muzzle_fx:get_animation():on_complete(function() muzzle_fx:erase() end)
                    self:get_field():spawn(muzzle_fx, self:get_tile())
                    Engine.play_audio(CANNON_AUDIO, AudioPriority.Low)
                    create_buster_hitbox(self, self:get_tile(self:get_facing(), 1))
                end)
            end
            self.anim:on_complete(function()
                self.fourth_act = true
            end)
        end
    end
    if self.third_act then
        self.third_act = false
        self.anim:set_state("BEASTBUSTER_CANCEL", {
            {duration=1, state="WARP_2"},
            {duration=1, state="WARP_1"},
            {duration=11, state="IDLE_1"},
        })
        self.moving_to_enemy_tile = false
        self.anim:on_frame(1, function()
            self:teleport(self.original_tile, ActionOrder.Immediate)
            self.original_tile = nil
        end)
        self.anim:on_complete(function()
            self.moving_to_enemy_tile = false
            self.enemy_attacked = false
            self.idle_speed = 0
            increment_pattern(self)
        end)
    end
    if self.fourth_act then
        self.fourth_act = false
        self.anim:set_state("BEASTBUSTER_CANCEL", {
            {duration=1, state="WARP_2"},
            {duration=1, state="WARP_1"},
            {duration=11, state="IDLE_1"},
        })
        self.moving_to_enemy_tile = false
        self.anim:on_frame(1, function()
            local tile = choose_move(self, self:get_field(), true)
            tile:reserve_entity_by_id(self:get_id())
            if self.can_move_to_func(tile) then
                self:teleport(tile, ActionOrder.Voluntary)
            end
            if self:get_tile() ~= self.original_tile then
                self.original_tile:remove_entity_by_id(self:get_id())
            end
            self.original_tile = nil
        end)
        self.anim:on_complete(function()
            self.moving_to_enemy_tile = false
            self.enemy_attacked = false
            self.idle_speed = 0
            increment_pattern(self)
        end)
    end
end

function thunderball(self)
    if self.first_act then
        self.first_act = false
        self.anim:set_state("THUNDERBALL", {
            {duration=37, state="IDLE_1"},
            {duration=1, state="IDLE_1"}, --counterable
            {duration=1, state="BUSTER_1"}, --attack
            {duration=2, state="BUSTER_2"},
            {duration=2, state="BUSTER_3"},
            {duration=26, state="BUSTER_1"},
            {duration=22, state="IDLE_1"},
        })
        self.anim:on_frame(2, function()
            self.counterable_component.timer = 24+2 -- Makes GregarBeast counterable for 24+2 frames.
        end)
        self.anim:on_frame(3, function()
            create_thunderball(self, self:get_tile(self:get_facing(), 1))
        end)
        self.anim:on_complete(function()
            self.idle_speed = 0
            increment_pattern(self)
        end)
    end
end

function beastbreath(self)
    if self.first_act then
        self.first_act = false
        if self.rooted > 0 then
            self.idle_speed = self.base_idle_speed
            increment_pattern(self)
        else
            self.anim:set_state("BEASTBREATH", {
                {duration=2, state="IDLE_1"},
                {duration=1, state="WARP_1"},
                {duration=1, state="WARP_2"},
                {duration=2, state="IDLE_1"},
                {duration=23, state="IDLE_1"}, --21?
                {duration=3, state="BREATH_1"},
                {duration=3, state="BREATH_2"},
                {duration=3, state="BREATH_1"},
                {duration=3, state="BREATH_2"},
                {duration=3, state="BREATH_1"},
                {duration=3, state="BREATH_2"},
                {duration=3, state="BREATH_1"},
                {duration=3, state="BREATH_2"},
                {duration=3, state="BREATH_1"},
                {duration=3, state="BREATH_2"},
                {duration=3, state="BREATH_1"},
                {duration=3, state="BREATH_2"},
                {duration=3, state="BREATH_1"},
                {duration=3, state="BREATH_2"},
                {duration=3, state="BREATH_1"},
                {duration=3, state="BREATH_2"},
                {duration=3, state="BREATH_1"},
                {duration=3, state="BREATH_2"},
                {duration=3, state="BREATH_1"},
                {duration=3, state="BREATH_2"},
                {duration=3, state="BREATH_1"},
                {duration=3, state="BREATH_2"},
                {duration=3, state="BREATH_1"},
                {duration=3, state="BREATH_2"},
                {duration=3, state="BREATH_1"},
                {duration=3, state="BREATH_2"},
                {duration=3, state="BREATH_1"},
                {duration=32, state="IDLE_1"},
            })
            self.prev_tile = self:get_tile()
            self.original_tile = self.prev_tile
            local tile = choose_move_for_breath(self, self:get_field())
            if not tile then
                self.idle_speed = self.base_idle_speed
                increment_pattern(self)
            else
                self.next_tile = tile
                self.next_tile:reserve_entity_by_id(self:get_id())
            end
            self.anim:on_frame(3, function()
                if self.can_move_to_func(self.next_tile) then
                    self:teleport(self.next_tile, ActionOrder.Voluntary)
                end
            end)
            self.anim:on_frame(4, function()
                if self.can_move_to_func(self.next_tile) then
                end
            end)
            self.anim:on_frame(5, function()
                if not self.can_move_to_func(self.next_tile) then
                    self.idle_speed = self.base_idle_speed
                    increment_pattern(self)
                else
                    local list = 
                    {
                        [1] = self:get_tile(self:get_facing(), 1),
                        [2] = self:get_tile(self:get_facing(), 2),
                        [3] = self:get_tile(self:get_facing(), 3),
                        [4] = self:get_tile(self:get_facing(), 2):get_tile(Direction.Up, 1),
                        [5] = self:get_tile(self:get_facing(), 3):get_tile(Direction.Up, 1),
                        [6] = self:get_tile(self:get_facing(), 2):get_tile(Direction.Down, 1),
                        [7] = self:get_tile(self:get_facing(), 3):get_tile(Direction.Down, 1)
                    }
                    highlight_tiles(self, list, 23, Highlight.Flash)
                end
            end)
            self.anim:on_frame(6, function()
                local list = 
                {
                    [1] = self:get_tile(self:get_facing(), 1),
                    [2] = self:get_tile(self:get_facing(), 2),
                    [3] = self:get_tile(self:get_facing(), 3),
                    [4] = self:get_tile(self:get_facing(), 2):get_tile(Direction.Up, 1),
                    [5] = self:get_tile(self:get_facing(), 3):get_tile(Direction.Up, 1),
                    [6] = self:get_tile(self:get_facing(), 2):get_tile(Direction.Down, 1),
                    [7] = self:get_tile(self:get_facing(), 3):get_tile(Direction.Down, 1)
                }
                for i=1, #list do
                    create_breath(self, list[i])
                end
                create_breath_sfx(self)
            end)
            self.anim:on_complete(function()
                self.idle_speed = 0
                increment_pattern(self)
            end)
        end
    end
end

--(Function by Alrysc)
function find_valid_move_location(self)
	local target_tile
	local field = self:get_field()

	local tiles = field:find_tiles(function(tile)
		return self.can_move_to_func(tile)
	end)
  
	debug_print (#tiles)
	if #tiles >= 1 then
		target_tile = tiles[math.random(#tiles)]
	else
		target_tile = self:get_tile()
	end
	
	local start_tile = self:get_tile()
	if #tiles > 1 then
		while target_tile == start_tile do
		-- pick another, don't try to jump on the same tile if it's not necessary
		target_tile = tiles[math.random(#tiles)]
		end
	end
  
    return target_tile
end

function choose_enemy(self, field)
    local team = self:get_team()

    local target = field:find_characters(function(c)
        return c:get_health() > 0 and c:get_team() ~= team
    end)

    if not target[1] then 
        debug_print("No targets")
        return nil
    end

    t_x = target[1]:get_tile():x()
    t_y = target[1]:get_tile():y()

    local facing = -1
    if self:get_facing() == Direction.Left then 
        facing = 1
    end

    local tile = field:tile_at(t_x+facing, t_y)

    return tile
end

function choose_move(self, field, no_exc)
    local team = self:get_team()

    local tiles = field:find_tiles(function(tile)
        if no_exc then
            return self.can_move_to_func(tile)
        else
            return tile ~= self:get_tile() and self.can_move_to_func(tile)
        end
    end)

    debug_print("Found ", #tiles, " possible tiles")

    if #tiles == 0 then 
        return self:get_tile()
    end

    return tiles[math.random(1, #tiles)]
end

function choose_move_back(self, field)
    local facing = self:get_facing()
    local team = self:get_team()

    local enemy_tile = self.attacked_tile:get_tile(Direction.reverse(facing), 3)
    if enemy_tile ~= nil and self.can_move_to_func(enemy_tile) then
        debug_print("Found possible tile")
        return enemy_tile
    else
        return nil
    end
end

function choose_move_to_enemy(self, field)
    local team = self:get_team()

    local enemy_tile = choose_enemy(self, field)
    if enemy_tile ~= nil and self.can_move_to_func(enemy_tile) then
        debug_print("Found possible tile")
        return enemy_tile
    else
        return nil
    end
end

function choose_move_for_breath(self, field)
    local facing = self:get_facing()
    local team = self:get_team()

    local x_start = 1
    local x_mid = 1
    local x_end = field:width()
    if facing == Direction.Left then
        x_start = field:width()
        x_mid = -1
        x_end = 1
    end
    for i=x_start, x_end, x_mid do
        local enemy_tile = field:tile_at(i,math.ceil(field:height()/2))
        if enemy_tile and self.can_move_to_func(enemy_tile) and (enemy_tile:get_tile(facing, 1):get_team() ~= team or enemy_tile:get_tile(facing, 1):is_edge()) then
            debug_print("Found possible tile")
            return enemy_tile
            --break
        end
    end
end

function reconstruct_pattern(self)
    local pattern = {}
    local states = self.states

    for i=1, 5 do
        table.insert(pattern, states.idle)
        table.insert(pattern, states.move)
    end
    table.insert(pattern, states.idle)
    table.insert(pattern, states.choose_attack)

    self.pattern = pattern
end

function increment_pattern(self)
    --debug_print("Pattern increment")
    self.first_act = true
    self.second_act = false
    self.third_act = false
    self.fourth_act = false
    self.enemy_attacked = false
    self.state_done = false
    self.pattern_index = self.pattern_index + 1
    if self.pattern_index > #self.pattern then 
        reconstruct_pattern(self)
        --debug_print("Reconstructed pattern")
        self.pattern_index = 1
    end
    local next_state = self.pattern[self.pattern_index]
    self.state = next_state
    --debug_print("Moving to state named ", next_state.name)
    if next_state == self.states.start_sub_pattern then 
        self.in_sub_pattern = true
        increment_pattern(self)
    end
    if next_state == self.states.finish_sub_pattern then 
        self.in_sub_pattern = false
        increment_pattern(self)
    end
    --debug_print("Changing to "..self.pattern_index..", which is "..self.pattern[self.pattern_index].name)
end

function check_obstacles(tile, self)
    local ob = tile:find_obstacles(function(o)
        return o:get_health() > 0 
    end)
    return #ob > 0 
end

function check_characters(tile, self)
    local characters = tile:find_characters(function(c)
        return c:get_id() ~= self:get_id() and c:get_team() ~= self:get_team()
    end)
    return #characters > 0
end

function check_characters_true(tile, self)
    local characters = tile:find_characters(function(c)
        return true
    end)
    return #characters > 0
end