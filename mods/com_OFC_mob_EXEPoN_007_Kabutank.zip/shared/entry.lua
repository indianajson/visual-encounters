local AUDIO_DAMAGE = Engine.load_audio(_folderpath.."EXE4_270.ogg")
local AUDIO_DAMAGE_OBS = Engine.load_audio(_folderpath.."EXE4_221.ogg")

local CHARACTER_ANIMATION = _folderpath.."battle.animation"
local CHARACTER_TEXTURE = Engine.load_texture(_folderpath.."battle.grayscaled.png")
local CANNON_AUDIO = Engine.load_audio(_folderpath.."EXE4_241.ogg")

local BOMB_TEXTURE = Engine.load_texture(_folderpath.."bomb.png")
local BOMB_ANIMPATH = _folderpath.."bomb.animation"

local SHADOW_TEXTURE = Engine.load_texture(_folderpath.."shadow.png")
local SHADOW_ANIMPATH = _folderpath.."shadow.animation"
local SMOKE_TEXTURE = Engine.load_texture(_folderpath.."smoke.png")
local SMOKE_ANIMPATH = _folderpath.."smoke.animation"
local BOOM_TEXTURE = Engine.load_texture(_folderpath.."boom.png")
local BOOM_ANIMPATH = _folderpath.."boom.animation"
local BOOM_AUDIO = Engine.load_audio(_folderpath.."EXE4_273.ogg")

local EFFECT_TEXTURE = Engine.load_texture(_folderpath.."effect.png")
local EFFECT_ANIMPATH = _folderpath.."effect.animation"
local TESTDOT_TEXTURE = Engine.load_texture(_folderpath.."testdot.png")
local TESTDOT_ANIMPATH = _folderpath.."testdot.animation"

--possible states for character
local states = { IDLE = 1, MOVE = 2, WAIT = 3 }
local debug = false

function debug_print(str)
    if debug then
        print("[Kabutank] "..str)
    end
end

---@param self Entity
function package_init(self, character_info)
    -- Required function, main package information
    -- Load extra resources
    local base_animation_path = CHARACTER_ANIMATION
    self:set_texture(CHARACTER_TEXTURE)
    self.animation = self:get_animation()
    self.animation:load(base_animation_path)

    -- Set up character meta
    self:set_name(character_info.name)
    self:set_health(character_info.hp)
    self:set_height(character_info.height)
    self:share_tile(false)
    self:set_explosion_behavior(3, 1, false)
    self:set_offset(0, 0)
    self:set_palette(Engine.load_texture(character_info.palette))
    self.damage = character_info.damage
    self.type = character_info.type
    self.min_tiles = character_info.min_tiles
    self.max_tiles = character_info.max_tiles
    self.animation:set_state("SPAWN")
    self.frame_counter = 0
    self.started = false
    self.idle_frames = 8
    --Select bubble move direction
    self.move_direction = Direction.Up
    self.move_speed = character_info.move_speed
    --self.defense = Battle.DefenseVirusBody.new()
    --self:add_defense_rule(self.defense)
    self.reached_edge = false
    self.has_attacked_once = false

    ---state IDLE
    self.action_idle = function(frame)
        if (frame == self.idle_frames) then
            ---choose move direction
            self.animation:set_state("IDLE")
            self.animation:set_playback(Playback.Loop)
            self.set_state(states.MOVE)
        end
    end

    self.turn = function()
        debug_print("turned")
        self.move_direction = Direction.reverse(self.move_direction)
    end

    --state MOVE
    self.action_move = function(frame)
        if frame == 1 then
            --get target to slide to
            local target_tile = self:get_tile(self.move_direction, 1)
            debug_print("Current tile "..Tiletostring(self:get_tile()))
            debug_print("Target = "..Tiletostring(target_tile))
            debug_print("Direction = "..directiontostring(self.move_direction))
            --if not free, change direction.
            if not is_tile_free_for_movement(target_tile, self) then
                self.turn()
                local turned_tile = self:get_tile(self.move_direction, 1)
                if (is_tile_free_for_movement(turned_tile, self)) then
                    --free to move to the turned tile, otherwise stuck.
                    self.set_state(states.MOVE)
                end
            end
            self:slide(target_tile, frames(self.move_speed), frames(2), ActionOrder.Immediate, nil)

        end
        if frame >= self.move_speed and not self:is_sliding() then
            debug_print(tostring(self.wait_tiles))
            if self.wait_tiles == 0 then
                --once has moved enough tiles, attack
                self.attack()
                self.set_state(states.WAIT)
                self.wait_tiles = math.random(self.min_tiles, self.max_tiles)
            else
                self.wait_tiles = self.wait_tiles - 1
                self.set_state(states.MOVE)
            end
        end
    end

    ---state WAIT
    self.action_wait = function(frame)
        if (frame == 40) then

            self.set_state(states.IDLE)
        end
    end

    --Utility to set the update state, and reset frame counter
    self.set_state = function(state)
        self.state = state
        self.frame_counter = 0
    end

    local actions = { [1] = self.action_idle, [2] = self.action_move, [3] = self.action_wait }

    self.update_func = function()
        self.frame_counter = self.frame_counter + 1
        if not self.started then
            --This runs once the battle is started
            self.current_direction = self:get_facing()
            self.started = true
            self.set_state(states.IDLE)
            self.wait_tiles = math.random(self.min_tiles, self.max_tiles)
        else
            --On every frame, we will call the state action func.
            local action_func = actions[self.state]
            action_func(self.frame_counter)
        end
    end

    --state ATTACK
    self.attack = function()
        self.has_attacked_once = true
        self.animation:set_state("ATTACK")

        self.animation:on_frame(5, function()
            debug_print("attacking")
            Engine.play_audio(CANNON_AUDIO, AudioPriority.Low)
            local tiles_ahead = 3
            local frames_in_air = 40
            local toss_height = 70
            local field = self:get_field()
            local facing = self:get_facing()
            local target_tile = find_target(self):get_tile()
            if not target_tile then
                return
            end

            toss_spell(self, toss_height, frames_in_air, target_tile)
            toss_spell_shadow(self, toss_height, frames_in_air, target_tile)
            --toss_spell_hitbox(self, toss_height, frames_in_air, target_tile)
            self.set_state(states.WAIT)
        end)
    end

    function Tiletostring(tile)
        return "Tile: ["..tostring(tile:x())..","..tostring(tile:y()).."]"
    end

    function directiontostring(dir)

        if dir == Direction.Up then return "Up"
        elseif dir == Direction.Down then return "Down"
        end
    end

end

---Checks if the tile in 2 given directions is free and returns that direction
function get_free_direction(tile, direction1, direction2)
    if (not tile:get_tile(direction1, 1):is_edge()) then
        return direction1
    else return direction2

    end
end

function is_tile_free_for_movement(tile, character)
    --Basic check to see if a tile is suitable for a chracter of a team to move to

    if tile:get_team() ~= character:get_team() or tile:is_reserved({ character:get_id(), character._reserver }) then
        return false
    end
    if (tile:is_edge() or not tile:is_walkable()) then
        return false
    end
    local occupants = tile:find_entities(function(ent)
        if (Battle.Character.from(ent) ~= nil or Battle.Obstacle.from(ent) ~= nil) then
            return true
        else
            return false
        end
    end)
    if #occupants == 1 and occupants[1]:get_id() == character:get_id() then
        return true
    end
    if #occupants > 0 then
        return false
    end

    return true
end

--Find a target character
function find_target(self)
    local field = self:get_field()
    local team = self:get_team()
    local target_list = field:find_characters(function(other_character)
        return other_character:get_team() ~= team
    end)
    if #target_list == 0 then
        return
    end
    local target_character = target_list[1]
    return target_character
end

function toss_spell(tosser, toss_height, frames_in_air, target_tile)
    local team = tosser:get_team()
    local field = tosser:get_field()
    local facing = tosser:get_facing()

    local starting_height = -90
    local start_tile = tosser:get_current_tile()
    local spell = Battle.Spell.new(team)
    spell:set_facing(facing)
    spell:never_flip(true)
    local spell_animation = spell:get_animation()
    spell_animation:load(BOMB_ANIMPATH)
    spell_animation:set_state("0")
    if tosser:get_height() > 1 then
        starting_height = -(tosser:get_height()*2)
    end

    spell.jump_started = false
    spell.starting_y_offset = starting_height
    spell.starting_x_offset = 20
    if facing == Direction.Left then
        spell.starting_x_offset = -20
    end
    spell.y_offset = spell.starting_y_offset
    spell.x_offset = spell.starting_x_offset
    local sprite = spell:sprite()
    sprite:set_texture(BOMB_TEXTURE)
    spell:set_offset(spell.x_offset,spell.y_offset)

    spell.update_func = function(self)
        if not spell.jump_started then
            self:jump(target_tile, toss_height, frames(frames_in_air), frames(frames_in_air), ActionOrder.Voluntary)
            self.jump_started = true
        end
        if self.y_offset < 0 then
            self.y_offset = self.y_offset + math.abs(self.starting_y_offset/frames_in_air)
            self.x_offset = self.x_offset - math.abs(self.starting_x_offset/120)
            self:set_offset(self.x_offset,self.y_offset)
            --self:set_offset(0,self.y_offset)
        else
            on_landing(tosser, target_tile)
            self:delete()
        end
    end
    spell.can_move_to_func = function(tile)
        return true
    end
    field:spawn(spell, start_tile)
end

function toss_spell_shadow(tosser, toss_height, frames_in_air, target_tile)
    local team = tosser:get_team()
    local field = tosser:get_field()
    local facing = tosser:get_facing()

    local starting_height = -90
    local start_tile = tosser:get_current_tile()
    local spell = Battle.Spell.new(team)
    spell:set_facing(facing)
    spell:never_flip(true)
    local spell_animation = spell:get_animation()
    spell_animation:load(SHADOW_ANIMPATH)
    spell_animation:set_state("0")
    if tosser:get_height() > 1 then
        starting_height = -(tosser:get_height())
    end

    spell.slide_started = false

    spell.jump_started = false
    spell.starting_y_offset = starting_height
    spell.starting_x_offset = 20
    if facing == Direction.Left then
        spell.starting_x_offset = -20
    end
    spell.y_offset = spell.starting_y_offset
    spell.x_offset = spell.starting_x_offset
    local sprite = spell:sprite()
    sprite:set_texture(SHADOW_TEXTURE)
    spell:set_offset(spell.x_offset,0)

    spell.update_func = function(self)
        if not spell.jump_started then
            self:jump(target_tile, 0, frames(frames_in_air), frames(frames_in_air), ActionOrder.Voluntary)
            self.jump_started = true
        end
        if self.y_offset < 0 then
            self.y_offset = self.y_offset + math.abs(self.starting_y_offset/frames_in_air)
            self.x_offset = self.x_offset - math.abs(self.starting_x_offset/120)
            self:set_offset(self.x_offset,0)
            --self:set_offset(0,0)
        else
            self:delete()
        end
    end
    spell.can_move_to_func = function(tile)
        return true
    end
    field:spawn(spell, start_tile)
end

function toss_spell_hitbox2(tosser, tile)
    local team = tosser:get_team()
    local field = tosser:get_field()
    local facing = tosser:get_facing()

    local spell = Battle.Spell.new(team)
    spell:set_hit_props(
        HitProps.new(
            tosser.damage,
            Hit.Impact | Hit.Flinch | Hit.Flash,
            Element.None,
            tosser:get_id(),
            Drag.None
        )
    )
    spell:set_facing(facing)
    spell:never_flip(true)
    local spell_animation = spell:get_animation()
    spell_animation:load(TESTDOT_ANIMPATH)
    spell_animation:set_state("0")
    spell_animation:on_complete(function()
		spell:erase()
	end)
    local sprite = spell:sprite()
    sprite:set_texture(TESTDOT_TEXTURE)
    sprite:hide()

    spell.update_func = function(self)
        self:get_current_tile():attack_entities(self)
    end
    spell.attack_func = function(self, ent)
        if Battle.Obstacle.from(ent) == nil then
            --[[
            if Battle.Player.from(user) ~= nil then
                Engine.play_audio(AUDIO_DAMAGE, AudioPriority.Low)
            end
            ]]
        else
            Engine.play_audio(AUDIO_DAMAGE_OBS, AudioPriority.Low)
        end
    end
    spell.can_move_to_func = function(tile)
        return true
    end
    field:spawn(spell, tile)
end

function on_landing(user, target_tile)
    local team = user:get_team()
    local field = user:get_field()
    local facing = user:get_facing()

    if target_tile:is_walkable() then
        toss_spell_hitbox2(user, target_tile)
        create_effect(facing, BOOM_TEXTURE, BOOM_ANIMPATH, "0", 0.0, -((3.0)*2), true, -9, field, target_tile)
        Engine.play_audio(BOOM_AUDIO, AudioPriority.Low)
        if user.type == 2 or user.type == 3 or user.type == 4 then
            if not target_tile:get_tile(Direction.Up, 1):is_edge() then
                toss_spell_hitbox2(user, target_tile:get_tile(Direction.Up, 1))
                create_effect(facing, BOOM_TEXTURE, BOOM_ANIMPATH, "0", 0.0, -((3.0)*2), true, -9, field, target_tile:get_tile(Direction.Up, 1))
                Engine.play_audio(BOOM_AUDIO, AudioPriority.Low)
            end
            if not target_tile:get_tile(Direction.Down, 1):is_edge() then
                toss_spell_hitbox2(user, target_tile:get_tile(Direction.Down, 1))
                create_effect(facing, BOOM_TEXTURE, BOOM_ANIMPATH, "0", 0.0, -((3.0)*2), true, -9, field, target_tile:get_tile(Direction.Down, 1))
                Engine.play_audio(BOOM_AUDIO, AudioPriority.Low)
            end
            if user.type == 3 or user.type == 4 then
                if not target_tile:get_tile(Direction.Left, 1):is_edge() then
                    toss_spell_hitbox2(user, target_tile:get_tile(Direction.Left, 1))
                    create_effect(facing, BOOM_TEXTURE, BOOM_ANIMPATH, "0", 0.0, -((3.0)*2), true, -9, field, target_tile:get_tile(Direction.Left, 1))
                    Engine.play_audio(BOOM_AUDIO, AudioPriority.Low)
                end
                if not target_tile:get_tile(Direction.Right, 1):is_edge() then
                    toss_spell_hitbox2(user, target_tile:get_tile(Direction.Right, 1))
                    create_effect(facing, BOOM_TEXTURE, BOOM_ANIMPATH, "0", 0.0, -((3.0)*2), true, -9, field, target_tile:get_tile(Direction.Right, 1))
                    Engine.play_audio(BOOM_AUDIO, AudioPriority.Low)
                end
                if user.type == 4 then
                    if not target_tile:get_tile(Direction.UpLeft, 1):is_edge() then
                        toss_spell_hitbox2(user, target_tile:get_tile(Direction.UpLeft, 1))
                        create_effect(facing, BOOM_TEXTURE, BOOM_ANIMPATH, "0", 0.0, -((3.0)*2), true, -9, field, target_tile:get_tile(Direction.UpLeft, 1))
                        Engine.play_audio(BOOM_AUDIO, AudioPriority.Low)
                    end
                    if not target_tile:get_tile(Direction.UpRight, 1):is_edge() then
                        toss_spell_hitbox2(user, target_tile:get_tile(Direction.UpRight, 1))
                        create_effect(facing, BOOM_TEXTURE, BOOM_ANIMPATH, "0", 0.0, -((3.0)*2), true, -9, field, target_tile:get_tile(Direction.UpRight, 1))
                        Engine.play_audio(BOOM_AUDIO, AudioPriority.Low)
                    end
                    if not target_tile:get_tile(Direction.DownLeft, 1):is_edge() then
                        toss_spell_hitbox2(user, target_tile:get_tile(Direction.DownLeft, 1))
                        create_effect(facing, BOOM_TEXTURE, BOOM_ANIMPATH, "0", 0.0, -((3.0)*2), true, -9, field, target_tile:get_tile(Direction.DownLeft, 1))
                        Engine.play_audio(BOOM_AUDIO, AudioPriority.Low)
                    end
                    if not target_tile:get_tile(Direction.DownRight, 1):is_edge() then
                        toss_spell_hitbox2(user, target_tile:get_tile(Direction.DownRight, 1))
                        create_effect(facing, BOOM_TEXTURE, BOOM_ANIMPATH, "0", 0.0, -((3.0)*2), true, -9, field, target_tile:get_tile(Direction.DownRight, 1))
                        Engine.play_audio(BOOM_AUDIO, AudioPriority.Low)
                    end
                end
            end
        end
    else
        create_effect(facing, SMOKE_TEXTURE, SMOKE_ANIMPATH, "0", 0.0, -((3.0)*2), true, -9, field, target_tile)
    end
end

function create_effect(effect_facing, effect_texture, effect_animpath, effect_state, offset_x, offset_y, flip, offset_layer, field, tile)
    local hitfx = Battle.Artifact.new()
    hitfx:set_facing(effect_facing)
    hitfx:set_texture(effect_texture, true)
    hitfx:set_offset(offset_x, offset_y)
    hitfx:never_flip(flip)
    local hitfx_sprite = hitfx:sprite()
    hitfx_sprite:set_layer(offset_layer)
    local hitfx_anim = hitfx:get_animation()
	hitfx_anim:load(effect_animpath)
	hitfx_anim:set_state(effect_state)
	hitfx_anim:refresh(hitfx_sprite)
    hitfx_anim:on_complete(function()
        hitfx:erase()
    end)
    field:spawn(hitfx, tile)
    
    return hitfx
end

return package_init
