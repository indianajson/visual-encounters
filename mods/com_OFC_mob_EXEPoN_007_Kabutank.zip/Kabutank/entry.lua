local shared_package_init = include("../shared/entry.lua")

function package_init(character)
    local character_info = {
        name = "Kabutank",
        hp = 50,
        damage = 10,
        type = 3,
        palette = _folderpath.."battle_v1.palette.png",
        height = 44,
        frames_between_actions = 34,
        move_speed = 50,
        min_tiles = 2,
        max_tiles = 4,
    }
    if character:get_rank() == Rank.V1 then
        --character_info.name = "Kabutank1"
        character_info.type = 1
    elseif character:get_rank() == Rank.V2 then
        character_info.hp = 80
        character_info.damage = 40
        character_info.type = 2
        character_info.palette = _folderpath.."battle_v2.palette.png"
        character_info.move_speed = 40
    elseif character:get_rank() == Rank.V3 then
        character_info.hp = 140
        character_info.damage = 60
        character_info.palette = _folderpath.."battle_v3.palette.png"
        character_info.move_speed = 30
        character_info.min_tiles = 1
        character_info.max_tiles = 3
    elseif character:get_rank() == Rank.SP then
        character_info.hp = 180
        character_info.damage = 80
        character_info.palette = _folderpath.."battle_sp.palette.png"
        character_info.move_speed = 20
        character_info.min_tiles = 1
        character_info.max_tiles = 3
    end
    shared_package_init(character, character_info)
end
