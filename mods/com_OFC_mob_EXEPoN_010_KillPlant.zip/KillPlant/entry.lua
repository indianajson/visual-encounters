local shared_package_init = include("../shared/entry.lua")

function package_init(character)
    local character_info = {
        name = "KillPlant",
        hp = 100,
        damage = 30,
        palette = _folderpath.."V1.png",
        frames_between_actions = 200,
        towers = 3,
    }
    if character:get_rank() == Rank.SP then
        character_info.hp = 190
        character_info.damage = 150
        character_info.palette = _folderpath.."SP.png"
        character_info.frames_between_actions = 140
        character_info.towers = 6
    end
    shared_package_init(character, character_info)
end
