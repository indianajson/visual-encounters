local shared_package_init = include("../shared/entry.lua")

function package_init(character)
    local character_info = {
        name = "KillFlowr",
        hp = 160,
        damage = 70,
        palette = _folderpath.."palette.png",
        frames_between_actions = 160,
        towers = 5,
    }
    shared_package_init(character, character_info)
end
