local shared_package_init = include("../shared/entry.lua")

function package_init(character)
    local character_info = {
        name = "KillWeed",
        hp = 130,
        damage = 50,
        palette = _folderpath.."palette.png",
        frames_between_actions = 180,
        towers = 4,
    }
    shared_package_init(character, character_info)
end
