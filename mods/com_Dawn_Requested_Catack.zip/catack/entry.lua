local noop = function () end
local animation_path = _modpath.."Catack Virus.animation"
local explosion_animation_path = _modpath.."Explosions.animation"
local explosion_texture = Engine.load_texture(_modpath.."Explosions.png")

local on_spell_sound = Engine.load_audio(_modpath.."boom.ogg")
local on_roll_sound = Engine.load_audio(_modpath.."move.ogg")
local on_windup_sound = Engine.load_audio(_modpath.."shot.ogg")

local create_boom = function(catack)
  local spell = Battle.Spell.new(catack:get_team())
	spell:set_facing(catack:get_facing())
	spell.slide_started = false
	local direction = spell:get_facing()
  spell:set_hit_props(
      HitProps.new(
          catack._attack, 
          Hit.Impact | Hit.Drag | Hit.Flinch | Hit.Flash, 
          Element.None,
          catack:get_context(),
          Drag.new(direction, 1)
      )
  )
  spell.can_slide = true
	spell.update_func = function(self, dt) 
      self:get_current_tile():attack_entities(self)      
      if self:is_sliding() == false and self.can_slide then
          if self:get_tile():x() == 1 or self:get_tile():x() == 6 then
            self.can_slide = false
            if #self:get_tile():find_entities(catack.tile_query) == 0 then
              self:teleport(catack:get_field():tile_at(self:get_tile():x(), 2), ActionOrder.Immediate, function() end)
              self:set_texture(explosion_texture)
              self:sprite():set_layer(-2)
              local anim = self:get_animation()
              anim:load(explosion_animation_path)
              anim:set_state("EDGE_EXPLOSION")
              if self:get_facing() == Direction.Left then
                self:set_offset(-40.0, -20.0)
              else
                self:set_offset(40.0, -20.0)
              end
              anim:refresh(self:sprite())
              local upper_hitbox = Battle.SharedHitbox.new(self, 0.1)
              upper_hitbox:set_hit_props(self:copy_hit_props())
              local lower_hitbox = Battle.SharedHitbox.new(self, 0.1)
              lower_hitbox:set_hit_props(self:copy_hit_props())
              catack:get_field():spawn(upper_hitbox, self:get_tile(Direction.Up, 1))
              catack:get_field():spawn(lower_hitbox, self:get_tile(Direction.Down, 1))
              anim:on_complete(function()
                self:delete()
              end)
            end
          end
          if self:get_current_tile():is_edge() and self.slide_started then 
              self:delete()
          end 
          local dest = self:get_tile(direction, 1)
          local ref = self
          if self.can_slide then
            self:slide(dest, frames(1), frames(0), ActionOrder.Immediate, function()
              ref.slide_started = true 
            end)
          end
      end
  end
	spell.collision_func = function(self, other)
    self.can_slide = false
    spell:set_offset(0.0, 0.0)
    self:set_texture(explosion_texture)
    self:sprite():set_layer(-2)
    local anim = self:get_animation()
    anim:load(explosion_animation_path)
    anim:set_state("CLOUDS")
    anim:refresh(self:sprite())
    anim:on_complete(function()
      self:delete()
    end)
	end
  spell.attack_func = function(self, other)
    self.can_slide = false
  end

  spell.delete_func = function(self)
    self:erase()
  end

  spell.can_move_to_func = function(tile)
      return true
  end

	Engine.play_audio(on_spell_sound, AudioPriority.Low)
	return spell
end

local update_func = function(catack, dt)
  if catack._current_idle_time <= 0 then
    if catack._can_move then
      catack._destination_tile = catack:get_tile(catack:get_facing(), 1)
      if catack._do_once then
        catack._do_once = false
        Engine.play_audio(on_roll_sound, AudioPriority.Low)
        if catack._destination_tile:get_team() ~= catack:get_team() then
          catack._destination_tile:set_team(catack:get_team(), false)
        end
        local anim = catack:get_animation()
        anim:set_state(catack._move_state)
        anim:set_playback(Playback.Loop)
      end
      if catack._destination_tile:x() == 1 or catack._destination_tile:x() == 6 or #catack._destination_tile:find_entities(catack.tile_query) > 0 or catack._continue_offsetting then
        if catack:get_facing() == Direction.Left then
          if catack:get_offset().x <= -40 or catack._offsetting_reverse then
            catack._offsetting_reverse = true
            catack:set_offset(catack:get_offset().x + catack._offset_speed, 0.0)
            if catack:get_offset().x == 0 then
              catack._offsetting_reverse = false
              catack._continue_offsetting = false
              catack._windup_state = "REVERSE_WINDUP"
              catack:set_offset(0.0, 0.0)
            end
          elseif catack:get_offset().x >= -40 and not catack._offsetting_reverse then
            catack._continue_offsetting = true            
            catack:set_offset(catack:get_offset().x - catack._offset_speed, 0.0)
            if catack:get_offset().x == -40 then
              local hitbox = Battle.Hitbox.new(catack:get_team())
              hitbox:set_hit_props(
                HitProps.new(
                  10,
                  Hit.Impact | Hit.Flinch, 
                  Element.None,
                  catack:get_context(),
                  Drag.None
                )
              )
              catack:get_field():spawn(hitbox, catack._destination_tile)
            end
          end
        elseif catack:get_facing() == Direction.Right then
          if catack:get_offset().x >= 40 or catack._offsetting_reverse then
            catack._offsetting_reverse = true
            catack:set_offset(catack:get_offset().x - catack._offset_speed, 0.0)
            if catack:get_offset().x == 0 then
              catack._offsetting_reverse = false
              catack._continue_offsetting = false
              catack._windup_state = "REVERSE_WINDUP"
              catack:set_offset(0.0, 0.0)
            end
          elseif catack:get_offset().x < 40 and not catack._offsetting_reverse then
            catack._continue_offsetting = true
            catack:set_offset(catack:get_offset().x + catack._offset_speed, 0.0)
            if catack:get_offset().x == -40 then
              local hitbox = Battle.Hitbox.new(catack:get_team())
              hitbox:set_hit_props(
                HitProps.new(
                  10,
                  Hit.Impact | Hit.Flinch, 
                  Element.None,
                  catack:get_context(),
                  Drag.None
                )
              )
              catack:get_field():spawn(hitbox, catack._destination_tile)
            end
          end
        end
        if not catack._continue_offsetting and catack:get_offset().x == 0 then
          catack._offsetting_forward = false
          catack._offsetting_reverse = false
          catack._destination_tile = catack:get_tile()
        end
      else
        catack:slide(catack._destination_tile, frames(catack._slide_speed), frames(10), ActionOrder.Voluntary, function() end)
      end
      if not catack._continue_offsetting then
        catack._can_move = false
        catack._can_attack = true
        catack._do_once = true
      end
    end
    if catack._can_attack then
      if catack:get_tile() == catack._destination_tile then
        if catack._do_once then
          local anim = catack:get_animation()
          Engine.play_audio(on_windup_sound, AudioPriority.Low)
          anim:set_state(catack._windup_state)
          anim:set_playback(Playback.Once)
          anim:on_complete(function()
            anim:set_state(catack._shoot_state)
            anim:set_playback(Playback.Once)
            anim:on_frame(3, function()
              local boom = create_boom(catack)
              catack:get_field():spawn(boom, catack:get_tile(catack:get_facing(), 1))
              anim:set_state(catack._hide_state)
              anim:set_playback(Playback.Once)
              anim:on_complete(function()
                anim:set_state(catack._idle_state)
                anim:set_playback(Playback.Loop)
                catack._can_move = true
                catack._can_attack = false
                catack._do_once = true
                catack._current_idle_time = catack._idle_between_strikes
                catack._windup_state = "ATTACK_WINDUP"
              end)
            end)
          end)
          catack._do_once = false
        end
      end
    end
  else
    catack._current_idle_time = catack._current_idle_time - 1
  end
end

function package_init(catack, ezencounters_data)
    -- EZENCOUNTERS MAX-HP SUPPORT v11 --
    do
        local payload = ezencounters_data
        if type(payload) == "table" then
            local ids = {"com.Dawn.Requested.Enemy.Catack"}
            local aliases = {["Catack"]=true}
            local requested = nil
            local conflict = false
            local maxima = payload.__ezencounters_hp_max_by_package
            if type(maxima) == "table" then
                for _, id in ipairs(ids) do
                    local value = tonumber(maxima[id])
                    if value ~= nil and value > 0 and value == value and value ~= math.huge then
                        if requested ~= nil and requested ~= value then conflict = true end
                        requested = value
                    end
                end
            end
            -- Some engine builds pass an independent copy of encounter data
            -- to the Character package. Resolve from original enemy entries
            -- as well, rather than depending on a mutation in package_build.
            if requested == nil and type(payload.enemies) == "table" then
                for _, enemy in ipairs(payload.enemies) do
                    if type(enemy) == "table" and aliases[enemy.name] then
                        local value = tonumber(enemy.max_hp)
                        if value == nil and #payload.enemies == 1 then
                            value = tonumber(payload.max_hp)
                        end
                        if value ~= nil and value > 0 and value == value and value ~= math.huge then
                            if requested ~= nil and requested ~= value then conflict = true end
                            requested = value
                        end
                    end
                end
            end
            if not conflict and requested ~= nil and requested == math.floor(requested) then
                print("[ezencounters hp] INITIAL MAX HP", ids[1], requested)
                catack:set_health(requested)
            end
        end
    end

  catack._cannon_sfx = Engine.load_audio(_modpath.."cannon.ogg")

  -- private variables
  catack._idle_state = "IDLE"
  catack._move_state = "MOVE"
  catack._windup_state = "ATTACK_WINDUP"
  catack._shoot_state = "SHOOT"
  catack._hide_state = "ATTACK_HIDE"
  catack._attack = 0
  catack._idle_between_strikes = 0
  catack._current_idle_time = 0
  catack._can_move = true
  catack._can_attack = false
  catack._do_once = true
  catack._offset_speed = 0
  catack._slide_speed = 0
  catack._destination_tile = nil
  catack._offsetting_forward = false
  catack._offsetting_reverse = false
  catack._continue_offsetting = false
  catack.tile_query = function(ent)
    return ent and Battle.Character.from(ent) ~= nil and not ent:is_deleted() and ent:get_id() ~= catack:get_id() or ent and Battle.Obstacle.from(ent) ~= nil and not ent:is_deleted()
  end

  -- meta
  catack:set_name("Catack")
  catack:set_height(36)

  --base color
  catack:set_texture(Engine.load_texture(_modpath.."Catack Virus.greyscaled.png"), false)
  local rank = catack:get_rank()

  if rank == Rank.V1 then
    catack.__ezhp_native_max_hp = (130)
    catack._idle_between_strikes = 180
    catack._current_idle_time = 180
    catack._attack = 70
    catack._offset_speed = 1
    catack._slide_speed = 60
    catack:set_palette(Engine.load_texture(_modpath.."catack_v1.palette.png"))
  elseif rank == Rank.V2 then
    catack.__ezhp_native_max_hp = (160)
    catack._idle_between_strikes = 150
    catack._current_idle_time = 150
    catack._attack = 100
    catack._offset_speed = 1
    catack._slide_speed = 60
    catack:set_palette(Engine.load_texture(_modpath.."catack_v2.palette.png"))
  elseif rank == Rank.V3 then
    catack.__ezhp_native_max_hp = (220)
    catack._idle_between_strikes = 120
    catack._current_idle_time = 120
    catack._attack = 150
    catack._offset_speed = 1
    catack._slide_speed = 60
    catack:set_palette(Engine.load_texture(_modpath.."catack_v3.palette.png"))
  elseif rank == Rank.SP then
    catack.__ezhp_native_max_hp = (300)
    catack._idle_between_strikes = 60
    catack._current_idle_time = 60
    catack._attack = 200
    catack._offset_speed = 1
    catack._slide_speed = 60
    catack:set_palette(Engine.load_texture(_modpath.."catack_sp.palette.png"))
  end

  local anim = catack:get_animation()
  anim:load(animation_path)
  anim:set_state(catack._idle_state)
  anim:set_playback(Playback.Loop)
  -- setup defense rules
  catack.defense = Battle.DefenseVirusBody.new() -- lua owns this need to keep it alive
  catack:add_defense_rule(catack.defense)

  -- setup event hanlders
  catack.update_func = update_func
  catack.battle_start_func = noop
  catack.battle_end_func = noop
  catack.on_spawn_func = noop
  catack.delete_func = noop
end

-- EZEncounters deferred native HP adapter.
-- The native fallback must not lock max HP in on_spawn_func: some client
-- spawners run on_spawn before their encounter mutate callback.
-- Battle start occurs after encounter mutations and before the first update.
local __ezhp_original_package_init = package_init
package_init = function(character, ...)
    __ezhp_original_package_init(character, ...)
    local __ezhp_original_battle_start = character.battle_start_func
    character.battle_start_func = function(self, ...)
        if self:get_max_health() == 0 then
            local native = tonumber(self.__ezhp_native_max_hp)
            if not native or native ~= native or native <= 0 or native == math.huge then native = 1 end
            native = math.max(1, math.floor(native))
            self:set_health(native)
            print('[EZHP][CLIENT][NATIVE_FALLBACK_BATTLE_START]', tostring(self:get_name()), native,
                'actual', self:get_max_health())
        end
        if __ezhp_original_battle_start then return __ezhp_original_battle_start(self, ...) end
    end
end
