local shared_package_init = include("../shared/entry.lua")
function package_init(character)
    local character_info = {
        name = "Bladia5",
        hp = 80,
        attack = 200,
        height = 70,
        palette = _folderpath.."bladia.png"
    }
    print('[EZDBG][CLIENT][Bladia][VARIANT_INIT]', '5', 'max_hp', 80)
    shared_package_init(character, character_info)
end
