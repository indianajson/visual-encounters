local shared_package_init = include("../shared/entry.lua")
function package_init(character)
    local character_info = {
        name = "Bladia6",
        hp = 240,
        attack = 250,
        height = 70,
        palette = _folderpath.."bladia.png"
    }
    print('[EZDBG][CLIENT][Bladia][VARIANT_INIT]', '6', 'max_hp', 240)
    shared_package_init(character, character_info)
end
