local shared_package_init = include("../shared/entry.lua")
function package_init(character)
    local character_info = {
        name = "Bladia",
        hp = 1200,
        attack = 50,
        height = 70,
        palette = _folderpath.."bladia.png"
    }
    print('[EZDBG][CLIENT][Bladia][VARIANT_INIT]', '1', 'max_hp', 1200)
    shared_package_init(character, character_info)
end
