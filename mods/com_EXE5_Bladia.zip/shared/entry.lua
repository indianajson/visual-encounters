local function create_smoke(self, anim_state)
    local smoke = Battle.Spell.new(self:get_team())
    smoke:set_texture(Engine.load_texture(_folderpath .. "teleport.png"), true)
    smoke:sprite():set_layer(-2)
    local animation = smoke:get_animation()
    animation:load(_folderpath .. "teleport.animation")
    animation:set_state(anim_state)
    animation:refresh(smoke:sprite())
    animation:on_complete(function()
        smoke:erase()
    end)
    return smoke
end

local function spawn_attack_visual(team, tile, field, facing)
    local visual = Battle.Spell.new(team)
    visual:set_facing(facing)
    visual:set_texture(Engine.load_texture(_folderpath .. "hit_effect.png"))
    local anim = visual:get_animation()
    anim:load(_folderpath .. "hit_effect.animation")
    anim:set_state("DEFAULT")
    anim:refresh(visual:sprite())
    visual:sprite():set_layer(-3)
    anim:on_complete(function()
        visual:erase()
    end)
    field:spawn(visual, tile)
end

local function increment_pattern(self)
    self.guard_index = 1
    self.can_block = true
    self.should_block = false
    self.pattern_index = self.pattern_index + 1
    if self.pattern_index > #self.pattern then self.pattern_index = 1 end
    self.pattern_cooldown_index = self.pattern_cooldown_index + 1
    if self.pattern_cooldown_index > #self.pattern_cooldown_list then self.pattern_cooldown_index = 1 end
    self.anim_once = true
    if self.is_guarding or self.defense ~= nil then
        self.is_guarding = false
        self:remove_defense_rule(self.defense)
    end
    self.pattern_cooldown = self.pattern_cooldown_list[self.pattern_cooldown_index]
end

local find_best_target
local face_opponent

local function warp(self, anim_state)
    local field = self:get_field()
    local current = self:get_current_tile()
    if not field or not current then
        increment_pattern(self)
        return
    end

    local midpoint = field:width() / 2
    local current_on_left = current:x() <= midpoint
    local same_team, opposite_side, same_side, any_available = {}, {}, {}, {}
    for x = 1, field:width() do
        for y = 1, field:height() do
            local tile = field:tile_at(x, y)
            if tile and tile ~= current and self.can_move_to_func(tile) then
                any_available[#any_available + 1] = tile
                if tile:get_team() == self:get_team() then
                    same_team[#same_team + 1] = tile
                end
                if (x <= midpoint) ~= current_on_left then
                    opposite_side[#opposite_side + 1] = tile
                else
                    same_side[#same_side + 1] = tile
                end
            end
        end
    end

    -- Occasionally teleport to the other side of the FIELD, not merely a
    -- different row. A cross-side teleport never changes the character's
    -- team or the destination tile's ownership. It may land on opposing
    -- territory by design; regular warps prefer own-team panels.
    local try_swap = math.random(1, 100) <= 25
    local choices
    if try_swap and #opposite_side > 0 then
        choices = opposite_side
    elseif #same_team > 0 then
        choices = same_team
    elseif #same_side > 0 then
        choices = same_side
    else
        choices = any_available
    end
    if #choices == 0 then
        print('[EZDBG][CLIENT][Bladia][WARP_SKIPPED] no open destination')
        increment_pattern(self)
        return
    end
    self.warp_tile = choices[math.random(1, #choices)]
    local target_tile = self.warp_tile
    print('[EZDBG][CLIENT][Bladia][WARP_BEGIN]', current:x(), current:y(),
        'to', target_tile:x(), target_tile:y(), 'cross_side',
        tostring((target_tile:x() <= midpoint) ~= current_on_left),
        'destination_team', tostring(target_tile:get_team()),
        'own_team', tostring(self:get_team()))

    field:spawn(create_smoke(self, anim_state), current)
    local c = Battle.Component.new(self, Lifetimes.Battlestep)
    c.duration = 60
    c.target_tile = target_tile
    c.owner = self
    c.smoke = create_smoke(self, 'BIG_TELEPORT_TO')
    c.update_func = function(component, dt)
        local owner = component.owner
        if owner:get_health() <= 0 then component:eject() return end
        component.duration = component.duration - 1
        if component.duration == 10 then
            local owner_anim = owner:get_animation()
            owner_anim:set_state('IDLE')
            owner_anim:refresh(owner:sprite())
            owner_anim:set_playback(Playback.Loop)
        end
        if component.duration <= 0 then
            component.target_tile:add_entity(owner)
            face_opponent(owner)
            field:spawn(component.smoke, component.target_tile)
            increment_pattern(owner)
            print('[EZDBG][CLIENT][Bladia][WARP_END]',
                component.target_tile:x(), component.target_tile:y(),
                'facing', tostring(owner:get_facing()))
            component:eject()
        end
    end
    c.scene_inject_func = function(component)
        local owner = component.owner
        local current_tile = owner:get_current_tile()
        if current_tile then
            local id = component:get_owner():get_id()
            current_tile:remove_entity_by_id(id)
            component.target_tile:reserve_entity_by_id(id)
        end
    end
    self:register_component(c)
end

local function spawn_attack(self)
    face_opponent(self)
    if self.tile ~= nil and self.panels ~= nil then
        local spell = Battle.Spell.new(self:get_team())
        spell:set_facing(self:get_facing())
        spell:set_hit_props(
            HitProps.new(
                self.attack,
                Hit.Impact | Hit.Flinch | Hit.Flash,
                Element.None,
                self:get_context(),
                Drag.None
            )
        )
        spell.duration = 4
        for i = 1, #self.panels, 1 do
            self.panels[i]:set_state(TileState.Cracked)
        end
        spell.update_func = function()
            spell.duration = spell.duration - 1
            if spell.duration == 0 then spell:delete() return end
            for i = 1, #self.panels, 1 do
                self.panels[i]:highlight(Highlight.Flash)
                self.panels[i]:attack_entities(spell)
            end
        end
        spell.collision_func = function(self)
            self:delete()
        end
        spell.delete_func = function()
            for i = 1, #self.panels, 1 do
                self.panels[i]:highlight(Highlight.None)
            end
            spell:erase()
            self.tile = nil
            self.panels = nil
        end
        local field = self:get_field()
        field:spawn(spell, self.tile)
        Engine.play_audio(Engine.load_audio(_folderpath .. "sounds/attack.ogg", true), AudioPriority.High)
        spawn_attack_visual(self:get_team(), self.tile, field, self:get_facing())
    end
end

local function spawn_attack_highlight(self)
    face_opponent(self)
    --Don't do anything if the target is dead.
    if not self.target or self.target and self.target:is_deleted() then return end
    --Get the tile to highlight.
    local tile = self.target:get_tile()
    --Adjust if it's not the middle tile.
    if tile:y() > 2 then
        tile = tile:get_tile(Direction.Up, 1)
    elseif tile:y() < 2 then
        tile = tile:get_tile(Direction.Down, 1)
    end
    --Now grab all three once we guarantee we're in the middle.
    local panels = { tile, tile:get_tile(Direction.Up, 1), tile:get_tile(Direction.Down, 1) }
    local spell = Battle.Spell.new(self:get_team())
    spell.timer = 48
    spell.update_func = function(self, dt)
        self.timer = self.timer - 1
        if self.timer == 0 then self:erase() return end
        for i = 1, #panels, 1 do
            panels[i]:highlight(Highlight.Flash)
        end
    end
    self.target:get_field():spawn(spell, tile)
    self.tile = tile
    self.panels = panels
end

find_best_target = function(self)
    local origin = self:get_current_tile()
    local field = self:get_field()
    if not field then return nil end
    local best, best_hp, best_dist = nil, math.huge, math.huge
    local opponents = field:find_characters(function(other)
        return other:get_team() ~= self:get_team()
            and other:get_health() > 0 and not other:is_deleted()
    end)
    for _, other in ipairs(opponents) do
        local tile = other:get_current_tile()
        if tile then
            local dist = origin and
                (math.abs(tile:x() - origin:x()) + math.abs(tile:y() - origin:y()))
                or math.huge
            local hp = other:get_health()
            if hp < best_hp or (hp == best_hp and dist < best_dist) then
                best, best_hp, best_dist = other, hp, dist
            end
        end
    end
    return best
end

-- Determine lateral facing from the target's current tile rather than
-- assuming the enemy is always on the right half of the battle field.
face_opponent = function(self)
    local current = self:get_current_tile()
    if not current then return end
    local target = self.target
    if not target or target:get_health() <= 0 or target:is_deleted() then
        target = find_best_target(self)
    end
    local tile = target and target:get_current_tile()
    if tile then
        if tile:x() > current:x() then self:set_facing(Direction.Right)
        elseif tile:x() < current:x() then self:set_facing(Direction.Left) end
    end
end

function package_init(self, character_info)
    self:set_texture(Engine.load_texture(_folderpath .. "bladia.greyscaled.png"))
    self:set_palette(Engine.load_texture(character_info.palette))
    local anim = self:get_animation()
    anim:load(_folderpath .. "bladia.animation")
    anim:set_state("SPAWN")
    anim:refresh(self:sprite())
    -- First set_health call fixes maximum HP in this client. Each rank/HP
    -- variant passes its own value here; later encounter mutation only sets
    -- starting HP and MUST NOT attempt to raise the maximum.
    local initial_max_hp = tonumber(character_info.hp)
    self.__ezhp_native_max_hp = (initial_max_hp)
    print('[EZDBG][CLIENT][Bladia][INIT_HP]', character_info.name,
        'configured', tostring(initial_max_hp),
        'max', tostring(self:get_max_health()),
        'current', tostring(self:get_health()),
        'team', tostring(self:get_team()),
        'facing', tostring(self:get_facing()))
    self.attack = character_info.attack
    self:set_name(character_info.name)
    local field = nil
    self.battle_start_func = function(self)
        field = self:get_field()
        anim:set_state("IDLE")
        anim:refresh(self:sprite())
        anim:set_playback(Playback.Loop)
    end
    self.tile = nil
    self.target = nil
    self.panels = nil
    self.pattern = { "IDLE", "ATTACK", "WARP" }
    self.pattern_index = 1
    self.pattern_cooldown_list = { 180, 168, 60 } --How long each state lasts. Idle for 180 frames. Attack for 168 frames. Vanish for 60 before reappearing. Reset.
    self.pattern_cooldown_index = 1
    self.anim_once = true
    self.guard_chances = { 33, 67, 100 } --Chance to guard. Every time we detect an attack and fail to guard, increment the chance for next time.
    self.guard_index = 1
    self.attack_find_query = function(s)
        if s then
            if Battle.Character.from(s) ~= nil or Battle.Obstacle.from(s) ~= nil or Battle.Player.from(s) ~= nil then return false end
            return s:get_tile():y() == self:get_tile():y() and s:get_team() ~= self:get_team()
        end
        return false
    end
    self.virus_body = Battle.DefenseVirusBody.new()
    self:add_defense_rule(self.virus_body)
    local tink = Engine.load_audio(_folderpath .. "sounds/tink.ogg")
    local guard_texture = Engine.load_texture(_folderpath .. "guard_hit.png")
    self.pattern_cooldown = self.pattern_cooldown_list[self.pattern_cooldown_index]
    self.is_guarding = false
    self.defense = nil
    self.warp_tile = nil
    local occupied_query = function(ent)
        return Battle.Obstacle.from(ent) ~= nil or Battle.Character.from(ent) ~= nil
    end
    self.can_move_to_func = function(tile)
        if not tile then return false end
        if tile:is_edge() then return false end
        if #tile:find_entities(occupied_query) > 0 then return false end
        return true
    end
    self.can_block = true --Bool used to determine if we can block right now. Turns off when blocking & when in certain animations.
    self.should_block = false --Bool used to determine if an attack worth blocking is found.
    self.update_func = function(self, dt)
        if not field then field = self:get_field() end
        if not field then return end
        if not self.is_guarding and self.can_block then
            local attacks = field:find_entities(self.attack_find_query)
            if #attacks > 0 then
                --Collapsed for loop. Goes over the attack list and checks if any have a damage value over 0.
                --If so, tells Bladia he should try to block.
                for i = 1, #attacks, 1 do if attacks[i]:copy_hit_props().damage > 0 then self.should_block = true break end end
                if math.random(1, 100) <= self.guard_chances[self.guard_index] and self.should_block then
                    self.is_guarding = true
                    self.should_block = false
                    self.can_block = false --Disable blocking while already blocking.
                    anim:set_state("BLOCK")
                    anim:on_frame(2, function()
                        self.defense = Battle.DefenseRule.new(1, DefenseOrder.CollisionOnly)
                        self.defense.owner = self
                        self.defense.can_block_func = function(judge, attacker, defender)
                            --Don't block if has the breaking flag
                            if attacker:copy_hit_props().flags & Hit.Breaking == Hit.Breaking then return end
                            --If no breaking flag then block, play the sound and animation
                            judge:block_damage()
                            judge:block_impact()
                            Engine.play_audio(tink, AudioPriority.Highest)
                            local xset = math.random(10, 50)
                            local yset = math.random(35, 50)
                            xset = xset * -1
                            yset = yset * -1
                            if defender:get_facing() == Direction.Right then xset = xset * -1 end
                            local shine = Battle.Spell.new(defender:get_team())
                            shine:set_offset(xset, yset)
                            shine:set_texture(guard_texture)
                            local shine_anim = shine:get_animation()
                            shine_anim:load(_folderpath .. "guard_hit.animation")
                            shine_anim:set_state("DEFAULT")
                            shine_anim:refresh(shine:sprite())
                            shine:sprite():set_layer(-2)
                            shine_anim:on_complete(function()
                                shine:delete()
                            end)
                            defender:get_field():spawn(shine, defender:get_tile())
                        end
                        self:add_defense_rule(self.defense)
                    end)
                    anim:on_complete(function()
                        self:remove_defense_rule(self.defense)
                        self.is_guarding = false
                        self.can_block = true
                    end)
                else
                    self.can_block = true
                    self.is_guarding = false
                    self.guard_index = self.guard_index + 1
                    if self.guard_index > #self.guard_chances then self.guard_index = #self.guard_chances end
                end
            end
        end
        if self.pattern_cooldown > 0 then self.pattern_cooldown = self.pattern_cooldown - 1 return end
        if self.pattern[self.pattern_index] == "IDLE" and self.anim_once then
            self.anim_once = false
            anim:set_state("IDLE")
            anim:refresh(self:sprite())
            anim:set_playback(Playback.Loop)
            increment_pattern(self)
        elseif self.pattern[self.pattern_index] == "ATTACK" and self.anim_once then
            self.anim_once = false
            self.target = find_best_target(self)
            anim:set_state("ATTACK")
            anim:refresh(self:sprite())
            anim:on_frame(1, function()
                if self.defense ~= nil then self:remove_defense_rule(self.defense) end
                self.can_block = false --Disable blocking.
            end)
            anim:on_frame(3, function()
                spawn_attack_highlight(self)
            end)
            anim:on_frame(4, function()
                self:toggle_counter(true)
            end)
            anim:on_frame(6, function()
                self:toggle_counter(false)
                self:shake_camera(8.0, 0.6)
                spawn_attack(self)
            end)
            anim:on_complete(function()
                increment_pattern(self)
                self.can_block = false
            end)
        elseif self.pattern[self.pattern_index] == "WARP" and self.anim_once then
            self.anim_once = false
            self.can_block = false
            warp(self, "BIG_TELEPORT_FROM")
        end
    end
end


-- EZEncounters deferred native HP adapter.
-- The native fallback must not lock max HP in on_spawn_func: some client
-- spawners run on_spawn before their encounter mutate callback.
-- Battle start occurs after encounter mutations and before the first update.
local __ezhp_original_package_init = package_init
package_init = function(character, ...)
    __ezhp_original_package_init(character, ...)
    local __ezhp_original_battle_start = character.battle_start_func
    character.battle_start_func = function(self, ...)
        if self:get_max_health() == 0 then
            local native = tonumber(self.__ezhp_native_max_hp)
            if not native or native ~= native or native <= 0 or native == math.huge then native = 1 end
            native = math.max(1, math.floor(native))
            self:set_health(native)
            print('[EZHP][CLIENT][NATIVE_FALLBACK_BATTLE_START]', tostring(self:get_name()), native,
                'actual', self:get_max_health())
        end
        if __ezhp_original_battle_start then return __ezhp_original_battle_start(self, ...) end
    end
end

return package_init
