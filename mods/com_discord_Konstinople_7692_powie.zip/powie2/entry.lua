local shared_entry = include("../shared/shared_entry.lua")

function package_init(character)
  shared_entry(character)
  character:set_name("Powie2")
  character._shock_shape = "column"

  if character:get_rank() == Rank.EX then
    character:set_palette(Engine.load_texture(_modpath.."powie2EX.palette.png"))
    character.__ezhp_native_max_hp = (180)
    character._damage = 110
  else
    character:set_palette(Engine.load_texture(_modpath.."powie2.palette.png"))
    character.__ezhp_native_max_hp = (140)
    character._damage = 70
  end
end

-- EZEncounters deferred native HP adapter.
-- The native fallback must not lock max HP in on_spawn_func: some client
-- spawners run on_spawn before their encounter mutate callback.
-- Battle start occurs after encounter mutations and before the first update.
local __ezhp_original_package_init = package_init
package_init = function(character, ...)
    __ezhp_original_package_init(character, ...)
    local __ezhp_original_battle_start = character.battle_start_func
    character.battle_start_func = function(self, ...)
        if self:get_max_health() == 0 then
            local native = tonumber(self.__ezhp_native_max_hp)
            if not native or native ~= native or native <= 0 or native == math.huge then native = 1 end
            native = math.max(1, math.floor(native))
            self:set_health(native)
            print('[EZHP][CLIENT][NATIVE_FALLBACK_BATTLE_START]', tostring(self:get_name()), native,
                'actual', self:get_max_health())
        end
        if __ezhp_original_battle_start then return __ezhp_original_battle_start(self, ...) end
    end
end
